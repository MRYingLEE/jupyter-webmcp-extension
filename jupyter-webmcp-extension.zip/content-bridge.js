"use strict";
(() => {
  // runtime/src/channel.ts
  var RUNTIME_BASE_ATTRIBUTE = "data-jwe-runtime-base";
  var SETTINGS_REQUEST = "jupyter-webmcp-extension:settings-request";
  var SETTINGS_RESPONSE = "jupyter-webmcp-extension:settings-response";
  var SETTINGS_CHANGED = "jupyter-webmcp-extension:settings-changed";
  var STATUS_EVENT = "jupyter-webmcp-extension:status";

  // src/shared/config.ts
  function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }

  // src/shared/frame-policy.ts
  function allowsTools(doc) {
    try {
      return doc.featurePolicy.allowsFeature("tools");
    } catch {
      return false;
    }
  }
  function mayGrantRuntime(input) {
    if (input.isTop) {
      return true;
    }
    const enabled = (origin) => input.enabledOrigins.includes(origin);
    return input.allowsTools && enabled(input.origin) && input.ancestorOrigins.every(enabled);
  }

  // src/shared/storage.ts
  var ENABLED_ORIGINS_KEY = "enabledOrigins";
  var SETTINGS_STORAGE_KEY = "settings";

  // src/content/bridge-isolated.ts
  var runtimeBase = chrome.runtime.getURL("runtime/");
  function setRuntimeBase() {
    const root = document.documentElement;
    if (!root) {
      return false;
    }
    root.setAttribute(RUNTIME_BASE_ATTRIBUTE, runtimeBase);
    return true;
  }
  function grantRuntime() {
    if (setRuntimeBase()) {
      return;
    }
    const observer = new MutationObserver(() => {
      if (setRuntimeBase()) {
        observer.disconnect();
      }
    });
    observer.observe(document, { childList: true, subtree: true });
  }
  async function frameMayBeGranted() {
    const stored = await chrome.storage.local.get(ENABLED_ORIGINS_KEY);
    const value = stored[ENABLED_ORIGINS_KEY];
    const enabledOrigins = Array.isArray(value) ? value.filter((item) => typeof item === "string") : [];
    return mayGrantRuntime({
      isTop: false,
      allowsTools: allowsTools(document),
      origin: location.origin,
      ancestorOrigins: Array.from(location.ancestorOrigins),
      enabledOrigins
    });
  }
  if (window.top === window) {
    grantRuntime();
  } else {
    void frameMayBeGranted().then((allowed) => {
      if (allowed) {
        grantRuntime();
      }
    });
  }
  async function readSettings() {
    const stored = await chrome.storage.local.get(SETTINGS_STORAGE_KEY);
    return stored[SETTINGS_STORAGE_KEY] ?? {};
  }
  document.addEventListener(SETTINGS_REQUEST, (event) => {
    const request = parseDetail(event.detail);
    const nonce = request?.nonce;
    if (typeof nonce !== "string") {
      return;
    }
    void readSettings().then(
      (settings) => {
        document.dispatchEvent(
          new CustomEvent(SETTINGS_RESPONSE, {
            detail: JSON.stringify({ nonce, settings })
          })
        );
      },
      (error) => {
        console.error("Unable to read WebMCP settings:", error);
      }
    );
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    const change = changes[SETTINGS_STORAGE_KEY];
    if (area !== "local" || !change) {
      return;
    }
    document.dispatchEvent(
      new CustomEvent(SETTINGS_CHANGED, {
        detail: JSON.stringify({ settings: change.newValue ?? {} })
      })
    );
  });
  document.addEventListener(STATUS_EVENT, (event) => {
    const status = parseStatus(event.detail);
    if (!status) {
      return;
    }
    const message = { type: "status", status };
    chrome.runtime.sendMessage(message).catch(() => {
    });
  });
  function parseDetail(detail) {
    if (typeof detail !== "string") {
      return null;
    }
    try {
      const parsed = JSON.parse(detail);
      return isRecord(parsed) ? parsed : null;
    } catch {
      return null;
    }
  }
  function parseStatus(detail) {
    const parsed = parseDetail(detail);
    if (!parsed) {
      return null;
    }
    const { component, state } = parsed;
    if (component !== "ai" && component !== "webmcp" && component !== "runtime") {
      return null;
    }
    if (state !== "active" && state !== "failed") {
      return null;
    }
    const status = { component, state };
    if (typeof parsed.detail === "string") {
      status.detail = parsed.detail.slice(0, 500);
    }
    return status;
  }
})();
//# sourceMappingURL=content-bridge.js.map
