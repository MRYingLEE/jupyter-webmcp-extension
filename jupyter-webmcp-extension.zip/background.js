// src/shared/storage.ts
var ENABLED_ORIGINS_KEY = "enabledOrigins";

// src/shared/origin.ts
function webOrigin(url) {
  if (!url) {
    return null;
  }
  try {
    const parsed = new URL(url);
    if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
      return null;
    }
    return parsed.origin;
  } catch {
    return null;
  }
}
function isWebOrigin(value) {
  return typeof value === "string" && !value.includes("*") && webOrigin(value) === value;
}
function originPattern(origin) {
  return `${origin}/*`;
}

// src/background/service-worker.ts
var TAB_STATUS_KEY = "tabStatus";
var FRAME_STATUS_KEY = "frameStatus";
function scriptIds(origin) {
  return [`jwe-main ${origin}`, `jwe-bridge ${origin}`];
}
async function enabledOrigins() {
  const stored = await chrome.storage.local.get(ENABLED_ORIGINS_KEY);
  const value = stored[ENABLED_ORIGINS_KEY];
  return Array.isArray(value) ? value.filter((item) => typeof item === "string") : [];
}
async function saveEnabledOrigins(origins) {
  await chrome.storage.local.set({ [ENABLED_ORIGINS_KEY]: origins });
}
async function unregisterOrigin(origin) {
  const ids = scriptIds(origin);
  const registered = await chrome.scripting.getRegisteredContentScripts({ ids });
  if (registered.length > 0) {
    await chrome.scripting.unregisterContentScripts({
      ids: registered.map((script) => script.id)
    });
  }
}
async function registerOrigin(origin) {
  await unregisterOrigin(origin);
  const [mainId, bridgeId] = scriptIds(origin);
  const matches = [originPattern(origin)];
  await chrome.scripting.registerContentScripts([
    {
      id: mainId,
      matches,
      js: ["content-main.js"],
      runAt: "document_start",
      world: "MAIN",
      allFrames: true
    },
    {
      id: bridgeId,
      matches,
      js: ["content-bridge.js"],
      runAt: "document_start",
      world: "ISOLATED",
      allFrames: true
    }
  ]);
}
async function hasPermission(origin) {
  return chrome.permissions.contains({ origins: [originPattern(origin)] });
}
async function reconcile() {
  const kept = [];
  for (const origin of await enabledOrigins()) {
    if (await hasPermission(origin)) {
      await registerOrigin(origin);
      kept.push(origin);
    } else {
      await unregisterOrigin(origin);
    }
  }
  await saveEnabledOrigins(kept);
}
async function enable(origin) {
  if (!await hasPermission(origin)) {
    return { ok: false, error: `Permission for ${origin} is not granted.` };
  }
  await registerOrigin(origin);
  const origins = await enabledOrigins();
  if (!origins.includes(origin)) {
    origins.push(origin);
    await saveEnabledOrigins(origins);
  }
  return { ok: true };
}
async function disable(origin) {
  await unregisterOrigin(origin);
  await saveEnabledOrigins(
    (await enabledOrigins()).filter((item) => item !== origin)
  );
}
async function readTabStatuses() {
  const stored = await chrome.storage.session.get(TAB_STATUS_KEY);
  return stored[TAB_STATUS_KEY] ?? {};
}
async function writeTabStatuses(statuses) {
  await chrome.storage.session.set({ [TAB_STATUS_KEY]: statuses });
}
async function readFrameStatuses() {
  const stored = await chrome.storage.session.get(FRAME_STATUS_KEY);
  return stored[FRAME_STATUS_KEY] ?? {};
}
async function writeFrameStatuses(statuses) {
  await chrome.storage.session.set({ [FRAME_STATUS_KEY]: statuses });
}
function withComponent(current, origin, documentId, status) {
  const sameDocument = current?.origin === origin && current.documentId === documentId;
  const components = { ...sameDocument ? current.components : {} };
  components[status.component] = {
    state: status.state,
    ...status.detail === void 0 ? {} : { detail: status.detail }
  };
  return { origin, documentId, components, updated: Date.now() };
}
async function recordStatus(tabId, frameId, origin, documentId, status) {
  if (frameId === 0) {
    const statuses = await readTabStatuses();
    statuses[tabId] = withComponent(statuses[tabId], origin, documentId, status);
    await writeTabStatuses(statuses);
  } else {
    const frames = await readFrameStatuses();
    const tabFrames = frames[tabId] ?? {};
    tabFrames[frameId] = withComponent(tabFrames[frameId], origin, documentId, status);
    frames[tabId] = tabFrames;
    await writeFrameStatuses(frames);
  }
  await updateBadge(tabId);
}
async function clearTab(tabId) {
  const statuses = await readTabStatuses();
  if (tabId in statuses) {
    delete statuses[tabId];
    await writeTabStatuses(statuses);
  }
  const frames = await readFrameStatuses();
  if (tabId in frames) {
    delete frames[tabId];
    await writeFrameStatuses(frames);
  }
  await chrome.action.setBadgeText({ tabId, text: "" });
}
async function updateBadge(tabId) {
  const top = (await readTabStatuses())[tabId];
  const frames = Object.values((await readFrameStatuses())[tabId] ?? {});
  const states = [top, ...frames].flatMap(
    (source) => Object.values(source?.components ?? {}).map((info) => info?.state)
  );
  if (states.length === 0) {
    await chrome.action.setBadgeText({ tabId, text: "" });
    return;
  }
  const failed = states.includes("failed");
  await chrome.action.setBadgeBackgroundColor({
    tabId,
    color: failed ? "#c62828" : "#2e7d32"
  });
  await chrome.action.setBadgeText({ tabId, text: failed ? "!" : "ON" });
}
function isExtensionPage(sender) {
  return sender.id === chrome.runtime.id && sender.url?.startsWith(chrome.runtime.getURL("")) === true;
}
async function handleMessage(message, sender) {
  switch (message.type) {
    case "status": {
      const tabId = sender.tab?.id;
      const origin = webOrigin(sender.url);
      if (sender.id === chrome.runtime.id && tabId !== void 0 && origin) {
        await recordStatus(
          tabId,
          sender.frameId ?? 0,
          origin,
          sender.documentId,
          message.status
        );
      }
      return { ok: true };
    }
    case "enable":
      if (!isExtensionPage(sender) || !isWebOrigin(message.origin)) {
        return { ok: false, error: "Not allowed." };
      }
      return enable(message.origin);
    case "disable":
      if (!isExtensionPage(sender) || !isWebOrigin(message.origin)) {
        return { ok: false, error: "Not allowed." };
      }
      await disable(message.origin);
      return { ok: true };
    case "state": {
      if (!isExtensionPage(sender) || !isWebOrigin(message.origin)) {
        return { ok: false, error: "Not allowed." };
      }
      const enabled = (await enabledOrigins()).includes(message.origin);
      const statuses = await readTabStatuses();
      const frames = (await readFrameStatuses())[message.tabId] ?? {};
      const response = {
        enabled,
        embedded: Object.entries(frames).map(([frameId, status2]) => ({
          ...status2,
          frameId: Number(frameId)
        }))
      };
      const status = statuses[message.tabId];
      if (status?.origin === message.origin) {
        response.status = status;
      }
      return response;
    }
  }
}
chrome.runtime.onInstalled.addListener(() => {
  void reconcile();
});
chrome.runtime.onStartup.addListener(() => {
  void reconcile();
});
chrome.runtime.onMessage.addListener(
  (message, sender, sendResponse) => {
    handleMessage(message, sender).then(
      (response) => sendResponse(response),
      (error) => sendResponse({ ok: false, error: String(error) })
    );
    return true;
  }
);
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.url === void 0) {
    return;
  }
  void readTabStatuses().then((statuses) => {
    const status = statuses[tabId];
    if (status && status.origin !== webOrigin(changeInfo.url)) {
      return clearTab(tabId);
    }
    return void 0;
  });
});
chrome.tabs.onRemoved.addListener((tabId) => {
  void clearTab(tabId);
});
//# sourceMappingURL=background.js.map
