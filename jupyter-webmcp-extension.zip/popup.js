"use strict";
(() => {
  // src/shared/origin.ts
  function webOrigin(url) {
    if (!url) {
      return null;
    }
    try {
      const parsed = new URL(url);
      if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
        return null;
      }
      return parsed.origin;
    } catch {
      return null;
    }
  }
  function originPattern(origin2) {
    return `${origin2}/*`;
  }

  // scripts/catalog-pins.json
  var catalog_pins_default = {
    entries: [
      {
        id: "widget-manager",
        label: "ipywidgets widget manager",
        role: "dependency",
        federation: "@jupyter-widgets/jupyterlab-manager",
        plugin: "@jupyter-widgets/jupyterlab-manager:plugin",
        provides: "IJupyterWidgetRegistry",
        requires: [],
        source: {
          kind: "pypi",
          package: "jupyterlab_widgets",
          version: "3.0.17",
          sha256: "40ac1e9955acf116c4d995d9bfa082d86ad9ec6d91c4f134827cf5e0a5eb75e0"
        }
      },
      {
        id: "anywidget-0.11",
        label: "anywidget 0.11",
        role: "extension",
        federation: "anywidget_0_11",
        plugin: "anywidget_0_11:plugin",
        line: "0.11",
        selectedByDefault: true,
        kernelRequirement: "anywidget==0.11.*",
        conflicts: ["anywidget"],
        requires: ["widget-manager"],
        source: {
          kind: "git",
          repository: "https://github.com/manzt/anywidget",
          commit: "35160ac08e75918faee008a3b8996ab2a0a16a46"
        }
      },
      {
        id: "anywidget-0.10",
        label: "anywidget 0.10",
        role: "extension",
        federation: "anywidget_0_10",
        plugin: "anywidget_0_10:plugin",
        line: "0.10",
        kernelRequirement: "anywidget==0.10.*",
        conflicts: ["anywidget"],
        requires: ["widget-manager"],
        source: {
          kind: "git",
          repository: "https://github.com/manzt/anywidget",
          commit: "5428c60730f79e52d8ae2f235942b023c0cbc665"
        }
      }
    ]
  };

  // src/shared/catalog.ts
  var CATALOG = catalog_pins_default.entries;
  var CATALOG_EXTENSIONS = CATALOG.filter(
    (entry) => entry.role === "extension"
  );
  var DEFAULT_SELECTION = CATALOG_EXTENSIONS.filter(
    (entry) => entry.selectedByDefault
  ).map((entry) => entry.id);
  var CATALOG_IDS = new Set(
    CATALOG.map((entry) => entry.id)
  );
  function catalogEntry(id) {
    return CATALOG.find((entry) => entry.id === id);
  }

  // src/shared/config.ts
  var AI_COMMANDS_PACKAGE = "jupyterlab-ai-commands";
  var WEBMCP_PACKAGE = "jupyter-webmcp";
  function parsePageConfig(text) {
    let data;
    try {
      data = JSON.parse(text);
    } catch {
      return null;
    }
    if (!isRecord(data)) {
      return null;
    }
    const { federated_extensions, fullLabextensionsUrl, appName, appVersion } = data;
    if (!Array.isArray(federated_extensions)) {
      return null;
    }
    if (typeof fullLabextensionsUrl !== "string" || !fullLabextensionsUrl) {
      return null;
    }
    if (typeof appName !== "string" && typeof appVersion !== "string") {
      return null;
    }
    return data;
  }
  function isExtensionDisabled(config, id) {
    let disabled = config.disabledExtensions;
    if (typeof disabled === "string") {
      try {
        disabled = JSON.parse(disabled);
      } catch {
        return false;
      }
    }
    const name = id.split(":", 1)[0];
    if (Array.isArray(disabled)) {
      return disabled.includes(id) || disabled.includes(name);
    }
    if (isRecord(disabled)) {
      return disabled[id] === true || disabled[name] === true;
    }
    return false;
  }
  function nativeExtensionNames(config) {
    return new Set(
      config.federated_extensions.map((entry) => entry?.name).filter((name) => typeof name === "string")
    );
  }
  function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }

  // src/shared/decision.ts
  function decideInjection(config, selected = /* @__PURE__ */ new Set()) {
    const native = nativeExtensionNames(config);
    return {
      ai: componentState(config, native, AI_COMMANDS_PACKAGE),
      webmcp: componentState(config, native, WEBMCP_PACKAGE),
      catalog: decideCatalog(config, selected)
    };
  }
  function decideCatalog(config, selected) {
    const native = nativeExtensionNames(config);
    const states = {};
    const candidates = [];
    for (const entry of CATALOG) {
      if (entry.role !== "extension") {
        continue;
      }
      if (!selected.has(entry.id)) {
        states[entry.id] = "unselected";
      } else if (isExtensionDisabled(config, entry.plugin)) {
        states[entry.id] = "disabled";
      } else if (native.has(entry.federation)) {
        states[entry.id] = "native";
      } else if (entry.conflicts?.some((name) => native.has(name))) {
        states[entry.id] = "conflict";
      } else {
        candidates.push(entry);
        states[entry.id] = "injected";
      }
    }
    const needed = new Set(candidates.flatMap((entry) => entry.requires));
    for (const entry of CATALOG) {
      if (entry.role !== "dependency") {
        continue;
      }
      if (isExtensionDisabled(config, entry.plugin)) {
        states[entry.id] = "disabled";
      } else if (native.has(entry.federation)) {
        states[entry.id] = "native";
      } else {
        states[entry.id] = needed.has(entry.id) ? "injected" : "unselected";
      }
    }
    for (const entry of candidates) {
      const blocked = entry.requires.some((id) => states[id] === "disabled");
      if (blocked) {
        states[entry.id] = "unsupported";
      }
    }
    return states;
  }
  function componentState(config, native, name) {
    if (isExtensionDisabled(config, `${name}:plugin`)) {
      return "disabled";
    }
    return native.has(name) ? "native" : "injected";
  }

  // src/shared/selection.ts
  var SELECTION_KEY = "jupyter-webmcp-extension:catalog-selection";
  function serializeSelection(baseUrl, ids) {
    return JSON.stringify({ baseUrl, ids: [...new Set(ids)] });
  }
  function selectionFor(raw, baseUrl) {
    const fallback = new Set(DEFAULT_SELECTION);
    if (raw === null || baseUrl === void 0) {
      return fallback;
    }
    let data;
    try {
      data = JSON.parse(raw);
    } catch {
      return fallback;
    }
    if (!isRecord(data) || data.baseUrl !== baseUrl || !Array.isArray(data.ids)) {
      return fallback;
    }
    return new Set(
      data.ids.filter((id) => typeof id === "string")
    );
  }

  // src/popup/popup.ts
  var originLabel = document.getElementById("origin");
  var message = document.getElementById("message");
  var toggle = document.getElementById("toggle");
  var reload = document.getElementById("reload");
  var statusList = document.getElementById("status");
  var catalogSection = document.getElementById("catalog");
  var catalogList = document.getElementById("catalog-list");
  var catalogNote = document.getElementById("catalog-note");
  var applyCatalog = document.getElementById("apply-catalog");
  var COMPONENT_LABELS = {
    ai: "AI commands",
    webmcp: "WebMCP",
    runtime: "Runtime"
  };
  var CATALOG_STATE_LABELS = {
    injected: "will be injected",
    native: "already loaded by this page",
    disabled: "disabled in this Jupyter instance",
    conflict: "a native extension with the same API is already loaded",
    unsupported: "a required dependency is disabled",
    unselected: "not selected"
  };
  var tabId;
  var origin = null;
  var catalogBaseUrl = null;
  function componentLabel(component) {
    return COMPONENT_LABELS[component] ?? catalogEntry(component)?.label ?? component;
  }
  function showMessage(text, error = false) {
    message.textContent = text;
    message.className = error ? "message error" : "message";
    message.hidden = false;
  }
  function appendComponents(prefix, status) {
    let shown = 0;
    for (const [component, info] of Object.entries(status?.components ?? {})) {
      if (!info) {
        continue;
      }
      const item = document.createElement("li");
      item.className = `state-${info.state}`;
      const label = componentLabel(component);
      const heading = document.createElement("span");
      heading.textContent = `${prefix}${label}: ${info.state}`;
      item.append(heading);
      if (info.detail) {
        const detail = document.createElement("div");
        detail.className = "status-detail";
        detail.textContent = info.detail;
        item.append(detail);
      }
      statusList.append(item);
      shown += 1;
    }
    return shown;
  }
  function renderStatus(status, embedded) {
    statusList.replaceChildren();
    const shown = appendComponents("", status);
    for (const frame of embedded) {
      appendComponents(`Embedded ${frame.origin}: `, frame);
    }
    if (shown === 0 && embedded.length === 0) {
      const item = document.createElement("li");
      item.className = "muted";
      item.textContent = "No runtime status for this page yet.";
      statusList.append(item);
    }
  }
  function renderEnabled(enabled) {
    toggle.hidden = false;
    toggle.textContent = enabled ? "Disable on this site" : "Enable on this site";
    toggle.dataset.enabled = String(enabled);
  }
  async function refresh() {
    if (tabId === void 0 || origin === null) {
      return;
    }
    const response = await chrome.runtime.sendMessage({
      type: "state",
      tabId,
      origin
    });
    renderEnabled(response.enabled);
    renderStatus(response.status, response.embedded);
    await renderCatalog(tabId, response.enabled);
  }
  async function readPage(id) {
    try {
      const [injection] = await chrome.scripting.executeScript({
        target: { tabId: id, frameIds: [0] },
        world: "MAIN",
        args: [SELECTION_KEY],
        // `text` is read instead of `textContent`, which the page hook rewrites.
        func: (key) => {
          const element = document.getElementById("jupyter-config-data");
          let selection = null;
          try {
            selection = sessionStorage.getItem(key);
          } catch {
            selection = null;
          }
          return { configText: element ? element.text : null, selection };
        }
      });
      return injection?.result ?? null;
    } catch {
      return null;
    }
  }
  async function writeSelection(id, value) {
    try {
      const [injection] = await chrome.scripting.executeScript({
        target: { tabId: id, frameIds: [0] },
        world: "MAIN",
        args: [SELECTION_KEY, value],
        func: (key, data) => {
          try {
            sessionStorage.setItem(key, data);
            return true;
          } catch {
            return false;
          }
        }
      });
      return injection?.result === true;
    } catch {
      return false;
    }
  }
  function catalogDetails(id, state) {
    const entry = catalogEntry(id);
    if (!entry) {
      return [];
    }
    const lines = [
      entry.role === "dependency" ? `Dependency, ${CATALOG_STATE_LABELS[state]}` : CATALOG_STATE_LABELS[state]
    ];
    if (entry.role === "dependency") {
      const required = CATALOG.filter((other) => other.requires.includes(entry.id)).map(
        (other) => other.label
      );
      lines.push(`Required by ${required.join(", ")}`);
    }
    if (entry.kernelRequirement) {
      lines.push(`Kernel: pip install "${entry.kernelRequirement}"`);
    }
    return lines;
  }
  async function renderCatalog(id, enabled) {
    catalogSection.hidden = true;
    if (!enabled) {
      return;
    }
    const snapshot = await readPage(id);
    const config = snapshot?.configText ? parsePageConfig(snapshot.configText) : null;
    if (!snapshot || !config) {
      return;
    }
    catalogSection.hidden = false;
    catalogList.replaceChildren();
    catalogBaseUrl = config.baseUrl ?? null;
    if (!config.baseUrl) {
      catalogNote.textContent = "This Jupyter page does not report its base URL, so extensions cannot be selected for it.";
      catalogNote.hidden = false;
      applyCatalog.hidden = true;
      return;
    }
    catalogNote.hidden = true;
    applyCatalog.hidden = false;
    const selected = selectionFor(snapshot.selection, config.baseUrl);
    const decision = decideInjection(config, selected);
    for (const entry of CATALOG) {
      const item = document.createElement("li");
      const state = decision.catalog[entry.id];
      if (entry.role === "extension") {
        const label = document.createElement("label");
        const box = document.createElement("input");
        box.type = "checkbox";
        box.value = entry.id;
        box.checked = selected.has(entry.id);
        label.append(box, ` ${entry.label}`);
        item.append(label);
      } else {
        item.append(entry.label);
      }
      const detail = document.createElement("div");
      detail.className = "status-detail";
      detail.textContent = catalogDetails(entry.id, state).join(". ");
      item.append(detail);
      catalogList.append(item);
    }
  }
  async function init() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    tabId = tab?.id;
    origin = webOrigin(tab?.url);
    if (origin === null) {
      originLabel.textContent = "This page cannot be extended.";
      return;
    }
    originLabel.textContent = origin;
    await refresh();
  }
  toggle.addEventListener("click", () => {
    if (origin === null || tabId === void 0) {
      return;
    }
    const currentOrigin = origin;
    const enabledNow = toggle.dataset.enabled === "true";
    if (enabledNow) {
      void (async () => {
        await chrome.runtime.sendMessage({ type: "disable", origin: currentOrigin });
        showMessage("Disabled. Reload the page to stop the runtime.");
        await refresh();
      })();
      return;
    }
    chrome.permissions.request(
      { origins: [originPattern(currentOrigin)] },
      (granted) => {
        if (!granted) {
          showMessage(`Permission for ${currentOrigin} was not granted.`, true);
          return;
        }
        void (async () => {
          const result = await chrome.runtime.sendMessage({
            type: "enable",
            origin: currentOrigin
          });
          if (!result.ok) {
            showMessage(result.error ?? "Could not enable.", true);
            return;
          }
          showMessage("Enabled. Reload the page to load the runtime.");
          reload.hidden = false;
          await refresh();
        })();
      }
    );
  });
  reload.addEventListener("click", () => {
    if (tabId !== void 0) {
      void chrome.tabs.reload(tabId);
    }
    window.close();
  });
  applyCatalog.addEventListener("click", () => {
    const id = tabId;
    const baseUrl = catalogBaseUrl;
    if (id === void 0 || baseUrl === null) {
      return;
    }
    const ids = Array.from(
      catalogList.querySelectorAll('input[type="checkbox"]:checked'),
      (box) => box.value
    );
    void (async () => {
      const saved = await writeSelection(id, serializeSelection(baseUrl, ids));
      if (!saved) {
        showMessage("Could not save the selection for this page.", true);
        return;
      }
      showMessage(
        "Saved. Reload the page to load the selected extensions. Unsaved notebook changes may be lost on reload."
      );
      reload.hidden = false;
      await refresh();
    })();
  });
  void init();
})();
//# sourceMappingURL=popup.js.map
