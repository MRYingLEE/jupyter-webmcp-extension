"use strict";
(() => {
  // src/shared/origin.ts
  function webOrigin(url) {
    if (!url) {
      return null;
    }
    try {
      const parsed = new URL(url);
      if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
        return null;
      }
      return parsed.origin;
    } catch {
      return null;
    }
  }
  function originPattern(origin2) {
    return `${origin2}/*`;
  }

  // src/popup/popup.ts
  var originLabel = document.getElementById("origin");
  var message = document.getElementById("message");
  var toggle = document.getElementById("toggle");
  var reload = document.getElementById("reload");
  var statusList = document.getElementById("status");
  var COMPONENT_LABELS = {
    ai: "AI commands",
    webmcp: "WebMCP",
    runtime: "Runtime"
  };
  var tabId;
  var origin = null;
  function showMessage(text, error = false) {
    message.textContent = text;
    message.className = error ? "message error" : "message";
    message.hidden = false;
  }
  function appendComponents(prefix, status) {
    let shown = 0;
    for (const [component, info] of Object.entries(status?.components ?? {})) {
      if (!info) {
        continue;
      }
      const item = document.createElement("li");
      item.className = `state-${info.state}`;
      const label = COMPONENT_LABELS[component];
      const heading = document.createElement("span");
      heading.textContent = `${prefix}${label}: ${info.state}`;
      item.append(heading);
      if (info.detail) {
        const detail = document.createElement("div");
        detail.className = "status-detail";
        detail.textContent = info.detail;
        item.append(detail);
      }
      statusList.append(item);
      shown += 1;
    }
    return shown;
  }
  function renderStatus(status, embedded) {
    statusList.replaceChildren();
    const shown = appendComponents("", status);
    for (const frame of embedded) {
      appendComponents(`Embedded ${frame.origin}: `, frame);
    }
    if (shown === 0 && embedded.length === 0) {
      const item = document.createElement("li");
      item.className = "muted";
      item.textContent = "No runtime status for this page yet.";
      statusList.append(item);
    }
  }
  function renderEnabled(enabled) {
    toggle.hidden = false;
    toggle.textContent = enabled ? "Disable on this site" : "Enable on this site";
    toggle.dataset.enabled = String(enabled);
  }
  async function refresh() {
    if (tabId === void 0 || origin === null) {
      return;
    }
    const response = await chrome.runtime.sendMessage({
      type: "state",
      tabId,
      origin
    });
    renderEnabled(response.enabled);
    renderStatus(response.status, response.embedded);
  }
  async function init() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    tabId = tab?.id;
    origin = webOrigin(tab?.url);
    if (origin === null) {
      originLabel.textContent = "This page cannot be extended.";
      return;
    }
    originLabel.textContent = origin;
    await refresh();
  }
  toggle.addEventListener("click", () => {
    if (origin === null || tabId === void 0) {
      return;
    }
    const currentOrigin = origin;
    const enabledNow = toggle.dataset.enabled === "true";
    if (enabledNow) {
      void (async () => {
        await chrome.runtime.sendMessage({ type: "disable", origin: currentOrigin });
        showMessage("Disabled. Reload the page to stop the runtime.");
        await refresh();
      })();
      return;
    }
    chrome.permissions.request(
      { origins: [originPattern(currentOrigin)] },
      (granted) => {
        if (!granted) {
          showMessage(`Permission for ${currentOrigin} was not granted.`, true);
          return;
        }
        void (async () => {
          const result = await chrome.runtime.sendMessage({
            type: "enable",
            origin: currentOrigin
          });
          if (!result.ok) {
            showMessage(result.error ?? "Could not enable.", true);
            return;
          }
          showMessage("Enabled. Reload the page to load the runtime.");
          reload.hidden = false;
          await refresh();
        })();
      }
    );
  });
  reload.addEventListener("click", () => {
    if (tabId !== void 0) {
      void chrome.tabs.reload(tabId);
    }
    window.close();
  });
  void init();
})();
//# sourceMappingURL=popup.js.map
