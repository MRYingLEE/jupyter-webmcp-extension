"use strict";
(() => {
  // src/shared/storage.ts
  var ENABLED_ORIGINS_KEY = "enabledOrigins";
  var SETTINGS_STORAGE_KEY = "settings";

  // runtime/src/webmcp-settings.ts
  var WEBMCP_DEFAULTS = {
    tools: [],
    disabledTools: [],
    blockedCommands: ["apputils:run-all-enabled", "apputils:run-first-enabled"],
    executionTimeout: 20,
    maxResultLength: 4e4
  };
  function normalizeSettings(raw) {
    const values = {};
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      return values;
    }
    const source = raw;
    for (const key of ["disabledTools", "blockedCommands"]) {
      const list = source[key];
      if (Array.isArray(list)) {
        values[key] = list.filter(
          (item) => typeof item === "string"
        );
      }
    }
    if (Array.isArray(source.tools)) {
      values.tools = source.tools.filter(
        (item) => !!item && typeof item === "object" && !Array.isArray(item)
      );
    }
    if (typeof source.executionTimeout === "number" && source.executionTimeout >= 0 && source.executionTimeout <= 3600) {
      values.executionTimeout = source.executionTimeout;
    }
    if (Number.isInteger(source.maxResultLength) && source.maxResultLength >= 1e3) {
      values.maxResultLength = source.maxResultLength;
    }
    return values;
  }

  // src/options/options.ts
  var settingsText = document.getElementById("settings");
  var save = document.getElementById("save");
  var reset = document.getElementById("reset");
  var message = document.getElementById("message");
  var sites = document.getElementById("sites");
  var noSites = document.getElementById("no-sites");
  function showMessage(lines, error = false) {
    message.replaceChildren(
      ...lines.map((line) => {
        const row = document.createElement("div");
        row.textContent = line;
        return row;
      })
    );
    message.className = error ? "message error" : "message";
    message.hidden = lines.length === 0;
  }
  async function loadSettings() {
    const stored = await chrome.storage.local.get(SETTINGS_STORAGE_KEY);
    const current = normalizeSettings(stored[SETTINGS_STORAGE_KEY]);
    const shown = { ...WEBMCP_DEFAULTS, ...current };
    settingsText.value = JSON.stringify(shown, null, 2);
  }
  function droppedKeys(parsed, normalized) {
    const notes = [];
    for (const [key, value] of Object.entries(parsed)) {
      if (!(key in WEBMCP_DEFAULTS)) {
        notes.push(`Unknown setting "${key}" was ignored.`);
      } else if (JSON.stringify(normalized[key]) !== JSON.stringify(value)) {
        notes.push(`Invalid value for "${key}" was replaced by the valid part or default.`);
      }
    }
    return notes;
  }
  save.addEventListener("click", () => {
    void (async () => {
      let parsed;
      try {
        parsed = JSON.parse(settingsText.value);
      } catch (error) {
        showMessage([`Not valid JSON: ${String(error)}`], true);
        return;
      }
      if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
        showMessage(["Settings must be a JSON object."], true);
        return;
      }
      const record = parsed;
      const normalized = normalizeSettings(record);
      await chrome.storage.local.set({ [SETTINGS_STORAGE_KEY]: normalized });
      showMessage(["Saved.", ...droppedKeys(record, normalized)]);
      await loadSettings();
    })();
  });
  reset.addEventListener("click", () => {
    void (async () => {
      await chrome.storage.local.remove(SETTINGS_STORAGE_KEY);
      showMessage(["Reset to defaults."]);
      await loadSettings();
    })();
  });
  async function renderSites() {
    const stored = await chrome.storage.local.get(ENABLED_ORIGINS_KEY);
    const origins = Array.isArray(stored[ENABLED_ORIGINS_KEY]) ? stored[ENABLED_ORIGINS_KEY] : [];
    sites.replaceChildren();
    noSites.hidden = origins.length > 0;
    for (const origin of origins) {
      const item = document.createElement("li");
      const label = document.createElement("span");
      label.textContent = `${origin} `;
      const button = document.createElement("button");
      button.type = "button";
      button.textContent = "Disable";
      button.addEventListener("click", () => {
        void (async () => {
          await chrome.runtime.sendMessage({ type: "disable", origin });
          await renderSites();
        })();
      });
      item.append(label, button);
      sites.append(item);
    }
  }
  void loadSettings();
  void renderSites();
})();
//# sourceMappingURL=options.js.map
