"use strict";
(self["rspackChunk_anywidget_monorepo"] = self["rspackChunk_anywidget_monorepo"] || []).push([[316], {
455(__unused_rspack___webpack_module__, __webpack_exports__, __webpack_require__) {
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ src_plugin)
});

// EXTERNAL MODULE: consume shared module (default) @jupyter-widgets/base@^6.0.12 (strict)
var base_6_0_strict_ = __webpack_require__(558);
;// CONCATENATED MODULE: ./packages/anywidget/src/model-proxy.ts
/**
 * This is a trick so that we can cleanup event listeners added
 * by the user-defined function.
 */ var INITIALIZE_MARKER = Symbol("anywidget.initialize");
/**
 * Prunes the view down to the minimum context necessary.
 *
 * Calls to `model.get` and `model.set` automatically add the
 * `context`, so we can gracefully unsubscribe from events
 * added by user-defined hooks.
 */ function modelProxy(model, context) {
    // oxlint-disable-next-line typescript-eslint/no-unsafe-type-assertion -- DOMWidgetModel.get/set/on/off have wider signatures than AnyModel, so bound versions don't narrow cleanly; the shape is structurally compatible
    return {
        get: model.get.bind(model),
        set: model.set.bind(model),
        save_changes: model.save_changes.bind(model),
        send: model.send.bind(model),
        on: function on(name, callback) {
            model.on(name, callback, context);
        },
        off: function off(name, callback) {
            model.off(name, callback, context);
        },
        // The widget_manager type is wider than what we want to expose to
        // developers. In a future version, we will expose a more limited API but
        // that can wait for a minor version bump.
        widget_manager: model.widget_manager
    };
}

;// CONCATENATED MODULE: ./packages/anywidget/src/util.ts
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) resolve(value);
    else Promise.resolve(value).then(_next, _throw);
}
function _async_to_generator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}
function _instanceof(left, right) {
    "@swc/helpers - instanceof";
    if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) {
        return !!right[Symbol.hasInstance](left);
    } else return left instanceof right;
}
function _ts_generator(thisArg, body) {
    var f, y, t, _ = {
        label: 0,
        sent: function() {
            if (t[0] & 1) throw t[1];
            return t[1];
        },
        trys: [],
        ops: []
    }, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype), d = Object.defineProperty;
    return d(g, "next", {
        value: verb(0)
    }), d(g, "throw", {
        value: verb(1)
    }), d(g, "return", {
        value: verb(2)
    }), typeof Symbol === "function" && d(g, Symbol.iterator, {
        value: function() {
            return this;
        }
    }), g;
    function verb(n) {
        return function(v) {
            return step([
                n,
                v
            ]);
        };
    }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while(g && (g = 0, op[0] && (_ = 0)), _)try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [
                op[0] & 2,
                t.value
            ];
            switch(op[0]){
                case 0:
                case 1:
                    t = op;
                    break;
                case 4:
                    _.label++;
                    return {
                        value: op[1],
                        done: false
                    };
                case 5:
                    _.label++;
                    y = op[1];
                    op = [
                        0
                    ];
                    continue;
                case 7:
                    op = _.ops.pop();
                    _.trys.pop();
                    continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                        _ = 0;
                        continue;
                    }
                    if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                        _.label = op[1];
                        break;
                    }
                    if (op[0] === 6 && _.label < t[1]) {
                        _.label = t[1];
                        t = op;
                        break;
                    }
                    if (t && _.label < t[2]) {
                        _.label = t[2];
                        _.ops.push(op);
                        break;
                    }
                    if (t[2]) _.ops.pop();
                    _.trys.pop();
                    continue;
            }
            op = body.call(thisArg, _);
        } catch (e) {
            op = [
                6,
                e
            ];
            y = 0;
        } finally{
            f = t = 0;
        }
        if (op[0] & 5) throw op[1];
        return {
            value: op[0] ? op[1] : void 0,
            done: true
        };
    }
}
function assert(condition, message) {
    if (!condition) throw new Error(message);
}
function safeCleanup(fn, kind) {
    return _async_to_generator(function() {
        return _ts_generator(this, function(_state) {
            return [
                2,
                Promise.resolve().then(function() {
                    return fn === null || fn === void 0 ? void 0 : fn();
                }).catch(function(e) {
                    return console.warn("[anywidget] error cleaning up ".concat(kind, "."), e);
                })
            ];
        });
    })();
}
/**
 * Cleans up the stack trace at anywidget boundary.
 * You can fully inspect the entire stack trace in the console interactively,
 * but the initial error message is cleaned up to be more user-friendly.
 */ function throwAnywidgetError(source) {
    var _ref;
    var _source_stack;
    if (!_instanceof(source, Error)) {
        // Don't know what to do with this.
        throw source;
    }
    var lines = (_ref = (_source_stack = source.stack) === null || _source_stack === void 0 ? void 0 : _source_stack.split("\n")) !== null && _ref !== void 0 ? _ref : [];
    var anywidgetIndex = lines.findIndex(function(line) {
        return line.includes("anywidget");
    });
    var cleanStack = anywidgetIndex === -1 ? lines : lines.slice(0, anywidgetIndex + 1);
    source.stack = cleanStack.join("\n");
    console.error(source);
    throw source;
}
/**
 * Polyfill for {@link https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise/withResolvers Promise.withResolvers}
 *
 * Trevor(2025-03-14): Should be able to remove once more stable across browsers.
 */ function promiseWithResolvers() {
    var resolve;
    var reject;
    var promise = new Promise(function(res, rej) {
        resolve = res;
        reject = rej;
    });
    return {
        promise: promise,
        resolve: resolve,
        reject: reject
    };
}

;// CONCATENATED MODULE: ./packages/anywidget/src/binding.ts
function binding_asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) resolve(value);
    else Promise.resolve(value).then(_next, _throw);
}
function binding_async_to_generator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                binding_asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                binding_asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) return descriptor.get.call(receiver);
    return descriptor.value;
}
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) descriptor.set.call(receiver, value);
    else {
        if (!descriptor.writable) {
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
function _class_call_check(instance, Constructor) {
    if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
}
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) throw new TypeError("attempted to " + action + " private field on non-instance");
    return privateMap.get(receiver);
}
function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}
function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}
function _defineProperties(target, props) {
    for(var i = 0; i < props.length; i++){
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}
function _create_class(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
}
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else obj[key] = value;
    return obj;
}
function binding_ts_generator(thisArg, body) {
    var f, y, t, _ = {
        label: 0,
        sent: function() {
            if (t[0] & 1) throw t[1];
            return t[1];
        },
        trys: [],
        ops: []
    }, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype), d = Object.defineProperty;
    return d(g, "next", {
        value: verb(0)
    }), d(g, "throw", {
        value: verb(1)
    }), d(g, "return", {
        value: verb(2)
    }), typeof Symbol === "function" && d(g, Symbol.iterator, {
        value: function() {
            return this;
        }
    }), g;
    function verb(n) {
        return function(v) {
            return step([
                n,
                v
            ]);
        };
    }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while(g && (g = 0, op[0] && (_ = 0)), _)try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [
                op[0] & 2,
                t.value
            ];
            switch(op[0]){
                case 0:
                case 1:
                    t = op;
                    break;
                case 4:
                    _.label++;
                    return {
                        value: op[1],
                        done: false
                    };
                case 5:
                    _.label++;
                    y = op[1];
                    op = [
                        0
                    ];
                    continue;
                case 7:
                    op = _.ops.pop();
                    _.trys.pop();
                    continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                        _ = 0;
                        continue;
                    }
                    if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                        _.label = op[1];
                        break;
                    }
                    if (op[0] === 6 && _.label < t[1]) {
                        _.label = t[1];
                        t = op;
                        break;
                    }
                    if (t && _.label < t[2]) {
                        _.label = t[2];
                        _.ops.push(op);
                        break;
                    }
                    if (t[2]) _.ops.pop();
                    _.trys.pop();
                    continue;
            }
            op = body.call(thisArg, _);
        } catch (e) {
            op = [
                6,
                e
            ];
            y = 0;
        } finally{
            f = t = 0;
        }
        if (op[0] & 5) throw op[1];
        return {
            value: op[0] ? op[1] : void 0,
            done: true
        };
    }
}
function _type_of(obj) {
    "@swc/helpers - typeof";
    return obj && typeof Symbol !== "undefined" && obj.constructor === Symbol ? "symbol" : typeof obj;
}


function isSafeCleanupFunction(x) {
    return typeof x === "function";
}
var binding_controller = /*#__PURE__*/ new WeakMap(), _widgetDef = /*#__PURE__*/ new WeakMap(), _exports = /*#__PURE__*/ new WeakMap(), _model = /*#__PURE__*/ new WeakMap(), _resolvers = /*#__PURE__*/ new WeakMap();
var binding_WidgetBinding = /*#__PURE__*/ function() {
    "use strict";
    function WidgetBinding(model) {
        _class_call_check(this, WidgetBinding);
        _class_private_field_init(this, binding_controller, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _widgetDef, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _exports, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _model, {
            writable: true,
            value: void 0
        });
        _define_property(this, "ready", void 0);
        _class_private_field_init(this, _resolvers, {
            writable: true,
            value: void 0
        });
        _class_private_field_set(this, _model, model);
        _class_private_field_set(this, _resolvers, promiseWithResolvers());
        this.ready = _class_private_field_get(this, _resolvers).promise;
    }
    _create_class(WidgetBinding, [
        {
            key: "bind",
            value: function bind(_0, _1) {
                return binding_async_to_generator(function(widgetDef, param) {
                    var experimental, _widgetDef_initialize, _$_class_private_field_get, prevResolvers, signal, model, result;
                    return binding_ts_generator(this, function(_state) {
                        switch(_state.label){
                            case 0:
                                experimental = param.experimental;
                                if (_class_private_field_get(this, _widgetDef) === widgetDef) return [
                                    2
                                ];
                                if (_class_private_field_get(this, _widgetDef) && _class_private_field_get(this, _widgetDef) !== widgetDef) {
                                    ;
                                    (_$_class_private_field_get = _class_private_field_get(this, binding_controller)) === null || _$_class_private_field_get === void 0 ? void 0 : _$_class_private_field_get.abort();
                                    // Settle the old promise so any awaiter that captured `this.ready`
                                    // (e.g. a parent's `host.getWidget` snapshot) unblocks instead of
                                    // hanging until the host's 10s timeout. No-op if already resolved.
                                    prevResolvers = _class_private_field_get(this, _resolvers);
                                    _class_private_field_set(this, _resolvers, promiseWithResolvers());
                                    this.ready = _class_private_field_get(this, _resolvers).promise;
                                    prevResolvers.promise.catch(function() {});
                                    prevResolvers.reject(new Error("[anywidget] widget bind aborted by re-bind"));
                                }
                                _class_private_field_set(this, _widgetDef, widgetDef);
                                _class_private_field_set(this, binding_controller, new AbortController());
                                signal = _class_private_field_get(this, binding_controller).signal;
                                model = _class_private_field_get(this, _model);
                                model.off(null, null, INITIALIZE_MARKER);
                                return [
                                    4,
                                    (_widgetDef_initialize = widgetDef.initialize) === null || _widgetDef_initialize === void 0 ? void 0 : _widgetDef_initialize.call(widgetDef, {
                                        model: modelProxy(model, INITIALIZE_MARKER),
                                        signal: signal,
                                        experimental: experimental
                                    })
                                ];
                            case 1:
                                result = _state.sent();
                                if (!signal.aborted) return [
                                    3,
                                    3
                                ];
                                return [
                                    4,
                                    safeCleanup(isSafeCleanupFunction(result) ? result : undefined, "esm update")
                                ];
                            case 2:
                                _state.sent();
                                return [
                                    2
                                ];
                            case 3:
                                if (isSafeCleanupFunction(result)) {
                                    signal.addEventListener("abort", function() {
                                        return safeCleanup(result, "esm update");
                                    });
                                    _class_private_field_set(this, _exports, undefined);
                                } else if ((typeof result === "undefined" ? "undefined" : _type_of(result)) === "object" && result !== null) {
                                    _class_private_field_set(this, _exports, result);
                                } else {
                                    _class_private_field_set(this, _exports, undefined);
                                }
                                _class_private_field_get(this, _resolvers).resolve(_class_private_field_get(this, _exports));
                                return [
                                    2
                                ];
                        }
                    });
                }).apply(this, arguments);
            }
        },
        {
            key: "createView",
            value: function createView(_0, _1) {
                return binding_async_to_generator(function(target, param) {
                    var signal, experimental, host, _$_class_private_field_get, controller, combined, model, cleanup, disposeView;
                    return binding_ts_generator(this, function(_state) {
                        switch(_state.label){
                            case 0:
                                signal = param.signal, experimental = param.experimental, host = param.host;
                                return [
                                    4,
                                    this.ready
                                ];
                            case 1:
                                _state.sent();
                                if (!((_$_class_private_field_get = _class_private_field_get(this, _widgetDef)) === null || _$_class_private_field_get === void 0 ? void 0 : _$_class_private_field_get.render)) return [
                                    2
                                ];
                                controller = new AbortController();
                                combined = AbortSignal.any([
                                    signal,
                                    controller.signal
                                ]);
                                model = _class_private_field_get(this, _model);
                                return [
                                    4,
                                    _class_private_field_get(this, _widgetDef).render({
                                        model: modelProxy(model, target),
                                        el: target.el,
                                        signal: combined,
                                        host: host,
                                        experimental: experimental
                                    })
                                ];
                            case 2:
                                cleanup = _state.sent();
                                disposeView = function disposeView(reason) {
                                    // Clear listeners keyed to this target. For ephemeral `{el}` targets
                                    // (host.getWidget().render), this prevents leaks across re-renders.
                                    model.off(null, null, target);
                                    void safeCleanup(cleanup, reason);
                                };
                                if (combined.aborted) {
                                    disposeView("dispose view - already aborted");
                                    return [
                                        2
                                    ];
                                }
                                combined.addEventListener("abort", function() {
                                    return disposeView("dispose view - aborted");
                                });
                                return [
                                    2
                                ];
                        }
                    });
                }).apply(this, arguments);
            }
        },
        {
            key: "exports",
            get: function get() {
                return _class_private_field_get(this, _exports);
            }
        },
        {
            key: "destroy",
            value: function destroy() {
                var _$_class_private_field_get;
                (_$_class_private_field_get = _class_private_field_get(this, binding_controller)) === null || _$_class_private_field_get === void 0 ? void 0 : _$_class_private_field_get.abort();
                _class_private_field_set(this, binding_controller, undefined);
                _class_private_field_set(this, _widgetDef, undefined);
            }
        }
    ]);
    return WidgetBinding;
}();
var _bindings = /*#__PURE__*/ new WeakMap();
var binding_BindingManager = /*#__PURE__*/ function() {
    "use strict";
    function BindingManager() {
        _class_call_check(this, BindingManager);
        _class_private_field_init(this, _bindings, {
            writable: true,
            value: new Map()
        });
    }
    _create_class(BindingManager, [
        {
            key: "getOrCreate",
            value: function getOrCreate(model) {
                var binding = _class_private_field_get(this, _bindings).get(model);
                if (!binding) {
                    binding = new binding_WidgetBinding(model);
                    _class_private_field_get(this, _bindings).set(model, binding);
                }
                return binding;
            }
        },
        {
            key: "get",
            value: function get(model) {
                return _class_private_field_get(this, _bindings).get(model);
            }
        },
        {
            key: "destroy",
            value: function destroy(model) {
                var binding = _class_private_field_get(this, _bindings).get(model);
                if (binding) {
                    binding.destroy();
                    _class_private_field_get(this, _bindings).delete(model);
                }
            }
        }
    ]);
    return BindingManager;
}();
var BINDINGS = new binding_BindingManager();

// EXTERNAL MODULE: ./node_modules/.pnpm/solid-js@1.9.18/node_modules/solid-js/dist/solid.js
var solid = __webpack_require__(771);
// EXTERNAL MODULE: ./node_modules/.pnpm/@lukeed+uuid@2.0.1/node_modules/@lukeed/uuid/dist/index.mjs
var dist = __webpack_require__(661);
;// CONCATENATED MODULE: ./packages/anywidget/src/invoke.ts

function invoke(model, name, msg) {
    var options = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : {};
    var _options_signal;
    // crypto.randomUUID() is not available in non-secure contexts (i.e., http://)
    // so we use simple (non-secure) polyfill.
    var id = dist.v4();
    var signal = (_options_signal = options.signal) !== null && _options_signal !== void 0 ? _options_signal : AbortSignal.timeout(3000);
    return new Promise(function(resolve, reject) {
        var _options_buffers;
        if (signal.aborted) {
            reject(signal.reason);
        }
        signal.addEventListener("abort", function() {
            model.off("msg:custom", handler);
            reject(signal.reason);
        });
        function handler(msg, buffers) {
            if (!(msg.id === id)) return;
            resolve([
                msg.response,
                buffers
            ]);
            model.off("msg:custom", handler);
        }
        model.on("msg:custom", handler);
        model.send({
            id: id,
            kind: "anywidget-command",
            name: name,
            msg: msg
        }, undefined, (_options_buffers = options.buffers) !== null && _options_buffers !== void 0 ? _options_buffers : []);
    });
}

;// CONCATENATED MODULE: ./packages/anywidget/src/widget-ref.ts
var WIDGET_REF_PREFIX = "anywidget:";
function parseWidgetRef(ref) {
    if (typeof ref === "string" && ref.startsWith(WIDGET_REF_PREFIX)) {
        return ref.slice(WIDGET_REF_PREFIX.length);
    }
    throw new Error("[anywidget] Invalid widget reference: ".concat(JSON.stringify(ref)));
}

;// CONCATENATED MODULE: ./packages/anywidget/src/host.ts
function host_asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) resolve(value);
    else Promise.resolve(value).then(_next, _throw);
}
function host_async_to_generator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                host_asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                host_asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}
function host_ts_generator(thisArg, body) {
    var f, y, t, _ = {
        label: 0,
        sent: function() {
            if (t[0] & 1) throw t[1];
            return t[1];
        },
        trys: [],
        ops: []
    }, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype), d = Object.defineProperty;
    return d(g, "next", {
        value: verb(0)
    }), d(g, "throw", {
        value: verb(1)
    }), d(g, "return", {
        value: verb(2)
    }), typeof Symbol === "function" && d(g, Symbol.iterator, {
        value: function() {
            return this;
        }
    }), g;
    function verb(n) {
        return function(v) {
            return step([
                n,
                v
            ]);
        };
    }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while(g && (g = 0, op[0] && (_ = 0)), _)try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [
                op[0] & 2,
                t.value
            ];
            switch(op[0]){
                case 0:
                case 1:
                    t = op;
                    break;
                case 4:
                    _.label++;
                    return {
                        value: op[1],
                        done: false
                    };
                case 5:
                    _.label++;
                    y = op[1];
                    op = [
                        0
                    ];
                    continue;
                case 7:
                    op = _.ops.pop();
                    _.trys.pop();
                    continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                        _ = 0;
                        continue;
                    }
                    if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                        _.label = op[1];
                        break;
                    }
                    if (op[0] === 6 && _.label < t[1]) {
                        _.label = t[1];
                        t = op;
                        break;
                    }
                    if (t && _.label < t[2]) {
                        _.label = t[2];
                        _.ops.push(op);
                        break;
                    }
                    if (t[2]) _.ops.pop();
                    _.trys.pop();
                    continue;
            }
            op = body.call(thisArg, _);
        } catch (e) {
            op = [
                6,
                e
            ];
            y = 0;
        } finally{
            f = t = 0;
        }
        if (op[0] & 5) throw op[1];
        return {
            value: op[0] ? op[1] : void 0,
            done: true
        };
    }
}




function createHost(model, param) {
    var signal = param.signal;
    var host = {
        getModel: // @ts-expect-error - modelProxy returns AnyModel; generic T is erased at runtime
        function getModel(ref) {
            return host_async_to_generator(function() {
                var modelId, childModel, context;
                return host_ts_generator(this, function(_state) {
                    switch(_state.label){
                        case 0:
                            modelId = parseWidgetRef(ref);
                            return [
                                4,
                                model.widget_manager.get_model(modelId)
                            ];
                        case 1:
                            childModel = _state.sent();
                            context = Symbol("anywidget.host.getModel");
                            signal.addEventListener("abort", function() {
                                return childModel.off(null, null, context);
                            });
                            return [
                                2,
                                modelProxy(childModel, context)
                            ];
                    }
                });
            })();
        },
        getWidget: // @ts-expect-error - generic T is erased at runtime, exports typed as unknown
        function getWidget(ref) {
            return host_async_to_generator(function() {
                var modelId, childModel, childBinding, timer, exports;
                return host_ts_generator(this, function(_state) {
                    switch(_state.label){
                        case 0:
                            modelId = parseWidgetRef(ref);
                            return [
                                4,
                                model.widget_manager.get_model(modelId)
                            ];
                        case 1:
                            childModel = _state.sent();
                            childBinding = BINDINGS.get(childModel);
                            if (!childBinding) {
                                throw new Error("[anywidget] No binding found for widget ".concat(modelId));
                            }
                            return [
                                4,
                                new Promise(function(resolve, reject) {
                                    timer = setTimeout(function() {
                                        return reject(new Error("[anywidget] Timed out waiting for widget ".concat(modelId, " to initialize")));
                                    }, 10000);
                                    childBinding.ready.then(resolve, reject);
                                }).finally(function() {
                                    return clearTimeout(timer);
                                })
                            ];
                        case 2:
                            exports = _state.sent();
                            return [
                                2,
                                {
                                    exports: exports,
                                    render: function render(_0) {
                                        return host_async_to_generator(function(param) {
                                            var el, viewSignal, childViewSignal;
                                            return host_ts_generator(this, function(_state) {
                                                switch(_state.label){
                                                    case 0:
                                                        el = param.el, viewSignal = param.signal;
                                                        childViewSignal = viewSignal !== null && viewSignal !== void 0 ? viewSignal : signal;
                                                        return [
                                                            4,
                                                            childBinding.createView({
                                                                el: el
                                                            }, {
                                                                signal: childViewSignal,
                                                                experimental: {
                                                                    // @ts-expect-error - bind isn't working
                                                                    invoke: invoke.bind(null, childModel)
                                                                },
                                                                host: host
                                                            })
                                                        ];
                                                    case 1:
                                                        _state.sent();
                                                        return [
                                                            2
                                                        ];
                                                }
                                            });
                                        }).apply(this, arguments);
                                    }
                                }
                            ];
                    }
                });
            })();
        }
    };
    return host;
}

;// CONCATENATED MODULE: ./packages/anywidget/src/load.ts
function load_asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) resolve(value);
    else Promise.resolve(value).then(_next, _throw);
}
function load_async_to_generator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                load_asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                load_asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}
function load_ts_generator(thisArg, body) {
    var f, y, t, _ = {
        label: 0,
        sent: function() {
            if (t[0] & 1) throw t[1];
            return t[1];
        },
        trys: [],
        ops: []
    }, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype), d = Object.defineProperty;
    return d(g, "next", {
        value: verb(0)
    }), d(g, "throw", {
        value: verb(1)
    }), d(g, "return", {
        value: verb(2)
    }), typeof Symbol === "function" && d(g, Symbol.iterator, {
        value: function() {
            return this;
        }
    }), g;
    function verb(n) {
        return function(v) {
            return step([
                n,
                v
            ]);
        };
    }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while(g && (g = 0, op[0] && (_ = 0)), _)try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [
                op[0] & 2,
                t.value
            ];
            switch(op[0]){
                case 0:
                case 1:
                    t = op;
                    break;
                case 4:
                    _.label++;
                    return {
                        value: op[1],
                        done: false
                    };
                case 5:
                    _.label++;
                    y = op[1];
                    op = [
                        0
                    ];
                    continue;
                case 7:
                    op = _.ops.pop();
                    _.trys.pop();
                    continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                        _ = 0;
                        continue;
                    }
                    if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                        _.label = op[1];
                        break;
                    }
                    if (op[0] === 6 && _.label < t[1]) {
                        _.label = t[1];
                        t = op;
                        break;
                    }
                    if (t && _.label < t[2]) {
                        _.label = t[2];
                        _.ops.push(op);
                        break;
                    }
                    if (t[2]) _.ops.pop();
                    _.trys.pop();
                    continue;
            }
            op = body.call(thisArg, _);
        } catch (e) {
            op = [
                6,
                e
            ];
            y = 0;
        } finally{
            f = t = 0;
        }
        if (op[0] & 5) throw op[1];
        return {
            value: op[0] ? op[1] : void 0,
            done: true
        };
    }
}

function isHref(str) {
    return str.startsWith("http://") || str.startsWith("https://");
}
function loadCssHref(href, anywidgetId) {
    return load_async_to_generator(function() {
        var prev, newLink;
        return load_ts_generator(this, function(_state) {
            prev = document.querySelector("link[id='".concat(anywidgetId, "']"));
            // Adapted from https://github.com/vitejs/vite/blob/d59e1acc2efc0307488364e9f2fad528ec57f204/packages/vite/src/client/client.ts#L185-L201
            // Swaps out old styles with new, but avoids flash of unstyled content.
            // No need to await the load since we already have styles applied.
            if (prev) {
                // oxlint-disable-next-line typescript-eslint/no-unsafe-type-assertion -- Node.cloneNode() returns Node; we know prev is HTMLLinkElement so the clone is too
                newLink = prev.cloneNode();
                newLink.href = href;
                newLink.addEventListener("load", function() {
                    return prev === null || prev === void 0 ? void 0 : prev.remove();
                });
                newLink.addEventListener("error", function() {
                    return prev === null || prev === void 0 ? void 0 : prev.remove();
                });
                prev.after(newLink);
                return [
                    2
                ];
            }
            return [
                2,
                new Promise(function(resolve) {
                    var link = Object.assign(document.createElement("link"), {
                        rel: "stylesheet",
                        href: href,
                        onload: resolve
                    });
                    document.head.appendChild(link);
                })
            ];
        });
    })();
}
function loadCssText(cssText, anywidgetId) {
    var prev = document.querySelector("style[id='".concat(anywidgetId, "']"));
    if (prev) {
        // replace instead of creating a new DOM node
        prev.textContent = cssText;
        return;
    }
    var style = Object.assign(document.createElement("style"), {
        id: anywidgetId,
        type: "text/css"
    });
    style.appendChild(document.createTextNode(cssText));
    document.head.appendChild(style);
}
function loadCss(css, anywidgetId) {
    return load_async_to_generator(function() {
        return load_ts_generator(this, function(_state) {
            if (!css || !anywidgetId) return [
                2
            ];
            if (isHref(css)) return [
                2,
                loadCssHref(css, anywidgetId)
            ];
            return [
                2,
                loadCssText(css, anywidgetId)
            ];
        });
    })();
}
function loadEsm(esm) {
    return load_async_to_generator(function() {
        var url, mod;
        return load_ts_generator(this, function(_state) {
            switch(_state.label){
                case 0:
                    if (!isHref(esm)) return [
                        3,
                        2
                    ];
                    return [
                        4,
                        import(/* webpackIgnore: true */ /* @vite-ignore */ esm)
                    ];
                case 1:
                    return [
                        2,
                        _state.sent()
                    ];
                case 2:
                    url = URL.createObjectURL(new Blob([
                        esm
                    ], {
                        type: "text/javascript"
                    }));
                    return [
                        4,
                        import(/* webpackIgnore: true */ /* @vite-ignore */ url)
                    ];
                case 3:
                    mod = _state.sent();
                    URL.revokeObjectURL(url);
                    return [
                        2,
                        mod
                    ];
            }
        });
    })();
}
function warnRenderDeprecation(anywidgetId) {
    console.warn("[anywidget] Deprecation Warning for ".concat(anywidgetId, ": Direct export of a 'render' will likely be deprecated in the future. To migrate ...\n\nRemove the 'export' keyword from 'render'\n-----------------------------------------\n\nexport function render({ model, el }) { ... }\n^^^^^^\n\nCreate a default export that returns an object with 'render'\n------------------------------------------------------------\n\nfunction render({ model, el }) { ... }\n         ^^^^^^\nexport default { render }\n                 ^^^^^^\n\nPin to anywidget>=0.9.0 in your pyproject.toml\n----------------------------------------------\n\ndependencies = [\"anywidget>=0.9.0\"]\n\nTo learn more, please see: https://github.com/manzt/anywidget/pull/395.\n"));
}
function loadWidget(esm, anywidgetId) {
    return load_async_to_generator(function() {
        var mod, widget, _tmp;
        return load_ts_generator(this, function(_state) {
            switch(_state.label){
                case 0:
                    return [
                        4,
                        loadEsm(esm)
                    ];
                case 1:
                    mod = _state.sent();
                    if (mod.render) {
                        warnRenderDeprecation(anywidgetId);
                        return [
                            2,
                            {
                                initialize: function initialize() {
                                    return load_async_to_generator(function() {
                                        return load_ts_generator(this, function(_state) {
                                            return [
                                                2
                                            ];
                                        });
                                    })();
                                },
                                render: mod.render
                            }
                        ];
                    }
                    assert(mod.default, "[anywidget] module must export a default function or object.");
                    if (!(typeof mod.default === "function")) return [
                        3,
                        3
                    ];
                    return [
                        4,
                        mod.default()
                    ];
                case 2:
                    _tmp = _state.sent();
                    return [
                        3,
                        4
                    ];
                case 3:
                    _tmp = mod.default;
                    _state.label = 4;
                case 4:
                    widget = _tmp;
                    return [
                        2,
                        widget
                    ];
            }
        });
    })();
}

;// CONCATENATED MODULE: ./packages/anywidget/src/observe.ts
function _array_like_to_array(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_with_holes(arr) {
    if (Array.isArray(arr)) return arr;
}
function _iterable_to_array_limit(arr, i) {
    var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
    if (_i == null) return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _s, _e;
    try {
        for(_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true){
            _arr.push(_s.value);
            if (i && _arr.length === i) break;
        }
    } catch (err) {
        _d = true;
        _e = err;
    } finally{
        try {
            if (!_n && _i["return"] != null) _i["return"]();
        } finally{
            if (_d) throw _e;
        }
    }
    return _arr;
}
function _non_iterable_rest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _sliced_to_array(arr, i) {
    return _array_with_holes(arr) || _iterable_to_array_limit(arr, i) || _unsupported_iterable_to_array(arr, i) || _non_iterable_rest();
}
function _unsupported_iterable_to_array(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array(o, minLen);
}

function observe(model, name, param) {
    var signal = param.signal;
    var _solid_createSignal = _sliced_to_array(solid/* .createSignal */.n5(model.get(name)), 2), get = _solid_createSignal[0], set = _solid_createSignal[1];
    var update = function update() {
        return set(function() {
            return model.get(name);
        });
    };
    model.on("change:".concat(name), update);
    signal === null || signal === void 0 ? void 0 : signal.addEventListener("abort", function() {
        model.off("change:".concat(name), update);
    });
    return get;
}

;// CONCATENATED MODULE: ./packages/anywidget/src/runtime.ts
function runtime_array_like_to_array(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function runtime_array_with_holes(arr) {
    if (Array.isArray(arr)) return arr;
}
function runtime_asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) resolve(value);
    else Promise.resolve(value).then(_next, _throw);
}
function runtime_async_to_generator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                runtime_asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                runtime_asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}
function runtime_check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function runtime_class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) return descriptor.get.call(receiver);
    return descriptor.value;
}
function runtime_class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) descriptor.set.call(receiver, value);
    else {
        if (!descriptor.writable) {
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
function runtime_class_call_check(instance, Constructor) {
    if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
}
function runtime_class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) throw new TypeError("attempted to " + action + " private field on non-instance");
    return privateMap.get(receiver);
}
function runtime_class_private_field_get(receiver, privateMap) {
    var descriptor = runtime_class_extract_field_descriptor(receiver, privateMap, "get");
    return runtime_class_apply_descriptor_get(receiver, descriptor);
}
function runtime_class_private_field_init(obj, privateMap, value) {
    runtime_check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function runtime_class_private_field_set(receiver, privateMap, value) {
    var descriptor = runtime_class_extract_field_descriptor(receiver, privateMap, "set");
    runtime_class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}
function runtime_defineProperties(target, props) {
    for(var i = 0; i < props.length; i++){
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}
function runtime_create_class(Constructor, protoProps, staticProps) {
    if (protoProps) runtime_defineProperties(Constructor.prototype, protoProps);
    if (staticProps) runtime_defineProperties(Constructor, staticProps);
    return Constructor;
}
function runtime_iterable_to_array_limit(arr, i) {
    var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
    if (_i == null) return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _s, _e;
    try {
        for(_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true){
            _arr.push(_s.value);
            if (i && _arr.length === i) break;
        }
    } catch (err) {
        _d = true;
        _e = err;
    } finally{
        try {
            if (!_n && _i["return"] != null) _i["return"]();
        } finally{
            if (_d) throw _e;
        }
    }
    return _arr;
}
function runtime_non_iterable_rest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function runtime_sliced_to_array(arr, i) {
    return runtime_array_with_holes(arr) || runtime_iterable_to_array_limit(arr, i) || runtime_unsupported_iterable_to_array(arr, i) || runtime_non_iterable_rest();
}
function runtime_ts_generator(thisArg, body) {
    var f, y, t, _ = {
        label: 0,
        sent: function() {
            if (t[0] & 1) throw t[1];
            return t[1];
        },
        trys: [],
        ops: []
    }, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype), d = Object.defineProperty;
    return d(g, "next", {
        value: verb(0)
    }), d(g, "throw", {
        value: verb(1)
    }), d(g, "return", {
        value: verb(2)
    }), typeof Symbol === "function" && d(g, Symbol.iterator, {
        value: function() {
            return this;
        }
    }), g;
    function verb(n) {
        return function(v) {
            return step([
                n,
                v
            ]);
        };
    }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while(g && (g = 0, op[0] && (_ = 0)), _)try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [
                op[0] & 2,
                t.value
            ];
            switch(op[0]){
                case 0:
                case 1:
                    t = op;
                    break;
                case 4:
                    _.label++;
                    return {
                        value: op[1],
                        done: false
                    };
                case 5:
                    _.label++;
                    y = op[1];
                    op = [
                        0
                    ];
                    continue;
                case 7:
                    op = _.ops.pop();
                    _.trys.pop();
                    continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                        _ = 0;
                        continue;
                    }
                    if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                        _.label = op[1];
                        break;
                    }
                    if (op[0] === 6 && _.label < t[1]) {
                        _.label = t[1];
                        t = op;
                        break;
                    }
                    if (t && _.label < t[2]) {
                        _.label = t[2];
                        _.ops.push(op);
                        break;
                    }
                    if (t[2]) _.ops.pop();
                    _.trys.pop();
                    continue;
            }
            op = body.call(thisArg, _);
        } catch (e) {
            op = [
                6,
                e
            ];
            y = 0;
        } finally{
            f = t = 0;
        }
        if (op[0] & 5) throw op[1];
        return {
            value: op[0] ? op[1] : void 0,
            done: true
        };
    }
}
function runtime_unsupported_iterable_to_array(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return runtime_array_like_to_array(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return runtime_array_like_to_array(o, minLen);
}







var // @ts-expect-error - Set synchronously in constructor.
_widgetResult = /*#__PURE__*/ new WeakMap(), _signal = /*#__PURE__*/ new WeakMap();
var runtime_Runtime = /*#__PURE__*/ function() {
    "use strict";
    function Runtime(model, options) {
        var _this = this;
        runtime_class_call_check(this, Runtime);
        runtime_class_private_field_init(this, _widgetResult, {
            writable: true,
            value: void 0
        });
        runtime_class_private_field_init(this, _signal, {
            writable: true,
            value: void 0
        });
        runtime_class_private_field_set(this, _signal, options.signal);
        runtime_class_private_field_get(this, _signal).throwIfAborted();
        runtime_class_private_field_get(this, _signal).addEventListener("abort", function() {
            return dispose();
        });
        var binding = BINDINGS.getOrCreate(model);
        var experimental = {
            // @ts-expect-error - invoke.bind loses generic type parameter
            invoke: invoke.bind(null, model)
        };
        var dispose = solid/* .createRoot */.Hr(function(dispose) {
            // DOMWidgetModel is untyped by trait shape; we know the anywidget traits, so narrow to AnyModel<State> for type-safe `.get()` access
            // oxlint-disable-next-line typescript-eslint/no-unsafe-type-assertion -- see above
            var typedModel = model;
            var id = typedModel.get("_anywidget_id");
            var css = observe(typedModel, "_css", {
                signal: runtime_class_private_field_get(_this, _signal)
            });
            var esm = observe(typedModel, "_esm", {
                signal: runtime_class_private_field_get(_this, _signal)
            });
            var _solid_createSignal = runtime_sliced_to_array(solid/* .createSignal */.n5({
                status: "pending"
            }), 2), widgetResult = _solid_createSignal[0], setWidgetResult = _solid_createSignal[1];
            runtime_class_private_field_set(_this, _widgetResult, widgetResult);
            solid/* .createEffect */.EH(solid.on(css, function() {
                return console.debug("[anywidget] css hot updated: ".concat(id));
            }, {
                defer: true
            }));
            solid/* .createEffect */.EH(solid.on(esm, function() {
                return console.debug("[anywidget] esm hot updated: ".concat(id));
            }, {
                defer: true
            }));
            solid/* .createEffect */.EH(function() {
                return loadCss(css(), id);
            });
            solid/* .createEffect */.EH(function() {
                // Per-effect controller so a stale loadWidget resolution from a
                // previous _esm value cannot overwrite a newer one. Solid fires
                // onCleanup before re-running the effect, aborting the prior load.
                var controller = new AbortController();
                solid/* .onCleanup */.Ki(function() {
                    return controller.abort();
                });
                loadWidget(esm(), id).then(function(widget) {
                    return runtime_async_to_generator(function() {
                        return runtime_ts_generator(this, function(_state) {
                            switch(_state.label){
                                case 0:
                                    if (controller.signal.aborted) return [
                                        2
                                    ];
                                    return [
                                        4,
                                        binding.bind(widget, {
                                            experimental: experimental
                                        })
                                    ];
                                case 1:
                                    _state.sent();
                                    if (controller.signal.aborted) return [
                                        2
                                    ];
                                    setWidgetResult({
                                        status: "ready",
                                        data: widget
                                    });
                                    return [
                                        2
                                    ];
                            }
                        });
                    })();
                }).catch(function(error) {
                    if (controller.signal.aborted) return;
                    setWidgetResult({
                        status: "error",
                        error: error
                    });
                });
            });
            return dispose;
        });
    }
    runtime_create_class(Runtime, [
        {
            key: "createView",
            value: function createView(view, options) {
                return runtime_async_to_generator(function() {
                    var _this, model, signal, binding, experimental, host, dispose;
                    return runtime_ts_generator(this, function(_state) {
                        _this = this;
                        model = view.model;
                        signal = AbortSignal.any([
                            runtime_class_private_field_get(this, _signal),
                            options.signal
                        ]); // either model or view destroyed
                        signal.throwIfAborted();
                        signal.addEventListener("abort", function() {
                            return dispose();
                        });
                        binding = BINDINGS.get(model);
                        assert(binding, "[anywidget] WidgetBinding not found.");
                        experimental = {
                            // @ts-expect-error - invoke.bind loses generic type parameter
                            invoke: invoke.bind(null, model)
                        };
                        host = createHost(model, {
                            signal: signal
                        });
                        dispose = solid/* .createRoot */.Hr(function(dispose) {
                            solid/* .createEffect */.EH(function() {
                                // Clear all previous event listeners from this hook.
                                model.off(null, null, view);
                                view.$el.empty();
                                var result = runtime_class_private_field_get(_this, _widgetResult).call(_this);
                                if (result.status === "pending") {
                                    return;
                                }
                                if (result.status === "error") {
                                    throwAnywidgetError(result.error);
                                    return;
                                }
                                var controller = new AbortController();
                                solid/* .onCleanup */.Ki(function() {
                                    return controller.abort();
                                });
                                Promise.resolve().then(function() {
                                    return binding.createView(view, {
                                        signal: AbortSignal.any([
                                            signal,
                                            controller.signal
                                        ]),
                                        experimental: experimental,
                                        host: host
                                    });
                                }).catch(function(error) {
                                    return throwAnywidgetError(error);
                                });
                            });
                            return function() {
                                return dispose();
                            };
                        });
                        return [
                            2
                        ];
                    });
                }).call(this);
            }
        }
    ]);
    return Runtime;
}();

;// CONCATENATED MODULE: ./packages/anywidget/src/widget.ts
function widget_array_like_to_array(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_without_holes(arr) {
    if (Array.isArray(arr)) return widget_array_like_to_array(arr);
}
function _assert_this_initialized(self) {
    if (self === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return self;
}
function widget_asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) resolve(value);
    else Promise.resolve(value).then(_next, _throw);
}
function widget_async_to_generator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                widget_asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                widget_asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}
function _call_super(_this, derived, args) {
    derived = _get_prototype_of(derived);
    return _possible_constructor_return(_this, _is_native_reflect_construct() ? Reflect.construct(derived, args || [], _get_prototype_of(_this).constructor) : derived.apply(_this, args));
}
function widget_check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function widget_class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) return descriptor.get.call(receiver);
    return descriptor.value;
}
function widget_class_call_check(instance, Constructor) {
    if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
}
function widget_class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) throw new TypeError("attempted to " + action + " private field on non-instance");
    return privateMap.get(receiver);
}
function widget_class_private_field_get(receiver, privateMap) {
    var descriptor = widget_class_extract_field_descriptor(receiver, privateMap, "get");
    return widget_class_apply_descriptor_get(receiver, descriptor);
}
function widget_class_private_field_init(obj, privateMap, value) {
    widget_check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function widget_defineProperties(target, props) {
    for(var i = 0; i < props.length; i++){
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}
function widget_create_class(Constructor, protoProps, staticProps) {
    if (protoProps) widget_defineProperties(Constructor.prototype, protoProps);
    if (staticProps) widget_defineProperties(Constructor, staticProps);
    return Constructor;
}
function widget_define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else obj[key] = value;
    return obj;
}
function _get(target, property, receiver) {
    if (typeof Reflect !== "undefined" && Reflect.get) _get = Reflect.get;
    else {
        _get = function get(target, property, receiver) {
            var base = _super_prop_base(target, property);
            if (!base) return;
            var desc = Object.getOwnPropertyDescriptor(base, property);
            if (desc.get) return desc.get.call(receiver || target);
            return desc.value;
        };
    }
    return _get(target, property, receiver || target);
}
function _get_prototype_of(o) {
    _get_prototype_of = Object.setPrototypeOf ? Object.getPrototypeOf : function getPrototypeOf(o) {
        return o.__proto__ || Object.getPrototypeOf(o);
    };
    return _get_prototype_of(o);
}
function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
        throw new TypeError("Super expression must either be null or a function");
    }
    subClass.prototype = Object.create(superClass && superClass.prototype, {
        constructor: {
            value: subClass,
            writable: true,
            configurable: true
        }
    });
    if (superClass) _set_prototype_of(subClass, superClass);
}
function _is_native_reflect_construct() {
    try {
        var result = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
    } catch (_) {}
    return (_is_native_reflect_construct = function() {
        return !!result;
    })();
}
function _iterable_to_array(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) {
        return Array.from(iter);
    }
}
function _non_iterable_spread() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _possible_constructor_return(self, call) {
    if (call && (widget_type_of(call) === "object" || typeof call === "function")) return call;
    return _assert_this_initialized(self);
}
function _set_prototype_of(o, p) {
    _set_prototype_of = Object.setPrototypeOf || function setPrototypeOf(o, p) {
        o.__proto__ = p;
        return o;
    };
    return _set_prototype_of(o, p);
}
function _super_prop_base(object, property) {
    while(!Object.prototype.hasOwnProperty.call(object, property)){
        object = _get_prototype_of(object);
        if (object === null) break;
    }
    return object;
}
function _to_consumable_array(arr) {
    return _array_without_holes(arr) || _iterable_to_array(arr) || widget_unsupported_iterable_to_array(arr) || _non_iterable_spread();
}
function widget_ts_generator(thisArg, body) {
    var f, y, t, _ = {
        label: 0,
        sent: function() {
            if (t[0] & 1) throw t[1];
            return t[1];
        },
        trys: [],
        ops: []
    }, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype), d = Object.defineProperty;
    return d(g, "next", {
        value: verb(0)
    }), d(g, "throw", {
        value: verb(1)
    }), d(g, "return", {
        value: verb(2)
    }), typeof Symbol === "function" && d(g, Symbol.iterator, {
        value: function() {
            return this;
        }
    }), g;
    function verb(n) {
        return function(v) {
            return step([
                n,
                v
            ]);
        };
    }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while(g && (g = 0, op[0] && (_ = 0)), _)try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [
                op[0] & 2,
                t.value
            ];
            switch(op[0]){
                case 0:
                case 1:
                    t = op;
                    break;
                case 4:
                    _.label++;
                    return {
                        value: op[1],
                        done: false
                    };
                case 5:
                    _.label++;
                    y = op[1];
                    op = [
                        0
                    ];
                    continue;
                case 7:
                    op = _.ops.pop();
                    _.trys.pop();
                    continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                        _ = 0;
                        continue;
                    }
                    if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                        _.label = op[1];
                        break;
                    }
                    if (op[0] === 6 && _.label < t[1]) {
                        _.label = t[1];
                        t = op;
                        break;
                    }
                    if (t && _.label < t[2]) {
                        _.label = t[2];
                        _.ops.push(op);
                        break;
                    }
                    if (t[2]) _.ops.pop();
                    _.trys.pop();
                    continue;
            }
            op = body.call(thisArg, _);
        } catch (e) {
            op = [
                6,
                e
            ];
            y = 0;
        } finally{
            f = t = 0;
        }
        if (op[0] & 5) throw op[1];
        return {
            value: op[0] ? op[1] : void 0,
            done: true
        };
    }
}
function widget_type_of(obj) {
    "@swc/helpers - typeof";
    return obj && typeof Symbol !== "undefined" && obj.constructor === Symbol ? "symbol" : typeof obj;
}
function widget_unsupported_iterable_to_array(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return widget_array_like_to_array(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return widget_array_like_to_array(o, minLen);
}



// @ts-expect-error - injected by bundler
var version = "0.11.0";
/* export default */ function src_widget(param) {
    var DOMWidgetModel = param.DOMWidgetModel, DOMWidgetView = param.DOMWidgetView;
    var RUNTIMES = new WeakMap();
    var AnyModel = /*#__PURE__*/ function(DOMWidgetModel) {
        "use strict";
        _inherits(AnyModel, DOMWidgetModel);
        function AnyModel() {
            widget_class_call_check(this, AnyModel);
            return _call_super(this, AnyModel, arguments);
        }
        widget_create_class(AnyModel, [
            {
                key: "initialize",
                value: function initialize() {
                    var _this = this;
                    for(var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++){
                        args[_key] = arguments[_key];
                    }
                    var _$_get;
                    (_$_get = _get(_get_prototype_of(AnyModel.prototype), "initialize", this)).call.apply(_$_get, [
                        this
                    ].concat(_to_consumable_array(args)));
                    var controller = new AbortController();
                    this.once("destroy", function() {
                        controller.abort("[anywidget] Runtime destroyed.");
                        BINDINGS.destroy(_this);
                        RUNTIMES.delete(_this);
                    });
                    RUNTIMES.set(this, new runtime_Runtime(this, {
                        signal: controller.signal
                    }));
                }
            },
            {
                /**
     * We override to support binary trailets because JSON.parse(JSON.stringify())
     * does not properly clone binary data (it just returns an empty object).
     *
     * https://github.com/jupyter-widgets/ipywidgets/blob/47058a373d2c2b3acf101677b2745e14b76dd74b/packages/base/src/widget.ts#L562-L583
     */ key: "serialize",
                value: function serialize(state) {
                    // oxlint-disable-next-line typescript-eslint/no-unsafe-type-assertion -- accessing static `.serializers` on `this.constructor`
                    var serializers = this.constructor.serializers || {};
                    var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
                    try {
                        for(var _iterator = Object.keys(state)[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
                            var k = _step.value;
                            try {
                                var _serializers_k, _state_k;
                                var serialize = (_serializers_k = serializers[k]) === null || _serializers_k === void 0 ? void 0 : _serializers_k.serialize;
                                if (serialize) {
                                    state[k] = serialize(state[k], this);
                                } else if (k === "layout" || k === "style") {
                                    // These keys come from ipywidgets, rely on JSON.stringify trick.
                                    state[k] = JSON.parse(JSON.stringify(state[k]));
                                } else {
                                    state[k] = structuredClone(state[k]);
                                }
                                if (typeof ((_state_k = state[k]) === null || _state_k === void 0 ? void 0 : _state_k.toJSON) === "function") {
                                    state[k] = state[k].toJSON();
                                }
                            } catch (e) {
                                console.error("Error serializing widget state attribute: ", k);
                                throw e;
                            }
                        }
                    } catch (err) {
                        _didIteratorError = true;
                        _iteratorError = err;
                    } finally{
                        try {
                            if (!_iteratorNormalCompletion && _iterator.return != null) {
                                _iterator.return();
                            }
                        } finally{
                            if (_didIteratorError) {
                                throw _iteratorError;
                            }
                        }
                    }
                    return state;
                }
            }
        ]);
        return AnyModel;
    }(DOMWidgetModel);
    widget_define_property(AnyModel, "model_name", "AnyModel");
    widget_define_property(AnyModel, "model_module", "anywidget");
    widget_define_property(AnyModel, "model_module_version", version);
    widget_define_property(AnyModel, "view_name", "AnyView");
    widget_define_property(AnyModel, "view_module", "anywidget");
    widget_define_property(AnyModel, "view_module_version", version);
    var _controller = /*#__PURE__*/ new WeakMap();
    var AnyView = /*#__PURE__*/ function(DOMWidgetView) {
        "use strict";
        _inherits(AnyView, DOMWidgetView);
        function AnyView() {
            widget_class_call_check(this, AnyView);
            var _this;
            _this = _call_super(this, AnyView, arguments), widget_class_private_field_init(_this, _controller, {
                writable: true,
                value: new AbortController()
            });
            return _this;
        }
        widget_create_class(AnyView, [
            {
                key: "render",
                value: function render() {
                    return widget_async_to_generator(function() {
                        var runtime;
                        return widget_ts_generator(this, function(_state) {
                            switch(_state.label){
                                case 0:
                                    runtime = RUNTIMES.get(this.model);
                                    assert(runtime, "[anywidget] Runtime not found.");
                                    return [
                                        4,
                                        runtime.createView(this, {
                                            signal: widget_class_private_field_get(this, _controller).signal
                                        })
                                    ];
                                case 1:
                                    _state.sent();
                                    return [
                                        2
                                    ];
                            }
                        });
                    }).call(this);
                }
            },
            {
                key: "remove",
                value: function remove() {
                    widget_class_private_field_get(this, _controller).abort("[anywidget] View destroyed.");
                    _get(_get_prototype_of(AnyView.prototype), "remove", this).call(this);
                }
            }
        ]);
        return AnyView;
    }(DOMWidgetView);
    return {
        AnyModel: AnyModel,
        AnyView: AnyView
    };
}

;// CONCATENATED MODULE: ./packages/anywidget/src/plugin.js




/**
 * @typedef JupyterLabRegistry
 * @property {(widget: { name: string, version: string, exports: any }) => void} registerWidget
 */

/* export default */ const src_plugin = ({
  id: "anywidget_0_11:plugin",
  requires: [/** @type{unknown} */ (base_6_0_strict_.IJupyterWidgetRegistry)],
  activate: (/** @type {unknown} */ _app, /** @type {JupyterLabRegistry} */ registry) => {
    let exports = src_widget(base_6_0_strict_);
    registry.registerWidget({
      name: "anywidget",
      // @ts-expect-error Added by bundler
      version: "0.11.0",
      exports,
    });
  },
  autoStart: true,
});


},

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiMzE2LjU5NmMxNTkwLmpzIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vQGFueXdpZGdldC9tb25vcmVwby8uL3BhY2thZ2VzL2FueXdpZGdldC9zcmMvbW9kZWwtcHJveHkudHMiLCJ3ZWJwYWNrOi8vQGFueXdpZGdldC9tb25vcmVwby8uL3BhY2thZ2VzL2FueXdpZGdldC9zcmMvdXRpbC50cyIsIndlYnBhY2s6Ly9AYW55d2lkZ2V0L21vbm9yZXBvLy4vcGFja2FnZXMvYW55d2lkZ2V0L3NyYy9iaW5kaW5nLnRzIiwid2VicGFjazovL0Bhbnl3aWRnZXQvbW9ub3JlcG8vLi9wYWNrYWdlcy9hbnl3aWRnZXQvc3JjL2ludm9rZS50cyIsIndlYnBhY2s6Ly9AYW55d2lkZ2V0L21vbm9yZXBvLy4vcGFja2FnZXMvYW55d2lkZ2V0L3NyYy93aWRnZXQtcmVmLnRzIiwid2VicGFjazovL0Bhbnl3aWRnZXQvbW9ub3JlcG8vLi9wYWNrYWdlcy9hbnl3aWRnZXQvc3JjL2hvc3QudHMiLCJ3ZWJwYWNrOi8vQGFueXdpZGdldC9tb25vcmVwby8uL3BhY2thZ2VzL2FueXdpZGdldC9zcmMvbG9hZC50cyIsIndlYnBhY2s6Ly9AYW55d2lkZ2V0L21vbm9yZXBvLy4vcGFja2FnZXMvYW55d2lkZ2V0L3NyYy9vYnNlcnZlLnRzIiwid2VicGFjazovL0Bhbnl3aWRnZXQvbW9ub3JlcG8vLi9wYWNrYWdlcy9hbnl3aWRnZXQvc3JjL3J1bnRpbWUudHMiLCJ3ZWJwYWNrOi8vQGFueXdpZGdldC9tb25vcmVwby8uL3BhY2thZ2VzL2FueXdpZGdldC9zcmMvd2lkZ2V0LnRzIiwid2VicGFjazovL0Bhbnl3aWRnZXQvbW9ub3JlcG8vLi9wYWNrYWdlcy9hbnl3aWRnZXQvc3JjL3BsdWdpbi5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IEFueU1vZGVsIH0gZnJvbSBcIkBhbnl3aWRnZXQvdHlwZXNcIjtcbmltcG9ydCB0eXBlIHsgRE9NV2lkZ2V0TW9kZWwgfSBmcm9tIFwiQGp1cHl0ZXItd2lkZ2V0cy9iYXNlXCI7XG5cbi8qKlxuICogVGhpcyBpcyBhIHRyaWNrIHNvIHRoYXQgd2UgY2FuIGNsZWFudXAgZXZlbnQgbGlzdGVuZXJzIGFkZGVkXG4gKiBieSB0aGUgdXNlci1kZWZpbmVkIGZ1bmN0aW9uLlxuICovXG5leHBvcnQgbGV0IElOSVRJQUxJWkVfTUFSS0VSID0gU3ltYm9sKFwiYW55d2lkZ2V0LmluaXRpYWxpemVcIik7XG5cbi8qKlxuICogUHJ1bmVzIHRoZSB2aWV3IGRvd24gdG8gdGhlIG1pbmltdW0gY29udGV4dCBuZWNlc3NhcnkuXG4gKlxuICogQ2FsbHMgdG8gYG1vZGVsLmdldGAgYW5kIGBtb2RlbC5zZXRgIGF1dG9tYXRpY2FsbHkgYWRkIHRoZVxuICogYGNvbnRleHRgLCBzbyB3ZSBjYW4gZ3JhY2VmdWxseSB1bnN1YnNjcmliZSBmcm9tIGV2ZW50c1xuICogYWRkZWQgYnkgdXNlci1kZWZpbmVkIGhvb2tzLlxuICovXG5leHBvcnQgZnVuY3Rpb24gbW9kZWxQcm94eShtb2RlbDogRE9NV2lkZ2V0TW9kZWwsIGNvbnRleHQ6IHVua25vd24pOiBBbnlNb2RlbCB7XG4gIC8vIG94bGludC1kaXNhYmxlLW5leHQtbGluZSB0eXBlc2NyaXB0LWVzbGludC9uby11bnNhZmUtdHlwZS1hc3NlcnRpb24gLS0gRE9NV2lkZ2V0TW9kZWwuZ2V0L3NldC9vbi9vZmYgaGF2ZSB3aWRlciBzaWduYXR1cmVzIHRoYW4gQW55TW9kZWwsIHNvIGJvdW5kIHZlcnNpb25zIGRvbid0IG5hcnJvdyBjbGVhbmx5OyB0aGUgc2hhcGUgaXMgc3RydWN0dXJhbGx5IGNvbXBhdGlibGVcbiAgcmV0dXJuIHtcbiAgICBnZXQ6IG1vZGVsLmdldC5iaW5kKG1vZGVsKSxcbiAgICBzZXQ6IG1vZGVsLnNldC5iaW5kKG1vZGVsKSxcbiAgICBzYXZlX2NoYW5nZXM6IG1vZGVsLnNhdmVfY2hhbmdlcy5iaW5kKG1vZGVsKSxcbiAgICBzZW5kOiBtb2RlbC5zZW5kLmJpbmQobW9kZWwpLFxuICAgIG9uKG5hbWUsIGNhbGxiYWNrKSB7XG4gICAgICBtb2RlbC5vbihuYW1lLCBjYWxsYmFjaywgY29udGV4dCk7XG4gICAgfSxcbiAgICBvZmYobmFtZSwgY2FsbGJhY2spIHtcbiAgICAgIG1vZGVsLm9mZihuYW1lLCBjYWxsYmFjaywgY29udGV4dCk7XG4gICAgfSxcbiAgICAvLyBUaGUgd2lkZ2V0X21hbmFnZXIgdHlwZSBpcyB3aWRlciB0aGFuIHdoYXQgd2Ugd2FudCB0byBleHBvc2UgdG9cbiAgICAvLyBkZXZlbG9wZXJzLiBJbiBhIGZ1dHVyZSB2ZXJzaW9uLCB3ZSB3aWxsIGV4cG9zZSBhIG1vcmUgbGltaXRlZCBBUEkgYnV0XG4gICAgLy8gdGhhdCBjYW4gd2FpdCBmb3IgYSBtaW5vciB2ZXJzaW9uIGJ1bXAuXG4gICAgd2lkZ2V0X21hbmFnZXI6IG1vZGVsLndpZGdldF9tYW5hZ2VyLFxuICB9IGFzIEFueU1vZGVsO1xufVxuIiwiZXhwb3J0IHR5cGUgQXdhaXRhYmxlPFQ+ID0gVCB8IFByb21pc2VMaWtlPFQ+O1xuXG5leHBvcnQgaW50ZXJmYWNlIFJlYWR5PFQ+IHtcbiAgc3RhdHVzOiBcInJlYWR5XCI7XG4gIGRhdGE6IFQ7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgUGVuZGluZyB7XG4gIHN0YXR1czogXCJwZW5kaW5nXCI7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgRXJyb3JlZCB7XG4gIHN0YXR1czogXCJlcnJvclwiO1xuICBlcnJvcjogdW5rbm93bjtcbn1cblxuZXhwb3J0IHR5cGUgUmVzdWx0PFQ+ID0gUGVuZGluZyB8IFJlYWR5PFQ+IHwgRXJyb3JlZDtcblxuZXhwb3J0IGZ1bmN0aW9uIGFzc2VydChjb25kaXRpb246IHVua25vd24sIG1lc3NhZ2U6IHN0cmluZyk6IGFzc2VydHMgY29uZGl0aW9uIHtcbiAgaWYgKCFjb25kaXRpb24pIHRocm93IG5ldyBFcnJvcihtZXNzYWdlKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNhZmVDbGVhbnVwKFxuICBmbjogdm9pZCB8ICgoKSA9PiBBd2FpdGFibGU8dm9pZD4pIHwgdW5kZWZpbmVkLFxuICBraW5kOiBzdHJpbmcsXG4pOiBQcm9taXNlPHZvaWQ+IHtcbiAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgpXG4gICAgLnRoZW4oKCkgPT4gZm4/LigpKVxuICAgIC5jYXRjaCgoZSkgPT4gY29uc29sZS53YXJuKGBbYW55d2lkZ2V0XSBlcnJvciBjbGVhbmluZyB1cCAke2tpbmR9LmAsIGUpKTtcbn1cblxuLyoqXG4gKiBDbGVhbnMgdXAgdGhlIHN0YWNrIHRyYWNlIGF0IGFueXdpZGdldCBib3VuZGFyeS5cbiAqIFlvdSBjYW4gZnVsbHkgaW5zcGVjdCB0aGUgZW50aXJlIHN0YWNrIHRyYWNlIGluIHRoZSBjb25zb2xlIGludGVyYWN0aXZlbHksXG4gKiBidXQgdGhlIGluaXRpYWwgZXJyb3IgbWVzc2FnZSBpcyBjbGVhbmVkIHVwIHRvIGJlIG1vcmUgdXNlci1mcmllbmRseS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRocm93QW55d2lkZ2V0RXJyb3Ioc291cmNlOiB1bmtub3duKTogbmV2ZXIge1xuICBpZiAoIShzb3VyY2UgaW5zdGFuY2VvZiBFcnJvcikpIHtcbiAgICAvLyBEb24ndCBrbm93IHdoYXQgdG8gZG8gd2l0aCB0aGlzLlxuICAgIHRocm93IHNvdXJjZTtcbiAgfVxuICBsZXQgbGluZXMgPSBzb3VyY2Uuc3RhY2s/LnNwbGl0KFwiXFxuXCIpID8/IFtdO1xuICBsZXQgYW55d2lkZ2V0SW5kZXggPSBsaW5lcy5maW5kSW5kZXgoKGxpbmUpID0+IGxpbmUuaW5jbHVkZXMoXCJhbnl3aWRnZXRcIikpO1xuICBsZXQgY2xlYW5TdGFjayA9IGFueXdpZGdldEluZGV4ID09PSAtMSA/IGxpbmVzIDogbGluZXMuc2xpY2UoMCwgYW55d2lkZ2V0SW5kZXggKyAxKTtcbiAgc291cmNlLnN0YWNrID0gY2xlYW5TdGFjay5qb2luKFwiXFxuXCIpO1xuICBjb25zb2xlLmVycm9yKHNvdXJjZSk7XG4gIHRocm93IHNvdXJjZTtcbn1cblxuLyoqXG4gKiBQb2x5ZmlsbCBmb3Ige0BsaW5rIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0phdmFTY3JpcHQvUmVmZXJlbmNlL0dsb2JhbF9PYmplY3RzL1Byb21pc2Uvd2l0aFJlc29sdmVycyBQcm9taXNlLndpdGhSZXNvbHZlcnN9XG4gKlxuICogVHJldm9yKDIwMjUtMDMtMTQpOiBTaG91bGQgYmUgYWJsZSB0byByZW1vdmUgb25jZSBtb3JlIHN0YWJsZSBhY3Jvc3MgYnJvd3NlcnMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwcm9taXNlV2l0aFJlc29sdmVyczxUPigpOiBQcm9taXNlV2l0aFJlc29sdmVyczxUPiB7XG4gIGxldCByZXNvbHZlITogKHZhbHVlOiBUIHwgUHJvbWlzZUxpa2U8VD4pID0+IHZvaWQ7XG4gIGxldCByZWplY3QhOiAocmVhc29uPzogdW5rbm93bikgPT4gdm9pZDtcbiAgbGV0IHByb21pc2UgPSBuZXcgUHJvbWlzZTxUPigocmVzLCByZWopID0+IHtcbiAgICByZXNvbHZlID0gcmVzO1xuICAgIHJlamVjdCA9IHJlajtcbiAgfSk7XG4gIHJldHVybiB7IHByb21pc2UsIHJlc29sdmUsIHJlamVjdCB9O1xufVxuIiwiaW1wb3J0IHR5cGUgeyBFeHBlcmltZW50YWwsIEhvc3QgfSBmcm9tIFwiQGFueXdpZGdldC90eXBlc1wiO1xuaW1wb3J0IHR5cGUgeyBET01XaWRnZXRNb2RlbCB9IGZyb20gXCJAanVweXRlci13aWRnZXRzL2Jhc2VcIjtcblxuaW1wb3J0IHR5cGUgeyBBbnlXaWRnZXQgfSBmcm9tIFwiLi9sb2FkLnRzXCI7XG5pbXBvcnQgeyBJTklUSUFMSVpFX01BUktFUiwgbW9kZWxQcm94eSB9IGZyb20gXCIuL21vZGVsLXByb3h5LnRzXCI7XG5pbXBvcnQgeyB0eXBlIEF3YWl0YWJsZSwgcHJvbWlzZVdpdGhSZXNvbHZlcnMsIHNhZmVDbGVhbnVwIH0gZnJvbSBcIi4vdXRpbC50c1wiO1xuXG4vKipcbiAqIFRoZSBtaW5pbWFsIHN1cmZhY2UgYGNyZWF0ZVZpZXdgIG5lZWRzIGZyb20gYSB2aWV3LWxpa2Ugb2JqZWN0LiBUaGUgb2JqZWN0XG4gKiBpZGVudGl0eSBpcyB1c2VkIGFzIHRoZSBsaXN0ZW5lciBjb250ZXh0IGZvciBgbW9kZWxQcm94eWAsIGFuZCBgZWxgIGlzIHRoZVxuICogcmVuZGVyIHRhcmdldC5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBWaWV3VGFyZ2V0IHtcbiAgZWw6IEhUTUxFbGVtZW50O1xufVxuXG5mdW5jdGlvbiBpc1NhZmVDbGVhbnVwRnVuY3Rpb24oeDogdW5rbm93bik6IHggaXMgKCkgPT4gQXdhaXRhYmxlPHZvaWQ+IHtcbiAgcmV0dXJuIHR5cGVvZiB4ID09PSBcImZ1bmN0aW9uXCI7XG59XG5cbmV4cG9ydCBjbGFzcyBXaWRnZXRCaW5kaW5nIHtcbiAgI2NvbnRyb2xsZXI6IEFib3J0Q29udHJvbGxlciB8IHVuZGVmaW5lZDtcbiAgI3dpZGdldERlZjogQW55V2lkZ2V0IHwgdW5kZWZpbmVkO1xuICAjZXhwb3J0czogdW5rbm93bjtcbiAgI21vZGVsOiBET01XaWRnZXRNb2RlbDtcbiAgcmVhZHk6IFByb21pc2U8dW5rbm93bj47XG4gICNyZXNvbHZlcnM6IFByb21pc2VXaXRoUmVzb2x2ZXJzPHVua25vd24+O1xuXG4gIGNvbnN0cnVjdG9yKG1vZGVsOiBET01XaWRnZXRNb2RlbCkge1xuICAgIHRoaXMuI21vZGVsID0gbW9kZWw7XG4gICAgdGhpcy4jcmVzb2x2ZXJzID0gcHJvbWlzZVdpdGhSZXNvbHZlcnMoKTtcbiAgICB0aGlzLnJlYWR5ID0gdGhpcy4jcmVzb2x2ZXJzLnByb21pc2U7XG4gIH1cblxuICBhc3luYyBiaW5kKFxuICAgIHdpZGdldERlZjogQW55V2lkZ2V0LFxuICAgIHsgZXhwZXJpbWVudGFsIH06IHsgZXhwZXJpbWVudGFsOiBFeHBlcmltZW50YWwgfSxcbiAgKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgaWYgKHRoaXMuI3dpZGdldERlZiA9PT0gd2lkZ2V0RGVmKSByZXR1cm47XG5cbiAgICBpZiAodGhpcy4jd2lkZ2V0RGVmICYmIHRoaXMuI3dpZGdldERlZiAhPT0gd2lkZ2V0RGVmKSB7XG4gICAgICB0aGlzLiNjb250cm9sbGVyPy5hYm9ydCgpO1xuICAgICAgLy8gU2V0dGxlIHRoZSBvbGQgcHJvbWlzZSBzbyBhbnkgYXdhaXRlciB0aGF0IGNhcHR1cmVkIGB0aGlzLnJlYWR5YFxuICAgICAgLy8gKGUuZy4gYSBwYXJlbnQncyBgaG9zdC5nZXRXaWRnZXRgIHNuYXBzaG90KSB1bmJsb2NrcyBpbnN0ZWFkIG9mXG4gICAgICAvLyBoYW5naW5nIHVudGlsIHRoZSBob3N0J3MgMTBzIHRpbWVvdXQuIE5vLW9wIGlmIGFscmVhZHkgcmVzb2x2ZWQuXG4gICAgICBsZXQgcHJldlJlc29sdmVycyA9IHRoaXMuI3Jlc29sdmVycztcbiAgICAgIHRoaXMuI3Jlc29sdmVycyA9IHByb21pc2VXaXRoUmVzb2x2ZXJzKCk7XG4gICAgICB0aGlzLnJlYWR5ID0gdGhpcy4jcmVzb2x2ZXJzLnByb21pc2U7XG4gICAgICBwcmV2UmVzb2x2ZXJzLnByb21pc2UuY2F0Y2goKCkgPT4ge30pO1xuICAgICAgcHJldlJlc29sdmVycy5yZWplY3QobmV3IEVycm9yKFwiW2FueXdpZGdldF0gd2lkZ2V0IGJpbmQgYWJvcnRlZCBieSByZS1iaW5kXCIpKTtcbiAgICB9XG5cbiAgICB0aGlzLiN3aWRnZXREZWYgPSB3aWRnZXREZWY7XG4gICAgdGhpcy4jY29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcbiAgICBsZXQgc2lnbmFsID0gdGhpcy4jY29udHJvbGxlci5zaWduYWw7XG4gICAgbGV0IG1vZGVsID0gdGhpcy4jbW9kZWw7XG5cbiAgICBtb2RlbC5vZmYobnVsbCwgbnVsbCwgSU5JVElBTElaRV9NQVJLRVIpO1xuXG4gICAgbGV0IHJlc3VsdCA9IGF3YWl0IHdpZGdldERlZi5pbml0aWFsaXplPy4oe1xuICAgICAgbW9kZWw6IG1vZGVsUHJveHkobW9kZWwsIElOSVRJQUxJWkVfTUFSS0VSKSxcbiAgICAgIHNpZ25hbCxcbiAgICAgIGV4cGVyaW1lbnRhbCxcbiAgICB9KTtcblxuICAgIGlmIChzaWduYWwuYWJvcnRlZCkge1xuICAgICAgYXdhaXQgc2FmZUNsZWFudXAoaXNTYWZlQ2xlYW51cEZ1bmN0aW9uKHJlc3VsdCkgPyByZXN1bHQgOiB1bmRlZmluZWQsIFwiZXNtIHVwZGF0ZVwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBpZiAoaXNTYWZlQ2xlYW51cEZ1bmN0aW9uKHJlc3VsdCkpIHtcbiAgICAgIHNpZ25hbC5hZGRFdmVudExpc3RlbmVyKFwiYWJvcnRcIiwgKCkgPT4gc2FmZUNsZWFudXAocmVzdWx0LCBcImVzbSB1cGRhdGVcIikpO1xuICAgICAgdGhpcy4jZXhwb3J0cyA9IHVuZGVmaW5lZDtcbiAgICB9IGVsc2UgaWYgKHR5cGVvZiByZXN1bHQgPT09IFwib2JqZWN0XCIgJiYgcmVzdWx0ICE9PSBudWxsKSB7XG4gICAgICB0aGlzLiNleHBvcnRzID0gcmVzdWx0O1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLiNleHBvcnRzID0gdW5kZWZpbmVkO1xuICAgIH1cblxuICAgIHRoaXMuI3Jlc29sdmVycy5yZXNvbHZlKHRoaXMuI2V4cG9ydHMpO1xuICB9XG5cbiAgYXN5bmMgY3JlYXRlVmlldyhcbiAgICB0YXJnZXQ6IFZpZXdUYXJnZXQsXG4gICAgeyBzaWduYWwsIGV4cGVyaW1lbnRhbCwgaG9zdCB9OiB7IHNpZ25hbDogQWJvcnRTaWduYWw7IGV4cGVyaW1lbnRhbDogRXhwZXJpbWVudGFsOyBob3N0OiBIb3N0IH0sXG4gICk6IFByb21pc2U8dW5kZWZpbmVkPiB7XG4gICAgYXdhaXQgdGhpcy5yZWFkeTtcbiAgICBpZiAoIXRoaXMuI3dpZGdldERlZj8ucmVuZGVyKSByZXR1cm47XG4gICAgbGV0IGNvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG4gICAgbGV0IGNvbWJpbmVkID0gQWJvcnRTaWduYWwuYW55KFtzaWduYWwsIGNvbnRyb2xsZXIuc2lnbmFsXSk7XG4gICAgbGV0IG1vZGVsID0gdGhpcy4jbW9kZWw7XG4gICAgbGV0IGNsZWFudXAgPSBhd2FpdCB0aGlzLiN3aWRnZXREZWYucmVuZGVyKHtcbiAgICAgIG1vZGVsOiBtb2RlbFByb3h5KG1vZGVsLCB0YXJnZXQpLFxuICAgICAgZWw6IHRhcmdldC5lbCxcbiAgICAgIHNpZ25hbDogY29tYmluZWQsXG4gICAgICBob3N0LFxuICAgICAgZXhwZXJpbWVudGFsLFxuICAgIH0pO1xuICAgIGxldCBkaXNwb3NlVmlldyA9IChyZWFzb246IHN0cmluZyk6IHZvaWQgPT4ge1xuICAgICAgLy8gQ2xlYXIgbGlzdGVuZXJzIGtleWVkIHRvIHRoaXMgdGFyZ2V0LiBGb3IgZXBoZW1lcmFsIGB7ZWx9YCB0YXJnZXRzXG4gICAgICAvLyAoaG9zdC5nZXRXaWRnZXQoKS5yZW5kZXIpLCB0aGlzIHByZXZlbnRzIGxlYWtzIGFjcm9zcyByZS1yZW5kZXJzLlxuICAgICAgbW9kZWwub2ZmKG51bGwsIG51bGwsIHRhcmdldCk7XG4gICAgICB2b2lkIHNhZmVDbGVhbnVwKGNsZWFudXAsIHJlYXNvbik7XG4gICAgfTtcbiAgICBpZiAoY29tYmluZWQuYWJvcnRlZCkge1xuICAgICAgZGlzcG9zZVZpZXcoXCJkaXNwb3NlIHZpZXcgLSBhbHJlYWR5IGFib3J0ZWRcIik7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbWJpbmVkLmFkZEV2ZW50TGlzdGVuZXIoXCJhYm9ydFwiLCAoKSA9PiBkaXNwb3NlVmlldyhcImRpc3Bvc2UgdmlldyAtIGFib3J0ZWRcIikpO1xuICB9XG5cbiAgZ2V0IGV4cG9ydHMoKTogdW5rbm93biB7XG4gICAgcmV0dXJuIHRoaXMuI2V4cG9ydHM7XG4gIH1cblxuICBkZXN0cm95KCk6IHZvaWQge1xuICAgIHRoaXMuI2NvbnRyb2xsZXI/LmFib3J0KCk7XG4gICAgdGhpcy4jY29udHJvbGxlciA9IHVuZGVmaW5lZDtcbiAgICB0aGlzLiN3aWRnZXREZWYgPSB1bmRlZmluZWQ7XG4gIH1cbn1cblxuY2xhc3MgQmluZGluZ01hbmFnZXIge1xuICAjYmluZGluZ3MgPSBuZXcgTWFwPERPTVdpZGdldE1vZGVsLCBXaWRnZXRCaW5kaW5nPigpO1xuXG4gIGdldE9yQ3JlYXRlKG1vZGVsOiBET01XaWRnZXRNb2RlbCk6IFdpZGdldEJpbmRpbmcge1xuICAgIGxldCBiaW5kaW5nID0gdGhpcy4jYmluZGluZ3MuZ2V0KG1vZGVsKTtcbiAgICBpZiAoIWJpbmRpbmcpIHtcbiAgICAgIGJpbmRpbmcgPSBuZXcgV2lkZ2V0QmluZGluZyhtb2RlbCk7XG4gICAgICB0aGlzLiNiaW5kaW5ncy5zZXQobW9kZWwsIGJpbmRpbmcpO1xuICAgIH1cbiAgICByZXR1cm4gYmluZGluZztcbiAgfVxuXG4gIGdldChtb2RlbDogRE9NV2lkZ2V0TW9kZWwpOiBXaWRnZXRCaW5kaW5nIHwgdW5kZWZpbmVkIHtcbiAgICByZXR1cm4gdGhpcy4jYmluZGluZ3MuZ2V0KG1vZGVsKTtcbiAgfVxuXG4gIGRlc3Ryb3kobW9kZWw6IERPTVdpZGdldE1vZGVsKTogdm9pZCB7XG4gICAgbGV0IGJpbmRpbmcgPSB0aGlzLiNiaW5kaW5ncy5nZXQobW9kZWwpO1xuICAgIGlmIChiaW5kaW5nKSB7XG4gICAgICBiaW5kaW5nLmRlc3Ryb3koKTtcbiAgICAgIHRoaXMuI2JpbmRpbmdzLmRlbGV0ZShtb2RlbCk7XG4gICAgfVxuICB9XG59XG5cbmV4cG9ydCBsZXQgQklORElOR1MgPSBuZXcgQmluZGluZ01hbmFnZXIoKTtcbiIsImltcG9ydCB0eXBlIHsgQW55TW9kZWwgfSBmcm9tIFwiQGFueXdpZGdldC90eXBlc1wiO1xuaW1wb3J0ICogYXMgdXVpZCBmcm9tIFwiQGx1a2VlZC91dWlkXCI7XG5cbmV4cG9ydCBpbnRlcmZhY2UgSW52b2tlT3B0aW9ucyB7XG4gIGJ1ZmZlcnM/OiBEYXRhVmlld1tdO1xuICBzaWduYWw/OiBBYm9ydFNpZ25hbDtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGludm9rZTxUPihcbiAgbW9kZWw6IEFueU1vZGVsLFxuICBuYW1lOiBzdHJpbmcsXG4gIG1zZz86IHVua25vd24sXG4gIG9wdGlvbnM6IEludm9rZU9wdGlvbnMgPSB7fSxcbik6IFByb21pc2U8W1QsIERhdGFWaWV3W11dPiB7XG4gIC8vIGNyeXB0by5yYW5kb21VVUlEKCkgaXMgbm90IGF2YWlsYWJsZSBpbiBub24tc2VjdXJlIGNvbnRleHRzIChpLmUuLCBodHRwOi8vKVxuICAvLyBzbyB3ZSB1c2Ugc2ltcGxlIChub24tc2VjdXJlKSBwb2x5ZmlsbC5cbiAgbGV0IGlkID0gdXVpZC52NCgpO1xuICBsZXQgc2lnbmFsID0gb3B0aW9ucy5zaWduYWwgPz8gQWJvcnRTaWduYWwudGltZW91dCgzMDAwKTtcblxuICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgIGlmIChzaWduYWwuYWJvcnRlZCkge1xuICAgICAgcmVqZWN0KHNpZ25hbC5yZWFzb24pO1xuICAgIH1cbiAgICBzaWduYWwuYWRkRXZlbnRMaXN0ZW5lcihcImFib3J0XCIsICgpID0+IHtcbiAgICAgIG1vZGVsLm9mZihcIm1zZzpjdXN0b21cIiwgaGFuZGxlcik7XG4gICAgICByZWplY3Qoc2lnbmFsLnJlYXNvbik7XG4gICAgfSk7XG5cbiAgICBmdW5jdGlvbiBoYW5kbGVyKFxuICAgICAgbXNnOiB7IGlkOiBzdHJpbmc7IGtpbmQ6IFwiYW55d2lkZ2V0LWNvbW1hbmQtcmVzcG9uc2VcIjsgcmVzcG9uc2U6IFQgfSxcbiAgICAgIGJ1ZmZlcnM6IERhdGFWaWV3W10sXG4gICAgKTogdm9pZCB7XG4gICAgICBpZiAoIShtc2cuaWQgPT09IGlkKSkgcmV0dXJuO1xuICAgICAgcmVzb2x2ZShbbXNnLnJlc3BvbnNlLCBidWZmZXJzXSk7XG4gICAgICBtb2RlbC5vZmYoXCJtc2c6Y3VzdG9tXCIsIGhhbmRsZXIpO1xuICAgIH1cbiAgICBtb2RlbC5vbihcIm1zZzpjdXN0b21cIiwgaGFuZGxlcik7XG4gICAgbW9kZWwuc2VuZCh7IGlkLCBraW5kOiBcImFueXdpZGdldC1jb21tYW5kXCIsIG5hbWUsIG1zZyB9LCB1bmRlZmluZWQsIG9wdGlvbnMuYnVmZmVycyA/PyBbXSk7XG4gIH0pO1xufVxuIiwiZXhwb3J0IGxldCBXSURHRVRfUkVGX1BSRUZJWCA9IFwiYW55d2lkZ2V0OlwiO1xuXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VXaWRnZXRSZWYocmVmOiB1bmtub3duKTogc3RyaW5nIHtcbiAgaWYgKHR5cGVvZiByZWYgPT09IFwic3RyaW5nXCIgJiYgcmVmLnN0YXJ0c1dpdGgoV0lER0VUX1JFRl9QUkVGSVgpKSB7XG4gICAgcmV0dXJuIHJlZi5zbGljZShXSURHRVRfUkVGX1BSRUZJWC5sZW5ndGgpO1xuICB9XG4gIHRocm93IG5ldyBFcnJvcihgW2FueXdpZGdldF0gSW52YWxpZCB3aWRnZXQgcmVmZXJlbmNlOiAke0pTT04uc3RyaW5naWZ5KHJlZil9YCk7XG59XG4iLCJpbXBvcnQgdHlwZSB7IEhvc3QgfSBmcm9tIFwiQGFueXdpZGdldC90eXBlc1wiO1xuaW1wb3J0IHR5cGUgeyBET01XaWRnZXRNb2RlbCB9IGZyb20gXCJAanVweXRlci13aWRnZXRzL2Jhc2VcIjtcblxuaW1wb3J0IHsgQklORElOR1MgfSBmcm9tIFwiLi9iaW5kaW5nLnRzXCI7XG5pbXBvcnQgeyBpbnZva2UgfSBmcm9tIFwiLi9pbnZva2UudHNcIjtcbmltcG9ydCB7IG1vZGVsUHJveHkgfSBmcm9tIFwiLi9tb2RlbC1wcm94eS50c1wiO1xuaW1wb3J0IHsgcGFyc2VXaWRnZXRSZWYgfSBmcm9tIFwiLi93aWRnZXQtcmVmLnRzXCI7XG5cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVIb3N0KG1vZGVsOiBET01XaWRnZXRNb2RlbCwgeyBzaWduYWwgfTogeyBzaWduYWw6IEFib3J0U2lnbmFsIH0pOiBIb3N0IHtcbiAgbGV0IGhvc3Q6IEhvc3QgPSB7XG4gICAgLy8gQHRzLWV4cGVjdC1lcnJvciAtIG1vZGVsUHJveHkgcmV0dXJucyBBbnlNb2RlbDsgZ2VuZXJpYyBUIGlzIGVyYXNlZCBhdCBydW50aW1lXG4gICAgYXN5bmMgZ2V0TW9kZWwocmVmKSB7XG4gICAgICBsZXQgbW9kZWxJZCA9IHBhcnNlV2lkZ2V0UmVmKHJlZik7XG4gICAgICBsZXQgY2hpbGRNb2RlbCA9IGF3YWl0IG1vZGVsLndpZGdldF9tYW5hZ2VyLmdldF9tb2RlbChtb2RlbElkKTtcbiAgICAgIGxldCBjb250ZXh0ID0gU3ltYm9sKFwiYW55d2lkZ2V0Lmhvc3QuZ2V0TW9kZWxcIik7XG4gICAgICBzaWduYWwuYWRkRXZlbnRMaXN0ZW5lcihcImFib3J0XCIsICgpID0+IGNoaWxkTW9kZWwub2ZmKG51bGwsIG51bGwsIGNvbnRleHQpKTtcbiAgICAgIHJldHVybiBtb2RlbFByb3h5KGNoaWxkTW9kZWwsIGNvbnRleHQpO1xuICAgIH0sXG4gICAgLy8gQHRzLWV4cGVjdC1lcnJvciAtIGdlbmVyaWMgVCBpcyBlcmFzZWQgYXQgcnVudGltZSwgZXhwb3J0cyB0eXBlZCBhcyB1bmtub3duXG4gICAgYXN5bmMgZ2V0V2lkZ2V0KHJlZikge1xuICAgICAgbGV0IG1vZGVsSWQgPSBwYXJzZVdpZGdldFJlZihyZWYpO1xuICAgICAgbGV0IGNoaWxkTW9kZWwgPSBhd2FpdCBtb2RlbC53aWRnZXRfbWFuYWdlci5nZXRfbW9kZWwobW9kZWxJZCk7XG4gICAgICBsZXQgY2hpbGRCaW5kaW5nID0gQklORElOR1MuZ2V0KGNoaWxkTW9kZWwpO1xuICAgICAgaWYgKCFjaGlsZEJpbmRpbmcpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBbYW55d2lkZ2V0XSBObyBiaW5kaW5nIGZvdW5kIGZvciB3aWRnZXQgJHttb2RlbElkfWApO1xuICAgICAgfVxuICAgICAgbGV0IHRpbWVyOiBSZXR1cm5UeXBlPHR5cGVvZiBzZXRUaW1lb3V0PiB8IHVuZGVmaW5lZDtcbiAgICAgIGxldCBleHBvcnRzID0gYXdhaXQgbmV3IFByb21pc2U8dW5rbm93bj4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgICB0aW1lciA9IHNldFRpbWVvdXQoXG4gICAgICAgICAgKCkgPT5cbiAgICAgICAgICAgIHJlamVjdChuZXcgRXJyb3IoYFthbnl3aWRnZXRdIFRpbWVkIG91dCB3YWl0aW5nIGZvciB3aWRnZXQgJHttb2RlbElkfSB0byBpbml0aWFsaXplYCkpLFxuICAgICAgICAgIDEwXzAwMCxcbiAgICAgICAgKTtcbiAgICAgICAgY2hpbGRCaW5kaW5nLnJlYWR5LnRoZW4ocmVzb2x2ZSwgcmVqZWN0KTtcbiAgICAgIH0pLmZpbmFsbHkoKCkgPT4gY2xlYXJUaW1lb3V0KHRpbWVyKSk7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBleHBvcnRzLFxuICAgICAgICBhc3luYyByZW5kZXIoeyBlbCwgc2lnbmFsOiB2aWV3U2lnbmFsIH0pIHtcbiAgICAgICAgICBsZXQgY2hpbGRWaWV3U2lnbmFsID0gdmlld1NpZ25hbCA/PyBzaWduYWw7XG4gICAgICAgICAgYXdhaXQgY2hpbGRCaW5kaW5nLmNyZWF0ZVZpZXcoXG4gICAgICAgICAgICB7IGVsIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIHNpZ25hbDogY2hpbGRWaWV3U2lnbmFsLFxuICAgICAgICAgICAgICBleHBlcmltZW50YWw6IHtcbiAgICAgICAgICAgICAgICAvLyBAdHMtZXhwZWN0LWVycm9yIC0gYmluZCBpc24ndCB3b3JraW5nXG4gICAgICAgICAgICAgICAgaW52b2tlOiBpbnZva2UuYmluZChudWxsLCBjaGlsZE1vZGVsKSxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgaG9zdCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgKTtcbiAgICAgICAgfSxcbiAgICAgIH07XG4gICAgfSxcbiAgfTtcbiAgcmV0dXJuIGhvc3Q7XG59XG4iLCJpbXBvcnQgdHlwZSB7IEluaXRpYWxpemUsIFJlbmRlciB9IGZyb20gXCJAYW55d2lkZ2V0L3R5cGVzXCI7XG5cbmltcG9ydCB7IGFzc2VydCB9IGZyb20gXCIuL3V0aWwudHNcIjtcblxuZXhwb3J0IGludGVyZmFjZSBBbnlXaWRnZXQge1xuICBpbml0aWFsaXplPzogSW5pdGlhbGl6ZTtcbiAgcmVuZGVyPzogUmVuZGVyO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIEFueVdpZGdldE1vZHVsZSB7XG4gIHJlbmRlcj86IFJlbmRlcjtcbiAgZGVmYXVsdD86IEFueVdpZGdldCB8ICgoKSA9PiBBbnlXaWRnZXQgfCBQcm9taXNlPEFueVdpZGdldD4pO1xufVxuXG5mdW5jdGlvbiBpc0hyZWYoc3RyOiBzdHJpbmcpOiBzdHIgaXMgYGh0dHBzOi8vJHtzdHJpbmd9YCB8IGBodHRwOi8vJHtzdHJpbmd9YCB7XG4gIHJldHVybiBzdHIuc3RhcnRzV2l0aChcImh0dHA6Ly9cIikgfHwgc3RyLnN0YXJ0c1dpdGgoXCJodHRwczovL1wiKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gbG9hZENzc0hyZWYoaHJlZjogc3RyaW5nLCBhbnl3aWRnZXRJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGxldCBwcmV2ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcjxIVE1MTGlua0VsZW1lbnQ+KGBsaW5rW2lkPScke2FueXdpZGdldElkfSddYCk7XG5cbiAgLy8gQWRhcHRlZCBmcm9tIGh0dHBzOi8vZ2l0aHViLmNvbS92aXRlanMvdml0ZS9ibG9iL2Q1OWUxYWNjMmVmYzAzMDc0ODgzNjRlOWYyZmFkNTI4ZWM1N2YyMDQvcGFja2FnZXMvdml0ZS9zcmMvY2xpZW50L2NsaWVudC50cyNMMTg1LUwyMDFcbiAgLy8gU3dhcHMgb3V0IG9sZCBzdHlsZXMgd2l0aCBuZXcsIGJ1dCBhdm9pZHMgZmxhc2ggb2YgdW5zdHlsZWQgY29udGVudC5cbiAgLy8gTm8gbmVlZCB0byBhd2FpdCB0aGUgbG9hZCBzaW5jZSB3ZSBhbHJlYWR5IGhhdmUgc3R5bGVzIGFwcGxpZWQuXG4gIGlmIChwcmV2KSB7XG4gICAgLy8gb3hsaW50LWRpc2FibGUtbmV4dC1saW5lIHR5cGVzY3JpcHQtZXNsaW50L25vLXVuc2FmZS10eXBlLWFzc2VydGlvbiAtLSBOb2RlLmNsb25lTm9kZSgpIHJldHVybnMgTm9kZTsgd2Uga25vdyBwcmV2IGlzIEhUTUxMaW5rRWxlbWVudCBzbyB0aGUgY2xvbmUgaXMgdG9vXG4gICAgbGV0IG5ld0xpbmsgPSBwcmV2LmNsb25lTm9kZSgpIGFzIHVua25vd24gYXMgSFRNTExpbmtFbGVtZW50O1xuICAgIG5ld0xpbmsuaHJlZiA9IGhyZWY7XG4gICAgbmV3TGluay5hZGRFdmVudExpc3RlbmVyKFwibG9hZFwiLCAoKSA9PiBwcmV2Py5yZW1vdmUoKSk7XG4gICAgbmV3TGluay5hZGRFdmVudExpc3RlbmVyKFwiZXJyb3JcIiwgKCkgPT4gcHJldj8ucmVtb3ZlKCkpO1xuICAgIHByZXYuYWZ0ZXIobmV3TGluayk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG4gICAgbGV0IGxpbmsgPSBPYmplY3QuYXNzaWduKGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJsaW5rXCIpLCB7XG4gICAgICByZWw6IFwic3R5bGVzaGVldFwiLFxuICAgICAgaHJlZixcbiAgICAgIG9ubG9hZDogcmVzb2x2ZSxcbiAgICB9KTtcbiAgICBkb2N1bWVudC5oZWFkLmFwcGVuZENoaWxkKGxpbmspO1xuICB9KTtcbn1cblxuZnVuY3Rpb24gbG9hZENzc1RleHQoY3NzVGV4dDogc3RyaW5nLCBhbnl3aWRnZXRJZDogc3RyaW5nKTogdm9pZCB7XG4gIGxldCBwcmV2ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcjxIVE1MU3R5bGVFbGVtZW50Pihgc3R5bGVbaWQ9JyR7YW55d2lkZ2V0SWR9J11gKTtcbiAgaWYgKHByZXYpIHtcbiAgICAvLyByZXBsYWNlIGluc3RlYWQgb2YgY3JlYXRpbmcgYSBuZXcgRE9NIG5vZGVcbiAgICBwcmV2LnRleHRDb250ZW50ID0gY3NzVGV4dDtcbiAgICByZXR1cm47XG4gIH1cbiAgbGV0IHN0eWxlID0gT2JqZWN0LmFzc2lnbihkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic3R5bGVcIiksIHtcbiAgICBpZDogYW55d2lkZ2V0SWQsXG4gICAgdHlwZTogXCJ0ZXh0L2Nzc1wiLFxuICB9KTtcbiAgc3R5bGUuYXBwZW5kQ2hpbGQoZG9jdW1lbnQuY3JlYXRlVGV4dE5vZGUoY3NzVGV4dCkpO1xuICBkb2N1bWVudC5oZWFkLmFwcGVuZENoaWxkKHN0eWxlKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGxvYWRDc3MoY3NzOiBzdHJpbmcgfCB1bmRlZmluZWQsIGFueXdpZGdldElkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgaWYgKCFjc3MgfHwgIWFueXdpZGdldElkKSByZXR1cm47XG4gIGlmIChpc0hyZWYoY3NzKSkgcmV0dXJuIGxvYWRDc3NIcmVmKGNzcywgYW55d2lkZ2V0SWQpO1xuICByZXR1cm4gbG9hZENzc1RleHQoY3NzLCBhbnl3aWRnZXRJZCk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGxvYWRFc20oZXNtOiBzdHJpbmcpOiBQcm9taXNlPEFueVdpZGdldE1vZHVsZT4ge1xuICBpZiAoaXNIcmVmKGVzbSkpIHtcbiAgICByZXR1cm4gYXdhaXQgaW1wb3J0KC8qIHdlYnBhY2tJZ25vcmU6IHRydWUgKi8gLyogQHZpdGUtaWdub3JlICovIGVzbSk7XG4gIH1cbiAgbGV0IHVybCA9IFVSTC5jcmVhdGVPYmplY3RVUkwobmV3IEJsb2IoW2VzbV0sIHsgdHlwZTogXCJ0ZXh0L2phdmFzY3JpcHRcIiB9KSk7XG4gIGxldCBtb2QgPSBhd2FpdCBpbXBvcnQoLyogd2VicGFja0lnbm9yZTogdHJ1ZSAqLyAvKiBAdml0ZS1pZ25vcmUgKi8gdXJsKTtcbiAgVVJMLnJldm9rZU9iamVjdFVSTCh1cmwpO1xuICByZXR1cm4gbW9kO1xufVxuXG5mdW5jdGlvbiB3YXJuUmVuZGVyRGVwcmVjYXRpb24oYW55d2lkZ2V0SWQ6IHN0cmluZyk6IHZvaWQge1xuICBjb25zb2xlLndhcm4oYFxcXG5bYW55d2lkZ2V0XSBEZXByZWNhdGlvbiBXYXJuaW5nIGZvciAke2FueXdpZGdldElkfTogRGlyZWN0IGV4cG9ydCBvZiBhICdyZW5kZXInIHdpbGwgbGlrZWx5IGJlIGRlcHJlY2F0ZWQgaW4gdGhlIGZ1dHVyZS4gVG8gbWlncmF0ZSAuLi5cblxuUmVtb3ZlIHRoZSAnZXhwb3J0JyBrZXl3b3JkIGZyb20gJ3JlbmRlcidcbi0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmV4cG9ydCBmdW5jdGlvbiByZW5kZXIoeyBtb2RlbCwgZWwgfSkgeyAuLi4gfVxuXl5eXl5eXG5cbkNyZWF0ZSBhIGRlZmF1bHQgZXhwb3J0IHRoYXQgcmV0dXJucyBhbiBvYmplY3Qgd2l0aCAncmVuZGVyJ1xuLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmZ1bmN0aW9uIHJlbmRlcih7IG1vZGVsLCBlbCB9KSB7IC4uLiB9XG4gICAgICAgICBeXl5eXl5cbmV4cG9ydCBkZWZhdWx0IHsgcmVuZGVyIH1cbiAgICAgICAgICAgICAgICAgXl5eXl5eXG5cblBpbiB0byBhbnl3aWRnZXQ+PTAuOS4wIGluIHlvdXIgcHlwcm9qZWN0LnRvbWxcbi0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZGVwZW5kZW5jaWVzID0gW1wiYW55d2lkZ2V0Pj0wLjkuMFwiXVxuXG5UbyBsZWFybiBtb3JlLCBwbGVhc2Ugc2VlOiBodHRwczovL2dpdGh1Yi5jb20vbWFuenQvYW55d2lkZ2V0L3B1bGwvMzk1LlxuYCk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBsb2FkV2lkZ2V0KGVzbTogc3RyaW5nLCBhbnl3aWRnZXRJZDogc3RyaW5nKTogUHJvbWlzZTxBbnlXaWRnZXQ+IHtcbiAgbGV0IG1vZCA9IGF3YWl0IGxvYWRFc20oZXNtKTtcbiAgaWYgKG1vZC5yZW5kZXIpIHtcbiAgICB3YXJuUmVuZGVyRGVwcmVjYXRpb24oYW55d2lkZ2V0SWQpO1xuICAgIHJldHVybiB7XG4gICAgICBhc3luYyBpbml0aWFsaXplKCkge30sXG4gICAgICByZW5kZXI6IG1vZC5yZW5kZXIsXG4gICAgfTtcbiAgfVxuICBhc3NlcnQobW9kLmRlZmF1bHQsIGBbYW55d2lkZ2V0XSBtb2R1bGUgbXVzdCBleHBvcnQgYSBkZWZhdWx0IGZ1bmN0aW9uIG9yIG9iamVjdC5gKTtcbiAgbGV0IHdpZGdldCA9IHR5cGVvZiBtb2QuZGVmYXVsdCA9PT0gXCJmdW5jdGlvblwiID8gYXdhaXQgbW9kLmRlZmF1bHQoKSA6IG1vZC5kZWZhdWx0O1xuICByZXR1cm4gd2lkZ2V0O1xufVxuIiwiaW1wb3J0IHR5cGUgeyBBbnlNb2RlbCB9IGZyb20gXCJAYW55d2lkZ2V0L3R5cGVzXCI7XG5pbXBvcnQgKiBhcyBzb2xpZCBmcm9tIFwic29saWQtanNcIjtcblxuZXhwb3J0IGZ1bmN0aW9uIG9ic2VydmU8VCBleHRlbmRzIFJlY29yZDxzdHJpbmcsIHVua25vd24+LCBLIGV4dGVuZHMga2V5b2YgVCAmIHN0cmluZz4oXG4gIG1vZGVsOiBBbnlNb2RlbDxUPixcbiAgbmFtZTogSyxcbiAgeyBzaWduYWwgfTogeyBzaWduYWw/OiBBYm9ydFNpZ25hbCB9LFxuKTogc29saWQuQWNjZXNzb3I8VFtLXT4ge1xuICBsZXQgW2dldCwgc2V0XSA9IHNvbGlkLmNyZWF0ZVNpZ25hbChtb2RlbC5nZXQobmFtZSkpO1xuICBsZXQgdXBkYXRlID0gKCkgPT4gc2V0KCgpID0+IG1vZGVsLmdldChuYW1lKSk7XG4gIG1vZGVsLm9uKGBjaGFuZ2U6JHtuYW1lfWAsIHVwZGF0ZSk7XG4gIHNpZ25hbD8uYWRkRXZlbnRMaXN0ZW5lcihcImFib3J0XCIsICgpID0+IHtcbiAgICBtb2RlbC5vZmYoYGNoYW5nZToke25hbWV9YCwgdXBkYXRlKTtcbiAgfSk7XG4gIHJldHVybiBnZXQ7XG59XG4iLCJpbXBvcnQgdHlwZSB7IEFueU1vZGVsLCBFeHBlcmltZW50YWwgfSBmcm9tIFwiQGFueXdpZGdldC90eXBlc1wiO1xuaW1wb3J0IHR5cGUgeyBET01XaWRnZXRNb2RlbCwgRE9NV2lkZ2V0VmlldyB9IGZyb20gXCJAanVweXRlci13aWRnZXRzL2Jhc2VcIjtcbmltcG9ydCAqIGFzIHNvbGlkIGZyb20gXCJzb2xpZC1qc1wiO1xuXG5pbXBvcnQgeyBCSU5ESU5HUyB9IGZyb20gXCIuL2JpbmRpbmcudHNcIjtcbmltcG9ydCB7IGNyZWF0ZUhvc3QgfSBmcm9tIFwiLi9ob3N0LnRzXCI7XG5pbXBvcnQgeyBpbnZva2UgfSBmcm9tIFwiLi9pbnZva2UudHNcIjtcbmltcG9ydCB7IHR5cGUgQW55V2lkZ2V0LCBsb2FkQ3NzLCBsb2FkV2lkZ2V0IH0gZnJvbSBcIi4vbG9hZC50c1wiO1xuaW1wb3J0IHsgb2JzZXJ2ZSB9IGZyb20gXCIuL29ic2VydmUudHNcIjtcbmltcG9ydCB7IGFzc2VydCwgdHlwZSBSZXN1bHQsIHRocm93QW55d2lkZ2V0RXJyb3IgfSBmcm9tIFwiLi91dGlsLnRzXCI7XG5cbmludGVyZmFjZSBTdGF0ZSB7XG4gIFtrZXk6IHN0cmluZ106IHVua25vd247XG4gIF9lc206IHN0cmluZztcbiAgX2FueXdpZGdldF9pZDogc3RyaW5nO1xuICBfY3NzOiBzdHJpbmcgfCB1bmRlZmluZWQ7XG59XG5cbmV4cG9ydCBjbGFzcyBSdW50aW1lIHtcbiAgLy8gQHRzLWV4cGVjdC1lcnJvciAtIFNldCBzeW5jaHJvbm91c2x5IGluIGNvbnN0cnVjdG9yLlxuICAjd2lkZ2V0UmVzdWx0OiBzb2xpZC5BY2Nlc3NvcjxSZXN1bHQ8QW55V2lkZ2V0Pj47XG4gICNzaWduYWw6IEFib3J0U2lnbmFsO1xuXG4gIGNvbnN0cnVjdG9yKG1vZGVsOiBET01XaWRnZXRNb2RlbCwgb3B0aW9uczogeyBzaWduYWw6IEFib3J0U2lnbmFsIH0pIHtcbiAgICB0aGlzLiNzaWduYWwgPSBvcHRpb25zLnNpZ25hbDtcbiAgICB0aGlzLiNzaWduYWwudGhyb3dJZkFib3J0ZWQoKTtcbiAgICB0aGlzLiNzaWduYWwuYWRkRXZlbnRMaXN0ZW5lcihcImFib3J0XCIsICgpID0+IGRpc3Bvc2UoKSk7XG4gICAgbGV0IGJpbmRpbmcgPSBCSU5ESU5HUy5nZXRPckNyZWF0ZShtb2RlbCk7XG4gICAgbGV0IGV4cGVyaW1lbnRhbDogRXhwZXJpbWVudGFsID0ge1xuICAgICAgLy8gQHRzLWV4cGVjdC1lcnJvciAtIGludm9rZS5iaW5kIGxvc2VzIGdlbmVyaWMgdHlwZSBwYXJhbWV0ZXJcbiAgICAgIGludm9rZTogaW52b2tlLmJpbmQobnVsbCwgbW9kZWwpLFxuICAgIH07XG4gICAgbGV0IGRpc3Bvc2UgPSBzb2xpZC5jcmVhdGVSb290KChkaXNwb3NlKSA9PiB7XG4gICAgICAvLyBET01XaWRnZXRNb2RlbCBpcyB1bnR5cGVkIGJ5IHRyYWl0IHNoYXBlOyB3ZSBrbm93IHRoZSBhbnl3aWRnZXQgdHJhaXRzLCBzbyBuYXJyb3cgdG8gQW55TW9kZWw8U3RhdGU+IGZvciB0eXBlLXNhZmUgYC5nZXQoKWAgYWNjZXNzXG4gICAgICAvLyBveGxpbnQtZGlzYWJsZS1uZXh0LWxpbmUgdHlwZXNjcmlwdC1lc2xpbnQvbm8tdW5zYWZlLXR5cGUtYXNzZXJ0aW9uIC0tIHNlZSBhYm92ZVxuICAgICAgbGV0IHR5cGVkTW9kZWwgPSBtb2RlbCBhcyB1bmtub3duIGFzIEFueU1vZGVsPFN0YXRlPjtcbiAgICAgIGxldCBpZCA9IHR5cGVkTW9kZWwuZ2V0KFwiX2FueXdpZGdldF9pZFwiKTtcbiAgICAgIGxldCBjc3MgPSBvYnNlcnZlKHR5cGVkTW9kZWwsIFwiX2Nzc1wiLCB7IHNpZ25hbDogdGhpcy4jc2lnbmFsIH0pO1xuICAgICAgbGV0IGVzbSA9IG9ic2VydmUodHlwZWRNb2RlbCwgXCJfZXNtXCIsIHsgc2lnbmFsOiB0aGlzLiNzaWduYWwgfSk7XG4gICAgICBsZXQgW3dpZGdldFJlc3VsdCwgc2V0V2lkZ2V0UmVzdWx0XSA9IHNvbGlkLmNyZWF0ZVNpZ25hbDxSZXN1bHQ8QW55V2lkZ2V0Pj4oe1xuICAgICAgICBzdGF0dXM6IFwicGVuZGluZ1wiLFxuICAgICAgfSk7XG4gICAgICB0aGlzLiN3aWRnZXRSZXN1bHQgPSB3aWRnZXRSZXN1bHQ7XG5cbiAgICAgIHNvbGlkLmNyZWF0ZUVmZmVjdChcbiAgICAgICAgc29saWQub24oY3NzLCAoKSA9PiBjb25zb2xlLmRlYnVnKGBbYW55d2lkZ2V0XSBjc3MgaG90IHVwZGF0ZWQ6ICR7aWR9YCksIHsgZGVmZXI6IHRydWUgfSksXG4gICAgICApO1xuICAgICAgc29saWQuY3JlYXRlRWZmZWN0KFxuICAgICAgICBzb2xpZC5vbihlc20sICgpID0+IGNvbnNvbGUuZGVidWcoYFthbnl3aWRnZXRdIGVzbSBob3QgdXBkYXRlZDogJHtpZH1gKSwgeyBkZWZlcjogdHJ1ZSB9KSxcbiAgICAgICk7XG4gICAgICBzb2xpZC5jcmVhdGVFZmZlY3QoKCkgPT4ge1xuICAgICAgICByZXR1cm4gbG9hZENzcyhjc3MoKSwgaWQpO1xuICAgICAgfSk7XG4gICAgICBzb2xpZC5jcmVhdGVFZmZlY3QoKCkgPT4ge1xuICAgICAgICAvLyBQZXItZWZmZWN0IGNvbnRyb2xsZXIgc28gYSBzdGFsZSBsb2FkV2lkZ2V0IHJlc29sdXRpb24gZnJvbSBhXG4gICAgICAgIC8vIHByZXZpb3VzIF9lc20gdmFsdWUgY2Fubm90IG92ZXJ3cml0ZSBhIG5ld2VyIG9uZS4gU29saWQgZmlyZXNcbiAgICAgICAgLy8gb25DbGVhbnVwIGJlZm9yZSByZS1ydW5uaW5nIHRoZSBlZmZlY3QsIGFib3J0aW5nIHRoZSBwcmlvciBsb2FkLlxuICAgICAgICBsZXQgY29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcbiAgICAgICAgc29saWQub25DbGVhbnVwKCgpID0+IGNvbnRyb2xsZXIuYWJvcnQoKSk7XG4gICAgICAgIGxvYWRXaWRnZXQoZXNtKCksIGlkKVxuICAgICAgICAgIC50aGVuKGFzeW5jICh3aWRnZXQpID0+IHtcbiAgICAgICAgICAgIGlmIChjb250cm9sbGVyLnNpZ25hbC5hYm9ydGVkKSByZXR1cm47XG4gICAgICAgICAgICBhd2FpdCBiaW5kaW5nLmJpbmQod2lkZ2V0LCB7IGV4cGVyaW1lbnRhbCB9KTtcbiAgICAgICAgICAgIGlmIChjb250cm9sbGVyLnNpZ25hbC5hYm9ydGVkKSByZXR1cm47XG4gICAgICAgICAgICBzZXRXaWRnZXRSZXN1bHQoeyBzdGF0dXM6IFwicmVhZHlcIiwgZGF0YTogd2lkZ2V0IH0pO1xuICAgICAgICAgIH0pXG4gICAgICAgICAgLmNhdGNoKChlcnJvcikgPT4ge1xuICAgICAgICAgICAgaWYgKGNvbnRyb2xsZXIuc2lnbmFsLmFib3J0ZWQpIHJldHVybjtcbiAgICAgICAgICAgIHNldFdpZGdldFJlc3VsdCh7IHN0YXR1czogXCJlcnJvclwiLCBlcnJvciB9KTtcbiAgICAgICAgICB9KTtcbiAgICAgIH0pO1xuXG4gICAgICByZXR1cm4gZGlzcG9zZTtcbiAgICB9KTtcbiAgfVxuXG4gIGFzeW5jIGNyZWF0ZVZpZXcodmlldzogRE9NV2lkZ2V0Vmlldywgb3B0aW9uczogeyBzaWduYWw6IEFib3J0U2lnbmFsIH0pOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBsZXQgbW9kZWwgPSB2aWV3Lm1vZGVsO1xuICAgIGxldCBzaWduYWwgPSBBYm9ydFNpZ25hbC5hbnkoW3RoaXMuI3NpZ25hbCwgb3B0aW9ucy5zaWduYWxdKTsgLy8gZWl0aGVyIG1vZGVsIG9yIHZpZXcgZGVzdHJveWVkXG4gICAgc2lnbmFsLnRocm93SWZBYm9ydGVkKCk7XG4gICAgc2lnbmFsLmFkZEV2ZW50TGlzdGVuZXIoXCJhYm9ydFwiLCAoKSA9PiBkaXNwb3NlKCkpO1xuICAgIGxldCBiaW5kaW5nID0gQklORElOR1MuZ2V0KG1vZGVsKTtcbiAgICBhc3NlcnQoYmluZGluZywgXCJbYW55d2lkZ2V0XSBXaWRnZXRCaW5kaW5nIG5vdCBmb3VuZC5cIik7XG4gICAgbGV0IGV4cGVyaW1lbnRhbDogRXhwZXJpbWVudGFsID0ge1xuICAgICAgLy8gQHRzLWV4cGVjdC1lcnJvciAtIGludm9rZS5iaW5kIGxvc2VzIGdlbmVyaWMgdHlwZSBwYXJhbWV0ZXJcbiAgICAgIGludm9rZTogaW52b2tlLmJpbmQobnVsbCwgbW9kZWwpLFxuICAgIH07XG4gICAgbGV0IGhvc3QgPSBjcmVhdGVIb3N0KG1vZGVsLCB7IHNpZ25hbCB9KTtcbiAgICBsZXQgZGlzcG9zZSA9IHNvbGlkLmNyZWF0ZVJvb3QoKGRpc3Bvc2UpID0+IHtcbiAgICAgIHNvbGlkLmNyZWF0ZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIC8vIENsZWFyIGFsbCBwcmV2aW91cyBldmVudCBsaXN0ZW5lcnMgZnJvbSB0aGlzIGhvb2suXG4gICAgICAgIG1vZGVsLm9mZihudWxsLCBudWxsLCB2aWV3KTtcbiAgICAgICAgdmlldy4kZWwuZW1wdHkoKTtcbiAgICAgICAgbGV0IHJlc3VsdCA9IHRoaXMuI3dpZGdldFJlc3VsdCgpO1xuICAgICAgICBpZiAocmVzdWx0LnN0YXR1cyA9PT0gXCJwZW5kaW5nXCIpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHJlc3VsdC5zdGF0dXMgPT09IFwiZXJyb3JcIikge1xuICAgICAgICAgIHRocm93QW55d2lkZ2V0RXJyb3IocmVzdWx0LmVycm9yKTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgbGV0IGNvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG4gICAgICAgIHNvbGlkLm9uQ2xlYW51cCgoKSA9PiBjb250cm9sbGVyLmFib3J0KCkpO1xuICAgICAgICBQcm9taXNlLnJlc29sdmUoKVxuICAgICAgICAgIC50aGVuKCgpID0+XG4gICAgICAgICAgICBiaW5kaW5nLmNyZWF0ZVZpZXcodmlldywge1xuICAgICAgICAgICAgICBzaWduYWw6IEFib3J0U2lnbmFsLmFueShbc2lnbmFsLCBjb250cm9sbGVyLnNpZ25hbF0pLFxuICAgICAgICAgICAgICBleHBlcmltZW50YWwsXG4gICAgICAgICAgICAgIGhvc3QsXG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICApXG4gICAgICAgICAgLmNhdGNoKChlcnJvcikgPT4gdGhyb3dBbnl3aWRnZXRFcnJvcihlcnJvcikpO1xuICAgICAgfSk7XG4gICAgICByZXR1cm4gKCkgPT4gZGlzcG9zZSgpO1xuICAgIH0pO1xuICB9XG59XG4iLCJpbXBvcnQgeyBCSU5ESU5HUyB9IGZyb20gXCIuL2JpbmRpbmcudHNcIjtcbmltcG9ydCB7IFJ1bnRpbWUgfSBmcm9tIFwiLi9ydW50aW1lLnRzXCI7XG5pbXBvcnQgeyBhc3NlcnQgfSBmcm9tIFwiLi91dGlsLnRzXCI7XG5cbi8vIEB0cy1leHBlY3QtZXJyb3IgLSBpbmplY3RlZCBieSBidW5kbGVyXG5sZXQgdmVyc2lvbjogc3RyaW5nID0gZ2xvYmFsVGhpcy5WRVJTSU9OO1xuXG5pbnRlcmZhY2UgV2lkZ2V0RmFjdG9yeU9wdGlvbnMge1xuICBET01XaWRnZXRNb2RlbDogdHlwZW9mIGltcG9ydChcIkBqdXB5dGVyLXdpZGdldHMvYmFzZVwiKS5ET01XaWRnZXRNb2RlbDtcbiAgRE9NV2lkZ2V0VmlldzogdHlwZW9mIGltcG9ydChcIkBqdXB5dGVyLXdpZGdldHMvYmFzZVwiKS5ET01XaWRnZXRWaWV3O1xufVxuXG5pbnRlcmZhY2UgV2lkZ2V0RmFjdG9yeVJlc3VsdCB7XG4gIEFueU1vZGVsOiB0eXBlb2YgaW1wb3J0KFwiQGp1cHl0ZXItd2lkZ2V0cy9iYXNlXCIpLkRPTVdpZGdldE1vZGVsO1xuICBBbnlWaWV3OiB0eXBlb2YgaW1wb3J0KFwiQGp1cHl0ZXItd2lkZ2V0cy9iYXNlXCIpLkRPTVdpZGdldFZpZXc7XG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uICh7XG4gIERPTVdpZGdldE1vZGVsLFxuICBET01XaWRnZXRWaWV3LFxufTogV2lkZ2V0RmFjdG9yeU9wdGlvbnMpOiBXaWRnZXRGYWN0b3J5UmVzdWx0IHtcbiAgbGV0IFJVTlRJTUVTID0gbmV3IFdlYWtNYXA8SW5zdGFuY2VUeXBlPHR5cGVvZiBET01XaWRnZXRNb2RlbD4sIFJ1bnRpbWU+KCk7XG5cbiAgY2xhc3MgQW55TW9kZWwgZXh0ZW5kcyBET01XaWRnZXRNb2RlbCB7XG4gICAgc3RhdGljIG1vZGVsX25hbWUgPSBcIkFueU1vZGVsXCI7XG4gICAgc3RhdGljIG1vZGVsX21vZHVsZSA9IFwiYW55d2lkZ2V0XCI7XG4gICAgc3RhdGljIG1vZGVsX21vZHVsZV92ZXJzaW9uID0gdmVyc2lvbjtcblxuICAgIHN0YXRpYyB2aWV3X25hbWUgPSBcIkFueVZpZXdcIjtcbiAgICBzdGF0aWMgdmlld19tb2R1bGUgPSBcImFueXdpZGdldFwiO1xuICAgIHN0YXRpYyB2aWV3X21vZHVsZV92ZXJzaW9uID0gdmVyc2lvbjtcblxuICAgIGluaXRpYWxpemUoLi4uYXJnczogUGFyYW1ldGVyczxJbnN0YW5jZVR5cGU8dHlwZW9mIERPTVdpZGdldE1vZGVsPltcImluaXRpYWxpemVcIl0+KTogdm9pZCB7XG4gICAgICBzdXBlci5pbml0aWFsaXplKC4uLmFyZ3MpO1xuICAgICAgbGV0IGNvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG4gICAgICB0aGlzLm9uY2UoXCJkZXN0cm95XCIsICgpID0+IHtcbiAgICAgICAgY29udHJvbGxlci5hYm9ydChcIlthbnl3aWRnZXRdIFJ1bnRpbWUgZGVzdHJveWVkLlwiKTtcbiAgICAgICAgQklORElOR1MuZGVzdHJveSh0aGlzKTtcbiAgICAgICAgUlVOVElNRVMuZGVsZXRlKHRoaXMpO1xuICAgICAgfSk7XG4gICAgICBSVU5USU1FUy5zZXQodGhpcywgbmV3IFJ1bnRpbWUodGhpcywgeyBzaWduYWw6IGNvbnRyb2xsZXIuc2lnbmFsIH0pKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBXZSBvdmVycmlkZSB0byBzdXBwb3J0IGJpbmFyeSB0cmFpbGV0cyBiZWNhdXNlIEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkoKSlcbiAgICAgKiBkb2VzIG5vdCBwcm9wZXJseSBjbG9uZSBiaW5hcnkgZGF0YSAoaXQganVzdCByZXR1cm5zIGFuIGVtcHR5IG9iamVjdCkuXG4gICAgICpcbiAgICAgKiBodHRwczovL2dpdGh1Yi5jb20vanVweXRlci13aWRnZXRzL2lweXdpZGdldHMvYmxvYi80NzA1OGEzNzNkMmMyYjNhY2YxMDE2NzdiMjc0NWUxNGI3NmRkNzRiL3BhY2thZ2VzL2Jhc2Uvc3JjL3dpZGdldC50cyNMNTYyLUw1ODNcbiAgICAgKi9cbiAgICBzZXJpYWxpemUoc3RhdGU6IFJlY29yZDxzdHJpbmcsIGFueT4pOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHtcbiAgICAgIC8vIG94bGludC1kaXNhYmxlLW5leHQtbGluZSB0eXBlc2NyaXB0LWVzbGludC9uby11bnNhZmUtdHlwZS1hc3NlcnRpb24gLS0gYWNjZXNzaW5nIHN0YXRpYyBgLnNlcmlhbGl6ZXJzYCBvbiBgdGhpcy5jb25zdHJ1Y3RvcmBcbiAgICAgIGxldCBzZXJpYWxpemVycyA9ICh0aGlzLmNvbnN0cnVjdG9yIGFzIHR5cGVvZiBET01XaWRnZXRNb2RlbCkuc2VyaWFsaXplcnMgfHwge307XG4gICAgICBmb3IgKGxldCBrIG9mIE9iamVjdC5rZXlzKHN0YXRlKSkge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGxldCBzZXJpYWxpemUgPSBzZXJpYWxpemVyc1trXT8uc2VyaWFsaXplO1xuICAgICAgICAgIGlmIChzZXJpYWxpemUpIHtcbiAgICAgICAgICAgIHN0YXRlW2tdID0gc2VyaWFsaXplKHN0YXRlW2tdLCB0aGlzKTtcbiAgICAgICAgICB9IGVsc2UgaWYgKGsgPT09IFwibGF5b3V0XCIgfHwgayA9PT0gXCJzdHlsZVwiKSB7XG4gICAgICAgICAgICAvLyBUaGVzZSBrZXlzIGNvbWUgZnJvbSBpcHl3aWRnZXRzLCByZWx5IG9uIEpTT04uc3RyaW5naWZ5IHRyaWNrLlxuICAgICAgICAgICAgc3RhdGVba10gPSBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KHN0YXRlW2tdKSk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHN0YXRlW2tdID0gc3RydWN0dXJlZENsb25lKHN0YXRlW2tdKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKHR5cGVvZiBzdGF0ZVtrXT8udG9KU09OID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgICAgICAgIHN0YXRlW2tdID0gc3RhdGVba10udG9KU09OKCk7XG4gICAgICAgICAgfVxuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHNlcmlhbGl6aW5nIHdpZGdldCBzdGF0ZSBhdHRyaWJ1dGU6IFwiLCBrKTtcbiAgICAgICAgICB0aHJvdyBlO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gc3RhdGU7XG4gICAgfVxuICB9XG5cbiAgY2xhc3MgQW55VmlldyBleHRlbmRzIERPTVdpZGdldFZpZXcge1xuICAgICNjb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xuICAgIGFzeW5jIHJlbmRlcigpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICAgIGxldCBydW50aW1lID0gUlVOVElNRVMuZ2V0KHRoaXMubW9kZWwpO1xuICAgICAgYXNzZXJ0KHJ1bnRpbWUsIFwiW2FueXdpZGdldF0gUnVudGltZSBub3QgZm91bmQuXCIpO1xuICAgICAgYXdhaXQgcnVudGltZS5jcmVhdGVWaWV3KHRoaXMsIHsgc2lnbmFsOiB0aGlzLiNjb250cm9sbGVyLnNpZ25hbCB9KTtcbiAgICB9XG4gICAgcmVtb3ZlKCk6IHZvaWQge1xuICAgICAgdGhpcy4jY29udHJvbGxlci5hYm9ydChcIlthbnl3aWRnZXRdIFZpZXcgZGVzdHJveWVkLlwiKTtcbiAgICAgIHN1cGVyLnJlbW92ZSgpO1xuICAgIH1cbiAgfVxuXG4gIHJldHVybiB7IEFueU1vZGVsLCBBbnlWaWV3IH07XG59XG4iLCJpbXBvcnQgKiBhcyBiYXNlIGZyb20gXCJAanVweXRlci13aWRnZXRzL2Jhc2VcIjtcblxuaW1wb3J0IGNyZWF0ZSBmcm9tIFwiLi93aWRnZXQudHNcIjtcblxuLyoqXG4gKiBAdHlwZWRlZiBKdXB5dGVyTGFiUmVnaXN0cnlcbiAqIEBwcm9wZXJ0eSB7KHdpZGdldDogeyBuYW1lOiBzdHJpbmcsIHZlcnNpb246IHN0cmluZywgZXhwb3J0czogYW55IH0pID0+IHZvaWR9IHJlZ2lzdGVyV2lkZ2V0XG4gKi9cblxuZXhwb3J0IGRlZmF1bHQge1xuICBpZDogXCJhbnl3aWRnZXRfMF8xMTpwbHVnaW5cIixcbiAgcmVxdWlyZXM6IFsvKiogQHR5cGV7dW5rbm93bn0gKi8gKGJhc2UuSUp1cHl0ZXJXaWRnZXRSZWdpc3RyeSldLFxuICBhY3RpdmF0ZTogKC8qKiBAdHlwZSB7dW5rbm93bn0gKi8gX2FwcCwgLyoqIEB0eXBlIHtKdXB5dGVyTGFiUmVnaXN0cnl9ICovIHJlZ2lzdHJ5KSA9PiB7XG4gICAgbGV0IGV4cG9ydHMgPSBjcmVhdGUoYmFzZSk7XG4gICAgcmVnaXN0cnkucmVnaXN0ZXJXaWRnZXQoe1xuICAgICAgbmFtZTogXCJhbnl3aWRnZXRcIixcbiAgICAgIC8vIEB0cy1leHBlY3QtZXJyb3IgQWRkZWQgYnkgYnVuZGxlclxuICAgICAgdmVyc2lvbjogZ2xvYmFsVGhpcy5WRVJTSU9OLFxuICAgICAgZXhwb3J0cyxcbiAgICB9KTtcbiAgfSxcbiAgYXV0b1N0YXJ0OiB0cnVlLFxufTtcbiJdLCJuYW1lcyI6WyJJTklUSUFMSVpFX01BUktFUiIsIlN5bWJvbCIsIm1vZGVsUHJveHkiLCJtb2RlbCIsImNvbnRleHQiLCJvbiIsIm5hbWUiLCJjYWxsYmFjayIsIm9mZiIsImFzc2VydCIsImNvbmRpdGlvbiIsIm1lc3NhZ2UiLCJFcnJvciIsInNhZmVDbGVhbnVwIiwiZm4iLCJraW5kIiwiUHJvbWlzZSIsImUiLCJjb25zb2xlIiwidGhyb3dBbnl3aWRnZXRFcnJvciIsInNvdXJjZSIsIl9zb3VyY2Vfc3RhY2siLCJfaW5zdGFuY2VvZiIsImxpbmVzIiwiYW55d2lkZ2V0SW5kZXgiLCJsaW5lIiwiY2xlYW5TdGFjayIsInByb21pc2VXaXRoUmVzb2x2ZXJzIiwicmVzb2x2ZSIsInJlamVjdCIsInByb21pc2UiLCJyZXMiLCJyZWoiLCJpc1NhZmVDbGVhbnVwRnVuY3Rpb24iLCJ4IiwiX2NvbnRyb2xsZXIiLCJfd2lkZ2V0RGVmIiwiX2V4cG9ydHMiLCJfbW9kZWwiLCJfcmVzb2x2ZXJzIiwiV2lkZ2V0QmluZGluZyIsImJpbmQiLCJ3aWRnZXREZWYiLCJwYXJhbSIsImV4cGVyaW1lbnRhbCIsInByZXZSZXNvbHZlcnMiLCJzaWduYWwiLCJyZXN1bHQiLCJBYm9ydENvbnRyb2xsZXIiLCJ1bmRlZmluZWQiLCJfdHlwZV9vZiIsImNyZWF0ZVZpZXciLCJ0YXJnZXQiLCJob3N0IiwiY29udHJvbGxlciIsImNvbWJpbmVkIiwiY2xlYW51cCIsImRpc3Bvc2VWaWV3IiwiQWJvcnRTaWduYWwiLCJyZWFzb24iLCJkZXN0cm95IiwiX2JpbmRpbmdzIiwiQmluZGluZ01hbmFnZXIiLCJNYXAiLCJnZXRPckNyZWF0ZSIsImJpbmRpbmciLCJnZXQiLCJCSU5ESU5HUyIsInV1aWQiLCJpbnZva2UiLCJtc2ciLCJvcHRpb25zIiwiX29wdGlvbnNfc2lnbmFsIiwiaWQiLCJfb3B0aW9uc19idWZmZXJzIiwiaGFuZGxlciIsImJ1ZmZlcnMiLCJXSURHRVRfUkVGX1BSRUZJWCIsInBhcnNlV2lkZ2V0UmVmIiwicmVmIiwiSlNPTiIsImNyZWF0ZUhvc3QiLCJnZXRNb2RlbCIsIm1vZGVsSWQiLCJjaGlsZE1vZGVsIiwiZ2V0V2lkZ2V0IiwiY2hpbGRCaW5kaW5nIiwidGltZXIiLCJleHBvcnRzIiwic2V0VGltZW91dCIsImNsZWFyVGltZW91dCIsInJlbmRlciIsImVsIiwidmlld1NpZ25hbCIsImNoaWxkVmlld1NpZ25hbCIsImlzSHJlZiIsInN0ciIsImxvYWRDc3NIcmVmIiwiaHJlZiIsImFueXdpZGdldElkIiwicHJldiIsIm5ld0xpbmsiLCJkb2N1bWVudCIsImxpbmsiLCJPYmplY3QiLCJsb2FkQ3NzVGV4dCIsImNzc1RleHQiLCJzdHlsZSIsImxvYWRDc3MiLCJjc3MiLCJsb2FkRXNtIiwiZXNtIiwidXJsIiwibW9kIiwiVVJMIiwiQmxvYiIsIndhcm5SZW5kZXJEZXByZWNhdGlvbiIsImxvYWRXaWRnZXQiLCJ3aWRnZXQiLCJpbml0aWFsaXplIiwic29saWQiLCJvYnNlcnZlIiwiX3NvbGlkX2NyZWF0ZVNpZ25hbCIsInNldCIsInVwZGF0ZSIsIl93aWRnZXRSZXN1bHQiLCJfc2lnbmFsIiwiUnVudGltZSIsImRpc3Bvc2UiLCJ0eXBlZE1vZGVsIiwid2lkZ2V0UmVzdWx0Iiwic2V0V2lkZ2V0UmVzdWx0IiwiZXJyb3IiLCJ2aWV3IiwidmVyc2lvbiIsImdsb2JhbFRoaXMiLCJET01XaWRnZXRNb2RlbCIsIkRPTVdpZGdldFZpZXciLCJSVU5USU1FUyIsIldlYWtNYXAiLCJBbnlNb2RlbCIsIl9rZXkiLCJhcmdzIiwiXyRfZ2V0Iiwic2VyaWFsaXplIiwic3RhdGUiLCJzZXJpYWxpemVycyIsIl9pdGVyYXRvckVycm9yIiwiayIsIl9zZXJpYWxpemVyc19rIiwiX3N0YXRlX2siLCJzdHJ1Y3R1cmVkQ2xvbmUiLCJBbnlWaWV3IiwicnVudGltZSIsInJlbW92ZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7QUFHQTs7O0NBR0MsR0FDTSxJQUFJQSxvQkFBb0JDLE9BQU8sd0JBQXdCO0FBRTlEOzs7Ozs7Q0FNQyxHQUNNLFNBQVNDLFdBQVdDLEtBQXFCLEVBQUVDLE9BQWdCO0lBQ2hFLHlOQUF5TjtJQUN6TixPQUFPO1FBQ0wsS0FBS0QsTUFBTSxHQUFHLENBQUMsSUFBSSxDQUFDQTtRQUNwQixLQUFLQSxNQUFNLEdBQUcsQ0FBQyxJQUFJLENBQUNBO1FBQ3BCLGNBQWNBLE1BQU0sWUFBWSxDQUFDLElBQUksQ0FBQ0E7UUFDdEMsTUFBTUEsTUFBTSxJQUFJLENBQUMsSUFBSSxDQUFDQTtRQUN0QkUsSUFBQUEsU0FBQUEsR0FBR0MsSUFBSSxFQUFFQyxRQUFRO1lBQ2ZKLE1BQU0sRUFBRSxDQUFDRyxNQUFNQyxVQUFVSDtRQUMzQjtRQUNBSSxLQUFBQSxTQUFBQSxJQUFJRixJQUFJLEVBQUVDLFFBQVE7WUFDaEJKLE1BQU0sR0FBRyxDQUFDRyxNQUFNQyxVQUFVSDtRQUM1QjtRQUNBLGtFQUFrRTtRQUNsRSx5RUFBeUU7UUFDekUsMENBQTBDO1FBQzFDLGdCQUFnQkQsTUFBTSxjQUFjO0lBQ3RDO0FBQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDaEJPLFNBQVNNLE9BQU9DLFNBQWtCLEVBQUVDLE9BQWU7SUFDeEQsSUFBSSxDQUFDRCxXQUFXLE1BQU0sSUFBSUUsTUFBTUQ7QUFDbEM7QUFFTyxTQUFlRSxZQUNwQkMsRUFBOEMsRUFDOUNDLElBQVk7OztZQUVaOztnQkFBT0MsUUFBUSxPQUFPLEdBQ25CLElBQUksQ0FBQzsyQkFBTUYsZUFBQUEseUJBQUFBO21CQUNYLEtBQUssQ0FBQyxTQUFDRzsyQkFBTUMsUUFBUSxJQUFJLENBQUUsaUNBQXFDLE9BQUxILE1BQUssTUFBSUU7Ozs7SUFDekU7O0FBRUE7Ozs7Q0FJQyxHQUNNLFNBQVNFLG9CQUFvQkMsTUFBZTs7UUFLckNDO0lBSlosSUFBSSxDQUFRQyxZQUFORixRQUFrQlIsUUFBUTtRQUM5QixtQ0FBbUM7UUFDbkMsTUFBTVE7SUFDUjtJQUNBLElBQUlHLGlCQUFRRixnQkFBQUEsT0FBTyxLQUFLLGNBQVpBLG9DQUFBQSxjQUFjLEtBQUssQ0FBQyw0Q0FBUyxFQUFFO0lBQzNDLElBQUlHLGlCQUFpQkQsTUFBTSxTQUFTLENBQUMsU0FBQ0U7ZUFBU0EsS0FBSyxRQUFRLENBQUM7O0lBQzdELElBQUlDLGFBQWFGLG1CQUFtQixDQUFDLElBQUlELFFBQVFBLE1BQU0sS0FBSyxDQUFDLEdBQUdDLGlCQUFpQjtJQUNqRkosT0FBTyxLQUFLLEdBQUdNLFdBQVcsSUFBSSxDQUFDO0lBQy9CUixRQUFRLEtBQUssQ0FBQ0U7SUFDZCxNQUFNQTtBQUNSO0FBRUE7Ozs7Q0FJQyxHQUNNLFNBQVNPO0lBQ2QsSUFBSUM7SUFDSixJQUFJQztJQUNKLElBQUlDLFVBQVUsSUFBSWQsUUFBVyxTQUFDZSxLQUFLQztRQUNqQ0osVUFBVUc7UUFDVkYsU0FBU0c7SUFDWDtJQUNBLE9BQU87UUFBRUYsU0FBQUE7UUFBU0YsU0FBQUE7UUFBU0MsUUFBQUE7SUFBTztBQUNwQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDMURpRTtBQUNhO0FBVzlFLFNBQVNJLHNCQUFzQkMsQ0FBVTtJQUN2QyxPQUFPLE9BQU9BLE1BQU07QUFDdEI7SUFHRUMsa0JBQUFBLGdDQUNBQywwQ0FDQUMsd0NBQ0FDLHNDQUVBQztBQU5LLElBQU1DLHFCQUFhQSxpQkFBbkI7O2FBQU1BLGNBUUNyQyxLQUFxQjtnQ0FSdEJxQztRQUNYTCxnQ0FBQUEsa0JBQUFBOzttQkFBQUEsS0FBQUE7O1FBQ0FDLGdDQUFBQTs7bUJBQUFBLEtBQUFBOztRQUNBQyxnQ0FBQUE7O21CQUFBQSxLQUFBQTs7UUFDQUMsZ0NBQUFBOzttQkFBQUEsS0FBQUE7O1FBQ0E7UUFDQUMsZ0NBQUFBOzttQkFBQUEsS0FBQUE7O3VDQUdPRCxRQUFTbkM7dUNBQ1RvQyxZQUFhWixvQkFBb0JBO1FBQ3RDLElBQUksQ0FBQyxLQUFLLEdBQUcsNkJBQUksRUFBQ1ksWUFBVyxPQUFPOztrQkFYM0JDOztZQWNMQyxLQUFBQTttQkFBTixTQUFNQTsyREFDSkMsU0FBb0IsRUFDcEJDLEtBQWdEO3dCQUE5Q0MsY0F1QmlCRixtREFkYkcsZUFTRkMsUUFDQTNDLE9BSUE0Qzs7OztnQ0F2QkZILGVBQUZELE1BQUVDO2dDQUVGLElBQUksNkJBQUksRUFBQ1IsZ0JBQWVNLFdBQVc7OztnQ0FFbkMsSUFBSSw2QkFBSSxFQUFDTixlQUFjLDZCQUFJLEVBQUNBLGdCQUFlTSxXQUFXOzsyRkFDcEQsSUFBSSxFQUFDUCxrQkFBQUEsZ0VBQUwsMkJBQWtCLEtBQUs7b0NBQ3ZCLG1FQUFtRTtvQ0FDbkUsa0VBQWtFO29DQUNsRSxtRUFBbUU7b0NBQy9EVSx5Q0FBZ0IsSUFBSSxFQUFDTjttRUFDcEJBLFlBQWFaLG9CQUFvQkE7b0NBQ3RDLElBQUksQ0FBQyxLQUFLLEdBQUcsNkJBQUksRUFBQ1ksWUFBVyxPQUFPO29DQUNwQ00sY0FBYyxPQUFPLENBQUMsS0FBSyxDQUFDLFlBQU87b0NBQ25DQSxjQUFjLE1BQU0sQ0FBQyxJQUFJakMsTUFBTTtnQ0FDakM7K0RBRUt3QixZQUFhTTsrREFDYlAsa0JBQUFBLEVBQWMsSUFBSWE7Z0NBQ25CRixTQUFTLDZCQUFJLEVBQUNYLGtCQUFBQSxFQUFZLE1BQU07Z0NBQ2hDaEMsaUNBQVEsSUFBSSxFQUFDbUM7Z0NBRWpCbkMsTUFBTSxHQUFHLENBQUMsTUFBTSxNQUFNSCxpQkFBaUJBO2dDQUUxQjs7cUNBQU0wQyx3QkFBQUEsVUFBVSxVQUFVLGNBQXBCQSw0Q0FBQUEsMkJBQUFBLFdBQXVCO3dDQUN4QyxPQUFPeEMsVUFBVUEsQ0FBQ0MsT0FBT0gsaUJBQWlCQTt3Q0FDMUM4QyxRQUFBQTt3Q0FDQUYsY0FBQUE7b0NBQ0Y7OztnQ0FKSUcsU0FBUztxQ0FNVEQsT0FBTyxPQUFPLEVBQWRBOzs7O2dDQUNGOztvQ0FBTWpDLFdBQVdBLENBQUNvQixzQkFBc0JjLFVBQVVBLFNBQVNFLFdBQVc7OztnQ0FBdEU7Z0NBQ0E7Ozs7Z0NBR0YsSUFBSWhCLHNCQUFzQmMsU0FBUztvQ0FDakNELE9BQU8sZ0JBQWdCLENBQUMsU0FBUzsrQ0FBTWpDLFdBQVdBLENBQUNrQyxRQUFROzttRUFDdERWLFVBQVdZO2dDQUNsQixPQUFPLElBQUlDLENBQUFBLE9BQU9ILHVDQUFQRyxTQUFPSCxPQUFLLE1BQU0sWUFBWUEsV0FBVyxNQUFNO21FQUNuRFYsVUFBV1U7Z0NBQ2xCLE9BQU87bUVBQ0FWLFVBQVdZO2dDQUNsQjtnQ0FFQSw2QkFBSSxFQUFDVixZQUFXLE9BQU8sMEJBQUMsSUFBSSxFQUFDRjs7Ozs7O2dCQUMvQjs7OztZQUVNYyxLQUFBQTttQkFBTixTQUFNQTsyREFDSkMsTUFBa0IsRUFDbEJULEtBQStGO3dCQUE3RkcsUUFBUUYsY0FBY1Msa0NBSXBCQyxZQUNBQyxVQUNBcEQsT0FDQXFELFNBT0FDOzs7O2dDQWRGWCxTQUFGSCxNQUFFRyxRQUFRRixlQUFWRCxNQUFVQyxjQUFjUyxPQUF4QlYsTUFBd0JVO2dDQUV4Qjs7b0NBQU0sSUFBSSxDQUFDLEtBQUs7OztnQ0FBaEI7Z0NBQ0EsSUFBSSx5REFBQyxJQUFJLEVBQUNqQiwwRUFBTCwyQkFBaUIsTUFBTSxHQUFFOzs7Z0NBQzFCa0IsYUFBYSxJQUFJTjtnQ0FDakJPLFdBQVdHLFlBQVksR0FBRztvQ0FBRVo7b0NBQVFRLFdBQVcsTUFBTTs7Z0NBQ3JEbkQsaUNBQVEsSUFBSSxFQUFDbUM7Z0NBQ0g7O29DQUFNLDZCQUFJLEVBQUNGLFlBQVcsTUFBTSxDQUFDO3dDQUN6QyxPQUFPbEMsVUFBVUEsQ0FBQ0MsT0FBT2lEO3dDQUN6QixJQUFJQSxPQUFPLEVBQUU7d0NBQ2IsUUFBUUc7d0NBQ1JGLE1BQUFBO3dDQUNBVCxjQUFBQTtvQ0FDRjs7O2dDQU5JWSxVQUFVO2dDQU9WQyxjQUFjLHFCQUFDRTtvQ0FDakIscUVBQXFFO29DQUNyRSxvRUFBb0U7b0NBQ3BFeEQsTUFBTSxHQUFHLENBQUMsTUFBTSxNQUFNaUQ7b0NBQ3RCLEtBQUt2QyxXQUFXQSxDQUFDMkMsU0FBU0c7Z0NBQzVCO2dDQUNBLElBQUlKLFNBQVMsT0FBTyxFQUFFO29DQUNwQkUsWUFBWTtvQ0FDWjs7O2dDQUNGO2dDQUNBRixTQUFTLGdCQUFnQixDQUFDLFNBQVM7MkNBQU1FLFlBQVk7Ozs7Ozs7Z0JBQ3ZEOzs7O1lBRUk7aUJBQUo7Z0JBQ0UsZ0NBQU8sSUFBSSxFQUFDcEI7WUFDZDs7O1lBRUF1QixLQUFBQTttQkFBQUEsU0FBQUE7O3VFQUNFLElBQUksRUFBQ3pCLGtCQUFBQSxnRUFBTCwyQkFBa0IsS0FBSzsrQ0FDbEJBLGtCQUFBQSxFQUFjYzsrQ0FDZGIsWUFBYWE7WUFDcEI7OztXQW5HV1Q7SUFvR1o7SUFHQ3FCO0FBREYsSUFBTUMsc0JBQWNBLGlCQUFwQjs7YUFBTUE7Z0NBQUFBO1FBQ0pELGdDQUFBQTs7bUJBQVksSUFBSUU7OztrQkFEWkQ7O1lBR0pFLEtBQUFBO21CQUFBQSxTQUFBQSxZQUFZN0QsS0FBcUI7Z0JBQy9CLElBQUk4RCxVQUFVLDZCQUFJLEVBQUNKLFdBQVUsR0FBRyxDQUFDMUQ7Z0JBQ2pDLElBQUksQ0FBQzhELFNBQVM7b0JBQ1pBLFVBQVUsSUFBSXpCLHFCQUFhQSxDQUFDckM7b0JBQzVCLDZCQUFJLEVBQUMwRCxXQUFVLEdBQUcsQ0FBQzFELE9BQU84RDtnQkFDNUI7Z0JBQ0EsT0FBT0E7WUFDVDs7O1lBRUFDLEtBQUFBO21CQUFBQSxTQUFBQSxJQUFJL0QsS0FBcUI7Z0JBQ3ZCLE9BQU8sNkJBQUksRUFBQzBELFdBQVUsR0FBRyxDQUFDMUQ7WUFDNUI7OztZQUVBeUQsS0FBQUE7bUJBQUFBLFNBQUFBLFFBQVF6RCxLQUFxQjtnQkFDM0IsSUFBSThELFVBQVUsNkJBQUksRUFBQ0osV0FBVSxHQUFHLENBQUMxRDtnQkFDakMsSUFBSThELFNBQVM7b0JBQ1hBLFFBQVEsT0FBTztvQkFDZiw2QkFBSSxFQUFDSixXQUFVLE1BQU0sQ0FBQzFEO2dCQUN4QjtZQUNGOzs7V0F0QkkyRDs7QUF5QkMsSUFBSUssV0FBVyxJQUFJTCxzQkFBY0EsR0FBRzs7Ozs7OztBQ2xKTjtBQU85QixTQUFTTyxPQUNkbEUsS0FBZSxFQUNmRyxJQUFZLEVBQ1pnRSxHQUFhO1FBQ2JDLFVBQUFBLGlFQUF5QixDQUFDO1FBS2JDO0lBSGIsOEVBQThFO0lBQzlFLDBDQUEwQztJQUMxQyxJQUFJQyxLQUFLTCxPQUFPO0lBQ2hCLElBQUl0QixVQUFTMEIsa0JBQUFBLFFBQVEsTUFBTSxjQUFkQSw2QkFBQUEsa0JBQWtCZCxZQUFZLE9BQU8sQ0FBQztJQUVuRCxPQUFPLElBQUkxQyxRQUFRLFNBQUNZLFNBQVNDO1lBa0J5QzZDO1FBakJwRSxJQUFJNUIsT0FBTyxPQUFPLEVBQUU7WUFDbEJqQixPQUFPaUIsT0FBTyxNQUFNO1FBQ3RCO1FBQ0FBLE9BQU8sZ0JBQWdCLENBQUMsU0FBUztZQUMvQjNDLE1BQU0sR0FBRyxDQUFDLGNBQWN3RTtZQUN4QjlDLE9BQU9pQixPQUFPLE1BQU07UUFDdEI7UUFFQSxTQUFTNkIsUUFDUEwsR0FBb0UsRUFDcEVNLE9BQW1CO1lBRW5CLElBQUksQ0FBRU4sQ0FBQUEsSUFBSSxFQUFFLEtBQUtHLEVBQUMsR0FBSTtZQUN0QjdDLFFBQVE7Z0JBQUMwQyxJQUFJLFFBQVE7Z0JBQUVNO2FBQVE7WUFDL0J6RSxNQUFNLEdBQUcsQ0FBQyxjQUFjd0U7UUFDMUI7UUFDQXhFLE1BQU0sRUFBRSxDQUFDLGNBQWN3RTtRQUN2QnhFLE1BQU0sSUFBSSxDQUFDO1lBQUVzRSxJQUFBQTtZQUFJLE1BQU07WUFBcUJuRSxNQUFBQTtZQUFNZ0UsS0FBQUE7UUFBSSxHQUFHckIsWUFBV3lCLG1CQUFBQSxRQUFRLE9BQU8sY0FBZkEsOEJBQUFBLG1CQUFtQixFQUFFO0lBQzNGO0FBQ0Y7OztBQ3ZDTyxJQUFJRyxvQkFBb0IsYUFBYTtBQUVyQyxTQUFTQyxlQUFlQyxHQUFZO0lBQ3pDLElBQUksT0FBT0EsUUFBUSxZQUFZQSxJQUFJLFVBQVUsQ0FBQ0Ysb0JBQW9CO1FBQ2hFLE9BQU9FLElBQUksS0FBSyxDQUFDRixrQkFBa0IsTUFBTTtJQUMzQztJQUNBLE1BQU0sSUFBSWpFLE1BQU8seUNBQTRELE9BQXBCb0UsS0FBSyxTQUFTLENBQUNEO0FBQzFFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0p3QztBQUNIO0FBQ1M7QUFDRztBQUUxQyxTQUFTRSxXQUFXOUUsS0FBcUIsRUFBRXdDLEtBQW1DO1FBQWpDRyxTQUFGSCxNQUFFRztJQUNsRCxJQUFJTyxPQUFhO1FBRVQ2QixVQUROLGlGQUFpRjtRQUNqRixTQUFNQSxTQUFTSCxHQUFHOztvQkFDWkksU0FDQUMsWUFDQWhGOzs7OzRCQUZBK0UsVUFBVUwsY0FBY0EsQ0FBQ0M7NEJBQ1o7O2dDQUFNNUUsTUFBTSxjQUFjLENBQUMsU0FBUyxDQUFDZ0Y7Ozs0QkFBbERDLGFBQWE7NEJBQ2JoRixVQUFVSCxPQUFPOzRCQUNyQjZDLE9BQU8sZ0JBQWdCLENBQUMsU0FBUzt1Q0FBTXNDLFdBQVcsR0FBRyxDQUFDLE1BQU0sTUFBTWhGOzs0QkFDbEU7O2dDQUFPRixVQUFVQSxDQUFDa0YsWUFBWWhGOzs7O1lBQ2hDOztRQUVNaUYsV0FETiw4RUFBOEU7UUFDOUUsU0FBTUEsVUFBVU4sR0FBRzs7b0JBQ2JJLFNBQ0FDLFlBQ0FFLGNBSUFDLE9BQ0FDOzs7OzRCQVBBTCxVQUFVTCxjQUFjQSxDQUFDQzs0QkFDWjs7Z0NBQU01RSxNQUFNLGNBQWMsQ0FBQyxTQUFTLENBQUNnRjs7OzRCQUFsREMsYUFBYTs0QkFDYkUsZUFBZW5CLFlBQVksQ0FBQ2lCOzRCQUNoQyxJQUFJLENBQUNFLGNBQWM7Z0NBQ2pCLE1BQU0sSUFBSTFFLE1BQU8sMkNBQWtELE9BQVJ1RTs0QkFDN0Q7NEJBRWM7O2dDQUFNLElBQUluRSxRQUFpQixTQUFDWSxTQUFTQztvQ0FDakQwRCxRQUFRRSxXQUNOOytDQUNFNUQsT0FBTyxJQUFJakIsTUFBTyw0Q0FBbUQsT0FBUnVFLFNBQVE7dUNBQ3ZFO29DQUVGRyxhQUFhLEtBQUssQ0FBQyxJQUFJLENBQUMxRCxTQUFTQztnQ0FDbkMsR0FBRyxPQUFPLENBQUM7MkNBQU02RCxhQUFhSDs7Ozs0QkFQMUJDLFVBQVU7NEJBUWQ7O2dDQUFPO29DQUNMQSxTQUFBQTtvQ0FDTUcsUUFBTixTQUFNQTtnRkFBT2hELEtBQTBCO2dEQUF4QmlELElBQVlDLFlBQ3JCQzs7Ozt3REFEU0YsS0FBRmpELE1BQUVpRCxJQUFZQyxhQUFkbEQsTUFBTTt3REFDYm1ELGtCQUFrQkQsdUJBQUFBLHdCQUFBQSxhQUFjL0M7d0RBQ3BDOzs0REFBTXdDLGFBQWEsVUFBVSxDQUMzQjtnRUFBRU0sSUFBQUE7NERBQUcsR0FDTDtnRUFDRSxRQUFRRTtnRUFDUixjQUFjO29FQUNaLHdDQUF3QztvRUFDeEMsUUFBUXpCLFdBQVcsQ0FBQyxNQUFNZTtnRUFDNUI7Z0VBQ0EvQixNQUFBQTs0REFDRjs7O3dEQVRGOzs7Ozs7d0NBV0Y7O2dDQUNGOzs7O1lBQ0Y7O0lBQ0Y7SUFDQSxPQUFPQTtBQUNUOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3JEbUM7QUFZbkMsU0FBUzBDLE9BQU9DLEdBQVc7SUFDekIsT0FBT0EsSUFBSSxVQUFVLENBQUMsY0FBY0EsSUFBSSxVQUFVLENBQUM7QUFDckQ7QUFFQSxTQUFlQyxZQUFZQyxJQUFZLEVBQUVDLFdBQW1COztZQUN0REMsTUFPRUM7O1lBUEZELE9BQU9FLFNBQVMsYUFBYSxDQUFtQixZQUF1QixPQUFaSCxhQUFZO1lBRTNFLHlJQUF5STtZQUN6SSx1RUFBdUU7WUFDdkUsa0VBQWtFO1lBQ2xFLElBQUlDLE1BQU07Z0JBQ1IsNEpBQTRKO2dCQUN4SkMsVUFBVUQsS0FBSyxTQUFTO2dCQUM1QkMsUUFBUSxJQUFJLEdBQUdIO2dCQUNmRyxRQUFRLGdCQUFnQixDQUFDLFFBQVE7MkJBQU1ELGlCQUFBQSwyQkFBQUEsS0FBTSxNQUFNOztnQkFDbkRDLFFBQVEsZ0JBQWdCLENBQUMsU0FBUzsyQkFBTUQsaUJBQUFBLDJCQUFBQSxLQUFNLE1BQU07O2dCQUNwREEsS0FBSyxLQUFLLENBQUNDO2dCQUNYOzs7WUFDRjtZQUVBOztnQkFBTyxJQUFJckYsUUFBUSxTQUFDWTtvQkFDbEIsSUFBSTJFLE9BQU9DLE9BQU8sTUFBTSxDQUFDRixTQUFTLGFBQWEsQ0FBQyxTQUFTO3dCQUN2RCxLQUFLO3dCQUNMSixNQUFBQTt3QkFDQSxRQUFRdEU7b0JBQ1Y7b0JBQ0EwRSxTQUFTLElBQUksQ0FBQyxXQUFXLENBQUNDO2dCQUM1Qjs7O0lBQ0Y7O0FBRUEsU0FBU0UsWUFBWUMsT0FBZSxFQUFFUCxXQUFtQjtJQUN2RCxJQUFJQyxPQUFPRSxTQUFTLGFBQWEsQ0FBb0IsYUFBd0IsT0FBWkgsYUFBWTtJQUM3RSxJQUFJQyxNQUFNO1FBQ1IsNkNBQTZDO1FBQzdDQSxLQUFLLFdBQVcsR0FBR007UUFDbkI7SUFDRjtJQUNBLElBQUlDLFFBQVFILE9BQU8sTUFBTSxDQUFDRixTQUFTLGFBQWEsQ0FBQyxVQUFVO1FBQ3pELElBQUlIO1FBQ0osTUFBTTtJQUNSO0lBQ0FRLE1BQU0sV0FBVyxDQUFDTCxTQUFTLGNBQWMsQ0FBQ0k7SUFDMUNKLFNBQVMsSUFBSSxDQUFDLFdBQVcsQ0FBQ0s7QUFDNUI7QUFFTyxTQUFlQyxRQUFRQyxHQUF1QixFQUFFVixXQUFtQjs7O1lBQ3hFLElBQUksQ0FBQ1UsT0FBTyxDQUFDVixhQUFhOzs7WUFDMUIsSUFBSUosT0FBT2MsTUFBTTs7Z0JBQU9aLFlBQVlZLEtBQUtWOztZQUN6Qzs7Z0JBQU9NLFlBQVlJLEtBQUtWOzs7SUFDMUI7O0FBRUEsU0FBZVcsUUFBUUMsR0FBVzs7WUFJNUJDLEtBQ0FDOzs7O3lCQUpBbEIsT0FBT2dCLE1BQVBoQjs7OztvQkFDSzs7d0JBQU0sTUFBTSxDQUFDLHVCQUF1QixHQUFHLGdCQUFnQixHQUFHZ0I7OztvQkFBakU7O3dCQUFPOzs7b0JBRUxDLE1BQU1FLElBQUksZUFBZSxDQUFDLElBQUlDO3dCQUFNSjt1QkFBTTt3QkFBRSxNQUFNO29CQUFrQjtvQkFDOUQ7O3dCQUFNLE1BQU0sQ0FBQyx1QkFBdUIsR0FBRyxnQkFBZ0IsR0FBR0M7OztvQkFBaEVDLE1BQU07b0JBQ1ZDLElBQUksZUFBZSxDQUFDRjtvQkFDcEI7O3dCQUFPQzs7OztJQUNUOztBQUVBLFNBQVNHLHNCQUFzQmpCLFdBQW1CO0lBQ2hEakYsUUFBUSxJQUFJLENBQUUsdUNBQ2tDLE9BQVppRixhQUFZO0FBdUJsRDtBQUVPLFNBQWVrQixXQUFXTixHQUFXLEVBQUVaLFdBQW1COztZQUMzRGMsS0FTQUs7Ozs7b0JBVE07O3dCQUFNUixRQUFRQzs7O29CQUFwQkUsTUFBTTtvQkFDVixJQUFJQSxJQUFJLE1BQU0sRUFBRTt3QkFDZEcsc0JBQXNCakI7d0JBQ3RCOzs0QkFBTztnQ0FDQ29CLFlBQU4sU0FBTUE7Ozs7Ozs7b0NBQWM7O2dDQUNwQixRQUFRTixJQUFJLE1BQU07NEJBQ3BCOztvQkFDRjtvQkFDQXhHLE1BQU1BLENBQUN3RyxJQUFJLE9BQU8sRUFBRTt5QkFDUCxRQUFPQSxJQUFJLE9BQU8sS0FBSyxVQUFTLEdBQWhDOzs7O29CQUFvQzs7d0JBQU1BLElBQUksT0FBTzs7OzJCQUFqQjs7Ozs7OzJCQUFzQkEsSUFBSSxPQUFPOzs7b0JBQTlFSztvQkFDSjs7d0JBQU9BOzs7O0lBQ1Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDakhrQztBQUUzQixTQUFTRyxRQUNkdEgsS0FBa0IsRUFDbEJHLElBQU8sRUFDUHFDLEtBQW9DO1FBQWxDRyxTQUFGSCxNQUFFRztJQUVGLElBQWlCNEUsdUNBQUFBLDJCQUFrQixDQUFDdkgsTUFBTSxHQUFHLENBQUNHLFlBQXpDNEQsTUFBWXdELHdCQUFQQyxNQUFPRDtJQUNqQixJQUFJRSxTQUFTO2VBQU1ELElBQUk7bUJBQU14SCxNQUFNLEdBQUcsQ0FBQ0c7OztJQUN2Q0gsTUFBTSxFQUFFLENBQUUsVUFBYyxPQUFMRyxPQUFRc0g7SUFDM0I5RSxtQkFBQUEsNkJBQUFBLE9BQVEsZ0JBQWdCLENBQUMsU0FBUztRQUNoQzNDLE1BQU0sR0FBRyxDQUFFLFVBQWMsT0FBTEcsT0FBUXNIO0lBQzlCO0lBQ0EsT0FBTzFEO0FBQ1Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNia0M7QUFFTTtBQUNEO0FBQ0Y7QUFDMkI7QUFDekI7QUFDOEI7SUFVbkUsdURBQXVEO0FBQ3ZEMkQsNkNBQ0FDO0FBSEssSUFBTUMsZUFBT0EsaUJBQWI7O2FBQU1BLFFBS0M1SCxLQUFxQixFQUFFb0UsT0FBZ0M7O3VDQUx4RHdEO1FBRVhGLGdDQUFBQSxPQUFBQTs7bUJBQUFBLEtBQUFBOztRQUNBQyxnQ0FBQUEsT0FBQUE7O21CQUFBQSxLQUFBQTs7OENBR09BLFNBQVV2RCxRQUFRLE1BQU07UUFDN0Isb0NBQUksRUFBQ3VELFNBQVEsY0FBYztRQUMzQixvQ0FBSSxFQUFDQSxTQUFRLGdCQUFnQixDQUFDLFNBQVM7bUJBQU1FOztRQUM3QyxJQUFJL0QsVUFBVUUsb0JBQW9CLENBQUNoRTtRQUNuQyxJQUFJeUMsZUFBNkI7WUFDL0IsOERBQThEO1lBQzlELFFBQVF5QixXQUFXLENBQUMsTUFBTWxFO1FBQzVCO1FBQ0EsSUFBSTZILFVBQVVSLHlCQUFnQixDQUFDLFNBQUNRO1lBQzlCLHFJQUFxSTtZQUNySSxtRkFBbUY7WUFDbkYsSUFBSUMsYUFBYTlIO1lBQ2pCLElBQUlzRSxLQUFLd0QsV0FBVyxHQUFHLENBQUM7WUFDeEIsSUFBSXBCLE1BQU1ZLE9BQU9BLENBQUNRLFlBQVksUUFBUTtnQkFBRSxNQUFNLEVBQUUsdUNBQUtIO1lBQVE7WUFDN0QsSUFBSWYsTUFBTVUsT0FBT0EsQ0FBQ1EsWUFBWSxRQUFRO2dCQUFFLE1BQU0sRUFBRSx1Q0FBS0g7WUFBUTtZQUM3RCxJQUFzQ0osc0JBQUFBLHVCQUFBQSxDQUFBQSwyQkFBa0IsQ0FBb0I7Z0JBQzFFLFFBQVE7WUFDVixRQUZLUSxlQUFpQ1Isd0JBQW5CUyxrQkFBbUJUO21EQUdqQ0csZUFBZ0JLO1lBRXJCViwyQkFBa0IsQ0FDaEJBLFFBQVEsQ0FBQ1gsS0FBSzt1QkFBTTNGLFFBQVEsS0FBSyxDQUFFLGdDQUFrQyxPQUFIdUQ7ZUFBTztnQkFBRSxPQUFPO1lBQUs7WUFFekYrQywyQkFBa0IsQ0FDaEJBLFFBQVEsQ0FBQ1QsS0FBSzt1QkFBTTdGLFFBQVEsS0FBSyxDQUFFLGdDQUFrQyxPQUFIdUQ7ZUFBTztnQkFBRSxPQUFPO1lBQUs7WUFFekYrQywyQkFBa0IsQ0FBQztnQkFDakIsT0FBT1osT0FBT0EsQ0FBQ0MsT0FBT3BDO1lBQ3hCO1lBQ0ErQywyQkFBa0IsQ0FBQztnQkFDakIsZ0VBQWdFO2dCQUNoRSxnRUFBZ0U7Z0JBQ2hFLG1FQUFtRTtnQkFDbkUsSUFBSWxFLGFBQWEsSUFBSU47Z0JBQ3JCd0Usd0JBQWUsQ0FBQzsyQkFBTWxFLFdBQVcsS0FBSzs7Z0JBQ3RDK0QsVUFBVUEsQ0FBQ04sT0FBT3RDLElBQ2YsSUFBSSxDQUFDLFNBQU82Qzs7Ozs7b0NBQ1gsSUFBSWhFLFdBQVcsTUFBTSxDQUFDLE9BQU8sRUFBRTs7O29DQUMvQjs7d0NBQU1XLFFBQVEsSUFBSSxDQUFDcUQsUUFBUTs0Q0FBRTFFLGNBQUFBO3dDQUFhOzs7b0NBQTFDO29DQUNBLElBQUlVLFdBQVcsTUFBTSxDQUFDLE9BQU8sRUFBRTs7O29DQUMvQjZFLGdCQUFnQjt3Q0FBRSxRQUFRO3dDQUFTLE1BQU1iO29DQUFPOzs7Ozs7b0JBQ2xEO21CQUNDLEtBQUssQ0FBQyxTQUFDYztvQkFDTixJQUFJOUUsV0FBVyxNQUFNLENBQUMsT0FBTyxFQUFFO29CQUMvQjZFLGdCQUFnQjt3QkFBRSxRQUFRO3dCQUFTQyxPQUFBQTtvQkFBTTtnQkFDM0M7WUFDSjtZQUVBLE9BQU9KO1FBQ1Q7O3lCQXZEU0Q7O1lBMERMNUUsS0FBQUE7bUJBQU4sU0FBTUEsV0FBV2tGLElBQW1CLEVBQUU5RCxPQUFnQzs7K0JBQ2hFcEUsT0FDQTJDLFFBR0FtQixTQUVBckIsY0FJQVMsTUFDQTJFOzs7d0JBWEE3SCxRQUFRa0ksS0FBSyxLQUFLO3dCQUNsQnZGLFNBQVNZLFlBQVksR0FBRzs0REFBRSxJQUFJLEVBQUNvRTs0QkFBU3ZELFFBQVEsTUFBTTs0QkFBSSxpQ0FBaUM7d0JBQy9GekIsT0FBTyxjQUFjO3dCQUNyQkEsT0FBTyxnQkFBZ0IsQ0FBQyxTQUFTO21DQUFNa0Y7O3dCQUNuQy9ELFVBQVVFLFlBQVksQ0FBQ2hFO3dCQUMzQk0sTUFBTUEsQ0FBQ3dELFNBQVM7d0JBQ1pyQixlQUE2Qjs0QkFDL0IsOERBQThEOzRCQUM5RCxRQUFReUIsV0FBVyxDQUFDLE1BQU1sRTt3QkFDNUI7d0JBQ0lrRCxPQUFPNEIsVUFBVUEsQ0FBQzlFLE9BQU87NEJBQUUyQyxRQUFBQTt3QkFBTzt3QkFDbENrRixVQUFVUix5QkFBZ0IsQ0FBQyxTQUFDUTs0QkFDOUJSLDJCQUFrQixDQUFDO2dDQUNqQixxREFBcUQ7Z0NBQ3JEckgsTUFBTSxHQUFHLENBQUMsTUFBTSxNQUFNa0k7Z0NBQ3RCQSxLQUFLLEdBQUcsQ0FBQyxLQUFLO2dDQUNkLElBQUl0RixTQUFTLHVDQUFLOEU7Z0NBQ2xCLElBQUk5RSxPQUFPLE1BQU0sS0FBSyxXQUFXO29DQUMvQjtnQ0FDRjtnQ0FDQSxJQUFJQSxPQUFPLE1BQU0sS0FBSyxTQUFTO29DQUM3QjVCLG1CQUFtQkEsQ0FBQzRCLE9BQU8sS0FBSztvQ0FDaEM7Z0NBQ0Y7Z0NBQ0EsSUFBSU8sYUFBYSxJQUFJTjtnQ0FDckJ3RSx3QkFBZSxDQUFDOzJDQUFNbEUsV0FBVyxLQUFLOztnQ0FDdEN0QyxRQUFRLE9BQU8sR0FDWixJQUFJLENBQUM7MkNBQ0ppRCxRQUFRLFVBQVUsQ0FBQ29FLE1BQU07d0NBQ3ZCLFFBQVEzRSxZQUFZLEdBQUcsQ0FBQzs0Q0FBQ1o7NENBQVFRLFdBQVcsTUFBTTt5Q0FBQzt3Q0FDbkRWLGNBQUFBO3dDQUNBUyxNQUFBQTtvQ0FDRjttQ0FFRCxLQUFLLENBQUMsU0FBQytFOzJDQUFVakgsbUJBQW1CQSxDQUFDaUg7OzRCQUMxQzs0QkFDQSxPQUFPO3VDQUFNSjs7d0JBQ2Y7Ozs7O2dCQUNGOzs7O1dBakdXRDtJQWtHWjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3BIdUM7QUFDRDtBQUNKO0FBRW5DLHlDQUF5QztBQUN6QyxJQUFJTyxVQUFrQkMsUUFBa0I7QUFZeEMscUJBQWUsU0FBUyxXQUFDNUYsS0FHRjtRQUZyQjZGLGlCQUR1QjdGLE1BQ3ZCNkYsZ0JBQ0FDLGdCQUZ1QjlGLE1BRXZCOEY7SUFFQSxJQUFJQyxXQUFXLElBQUlDO0lBRW5CLElBQU1DLHlCQUFOOztrQkFBTUE7aUJBQUFBOzBDQUFBQTtZQUFOLHlCQUFNQTs7NEJBQUFBOztnQkFTSnJCLEtBQUFBO3VCQUFBQSxTQUFBQTs7b0JBQVdzQixJQUFBQSxJQUFBQSxPQUFBQSxVQUFBQSxRQUFHQyxPQUFIRCxVQUFBQSxPQUFBQSxPQUFBQSxHQUFBQSxPQUFBQSxNQUFBQTt3QkFBR0MsS0FBSEQsUUFBQUEsU0FBQUEsQ0FBQUEsS0FBc0U7O3dCQUMvRUU7cUJBQUFBLFNBQUFBLHVCQVZFSCxxQkFVSSxjQUFORyxJQUFLLGNBQUxBOzs2QkFBaUIscUJBQUdEO29CQUNwQixJQUFJeEYsYUFBYSxJQUFJTjtvQkFDckIsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXO3dCQUNuQk0sV0FBVyxLQUFLLENBQUM7d0JBQ2pCYSxnQkFBZ0I7d0JBQ2hCdUUsU0FBUyxNQUFNO29CQUNqQjtvQkFDQUEsU0FBUyxHQUFHLENBQUMsSUFBSSxFQUFFLElBQUlYLGVBQU9BLENBQUMsSUFBSSxFQUFFO3dCQUFFLFFBQVF6RSxXQUFXLE1BQU07b0JBQUM7Z0JBQ25FOzs7Z0JBRUE7Ozs7O0tBS0MsR0FDRDBGLEtBQUFBO3VCQUFBQSxTQUFBQSxVQUFVQyxLQUEwQjtvQkFDbEMsK0hBQStIO29CQUMvSCxJQUFJQyxjQUFlLElBQUksQ0FBQyxXQUFXLENBQTJCLFdBQVcsSUFBSSxDQUFDO3dCQUN6RUMsa0NBQUFBLDJCQUFBQTs7d0JBQUwsUUFBS0EsWUFBUzNDLE9BQU8sSUFBSSxDQUFDeUMsMkJBQXJCRSxTQUFBQSw2QkFBQUEsUUFBQUEseUJBQUFBLGlDQUE2Qjs0QkFBN0JBLElBQUlDLElBQUpEOzRCQUNILElBQUk7b0NBQ2NFLGdCQVNMQztnQ0FUWCxJQUFJTixhQUFZSyxpQkFBQUEsV0FBVyxDQUFDRCxFQUFFLGNBQWRDLHFDQUFBQSxlQUFnQixTQUFTO2dDQUN6QyxJQUFJTCxXQUFXO29DQUNiQyxLQUFLLENBQUNHLEVBQUUsR0FBR0osVUFBVUMsS0FBSyxDQUFDRyxFQUFFLEVBQUUsSUFBSTtnQ0FDckMsT0FBTyxJQUFJQSxNQUFNLFlBQVlBLE1BQU0sU0FBUztvQ0FDMUMsaUVBQWlFO29DQUNqRUgsS0FBSyxDQUFDRyxFQUFFLEdBQUdwRSxLQUFLLEtBQUssQ0FBQ0EsS0FBSyxTQUFTLENBQUNpRSxLQUFLLENBQUNHLEVBQUU7Z0NBQy9DLE9BQU87b0NBQ0xILEtBQUssQ0FBQ0csRUFBRSxHQUFHRyxnQkFBZ0JOLEtBQUssQ0FBQ0csRUFBRTtnQ0FDckM7Z0NBQ0EsSUFBSSxTQUFPRSxXQUFBQSxLQUFLLENBQUNGLEVBQUUsY0FBUkUsK0JBQUFBLFNBQVUsTUFBTSxNQUFLLFlBQVk7b0NBQzFDTCxLQUFLLENBQUNHLEVBQUUsR0FBR0gsS0FBSyxDQUFDRyxFQUFFLENBQUMsTUFBTTtnQ0FDNUI7NEJBQ0YsRUFBRSxPQUFPbkksR0FBRztnQ0FDVkMsUUFBUSxLQUFLLENBQUMsOENBQThDa0k7Z0NBQzVELE1BQU1uSTs0QkFDUjt3QkFDRjs7d0JBbEJLa0k7d0JBQUFBOzs7aUNBQUFBLDZCQUFBQTtnQ0FBQUE7OztnQ0FBQUE7c0NBQUFBOzs7O29CQW1CTCxPQUFPRjtnQkFDVDs7O2VBakRJTDtNQUFpQko7SUFDckIsdUJBRElJLFVBQ0csY0FBYTtJQUNwQix1QkFGSUEsVUFFRyxnQkFBZTtJQUN0Qix1QkFISUEsVUFHRyx3QkFBdUJOO0lBRTlCLHVCQUxJTSxVQUtHLGFBQVk7SUFDbkIsdUJBTklBLFVBTUcsZUFBYztJQUNyQix1QkFQSUEsVUFPRyx1QkFBc0JOO1FBOEM3Qm5HO0lBREYsSUFBTXFILHdCQUFOOztrQkFBTUE7aUJBQUFBOzBDQUFBQTs7b0JBQU4sa0JBQU1BLHFCQUNKckgsK0JBQUFBLFFBQUFBOzt1QkFBYyxJQUFJYTs7Ozs0QkFEZHdHOztnQkFFRTdELEtBQUFBO3VCQUFOLFNBQU1BOzs0QkFDQThEOzs7O29DQUFBQSxVQUFVZixTQUFTLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSztvQ0FDckNqSSxNQUFNQSxDQUFDZ0osU0FBUztvQ0FDaEI7O3dDQUFNQSxRQUFRLFVBQVUsQ0FBQyxJQUFJLEVBQUU7NENBQUUsUUFBUSxtQ0FBSSxFQUFDdEgsYUFBWSxNQUFNO3dDQUFDOzs7b0NBQWpFOzs7Ozs7b0JBQ0Y7Ozs7Z0JBQ0F1SCxLQUFBQTt1QkFBQUEsU0FBQUE7b0JBQ0UsbUNBQUksRUFBQ3ZILGFBQVksS0FBSyxDQUFDO29CQUN2Qix1QkFURXFILG9CQVNJLFVBQU4sSUFBSztnQkFDUDs7O2VBVklBO01BQWdCZjtJQWF0QixPQUFPO1FBQUVHLFVBQUFBO1FBQVVZLFNBQUFBO0lBQVE7QUFDN0I7OztBQ3pGOEM7O0FBRWI7O0FBRWpDO0FBQ0E7QUFDQSxjQUFjLFdBQVcsNkNBQTZDLFdBQVc7QUFDakY7O0FBRUEseUNBQWU7QUFDZjtBQUNBLHVCQUF1QixTQUFTLElBQUksdUNBQTJCO0FBQy9ELHdCQUF3QixTQUFTLG9CQUFvQixvQkFBb0I7QUFDekUsa0JBQWtCLFVBQU0sQ0FBQyxnQkFBSTtBQUM3QjtBQUNBO0FBQ0E7QUFDQSxlQUFlLFFBQWtCO0FBQ2pDO0FBQ0EsS0FBSztBQUNMLEdBQUc7QUFDSDtBQUNBLENBQUMsRUFBQyJ9