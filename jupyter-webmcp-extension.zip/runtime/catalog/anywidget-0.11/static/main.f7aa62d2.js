(() => {
"use strict";
var __webpack_modules__ = ({
592() {

;// CONCATENATED MODULE: ./packages/anywidget/src/model-proxy.ts
/**
 * This is a trick so that we can cleanup event listeners added
 * by the user-defined function.
 */ var INITIALIZE_MARKER = Symbol("anywidget.initialize");
/**
 * Prunes the view down to the minimum context necessary.
 *
 * Calls to `model.get` and `model.set` automatically add the
 * `context`, so we can gracefully unsubscribe from events
 * added by user-defined hooks.
 */ function modelProxy(model, context) {
    // oxlint-disable-next-line typescript-eslint/no-unsafe-type-assertion -- DOMWidgetModel.get/set/on/off have wider signatures than AnyModel, so bound versions don't narrow cleanly; the shape is structurally compatible
    return {
        get: model.get.bind(model),
        set: model.set.bind(model),
        save_changes: model.save_changes.bind(model),
        send: model.send.bind(model),
        on: function on(name, callback) {
            model.on(name, callback, context);
        },
        off: function off(name, callback) {
            model.off(name, callback, context);
        },
        // The widget_manager type is wider than what we want to expose to
        // developers. In a future version, we will expose a more limited API but
        // that can wait for a minor version bump.
        widget_manager: model.widget_manager
    };
}

;// CONCATENATED MODULE: ./packages/anywidget/src/util.ts
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) resolve(value);
    else Promise.resolve(value).then(_next, _throw);
}
function _async_to_generator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}
function _instanceof(left, right) {
    "@swc/helpers - instanceof";
    if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) {
        return !!right[Symbol.hasInstance](left);
    } else return left instanceof right;
}
function _ts_generator(thisArg, body) {
    var f, y, t, _ = {
        label: 0,
        sent: function() {
            if (t[0] & 1) throw t[1];
            return t[1];
        },
        trys: [],
        ops: []
    }, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype), d = Object.defineProperty;
    return d(g, "next", {
        value: verb(0)
    }), d(g, "throw", {
        value: verb(1)
    }), d(g, "return", {
        value: verb(2)
    }), typeof Symbol === "function" && d(g, Symbol.iterator, {
        value: function() {
            return this;
        }
    }), g;
    function verb(n) {
        return function(v) {
            return step([
                n,
                v
            ]);
        };
    }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while(g && (g = 0, op[0] && (_ = 0)), _)try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [
                op[0] & 2,
                t.value
            ];
            switch(op[0]){
                case 0:
                case 1:
                    t = op;
                    break;
                case 4:
                    _.label++;
                    return {
                        value: op[1],
                        done: false
                    };
                case 5:
                    _.label++;
                    y = op[1];
                    op = [
                        0
                    ];
                    continue;
                case 7:
                    op = _.ops.pop();
                    _.trys.pop();
                    continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                        _ = 0;
                        continue;
                    }
                    if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                        _.label = op[1];
                        break;
                    }
                    if (op[0] === 6 && _.label < t[1]) {
                        _.label = t[1];
                        t = op;
                        break;
                    }
                    if (t && _.label < t[2]) {
                        _.label = t[2];
                        _.ops.push(op);
                        break;
                    }
                    if (t[2]) _.ops.pop();
                    _.trys.pop();
                    continue;
            }
            op = body.call(thisArg, _);
        } catch (e) {
            op = [
                6,
                e
            ];
            y = 0;
        } finally{
            f = t = 0;
        }
        if (op[0] & 5) throw op[1];
        return {
            value: op[0] ? op[1] : void 0,
            done: true
        };
    }
}
function assert(condition, message) {
    if (!condition) throw new Error(message);
}
function safeCleanup(fn, kind) {
    return _async_to_generator(function() {
        return _ts_generator(this, function(_state) {
            return [
                2,
                Promise.resolve().then(function() {
                    return fn === null || fn === void 0 ? void 0 : fn();
                }).catch(function(e) {
                    return console.warn("[anywidget] error cleaning up ".concat(kind, "."), e);
                })
            ];
        });
    })();
}
/**
 * Cleans up the stack trace at anywidget boundary.
 * You can fully inspect the entire stack trace in the console interactively,
 * but the initial error message is cleaned up to be more user-friendly.
 */ function throwAnywidgetError(source) {
    var _ref;
    var _source_stack;
    if (!_instanceof(source, Error)) {
        // Don't know what to do with this.
        throw source;
    }
    var lines = (_ref = (_source_stack = source.stack) === null || _source_stack === void 0 ? void 0 : _source_stack.split("\n")) !== null && _ref !== void 0 ? _ref : [];
    var anywidgetIndex = lines.findIndex(function(line) {
        return line.includes("anywidget");
    });
    var cleanStack = anywidgetIndex === -1 ? lines : lines.slice(0, anywidgetIndex + 1);
    source.stack = cleanStack.join("\n");
    console.error(source);
    throw source;
}
/**
 * Polyfill for {@link https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise/withResolvers Promise.withResolvers}
 *
 * Trevor(2025-03-14): Should be able to remove once more stable across browsers.
 */ function promiseWithResolvers() {
    var resolve;
    var reject;
    var promise = new Promise(function(res, rej) {
        resolve = res;
        reject = rej;
    });
    return {
        promise: promise,
        resolve: resolve,
        reject: reject
    };
}

;// CONCATENATED MODULE: ./packages/anywidget/src/binding.ts
function binding_asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) resolve(value);
    else Promise.resolve(value).then(_next, _throw);
}
function binding_async_to_generator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                binding_asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                binding_asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) return descriptor.get.call(receiver);
    return descriptor.value;
}
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) descriptor.set.call(receiver, value);
    else {
        if (!descriptor.writable) {
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
function _class_call_check(instance, Constructor) {
    if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
}
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) throw new TypeError("attempted to " + action + " private field on non-instance");
    return privateMap.get(receiver);
}
function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}
function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}
function _defineProperties(target, props) {
    for(var i = 0; i < props.length; i++){
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}
function _create_class(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
}
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else obj[key] = value;
    return obj;
}
function binding_ts_generator(thisArg, body) {
    var f, y, t, _ = {
        label: 0,
        sent: function() {
            if (t[0] & 1) throw t[1];
            return t[1];
        },
        trys: [],
        ops: []
    }, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype), d = Object.defineProperty;
    return d(g, "next", {
        value: verb(0)
    }), d(g, "throw", {
        value: verb(1)
    }), d(g, "return", {
        value: verb(2)
    }), typeof Symbol === "function" && d(g, Symbol.iterator, {
        value: function() {
            return this;
        }
    }), g;
    function verb(n) {
        return function(v) {
            return step([
                n,
                v
            ]);
        };
    }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while(g && (g = 0, op[0] && (_ = 0)), _)try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [
                op[0] & 2,
                t.value
            ];
            switch(op[0]){
                case 0:
                case 1:
                    t = op;
                    break;
                case 4:
                    _.label++;
                    return {
                        value: op[1],
                        done: false
                    };
                case 5:
                    _.label++;
                    y = op[1];
                    op = [
                        0
                    ];
                    continue;
                case 7:
                    op = _.ops.pop();
                    _.trys.pop();
                    continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                        _ = 0;
                        continue;
                    }
                    if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                        _.label = op[1];
                        break;
                    }
                    if (op[0] === 6 && _.label < t[1]) {
                        _.label = t[1];
                        t = op;
                        break;
                    }
                    if (t && _.label < t[2]) {
                        _.label = t[2];
                        _.ops.push(op);
                        break;
                    }
                    if (t[2]) _.ops.pop();
                    _.trys.pop();
                    continue;
            }
            op = body.call(thisArg, _);
        } catch (e) {
            op = [
                6,
                e
            ];
            y = 0;
        } finally{
            f = t = 0;
        }
        if (op[0] & 5) throw op[1];
        return {
            value: op[0] ? op[1] : void 0,
            done: true
        };
    }
}
function _type_of(obj) {
    "@swc/helpers - typeof";
    return obj && typeof Symbol !== "undefined" && obj.constructor === Symbol ? "symbol" : typeof obj;
}


function isSafeCleanupFunction(x) {
    return typeof x === "function";
}
var binding_controller = /*#__PURE__*/ new WeakMap(), _widgetDef = /*#__PURE__*/ new WeakMap(), _exports = /*#__PURE__*/ new WeakMap(), _model = /*#__PURE__*/ new WeakMap(), _resolvers = /*#__PURE__*/ new WeakMap();
var binding_WidgetBinding = /*#__PURE__*/ function() {
    "use strict";
    function WidgetBinding(model) {
        _class_call_check(this, WidgetBinding);
        _class_private_field_init(this, binding_controller, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _widgetDef, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _exports, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _model, {
            writable: true,
            value: void 0
        });
        _define_property(this, "ready", void 0);
        _class_private_field_init(this, _resolvers, {
            writable: true,
            value: void 0
        });
        _class_private_field_set(this, _model, model);
        _class_private_field_set(this, _resolvers, promiseWithResolvers());
        this.ready = _class_private_field_get(this, _resolvers).promise;
    }
    _create_class(WidgetBinding, [
        {
            key: "bind",
            value: function bind(_0, _1) {
                return binding_async_to_generator(function(widgetDef, param) {
                    var experimental, _widgetDef_initialize, _$_class_private_field_get, prevResolvers, signal, model, result;
                    return binding_ts_generator(this, function(_state) {
                        switch(_state.label){
                            case 0:
                                experimental = param.experimental;
                                if (_class_private_field_get(this, _widgetDef) === widgetDef) return [
                                    2
                                ];
                                if (_class_private_field_get(this, _widgetDef) && _class_private_field_get(this, _widgetDef) !== widgetDef) {
                                    ;
                                    (_$_class_private_field_get = _class_private_field_get(this, binding_controller)) === null || _$_class_private_field_get === void 0 ? void 0 : _$_class_private_field_get.abort();
                                    // Settle the old promise so any awaiter that captured `this.ready`
                                    // (e.g. a parent's `host.getWidget` snapshot) unblocks instead of
                                    // hanging until the host's 10s timeout. No-op if already resolved.
                                    prevResolvers = _class_private_field_get(this, _resolvers);
                                    _class_private_field_set(this, _resolvers, promiseWithResolvers());
                                    this.ready = _class_private_field_get(this, _resolvers).promise;
                                    prevResolvers.promise.catch(function() {});
                                    prevResolvers.reject(new Error("[anywidget] widget bind aborted by re-bind"));
                                }
                                _class_private_field_set(this, _widgetDef, widgetDef);
                                _class_private_field_set(this, binding_controller, new AbortController());
                                signal = _class_private_field_get(this, binding_controller).signal;
                                model = _class_private_field_get(this, _model);
                                model.off(null, null, INITIALIZE_MARKER);
                                return [
                                    4,
                                    (_widgetDef_initialize = widgetDef.initialize) === null || _widgetDef_initialize === void 0 ? void 0 : _widgetDef_initialize.call(widgetDef, {
                                        model: modelProxy(model, INITIALIZE_MARKER),
                                        signal: signal,
                                        experimental: experimental
                                    })
                                ];
                            case 1:
                                result = _state.sent();
                                if (!signal.aborted) return [
                                    3,
                                    3
                                ];
                                return [
                                    4,
                                    safeCleanup(isSafeCleanupFunction(result) ? result : undefined, "esm update")
                                ];
                            case 2:
                                _state.sent();
                                return [
                                    2
                                ];
                            case 3:
                                if (isSafeCleanupFunction(result)) {
                                    signal.addEventListener("abort", function() {
                                        return safeCleanup(result, "esm update");
                                    });
                                    _class_private_field_set(this, _exports, undefined);
                                } else if ((typeof result === "undefined" ? "undefined" : _type_of(result)) === "object" && result !== null) {
                                    _class_private_field_set(this, _exports, result);
                                } else {
                                    _class_private_field_set(this, _exports, undefined);
                                }
                                _class_private_field_get(this, _resolvers).resolve(_class_private_field_get(this, _exports));
                                return [
                                    2
                                ];
                        }
                    });
                }).apply(this, arguments);
            }
        },
        {
            key: "createView",
            value: function createView(_0, _1) {
                return binding_async_to_generator(function(target, param) {
                    var signal, experimental, host, _$_class_private_field_get, controller, combined, model, cleanup, disposeView;
                    return binding_ts_generator(this, function(_state) {
                        switch(_state.label){
                            case 0:
                                signal = param.signal, experimental = param.experimental, host = param.host;
                                return [
                                    4,
                                    this.ready
                                ];
                            case 1:
                                _state.sent();
                                if (!((_$_class_private_field_get = _class_private_field_get(this, _widgetDef)) === null || _$_class_private_field_get === void 0 ? void 0 : _$_class_private_field_get.render)) return [
                                    2
                                ];
                                controller = new AbortController();
                                combined = AbortSignal.any([
                                    signal,
                                    controller.signal
                                ]);
                                model = _class_private_field_get(this, _model);
                                return [
                                    4,
                                    _class_private_field_get(this, _widgetDef).render({
                                        model: modelProxy(model, target),
                                        el: target.el,
                                        signal: combined,
                                        host: host,
                                        experimental: experimental
                                    })
                                ];
                            case 2:
                                cleanup = _state.sent();
                                disposeView = function disposeView(reason) {
                                    // Clear listeners keyed to this target. For ephemeral `{el}` targets
                                    // (host.getWidget().render), this prevents leaks across re-renders.
                                    model.off(null, null, target);
                                    void safeCleanup(cleanup, reason);
                                };
                                if (combined.aborted) {
                                    disposeView("dispose view - already aborted");
                                    return [
                                        2
                                    ];
                                }
                                combined.addEventListener("abort", function() {
                                    return disposeView("dispose view - aborted");
                                });
                                return [
                                    2
                                ];
                        }
                    });
                }).apply(this, arguments);
            }
        },
        {
            key: "exports",
            get: function get() {
                return _class_private_field_get(this, _exports);
            }
        },
        {
            key: "destroy",
            value: function destroy() {
                var _$_class_private_field_get;
                (_$_class_private_field_get = _class_private_field_get(this, binding_controller)) === null || _$_class_private_field_get === void 0 ? void 0 : _$_class_private_field_get.abort();
                _class_private_field_set(this, binding_controller, undefined);
                _class_private_field_set(this, _widgetDef, undefined);
            }
        }
    ]);
    return WidgetBinding;
}();
var _bindings = /*#__PURE__*/ new WeakMap();
var binding_BindingManager = /*#__PURE__*/ function() {
    "use strict";
    function BindingManager() {
        _class_call_check(this, BindingManager);
        _class_private_field_init(this, _bindings, {
            writable: true,
            value: new Map()
        });
    }
    _create_class(BindingManager, [
        {
            key: "getOrCreate",
            value: function getOrCreate(model) {
                var binding = _class_private_field_get(this, _bindings).get(model);
                if (!binding) {
                    binding = new binding_WidgetBinding(model);
                    _class_private_field_get(this, _bindings).set(model, binding);
                }
                return binding;
            }
        },
        {
            key: "get",
            value: function get(model) {
                return _class_private_field_get(this, _bindings).get(model);
            }
        },
        {
            key: "destroy",
            value: function destroy(model) {
                var binding = _class_private_field_get(this, _bindings).get(model);
                if (binding) {
                    binding.destroy();
                    _class_private_field_get(this, _bindings).delete(model);
                }
            }
        }
    ]);
    return BindingManager;
}();
var BINDINGS = new binding_BindingManager();

;// CONCATENATED MODULE: ./node_modules/.pnpm/solid-js@1.9.18/node_modules/solid-js/dist/solid.js
let taskIdCounter = 1,
  isCallbackScheduled = false,
  isPerformingWork = false,
  solid_taskQueue = (/* unused pure expression or super */ null && ([])),
  currentTask = null,
  shouldYieldToHost = null,
  yieldInterval = 5,
  deadline = 0,
  maxYieldInterval = 300,
  maxDeadline = 0,
  scheduleCallback = null,
  scheduledCallback = null;
const maxSigned31BitInt = 1073741823;
function setupScheduler() {
  const channel = new MessageChannel(),
    port1 = channel.port1,
    port = channel.port2;
  if (typeof port1.unref === "function") port1.unref();
  if (typeof port.unref === "function") port.unref();
  scheduleCallback = () => port.postMessage(null);
  port1.onmessage = () => {
    if (scheduledCallback !== null) {
      const currentTime = performance.now();
      deadline = currentTime + yieldInterval;
      maxDeadline = currentTime + maxYieldInterval;
      try {
        const hasMoreWork = scheduledCallback(currentTime);
        if (!hasMoreWork) {
          scheduledCallback = null;
        } else port.postMessage(null);
      } catch (error) {
        port.postMessage(null);
        throw error;
      }
    }
  };
  if (navigator && navigator.scheduling && navigator.scheduling.isInputPending) {
    const scheduling = navigator.scheduling;
    shouldYieldToHost = () => {
      const currentTime = performance.now();
      if (currentTime >= deadline) {
        if (scheduling.isInputPending()) {
          return true;
        }
        return currentTime >= maxDeadline;
      } else {
        return false;
      }
    };
  } else {
    shouldYieldToHost = () => performance.now() >= deadline;
  }
}
function enqueue(taskQueue, task) {
  function findIndex() {
    let m = 0;
    let n = taskQueue.length - 1;
    while (m <= n) {
      const k = n + m >> 1;
      const cmp = task.expirationTime - taskQueue[k].expirationTime;
      if (cmp > 0) m = k + 1;else if (cmp < 0) n = k - 1;else return k;
    }
    return m;
  }
  taskQueue.splice(findIndex(), 0, task);
}
function requestCallback(fn, options) {
  if (!scheduleCallback) setupScheduler();
  let startTime = performance.now(),
    timeout = maxSigned31BitInt;
  if (options && options.timeout) timeout = options.timeout;
  const newTask = {
    id: taskIdCounter++,
    fn,
    startTime,
    expirationTime: startTime + timeout
  };
  enqueue(solid_taskQueue, newTask);
  if (!isCallbackScheduled && !isPerformingWork) {
    isCallbackScheduled = true;
    scheduledCallback = flushWork;
    scheduleCallback();
  }
  return newTask;
}
function cancelCallback(task) {
  task.fn = null;
}
function flushWork(initialTime) {
  isCallbackScheduled = false;
  isPerformingWork = true;
  try {
    return workLoop(initialTime);
  } finally {
    currentTask = null;
    isPerformingWork = false;
  }
}
function workLoop(initialTime) {
  let currentTime = initialTime;
  currentTask = solid_taskQueue[0] || null;
  while (currentTask !== null) {
    if (currentTask.expirationTime > currentTime && shouldYieldToHost()) {
      break;
    }
    const callback = currentTask.fn;
    if (callback !== null) {
      currentTask.fn = null;
      const didUserCallbackTimeout = currentTask.expirationTime <= currentTime;
      callback(didUserCallbackTimeout);
      currentTime = performance.now();
      if (currentTask === solid_taskQueue[0]) {
        solid_taskQueue.shift();
      }
    } else solid_taskQueue.shift();
    currentTask = solid_taskQueue[0] || null;
  }
  return currentTask !== null;
}

const sharedConfig = {
  context: undefined,
  registry: undefined,
  effects: undefined,
  done: false,
  getContextId() {
    return getContextId(this.context.count);
  },
  getNextContextId() {
    return getContextId(this.context.count++);
  }
};
function getContextId(count) {
  const num = String(count),
    len = num.length - 1;
  return sharedConfig.context.id + (len ? String.fromCharCode(96 + len) : "") + num;
}
function setHydrateContext(context) {
  sharedConfig.context = context;
}
function nextHydrateContext() {
  return {
    ...sharedConfig.context,
    id: sharedConfig.getNextContextId(),
    count: 0
  };
}

const IS_DEV = false;
const equalFn = (a, b) => a === b;
const $PROXY = Symbol("solid-proxy");
const SUPPORTS_PROXY = (/* unused pure expression or super */ null && (typeof Proxy === "function"));
const $TRACK = Symbol("solid-track");
const $DEVCOMP = Symbol("solid-dev-component");
const signalOptions = {
  equals: equalFn
};
let ERROR = null;
let runEffects = runQueue;
const STALE = 1;
const PENDING = 2;
const UNOWNED = {
  owned: null,
  cleanups: null,
  context: null,
  owner: null
};
const NO_INIT = (/* unused pure expression or super */ null && ({}));
var Owner = null;
let Transition = null;
let Scheduler = null;
let ExternalSourceConfig = null;
let Listener = null;
let Updates = null;
let Effects = null;
let ExecCount = 0;
function createRoot(fn, detachedOwner) {
  const listener = Listener,
    owner = Owner,
    unowned = fn.length === 0,
    current = detachedOwner === undefined ? owner : detachedOwner,
    root = unowned ? UNOWNED : {
      owned: null,
      cleanups: null,
      context: current ? current.context : null,
      owner: current
    },
    updateFn = unowned ? fn : () => fn(createDisposer(root));
  Owner = root;
  Listener = null;
  try {
    return runUpdates(updateFn, true);
  } finally {
    Listener = listener;
    Owner = owner;
  }
}
function createDisposer(root) {
  return () => solid_untrack(() => cleanNode(root));
}
function createSignal(value, options) {
  options = options ? Object.assign({}, signalOptions, options) : signalOptions;
  const s = {
    value,
    observers: null,
    observerSlots: null,
    comparator: options.equals || undefined
  };
  const setter = value => {
    if (typeof value === "function") {
      if (Transition && Transition.running && Transition.sources.has(s)) value = value(s.tValue);else value = value(s.value);
    }
    return writeSignal(s, value);
  };
  return [readSignal.bind(s), setter];
}
function createComputed(fn, value, options) {
  const c = createComputation(fn, value, true, STALE);
  if (Scheduler && Transition && Transition.running) Updates.push(c);else updateComputation(c);
}
function createRenderEffect(fn, value, options) {
  const c = createComputation(fn, value, false, STALE);
  if (Scheduler && Transition && Transition.running) Updates.push(c);else updateComputation(c);
}
function createEffect(fn, value, options) {
  runEffects = runUserEffects;
  const c = createComputation(fn, value, false, STALE),
    s = solid_SuspenseContext && useContext(solid_SuspenseContext);
  if (s) c.suspense = s;
  if (!options || !options.render) c.user = true;
  Effects ? Effects.push(c) : updateComputation(c);
}
function createReaction(onInvalidate, options) {
  let fn;
  const c = createComputation(() => {
      fn ? fn() : solid_untrack(onInvalidate);
      fn = undefined;
    }, undefined, false, 0),
    s = solid_SuspenseContext && useContext(solid_SuspenseContext);
  if (s) c.suspense = s;
  c.user = true;
  return tracking => {
    fn = tracking;
    updateComputation(c);
  };
}
function createMemo(fn, value, options) {
  options = options ? Object.assign({}, signalOptions, options) : signalOptions;
  const c = createComputation(fn, value, true, 0);
  c.observers = null;
  c.observerSlots = null;
  c.comparator = options.equals || undefined;
  if (Scheduler && Transition && Transition.running) {
    c.tState = STALE;
    Updates.push(c);
  } else updateComputation(c);
  return readSignal.bind(c);
}
function isPromise(v) {
  return v && typeof v === "object" && "then" in v;
}
function createResource(pSource, pFetcher, pOptions) {
  let source;
  let fetcher;
  let options;
  if (typeof pFetcher === "function") {
    source = pSource;
    fetcher = pFetcher;
    options = pOptions || {};
  } else {
    source = true;
    fetcher = pSource;
    options = pFetcher || {};
  }
  let pr = null,
    initP = NO_INIT,
    id = null,
    loadedUnderTransition = false,
    scheduled = false,
    resolved = "initialValue" in options,
    dynamic = typeof source === "function" && createMemo(source);
  const contexts = new Set(),
    [value, setValue] = (options.storage || createSignal)(options.initialValue),
    [error, setError] = createSignal(undefined),
    [track, trigger] = createSignal(undefined, {
      equals: false
    }),
    [state, setState] = createSignal(resolved ? "ready" : "unresolved");
  if (Owner) onCleanup(() => {
    for (const c of contexts.keys()) c.decrement();
    contexts.clear();
    if (Transition && pr) Transition.promises.delete(pr);
    pr = null;
  });
  if (sharedConfig.context) {
    id = sharedConfig.getNextContextId();
    if (options.ssrLoadFrom === "initial") initP = options.initialValue;else if (sharedConfig.load && sharedConfig.has(id)) initP = sharedConfig.load(id);
  }
  function loadEnd(p, v, error, key) {
    if (pr === p) {
      pr = null;
      key !== undefined && (resolved = true);
      if ((p === initP || v === initP) && options.onHydrated) queueMicrotask(() => options.onHydrated(key, {
        value: v
      }));
      initP = NO_INIT;
      if (Transition && p && loadedUnderTransition) {
        Transition.promises.delete(p);
        loadedUnderTransition = false;
        runUpdates(() => {
          Transition.running = true;
          completeLoad(v, error);
        }, false);
      } else completeLoad(v, error);
    }
    return v;
  }
  function completeLoad(v, err) {
    runUpdates(() => {
      if (err === undefined) setValue(() => v);
      setState(err !== undefined ? "errored" : resolved ? "ready" : "unresolved");
      setError(err);
      for (const c of contexts.keys()) c.decrement();
      contexts.clear();
    }, false);
  }
  function read() {
    const c = solid_SuspenseContext && useContext(solid_SuspenseContext),
      v = value(),
      err = error();
    if (err !== undefined && !pr) throw err;
    if (Listener && !Listener.user && c) {
      createComputed(() => {
        track();
        if (pr) {
          if (c.resolved && Transition && loadedUnderTransition) Transition.promises.add(pr);else if (!contexts.has(c)) {
            c.increment();
            contexts.add(c);
          }
        }
      });
    }
    return v;
  }
  function load(refetching = true) {
    if (refetching !== false && scheduled) return;
    scheduled = false;
    const lookup = dynamic ? dynamic() : source;
    loadedUnderTransition = Transition && Transition.running;
    if (lookup == null || lookup === false) {
      loadEnd(pr, solid_untrack(value));
      return;
    }
    if (Transition && pr) Transition.promises.delete(pr);
    let error;
    const p = initP !== NO_INIT ? initP : solid_untrack(() => {
      try {
        return fetcher(lookup, {
          value: value(),
          refetching
        });
      } catch (fetcherError) {
        error = fetcherError;
      }
    });
    if (error !== undefined) {
      loadEnd(pr, undefined, castError(error), lookup);
      return;
    } else if (!isPromise(p)) {
      loadEnd(pr, p, undefined, lookup);
      return p;
    }
    pr = p;
    if ("v" in p) {
      if (p.s === 1) loadEnd(pr, p.v, undefined, lookup);else loadEnd(pr, undefined, castError(p.v), lookup);
      return p;
    }
    scheduled = true;
    queueMicrotask(() => scheduled = false);
    runUpdates(() => {
      setState(resolved ? "refreshing" : "pending");
      trigger();
    }, false);
    return p.then(v => loadEnd(p, v, undefined, lookup), e => loadEnd(p, undefined, castError(e), lookup));
  }
  Object.defineProperties(read, {
    state: {
      get: () => state()
    },
    error: {
      get: () => error()
    },
    loading: {
      get() {
        const s = state();
        return s === "pending" || s === "refreshing";
      }
    },
    latest: {
      get() {
        if (!resolved) return read();
        const err = error();
        if (err && !pr) throw err;
        return value();
      }
    }
  });
  let owner = Owner;
  if (dynamic) createComputed(() => (owner = Owner, load(false)));else load(false);
  return [read, {
    refetch: info => runWithOwner(owner, () => load(info)),
    mutate: setValue
  }];
}
function createDeferred(source, options) {
  let t,
    timeout = options ? options.timeoutMs : undefined;
  const node = createComputation(() => {
    if (!t || !t.fn) t = requestCallback(() => setDeferred(() => node.value), timeout !== undefined ? {
      timeout
    } : undefined);
    return source();
  }, undefined, true);
  const [deferred, setDeferred] = createSignal(Transition && Transition.running && Transition.sources.has(node) ? node.tValue : node.value, options);
  updateComputation(node);
  setDeferred(() => Transition && Transition.running && Transition.sources.has(node) ? node.tValue : node.value);
  return deferred;
}
function createSelector(source, fn = equalFn, options) {
  const subs = new Map();
  const node = createComputation(p => {
    const v = source();
    for (const [key, val] of subs.entries()) if (fn(key, v) !== fn(key, p)) {
      for (const c of val.values()) {
        if (Transition && Transition.running) c.tState = STALE;else c.state = STALE;
        if (c.pure) Updates.push(c);else Effects.push(c);
      }
    }
    return v;
  }, undefined, true, STALE);
  updateComputation(node);
  return key => {
    const listener = Listener;
    if (listener) {
      let l;
      if (l = subs.get(key)) l.add(listener);else subs.set(key, l = new Set([listener]));
      onCleanup(() => {
        l.delete(listener);
        !l.size && subs.delete(key);
      });
    }
    return fn(key, Transition && Transition.running && Transition.sources.has(node) ? node.tValue : node.value);
  };
}
function batch(fn) {
  return runUpdates(fn, false);
}
function solid_untrack(fn) {
  if (!ExternalSourceConfig && Listener === null) return fn();
  const listener = Listener;
  Listener = null;
  try {
    if (ExternalSourceConfig) return ExternalSourceConfig.untrack(fn);
    return fn();
  } finally {
    Listener = listener;
  }
}
function solid_on(deps, fn, options) {
  const isArray = Array.isArray(deps);
  let prevInput;
  let defer = options && options.defer;
  return prevValue => {
    let input;
    if (isArray) {
      input = Array(deps.length);
      for (let i = 0; i < deps.length; i++) input[i] = deps[i]();
    } else input = deps();
    if (defer) {
      defer = false;
      return prevValue;
    }
    const result = solid_untrack(() => fn(input, prevInput, prevValue));
    prevInput = input;
    return result;
  };
}
function onMount(fn) {
  createEffect(() => solid_untrack(fn));
}
function onCleanup(fn) {
  if (Owner === null) ;else if (Owner.cleanups === null) Owner.cleanups = [fn];else Owner.cleanups.push(fn);
  return fn;
}
function catchError(fn, handler) {
  ERROR || (ERROR = Symbol("error"));
  Owner = createComputation(undefined, undefined, true);
  Owner.context = {
    ...Owner.context,
    [ERROR]: [handler]
  };
  if (Transition && Transition.running) Transition.sources.add(Owner);
  try {
    return fn();
  } catch (err) {
    handleError(err);
  } finally {
    Owner = Owner.owner;
  }
}
function getListener() {
  return Listener;
}
function getOwner() {
  return Owner;
}
function runWithOwner(o, fn) {
  const prev = Owner;
  const prevListener = Listener;
  Owner = o;
  Listener = null;
  try {
    return runUpdates(fn, true);
  } catch (err) {
    handleError(err);
  } finally {
    Owner = prev;
    Listener = prevListener;
  }
}
function enableScheduling(scheduler = requestCallback) {
  Scheduler = scheduler;
}
function startTransition(fn) {
  if (Transition && Transition.running) {
    fn();
    return Transition.done;
  }
  const l = Listener;
  const o = Owner;
  return Promise.resolve().then(() => {
    Listener = l;
    Owner = o;
    let t;
    if (Scheduler || solid_SuspenseContext) {
      t = Transition || (Transition = {
        sources: new Set(),
        effects: [],
        promises: new Set(),
        disposed: new Set(),
        queue: new Set(),
        running: true
      });
      t.done || (t.done = new Promise(res => t.resolve = res));
      t.running = true;
    }
    runUpdates(fn, false);
    Listener = Owner = null;
    return t ? t.done : undefined;
  });
}
const [transPending, setTransPending] = /*@__PURE__*/createSignal(false);
function useTransition() {
  return [transPending, startTransition];
}
function resumeEffects(e) {
  Effects.push.apply(Effects, e);
  e.length = 0;
}
function createContext(defaultValue, options) {
  const id = Symbol("context");
  return {
    id,
    Provider: createProvider(id),
    defaultValue
  };
}
function useContext(context) {
  let value;
  return Owner && Owner.context && (value = Owner.context[context.id]) !== undefined ? value : context.defaultValue;
}
function solid_children(fn) {
  const children = createMemo(fn);
  const memo = createMemo(() => resolveChildren(children()));
  memo.toArray = () => {
    const c = memo();
    return Array.isArray(c) ? c : c != null ? [c] : [];
  };
  return memo;
}
let solid_SuspenseContext;
function getSuspenseContext() {
  return solid_SuspenseContext || (solid_SuspenseContext = createContext());
}
function enableExternalSource(factory, untrack = fn => fn()) {
  if (ExternalSourceConfig) {
    const {
      factory: oldFactory,
      untrack: oldUntrack
    } = ExternalSourceConfig;
    ExternalSourceConfig = {
      factory: (fn, trigger) => {
        const oldSource = oldFactory(fn, trigger);
        const source = factory(x => oldSource.track(x), trigger);
        return {
          track: x => source.track(x),
          dispose() {
            source.dispose();
            oldSource.dispose();
          }
        };
      },
      untrack: fn => oldUntrack(() => untrack(fn))
    };
  } else {
    ExternalSourceConfig = {
      factory,
      untrack
    };
  }
}
function readSignal() {
  const runningTransition = Transition && Transition.running;
  if (this.sources && (runningTransition ? this.tState : this.state)) {
    if ((runningTransition ? this.tState : this.state) === STALE) updateComputation(this);else {
      const updates = Updates;
      Updates = null;
      runUpdates(() => lookUpstream(this), false);
      Updates = updates;
    }
  }
  if (Listener) {
    const observers = this.observers;
    if (!observers || observers[observers.length - 1] !== Listener) {
      const sSlot = observers ? observers.length : 0;
      if (!Listener.sources) {
        Listener.sources = [this];
        Listener.sourceSlots = [sSlot];
      } else {
        Listener.sources.push(this);
        Listener.sourceSlots.push(sSlot);
      }
      if (!observers) {
        this.observers = [Listener];
        this.observerSlots = [Listener.sources.length - 1];
      } else {
        observers.push(Listener);
        this.observerSlots.push(Listener.sources.length - 1);
      }
    }
  }
  if (runningTransition && Transition.sources.has(this)) return this.tValue;
  return this.value;
}
function writeSignal(node, value, isComp) {
  let current = Transition && Transition.running && Transition.sources.has(node) ? node.tValue : node.value;
  if (!node.comparator || !node.comparator(current, value)) {
    if (Transition) {
      const TransitionRunning = Transition.running;
      if (TransitionRunning || !isComp && Transition.sources.has(node)) {
        Transition.sources.add(node);
        node.tValue = value;
      }
      if (!TransitionRunning) node.value = value;
    } else node.value = value;
    if (node.observers && node.observers.length) {
      runUpdates(() => {
        for (let i = 0; i < node.observers.length; i += 1) {
          const o = node.observers[i];
          const TransitionRunning = Transition && Transition.running;
          if (TransitionRunning && Transition.disposed.has(o)) continue;
          if (TransitionRunning ? !o.tState : !o.state) {
            if (o.pure) Updates.push(o);else Effects.push(o);
            if (o.observers) markDownstream(o);
          }
          if (!TransitionRunning) o.state = STALE;else o.tState = STALE;
        }
        if (Updates.length > 10e5) {
          Updates = [];
          if (false) {}
          throw new Error();
        }
      }, false);
    }
  }
  return value;
}
function updateComputation(node) {
  if (!node.fn) return;
  cleanNode(node);
  const time = ExecCount;
  runComputation(node, Transition && Transition.running && Transition.sources.has(node) ? node.tValue : node.value, time);
  if (Transition && !Transition.running && Transition.sources.has(node)) {
    queueMicrotask(() => {
      runUpdates(() => {
        Transition && (Transition.running = true);
        Listener = Owner = node;
        runComputation(node, node.tValue, time);
        Listener = Owner = null;
      }, false);
    });
  }
}
function runComputation(node, value, time) {
  let nextValue;
  const owner = Owner,
    listener = Listener;
  Listener = Owner = node;
  try {
    nextValue = node.fn(value);
  } catch (err) {
    if (node.pure) {
      if (Transition && Transition.running) {
        node.tState = STALE;
        node.tOwned && node.tOwned.forEach(cleanNode);
        node.tOwned = undefined;
      } else {
        node.state = STALE;
        node.owned && node.owned.forEach(cleanNode);
        node.owned = null;
      }
    }
    node.updatedAt = time + 1;
    return handleError(err);
  } finally {
    Listener = listener;
    Owner = owner;
  }
  if (!node.updatedAt || node.updatedAt <= time) {
    if (node.updatedAt != null && "observers" in node) {
      writeSignal(node, nextValue, true);
    } else if (Transition && Transition.running && node.pure) {
      if (!Transition.sources.has(node)) node.value = nextValue;
      Transition.sources.add(node);
      node.tValue = nextValue;
    } else node.value = nextValue;
    node.updatedAt = time;
  }
}
function createComputation(fn, init, pure, state = STALE, options) {
  const c = {
    fn,
    state: state,
    updatedAt: null,
    owned: null,
    sources: null,
    sourceSlots: null,
    cleanups: null,
    value: init,
    owner: Owner,
    context: Owner ? Owner.context : null,
    pure
  };
  if (Transition && Transition.running) {
    c.state = 0;
    c.tState = state;
  }
  if (Owner === null) ;else if (Owner !== UNOWNED) {
    if (Transition && Transition.running && Owner.pure) {
      if (!Owner.tOwned) Owner.tOwned = [c];else Owner.tOwned.push(c);
    } else {
      if (!Owner.owned) Owner.owned = [c];else Owner.owned.push(c);
    }
  }
  if (ExternalSourceConfig && c.fn) {
    const sourceFn = c.fn;
    const [track, trigger] = createSignal(undefined, {
      equals: false
    });
    const ordinary = ExternalSourceConfig.factory(sourceFn, trigger);
    onCleanup(() => ordinary.dispose());
    let inTransition;
    let trackedOrdinary = false;
    const triggerInTransition = () => startTransition(trigger).then(() => {
      if (inTransition) {
        inTransition.dispose();
        inTransition = undefined;
        if (!trackedOrdinary) trigger();
      }
    });
    c.fn = x => {
      track();
      if (Transition && Transition.running) {
        if (!inTransition) inTransition = ExternalSourceConfig.factory(sourceFn, triggerInTransition);
        return inTransition.track(x);
      }
      trackedOrdinary = true;
      return ordinary.track(x);
    };
  }
  return c;
}
function runTop(node) {
  const runningTransition = Transition && Transition.running;
  if ((runningTransition ? node.tState : node.state) === 0) return;
  if ((runningTransition ? node.tState : node.state) === PENDING) return lookUpstream(node);
  if (node.suspense && solid_untrack(node.suspense.inFallback)) return node.suspense.effects.push(node);
  const ancestors = [node];
  while ((node = node.owner) && (!node.updatedAt || node.updatedAt < ExecCount)) {
    if (runningTransition && Transition.disposed.has(node)) return;
    if (runningTransition ? node.tState : node.state) ancestors.push(node);
  }
  for (let i = ancestors.length - 1; i >= 0; i--) {
    node = ancestors[i];
    if (runningTransition) {
      let top = node,
        prev = ancestors[i + 1];
      while ((top = top.owner) && top !== prev) {
        if (Transition.disposed.has(top)) return;
      }
    }
    if ((runningTransition ? node.tState : node.state) === STALE) {
      updateComputation(node);
    } else if ((runningTransition ? node.tState : node.state) === PENDING) {
      const updates = Updates;
      Updates = null;
      runUpdates(() => lookUpstream(node, ancestors[0]), false);
      Updates = updates;
    }
  }
}
function runUpdates(fn, init) {
  if (Updates) return fn();
  let wait = false;
  if (!init) Updates = [];
  if (Effects) wait = true;else Effects = [];
  ExecCount++;
  try {
    const res = fn();
    completeUpdates(wait);
    return res;
  } catch (err) {
    if (!wait) Effects = null;
    Updates = null;
    handleError(err);
  }
}
function completeUpdates(wait) {
  if (Updates) {
    if (Scheduler && Transition && Transition.running) scheduleQueue(Updates);else runQueue(Updates);
    Updates = null;
  }
  if (wait) return;
  let res;
  if (Transition) {
    if (!Transition.promises.size && !Transition.queue.size) {
      const sources = Transition.sources;
      const disposed = Transition.disposed;
      Effects.push.apply(Effects, Transition.effects);
      res = Transition.resolve;
      for (const e of Effects) {
        "tState" in e && (e.state = e.tState);
        delete e.tState;
      }
      Transition = null;
      runUpdates(() => {
        for (const d of disposed) cleanNode(d);
        for (const v of sources) {
          v.value = v.tValue;
          if (v.owned) {
            for (let i = 0, len = v.owned.length; i < len; i++) cleanNode(v.owned[i]);
          }
          if (v.tOwned) v.owned = v.tOwned;
          delete v.tValue;
          delete v.tOwned;
          v.tState = 0;
        }
        setTransPending(false);
      }, false);
    } else if (Transition.running) {
      Transition.running = false;
      Transition.effects.push.apply(Transition.effects, Effects);
      Effects = null;
      setTransPending(true);
      return;
    }
  }
  const e = Effects;
  Effects = null;
  if (e.length) runUpdates(() => runEffects(e), false);
  if (res) res();
}
function runQueue(queue) {
  for (let i = 0; i < queue.length; i++) runTop(queue[i]);
}
function scheduleQueue(queue) {
  for (let i = 0; i < queue.length; i++) {
    const item = queue[i];
    const tasks = Transition.queue;
    if (!tasks.has(item)) {
      tasks.add(item);
      Scheduler(() => {
        tasks.delete(item);
        runUpdates(() => {
          Transition.running = true;
          runTop(item);
        }, false);
        Transition && (Transition.running = false);
      });
    }
  }
}
function runUserEffects(queue) {
  let i,
    userLength = 0;
  for (i = 0; i < queue.length; i++) {
    const e = queue[i];
    if (!e.user) runTop(e);else queue[userLength++] = e;
  }
  if (sharedConfig.context) {
    if (sharedConfig.count) {
      sharedConfig.effects || (sharedConfig.effects = []);
      sharedConfig.effects.push(...queue.slice(0, userLength));
      return;
    }
    setHydrateContext();
  }
  if (sharedConfig.effects && (sharedConfig.done || !sharedConfig.count)) {
    queue = [...sharedConfig.effects, ...queue];
    userLength += sharedConfig.effects.length;
    delete sharedConfig.effects;
  }
  for (i = 0; i < userLength; i++) runTop(queue[i]);
}
function lookUpstream(node, ignore) {
  const runningTransition = Transition && Transition.running;
  if (runningTransition) node.tState = 0;else node.state = 0;
  for (let i = 0; i < node.sources.length; i += 1) {
    const source = node.sources[i];
    if (source.sources) {
      const state = runningTransition ? source.tState : source.state;
      if (state === STALE) {
        if (source !== ignore && (!source.updatedAt || source.updatedAt < ExecCount)) runTop(source);
      } else if (state === PENDING) lookUpstream(source, ignore);
    }
  }
}
function markDownstream(node) {
  const runningTransition = Transition && Transition.running;
  for (let i = 0; i < node.observers.length; i += 1) {
    const o = node.observers[i];
    if (runningTransition ? !o.tState : !o.state) {
      if (runningTransition) o.tState = PENDING;else o.state = PENDING;
      if (o.pure) Updates.push(o);else Effects.push(o);
      o.observers && markDownstream(o);
    }
  }
}
function cleanNode(node) {
  let i;
  if (node.sources) {
    while (node.sources.length) {
      const source = node.sources.pop(),
        index = node.sourceSlots.pop(),
        obs = source.observers;
      if (obs && obs.length) {
        const n = obs.pop(),
          s = source.observerSlots.pop();
        if (index < obs.length) {
          n.sourceSlots[s] = index;
          obs[index] = n;
          source.observerSlots[index] = s;
        }
      }
    }
  }
  if (node.tOwned) {
    for (i = node.tOwned.length - 1; i >= 0; i--) cleanNode(node.tOwned[i]);
    delete node.tOwned;
  }
  if (Transition && Transition.running && node.pure) {
    solid_reset(node, true);
  } else if (node.owned) {
    for (i = node.owned.length - 1; i >= 0; i--) cleanNode(node.owned[i]);
    node.owned = null;
  }
  if (node.cleanups) {
    for (i = node.cleanups.length - 1; i >= 0; i--) node.cleanups[i]();
    node.cleanups = null;
  }
  if (Transition && Transition.running) node.tState = 0;else node.state = 0;
}
function solid_reset(node, top) {
  if (!top) {
    node.tState = 0;
    Transition.disposed.add(node);
  }
  if (node.owned) {
    for (let i = 0; i < node.owned.length; i++) solid_reset(node.owned[i]);
  }
}
function castError(err) {
  if (err instanceof Error) return err;
  return new Error(typeof err === "string" ? err : "Unknown error", {
    cause: err
  });
}
function runErrors(err, fns, owner) {
  try {
    for (const f of fns) f(err);
  } catch (e) {
    handleError(e, owner && owner.owner || null);
  }
}
function handleError(err, owner = Owner) {
  const fns = ERROR && owner && owner.context && owner.context[ERROR];
  const error = castError(err);
  if (!fns) throw error;
  if (Effects) Effects.push({
    fn() {
      runErrors(error, fns, owner);
    },
    state: STALE
  });else runErrors(error, fns, owner);
}
function resolveChildren(children) {
  if (typeof children === "function" && !children.length) return resolveChildren(children());
  if (Array.isArray(children)) {
    const results = [];
    for (let i = 0; i < children.length; i++) {
      const result = resolveChildren(children[i]);
      if (Array.isArray(result)) {
        if (result.length < 32768) results.push.apply(results, result);else for (let j = 0; j < result.length; j++) results.push(result[j]);
      } else {
        results.push(result);
      }
    }
    return results;
  }
  return children;
}
function createProvider(id, options) {
  return function provider(props) {
    let res;
    createRenderEffect(() => res = solid_untrack(() => {
      Owner.context = {
        ...Owner.context,
        [id]: props.value
      };
      return solid_children(() => props.children);
    }), undefined);
    return res;
  };
}
function onError(fn) {
  ERROR || (ERROR = Symbol("error"));
  if (Owner === null) ;else if (Owner.context === null || !Owner.context[ERROR]) {
    Owner.context = {
      ...Owner.context,
      [ERROR]: [fn]
    };
    mutateContext(Owner, ERROR, [fn]);
  } else Owner.context[ERROR].push(fn);
}
function mutateContext(o, key, value) {
  if (o.owned) {
    for (let i = 0; i < o.owned.length; i++) {
      if (o.owned[i].context === o.context) mutateContext(o.owned[i], key, value);
      if (!o.owned[i].context) {
        o.owned[i].context = o.context;
        mutateContext(o.owned[i], key, value);
      } else if (!o.owned[i].context[key]) {
        o.owned[i].context[key] = value;
        mutateContext(o.owned[i], key, value);
      }
    }
  }
}

function observable(input) {
  return {
    subscribe(observer) {
      if (!(observer instanceof Object) || observer == null) {
        throw new TypeError("Expected the observer to be an object.");
      }
      const handler = typeof observer === "function" ? observer : observer.next && observer.next.bind(observer);
      if (!handler) {
        return {
          unsubscribe() {}
        };
      }
      const dispose = createRoot(disposer => {
        createEffect(() => {
          const v = input();
          solid_untrack(() => handler(v));
        });
        return disposer;
      });
      if (getOwner()) onCleanup(dispose);
      return {
        unsubscribe() {
          dispose();
        }
      };
    },
    [Symbol.observable || "@@observable"]() {
      return this;
    }
  };
}
function from(producer, initalValue = undefined) {
  const [s, set] = createSignal(initalValue, {
    equals: false
  });
  if ("subscribe" in producer) {
    const unsub = producer.subscribe(v => set(() => v));
    onCleanup(() => "unsubscribe" in unsub ? unsub.unsubscribe() : unsub());
  } else {
    const clean = producer(set);
    onCleanup(clean);
  }
  return s;
}

const FALLBACK = Symbol("fallback");
function solid_dispose(d) {
  for (let i = 0; i < d.length; i++) d[i]();
}
function mapArray(list, mapFn, options = {}) {
  let items = [],
    mapped = [],
    disposers = [],
    len = 0,
    indexes = mapFn.length > 1 ? [] : null;
  onCleanup(() => solid_dispose(disposers));
  return () => {
    let newItems = list() || [],
      newLen = newItems.length,
      i,
      j;
    newItems[$TRACK];
    return solid_untrack(() => {
      let newIndices, newIndicesNext, temp, tempdisposers, tempIndexes, start, end, newEnd, item;
      if (newLen === 0) {
        if (len !== 0) {
          solid_dispose(disposers);
          disposers = [];
          items = [];
          mapped = [];
          len = 0;
          indexes && (indexes = []);
        }
        if (options.fallback) {
          items = [FALLBACK];
          mapped[0] = createRoot(disposer => {
            disposers[0] = disposer;
            return options.fallback();
          });
          len = 1;
        }
      }
      else if (len === 0) {
        mapped = new Array(newLen);
        for (j = 0; j < newLen; j++) {
          items[j] = newItems[j];
          mapped[j] = createRoot(mapper);
        }
        len = newLen;
      } else {
        temp = new Array(newLen);
        tempdisposers = new Array(newLen);
        indexes && (tempIndexes = new Array(newLen));
        for (start = 0, end = Math.min(len, newLen); start < end && items[start] === newItems[start]; start++);
        for (end = len - 1, newEnd = newLen - 1; end >= start && newEnd >= start && items[end] === newItems[newEnd]; end--, newEnd--) {
          temp[newEnd] = mapped[end];
          tempdisposers[newEnd] = disposers[end];
          indexes && (tempIndexes[newEnd] = indexes[end]);
        }
        newIndices = new Map();
        newIndicesNext = new Array(newEnd + 1);
        for (j = newEnd; j >= start; j--) {
          item = newItems[j];
          i = newIndices.get(item);
          newIndicesNext[j] = i === undefined ? -1 : i;
          newIndices.set(item, j);
        }
        for (i = start; i <= end; i++) {
          item = items[i];
          j = newIndices.get(item);
          if (j !== undefined && j !== -1) {
            temp[j] = mapped[i];
            tempdisposers[j] = disposers[i];
            indexes && (tempIndexes[j] = indexes[i]);
            j = newIndicesNext[j];
            newIndices.set(item, j);
          } else disposers[i]();
        }
        for (j = start; j < newLen; j++) {
          if (j in temp) {
            mapped[j] = temp[j];
            disposers[j] = tempdisposers[j];
            if (indexes) {
              indexes[j] = tempIndexes[j];
              indexes[j](j);
            }
          } else mapped[j] = createRoot(mapper);
        }
        mapped = mapped.slice(0, len = newLen);
        items = newItems.slice(0);
      }
      return mapped;
    });
    function mapper(disposer) {
      disposers[j] = disposer;
      if (indexes) {
        const [s, set] = createSignal(j);
        indexes[j] = set;
        return mapFn(newItems[j], s);
      }
      return mapFn(newItems[j]);
    }
  };
}
function indexArray(list, mapFn, options = {}) {
  let items = [],
    mapped = [],
    disposers = [],
    signals = [],
    len = 0,
    i;
  onCleanup(() => solid_dispose(disposers));
  return () => {
    const newItems = list() || [],
      newLen = newItems.length;
    newItems[$TRACK];
    return solid_untrack(() => {
      if (newLen === 0) {
        if (len !== 0) {
          solid_dispose(disposers);
          disposers = [];
          items = [];
          mapped = [];
          len = 0;
          signals = [];
        }
        if (options.fallback) {
          items = [FALLBACK];
          mapped[0] = createRoot(disposer => {
            disposers[0] = disposer;
            return options.fallback();
          });
          len = 1;
        }
        return mapped;
      }
      if (items[0] === FALLBACK) {
        disposers[0]();
        disposers = [];
        items = [];
        mapped = [];
        len = 0;
      }
      for (i = 0; i < newLen; i++) {
        if (i < items.length && items[i] !== newItems[i]) {
          signals[i](() => newItems[i]);
        } else if (i >= items.length) {
          mapped[i] = createRoot(mapper);
        }
      }
      for (; i < items.length; i++) {
        disposers[i]();
      }
      len = signals.length = disposers.length = newLen;
      items = newItems.slice(0);
      return mapped = mapped.slice(0, len);
    });
    function mapper(disposer) {
      disposers[i] = disposer;
      const [s, set] = createSignal(newItems[i]);
      signals[i] = set;
      return mapFn(s, i);
    }
  };
}

let hydrationEnabled = false;
function enableHydration() {
  hydrationEnabled = true;
}
function createComponent(Comp, props) {
  if (hydrationEnabled) {
    if (sharedConfig.context) {
      const c = sharedConfig.context;
      setHydrateContext(nextHydrateContext());
      const r = solid_untrack(() => Comp(props || {}));
      setHydrateContext(c);
      return r;
    }
  }
  return solid_untrack(() => Comp(props || {}));
}
function trueFn() {
  return true;
}
const propTraps = (/* unused pure expression or super */ null && ({
  get(_, property, receiver) {
    if (property === $PROXY) return receiver;
    return _.get(property);
  },
  has(_, property) {
    if (property === $PROXY) return true;
    return _.has(property);
  },
  set: trueFn,
  deleteProperty: trueFn,
  getOwnPropertyDescriptor(_, property) {
    return {
      configurable: true,
      enumerable: true,
      get() {
        return _.get(property);
      },
      set: trueFn,
      deleteProperty: trueFn
    };
  },
  ownKeys(_) {
    return _.keys();
  }
}));
function resolveSource(s) {
  return !(s = typeof s === "function" ? s() : s) ? {} : s;
}
function resolveSources() {
  for (let i = 0, length = this.length; i < length; ++i) {
    const v = this[i]();
    if (v !== undefined) return v;
  }
}
function mergeProps(...sources) {
  let proxy = false;
  for (let i = 0; i < sources.length; i++) {
    const s = sources[i];
    proxy = proxy || !!s && $PROXY in s;
    sources[i] = typeof s === "function" ? (proxy = true, createMemo(s)) : s;
  }
  if (SUPPORTS_PROXY && proxy) {
    return new Proxy({
      get(property) {
        for (let i = sources.length - 1; i >= 0; i--) {
          const v = resolveSource(sources[i])[property];
          if (v !== undefined) return v;
        }
      },
      has(property) {
        for (let i = sources.length - 1; i >= 0; i--) {
          if (property in resolveSource(sources[i])) return true;
        }
        return false;
      },
      keys() {
        const keys = [];
        for (let i = 0; i < sources.length; i++) keys.push(...Object.keys(resolveSource(sources[i])));
        return [...new Set(keys)];
      }
    }, propTraps);
  }
  const sourcesMap = {};
  const defined = Object.create(null);
  for (let i = sources.length - 1; i >= 0; i--) {
    const source = sources[i];
    if (!source) continue;
    const sourceKeys = Object.getOwnPropertyNames(source);
    for (let i = sourceKeys.length - 1; i >= 0; i--) {
      const key = sourceKeys[i];
      if (key === "__proto__" || key === "constructor") continue;
      const desc = Object.getOwnPropertyDescriptor(source, key);
      if (!defined[key]) {
        defined[key] = desc.get ? {
          enumerable: true,
          configurable: true,
          get: resolveSources.bind(sourcesMap[key] = [desc.get.bind(source)])
        } : desc.value !== undefined ? desc : undefined;
      } else {
        const sources = sourcesMap[key];
        if (sources) {
          if (desc.get) sources.push(desc.get.bind(source));else if (desc.value !== undefined) sources.push(() => desc.value);
        }
      }
    }
  }
  const target = {};
  const definedKeys = Object.keys(defined);
  for (let i = definedKeys.length - 1; i >= 0; i--) {
    const key = definedKeys[i],
      desc = defined[key];
    if (desc && desc.get) Object.defineProperty(target, key, desc);else target[key] = desc ? desc.value : undefined;
  }
  return target;
}
function splitProps(props, ...keys) {
  const len = keys.length;
  if (SUPPORTS_PROXY && $PROXY in props) {
    const blocked = len > 1 ? keys.flat() : keys[0];
    const claimed = new Set();
    const res = keys.map(k => {
      const owned = k.filter(property => !claimed.has(property) && (claimed.add(property), true));
      return new Proxy({
        get(property) {
          return owned.includes(property) ? props[property] : undefined;
        },
        has(property) {
          return owned.includes(property) && property in props;
        },
        keys() {
          return owned.filter(property => property in props);
        }
      }, propTraps);
    });
    res.push(new Proxy({
      get(property) {
        return blocked.includes(property) ? undefined : props[property];
      },
      has(property) {
        return blocked.includes(property) ? false : property in props;
      },
      keys() {
        return Object.keys(props).filter(k => !blocked.includes(k));
      }
    }, propTraps));
    return res;
  }
  const objects = [];
  for (let i = 0; i <= len; i++) {
    objects[i] = {};
  }
  for (const propName of Object.getOwnPropertyNames(props)) {
    let keyIndex = len;
    for (let i = 0; i < keys.length; i++) {
      if (keys[i].includes(propName)) {
        keyIndex = i;
        break;
      }
    }
    const desc = Object.getOwnPropertyDescriptor(props, propName);
    const isDefaultDesc = !desc.get && !desc.set && desc.enumerable && desc.writable && desc.configurable;
    isDefaultDesc ? objects[keyIndex][propName] = desc.value : Object.defineProperty(objects[keyIndex], propName, desc);
  }
  return objects;
}
function lazy(fn) {
  let comp;
  let p;
  const load = () => {
    if (!p) {
      const cur = p = fn();
      cur.then(mod => {
        comp = () => mod.default;
      }, () => {
        if (p === cur) p = undefined;
      });
    }
    return p;
  };
  const wrap = props => {
    const ctx = sharedConfig.context;
    if (ctx) {
      const [s, set] = createSignal();
      sharedConfig.count || (sharedConfig.count = 0);
      sharedConfig.count++;
      load().then(mod => {
        !sharedConfig.done && setHydrateContext(ctx);
        sharedConfig.count--;
        set(() => mod.default);
        setHydrateContext();
      }, err => {
        !sharedConfig.done && setHydrateContext(ctx);
        sharedConfig.count--;
        set(() => () => {
          throw err;
        });
        setHydrateContext();
      });
      comp = s;
    } else if (!comp) {
      const [s] = createResource(() => load().then(mod => mod.default));
      comp = s;
      onCleanup(() => {
        if (comp === s) comp = undefined;
      });
    }
    let Comp;
    return createMemo(() => (Comp = comp?.()) ? solid_untrack(() => {
      if (false) {}
      if (!ctx || sharedConfig.done) return Comp(props);
      const c = sharedConfig.context;
      setHydrateContext(ctx);
      const r = Comp(props);
      setHydrateContext(c);
      return r;
    }) : "");
  };
  wrap.preload = () => load();
  return wrap;
}
let solid_counter = 0;
function createUniqueId() {
  const ctx = sharedConfig.context;
  return ctx ? sharedConfig.getNextContextId() : `cl-${solid_counter++}`;
}

const narrowedError = name => `Stale read from <${name}>.`;
function For(props) {
  const fallback = "fallback" in props && {
    fallback: () => props.fallback
  };
  return createMemo(mapArray(() => props.each, props.children, fallback || undefined));
}
function Index(props) {
  const fallback = "fallback" in props && {
    fallback: () => props.fallback
  };
  return createMemo(indexArray(() => props.each, props.children, fallback || undefined));
}
function Show(props) {
  const keyed = props.keyed;
  const conditionValue = createMemo(() => props.when, undefined, undefined);
  const condition = keyed ? conditionValue : createMemo(conditionValue, undefined, {
    equals: (a, b) => !a === !b
  });
  return createMemo(() => {
    const c = condition();
    if (c) {
      const child = props.children;
      const fn = typeof child === "function" && child.length > 0;
      return fn ? solid_untrack(() => child(keyed ? c : () => {
        if (!solid_untrack(condition)) throw narrowedError("Show");
        return conditionValue();
      })) : child;
    }
    return props.fallback;
  }, undefined, undefined);
}
function Switch(props) {
  const chs = solid_children(() => props.children);
  const switchFunc = createMemo(() => {
    const ch = chs();
    const mps = Array.isArray(ch) ? ch : [ch];
    let func = () => undefined;
    for (let i = 0; i < mps.length; i++) {
      const index = i;
      const mp = mps[i];
      const prevFunc = func;
      const conditionValue = createMemo(() => prevFunc() ? undefined : mp.when, undefined, undefined);
      const condition = mp.keyed ? conditionValue : createMemo(conditionValue, undefined, {
        equals: (a, b) => !a === !b
      });
      func = () => prevFunc() || (condition() ? [index, conditionValue, mp] : undefined);
    }
    return func;
  });
  return createMemo(() => {
    const sel = switchFunc()();
    if (!sel) return props.fallback;
    const [index, conditionValue, mp] = sel;
    const child = mp.children;
    const fn = typeof child === "function" && child.length > 0;
    return fn ? solid_untrack(() => child(mp.keyed ? conditionValue() : () => {
      if (solid_untrack(switchFunc)()?.[0] !== index) throw narrowedError("Match");
      return conditionValue();
    })) : child;
  }, undefined, undefined);
}
function Match(props) {
  return props;
}
let Errors;
function resetErrorBoundaries() {
  Errors && [...Errors].forEach(fn => fn());
}
function ErrorBoundary(props) {
  let err;
  if (sharedConfig.context && sharedConfig.load) err = sharedConfig.load(sharedConfig.getContextId());
  const [errored, setErrored] = createSignal(err, undefined);
  Errors || (Errors = new Set());
  Errors.add(setErrored);
  onCleanup(() => Errors.delete(setErrored));
  return createMemo(() => {
    let e;
    if (e = errored()) {
      const f = props.fallback;
      return typeof f === "function" && f.length ? solid_untrack(() => f(e, () => setErrored())) : f;
    }
    return catchError(() => props.children, setErrored);
  }, undefined, undefined);
}

const suspenseListEquals = (a, b) => a.showContent === b.showContent && a.showFallback === b.showFallback;
const SuspenseListContext = /* #__PURE__ */(/* unused pure expression or super */ null && (createContext()));
function SuspenseList(props) {
  let [wrapper, setWrapper] = createSignal(() => ({
      inFallback: false
    })),
    show;
  const listContext = useContext(SuspenseListContext);
  const [registry, setRegistry] = createSignal([]);
  if (listContext) {
    show = listContext.register(createMemo(() => wrapper()().inFallback));
  }
  const resolved = createMemo(prev => {
    const reveal = props.revealOrder,
      tail = props.tail,
      {
        showContent = true,
        showFallback = true
      } = show ? show() : {},
      reg = registry(),
      reverse = reveal === "backwards";
    if (reveal === "together") {
      const all = reg.every(inFallback => !inFallback());
      const res = reg.map(() => ({
        showContent: all && showContent,
        showFallback
      }));
      res.inFallback = !all;
      return res;
    }
    let stop = false;
    let inFallback = prev.inFallback;
    const res = [];
    for (let i = 0, len = reg.length; i < len; i++) {
      const n = reverse ? len - i - 1 : i,
        s = reg[n]();
      if (!stop && !s) {
        res[n] = {
          showContent,
          showFallback
        };
      } else {
        const next = !stop;
        if (next) inFallback = true;
        res[n] = {
          showContent: next,
          showFallback: !tail || next && tail === "collapsed" ? showFallback : false
        };
        stop = true;
      }
    }
    if (!stop) inFallback = false;
    res.inFallback = inFallback;
    return res;
  }, {
    inFallback: false
  });
  setWrapper(() => resolved);
  return createComponent(SuspenseListContext.Provider, {
    value: {
      register: inFallback => {
        let index;
        setRegistry(registry => {
          index = registry.length;
          return [...registry, inFallback];
        });
        return createMemo(() => resolved()[index], undefined, {
          equals: suspenseListEquals
        });
      }
    },
    get children() {
      return props.children;
    }
  });
}
function Suspense(props) {
  let counter = 0,
    show,
    ctx,
    p,
    flicker,
    error;
  const [inFallback, setFallback] = createSignal(false),
    SuspenseContext = getSuspenseContext(),
    store = {
      increment: () => {
        if (++counter === 1) setFallback(true);
      },
      decrement: () => {
        if (--counter === 0) setFallback(false);
      },
      inFallback,
      effects: [],
      resolved: false
    },
    owner = getOwner();
  if (sharedConfig.context && sharedConfig.load) {
    const key = sharedConfig.getContextId();
    let ref = sharedConfig.load(key);
    if (ref) {
      if (typeof ref !== "object" || ref.s !== 1) p = ref;else sharedConfig.gather(key);
    }
    if (p && p !== "$$f") {
      const [s, set] = createSignal(undefined, {
        equals: false
      });
      flicker = s;
      p.then(() => {
        if (sharedConfig.done) return set();
        sharedConfig.gather(key);
        setHydrateContext(ctx);
        set();
        setHydrateContext();
      }, err => {
        error = err;
        set();
      });
    }
  }
  const listContext = useContext(SuspenseListContext);
  if (listContext) show = listContext.register(store.inFallback);
  let dispose;
  onCleanup(() => dispose && dispose());
  return createComponent(SuspenseContext.Provider, {
    value: store,
    get children() {
      return createMemo(() => {
        if (error) throw error;
        ctx = sharedConfig.context;
        if (flicker) {
          flicker();
          return flicker = undefined;
        }
        if (ctx && p === "$$f") setHydrateContext();
        const rendered = createMemo(() => props.children);
        return createMemo(prev => {
          const inFallback = store.inFallback(),
            {
              showContent = true,
              showFallback = true
            } = show ? show() : {};
          if ((!inFallback || p && p !== "$$f") && showContent) {
            store.resolved = true;
            dispose && dispose();
            dispose = ctx = p = undefined;
            resumeEffects(store.effects);
            return rendered();
          }
          if (!showFallback) return;
          if (dispose) return prev;
          return createRoot(disposer => {
            dispose = disposer;
            if (ctx) {
              setHydrateContext({
                id: ctx.id + "F",
                count: 0
              });
              ctx = undefined;
            }
            return props.fallback;
          }, owner);
        });
      });
    }
  });
}

const DEV = (/* unused pure expression or super */ null && (undefined));



;// CONCATENATED MODULE: ./node_modules/.pnpm/@lukeed+uuid@2.0.1/node_modules/@lukeed/uuid/dist/index.mjs
var IDX=256, HEX=[], BUFFER;
while (IDX--) HEX[IDX] = (IDX + 256).toString(16).substring(1);

function v4() {
	var i=0, num, out='';

	if (!BUFFER || ((IDX + 16) > 256)) {
		BUFFER = Array(i=256);
		while (i--) BUFFER[i] = 256 * Math.random() | 0;
		i = IDX = 0;
	}

	for (; i < 16; i++) {
		num = BUFFER[IDX + i];
		if (i==6) out += HEX[num & 15 | 64];
		else if (i==8) out += HEX[num & 63 | 128];
		else out += HEX[num];

		if (i & 1 && i > 1 && i < 11) out += '-';
	}

	IDX++;
	return out;
}

;// CONCATENATED MODULE: ./packages/anywidget/src/invoke.ts

function invoke(model, name, msg) {
    var options = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : {};
    var _options_signal;
    // crypto.randomUUID() is not available in non-secure contexts (i.e., http://)
    // so we use simple (non-secure) polyfill.
    var id = v4();
    var signal = (_options_signal = options.signal) !== null && _options_signal !== void 0 ? _options_signal : AbortSignal.timeout(3000);
    return new Promise(function(resolve, reject) {
        var _options_buffers;
        if (signal.aborted) {
            reject(signal.reason);
        }
        signal.addEventListener("abort", function() {
            model.off("msg:custom", handler);
            reject(signal.reason);
        });
        function handler(msg, buffers) {
            if (!(msg.id === id)) return;
            resolve([
                msg.response,
                buffers
            ]);
            model.off("msg:custom", handler);
        }
        model.on("msg:custom", handler);
        model.send({
            id: id,
            kind: "anywidget-command",
            name: name,
            msg: msg
        }, undefined, (_options_buffers = options.buffers) !== null && _options_buffers !== void 0 ? _options_buffers : []);
    });
}

;// CONCATENATED MODULE: ./packages/anywidget/src/widget-ref.ts
var WIDGET_REF_PREFIX = "anywidget:";
function parseWidgetRef(ref) {
    if (typeof ref === "string" && ref.startsWith(WIDGET_REF_PREFIX)) {
        return ref.slice(WIDGET_REF_PREFIX.length);
    }
    throw new Error("[anywidget] Invalid widget reference: ".concat(JSON.stringify(ref)));
}

;// CONCATENATED MODULE: ./packages/anywidget/src/host.ts
function host_asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) resolve(value);
    else Promise.resolve(value).then(_next, _throw);
}
function host_async_to_generator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                host_asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                host_asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}
function host_ts_generator(thisArg, body) {
    var f, y, t, _ = {
        label: 0,
        sent: function() {
            if (t[0] & 1) throw t[1];
            return t[1];
        },
        trys: [],
        ops: []
    }, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype), d = Object.defineProperty;
    return d(g, "next", {
        value: verb(0)
    }), d(g, "throw", {
        value: verb(1)
    }), d(g, "return", {
        value: verb(2)
    }), typeof Symbol === "function" && d(g, Symbol.iterator, {
        value: function() {
            return this;
        }
    }), g;
    function verb(n) {
        return function(v) {
            return step([
                n,
                v
            ]);
        };
    }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while(g && (g = 0, op[0] && (_ = 0)), _)try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [
                op[0] & 2,
                t.value
            ];
            switch(op[0]){
                case 0:
                case 1:
                    t = op;
                    break;
                case 4:
                    _.label++;
                    return {
                        value: op[1],
                        done: false
                    };
                case 5:
                    _.label++;
                    y = op[1];
                    op = [
                        0
                    ];
                    continue;
                case 7:
                    op = _.ops.pop();
                    _.trys.pop();
                    continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                        _ = 0;
                        continue;
                    }
                    if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                        _.label = op[1];
                        break;
                    }
                    if (op[0] === 6 && _.label < t[1]) {
                        _.label = t[1];
                        t = op;
                        break;
                    }
                    if (t && _.label < t[2]) {
                        _.label = t[2];
                        _.ops.push(op);
                        break;
                    }
                    if (t[2]) _.ops.pop();
                    _.trys.pop();
                    continue;
            }
            op = body.call(thisArg, _);
        } catch (e) {
            op = [
                6,
                e
            ];
            y = 0;
        } finally{
            f = t = 0;
        }
        if (op[0] & 5) throw op[1];
        return {
            value: op[0] ? op[1] : void 0,
            done: true
        };
    }
}




function createHost(model, param) {
    var signal = param.signal;
    var host = {
        getModel: // @ts-expect-error - modelProxy returns AnyModel; generic T is erased at runtime
        function getModel(ref) {
            return host_async_to_generator(function() {
                var modelId, childModel, context;
                return host_ts_generator(this, function(_state) {
                    switch(_state.label){
                        case 0:
                            modelId = parseWidgetRef(ref);
                            return [
                                4,
                                model.widget_manager.get_model(modelId)
                            ];
                        case 1:
                            childModel = _state.sent();
                            context = Symbol("anywidget.host.getModel");
                            signal.addEventListener("abort", function() {
                                return childModel.off(null, null, context);
                            });
                            return [
                                2,
                                modelProxy(childModel, context)
                            ];
                    }
                });
            })();
        },
        getWidget: // @ts-expect-error - generic T is erased at runtime, exports typed as unknown
        function getWidget(ref) {
            return host_async_to_generator(function() {
                var modelId, childModel, childBinding, timer, exports;
                return host_ts_generator(this, function(_state) {
                    switch(_state.label){
                        case 0:
                            modelId = parseWidgetRef(ref);
                            return [
                                4,
                                model.widget_manager.get_model(modelId)
                            ];
                        case 1:
                            childModel = _state.sent();
                            childBinding = BINDINGS.get(childModel);
                            if (!childBinding) {
                                throw new Error("[anywidget] No binding found for widget ".concat(modelId));
                            }
                            return [
                                4,
                                new Promise(function(resolve, reject) {
                                    timer = setTimeout(function() {
                                        return reject(new Error("[anywidget] Timed out waiting for widget ".concat(modelId, " to initialize")));
                                    }, 10000);
                                    childBinding.ready.then(resolve, reject);
                                }).finally(function() {
                                    return clearTimeout(timer);
                                })
                            ];
                        case 2:
                            exports = _state.sent();
                            return [
                                2,
                                {
                                    exports: exports,
                                    render: function render(_0) {
                                        return host_async_to_generator(function(param) {
                                            var el, viewSignal, childViewSignal;
                                            return host_ts_generator(this, function(_state) {
                                                switch(_state.label){
                                                    case 0:
                                                        el = param.el, viewSignal = param.signal;
                                                        childViewSignal = viewSignal !== null && viewSignal !== void 0 ? viewSignal : signal;
                                                        return [
                                                            4,
                                                            childBinding.createView({
                                                                el: el
                                                            }, {
                                                                signal: childViewSignal,
                                                                experimental: {
                                                                    // @ts-expect-error - bind isn't working
                                                                    invoke: invoke.bind(null, childModel)
                                                                },
                                                                host: host
                                                            })
                                                        ];
                                                    case 1:
                                                        _state.sent();
                                                        return [
                                                            2
                                                        ];
                                                }
                                            });
                                        }).apply(this, arguments);
                                    }
                                }
                            ];
                    }
                });
            })();
        }
    };
    return host;
}

;// CONCATENATED MODULE: ./packages/anywidget/src/load.ts
function load_asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) resolve(value);
    else Promise.resolve(value).then(_next, _throw);
}
function load_async_to_generator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                load_asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                load_asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}
function load_ts_generator(thisArg, body) {
    var f, y, t, _ = {
        label: 0,
        sent: function() {
            if (t[0] & 1) throw t[1];
            return t[1];
        },
        trys: [],
        ops: []
    }, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype), d = Object.defineProperty;
    return d(g, "next", {
        value: verb(0)
    }), d(g, "throw", {
        value: verb(1)
    }), d(g, "return", {
        value: verb(2)
    }), typeof Symbol === "function" && d(g, Symbol.iterator, {
        value: function() {
            return this;
        }
    }), g;
    function verb(n) {
        return function(v) {
            return step([
                n,
                v
            ]);
        };
    }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while(g && (g = 0, op[0] && (_ = 0)), _)try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [
                op[0] & 2,
                t.value
            ];
            switch(op[0]){
                case 0:
                case 1:
                    t = op;
                    break;
                case 4:
                    _.label++;
                    return {
                        value: op[1],
                        done: false
                    };
                case 5:
                    _.label++;
                    y = op[1];
                    op = [
                        0
                    ];
                    continue;
                case 7:
                    op = _.ops.pop();
                    _.trys.pop();
                    continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                        _ = 0;
                        continue;
                    }
                    if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                        _.label = op[1];
                        break;
                    }
                    if (op[0] === 6 && _.label < t[1]) {
                        _.label = t[1];
                        t = op;
                        break;
                    }
                    if (t && _.label < t[2]) {
                        _.label = t[2];
                        _.ops.push(op);
                        break;
                    }
                    if (t[2]) _.ops.pop();
                    _.trys.pop();
                    continue;
            }
            op = body.call(thisArg, _);
        } catch (e) {
            op = [
                6,
                e
            ];
            y = 0;
        } finally{
            f = t = 0;
        }
        if (op[0] & 5) throw op[1];
        return {
            value: op[0] ? op[1] : void 0,
            done: true
        };
    }
}

function isHref(str) {
    return str.startsWith("http://") || str.startsWith("https://");
}
function loadCssHref(href, anywidgetId) {
    return load_async_to_generator(function() {
        var prev, newLink;
        return load_ts_generator(this, function(_state) {
            prev = document.querySelector("link[id='".concat(anywidgetId, "']"));
            // Adapted from https://github.com/vitejs/vite/blob/d59e1acc2efc0307488364e9f2fad528ec57f204/packages/vite/src/client/client.ts#L185-L201
            // Swaps out old styles with new, but avoids flash of unstyled content.
            // No need to await the load since we already have styles applied.
            if (prev) {
                // oxlint-disable-next-line typescript-eslint/no-unsafe-type-assertion -- Node.cloneNode() returns Node; we know prev is HTMLLinkElement so the clone is too
                newLink = prev.cloneNode();
                newLink.href = href;
                newLink.addEventListener("load", function() {
                    return prev === null || prev === void 0 ? void 0 : prev.remove();
                });
                newLink.addEventListener("error", function() {
                    return prev === null || prev === void 0 ? void 0 : prev.remove();
                });
                prev.after(newLink);
                return [
                    2
                ];
            }
            return [
                2,
                new Promise(function(resolve) {
                    var link = Object.assign(document.createElement("link"), {
                        rel: "stylesheet",
                        href: href,
                        onload: resolve
                    });
                    document.head.appendChild(link);
                })
            ];
        });
    })();
}
function loadCssText(cssText, anywidgetId) {
    var prev = document.querySelector("style[id='".concat(anywidgetId, "']"));
    if (prev) {
        // replace instead of creating a new DOM node
        prev.textContent = cssText;
        return;
    }
    var style = Object.assign(document.createElement("style"), {
        id: anywidgetId,
        type: "text/css"
    });
    style.appendChild(document.createTextNode(cssText));
    document.head.appendChild(style);
}
function loadCss(css, anywidgetId) {
    return load_async_to_generator(function() {
        return load_ts_generator(this, function(_state) {
            if (!css || !anywidgetId) return [
                2
            ];
            if (isHref(css)) return [
                2,
                loadCssHref(css, anywidgetId)
            ];
            return [
                2,
                loadCssText(css, anywidgetId)
            ];
        });
    })();
}
function loadEsm(esm) {
    return load_async_to_generator(function() {
        var url, mod;
        return load_ts_generator(this, function(_state) {
            switch(_state.label){
                case 0:
                    if (!isHref(esm)) return [
                        3,
                        2
                    ];
                    return [
                        4,
                        import(/* webpackIgnore: true */ /* @vite-ignore */ esm)
                    ];
                case 1:
                    return [
                        2,
                        _state.sent()
                    ];
                case 2:
                    url = URL.createObjectURL(new Blob([
                        esm
                    ], {
                        type: "text/javascript"
                    }));
                    return [
                        4,
                        import(/* webpackIgnore: true */ /* @vite-ignore */ url)
                    ];
                case 3:
                    mod = _state.sent();
                    URL.revokeObjectURL(url);
                    return [
                        2,
                        mod
                    ];
            }
        });
    })();
}
function warnRenderDeprecation(anywidgetId) {
    console.warn("[anywidget] Deprecation Warning for ".concat(anywidgetId, ": Direct export of a 'render' will likely be deprecated in the future. To migrate ...\n\nRemove the 'export' keyword from 'render'\n-----------------------------------------\n\nexport function render({ model, el }) { ... }\n^^^^^^\n\nCreate a default export that returns an object with 'render'\n------------------------------------------------------------\n\nfunction render({ model, el }) { ... }\n         ^^^^^^\nexport default { render }\n                 ^^^^^^\n\nPin to anywidget>=0.9.0 in your pyproject.toml\n----------------------------------------------\n\ndependencies = [\"anywidget>=0.9.0\"]\n\nTo learn more, please see: https://github.com/manzt/anywidget/pull/395.\n"));
}
function loadWidget(esm, anywidgetId) {
    return load_async_to_generator(function() {
        var mod, widget, _tmp;
        return load_ts_generator(this, function(_state) {
            switch(_state.label){
                case 0:
                    return [
                        4,
                        loadEsm(esm)
                    ];
                case 1:
                    mod = _state.sent();
                    if (mod.render) {
                        warnRenderDeprecation(anywidgetId);
                        return [
                            2,
                            {
                                initialize: function initialize() {
                                    return load_async_to_generator(function() {
                                        return load_ts_generator(this, function(_state) {
                                            return [
                                                2
                                            ];
                                        });
                                    })();
                                },
                                render: mod.render
                            }
                        ];
                    }
                    assert(mod.default, "[anywidget] module must export a default function or object.");
                    if (!(typeof mod.default === "function")) return [
                        3,
                        3
                    ];
                    return [
                        4,
                        mod.default()
                    ];
                case 2:
                    _tmp = _state.sent();
                    return [
                        3,
                        4
                    ];
                case 3:
                    _tmp = mod.default;
                    _state.label = 4;
                case 4:
                    widget = _tmp;
                    return [
                        2,
                        widget
                    ];
            }
        });
    })();
}

;// CONCATENATED MODULE: ./packages/anywidget/src/observe.ts
function _array_like_to_array(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_with_holes(arr) {
    if (Array.isArray(arr)) return arr;
}
function _iterable_to_array_limit(arr, i) {
    var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
    if (_i == null) return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _s, _e;
    try {
        for(_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true){
            _arr.push(_s.value);
            if (i && _arr.length === i) break;
        }
    } catch (err) {
        _d = true;
        _e = err;
    } finally{
        try {
            if (!_n && _i["return"] != null) _i["return"]();
        } finally{
            if (_d) throw _e;
        }
    }
    return _arr;
}
function _non_iterable_rest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _sliced_to_array(arr, i) {
    return _array_with_holes(arr) || _iterable_to_array_limit(arr, i) || _unsupported_iterable_to_array(arr, i) || _non_iterable_rest();
}
function _unsupported_iterable_to_array(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array(o, minLen);
}

function observe(model, name, param) {
    var signal = param.signal;
    var _solid_createSignal = _sliced_to_array(createSignal(model.get(name)), 2), get = _solid_createSignal[0], set = _solid_createSignal[1];
    var update = function update() {
        return set(function() {
            return model.get(name);
        });
    };
    model.on("change:".concat(name), update);
    signal === null || signal === void 0 ? void 0 : signal.addEventListener("abort", function() {
        model.off("change:".concat(name), update);
    });
    return get;
}

;// CONCATENATED MODULE: ./packages/anywidget/src/runtime.ts
function runtime_array_like_to_array(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function runtime_array_with_holes(arr) {
    if (Array.isArray(arr)) return arr;
}
function runtime_asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) resolve(value);
    else Promise.resolve(value).then(_next, _throw);
}
function runtime_async_to_generator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                runtime_asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                runtime_asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}
function runtime_check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function runtime_class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) return descriptor.get.call(receiver);
    return descriptor.value;
}
function runtime_class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) descriptor.set.call(receiver, value);
    else {
        if (!descriptor.writable) {
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
function runtime_class_call_check(instance, Constructor) {
    if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
}
function runtime_class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) throw new TypeError("attempted to " + action + " private field on non-instance");
    return privateMap.get(receiver);
}
function runtime_class_private_field_get(receiver, privateMap) {
    var descriptor = runtime_class_extract_field_descriptor(receiver, privateMap, "get");
    return runtime_class_apply_descriptor_get(receiver, descriptor);
}
function runtime_class_private_field_init(obj, privateMap, value) {
    runtime_check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function runtime_class_private_field_set(receiver, privateMap, value) {
    var descriptor = runtime_class_extract_field_descriptor(receiver, privateMap, "set");
    runtime_class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}
function runtime_defineProperties(target, props) {
    for(var i = 0; i < props.length; i++){
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}
function runtime_create_class(Constructor, protoProps, staticProps) {
    if (protoProps) runtime_defineProperties(Constructor.prototype, protoProps);
    if (staticProps) runtime_defineProperties(Constructor, staticProps);
    return Constructor;
}
function runtime_iterable_to_array_limit(arr, i) {
    var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
    if (_i == null) return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _s, _e;
    try {
        for(_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true){
            _arr.push(_s.value);
            if (i && _arr.length === i) break;
        }
    } catch (err) {
        _d = true;
        _e = err;
    } finally{
        try {
            if (!_n && _i["return"] != null) _i["return"]();
        } finally{
            if (_d) throw _e;
        }
    }
    return _arr;
}
function runtime_non_iterable_rest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function runtime_sliced_to_array(arr, i) {
    return runtime_array_with_holes(arr) || runtime_iterable_to_array_limit(arr, i) || runtime_unsupported_iterable_to_array(arr, i) || runtime_non_iterable_rest();
}
function runtime_ts_generator(thisArg, body) {
    var f, y, t, _ = {
        label: 0,
        sent: function() {
            if (t[0] & 1) throw t[1];
            return t[1];
        },
        trys: [],
        ops: []
    }, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype), d = Object.defineProperty;
    return d(g, "next", {
        value: verb(0)
    }), d(g, "throw", {
        value: verb(1)
    }), d(g, "return", {
        value: verb(2)
    }), typeof Symbol === "function" && d(g, Symbol.iterator, {
        value: function() {
            return this;
        }
    }), g;
    function verb(n) {
        return function(v) {
            return step([
                n,
                v
            ]);
        };
    }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while(g && (g = 0, op[0] && (_ = 0)), _)try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [
                op[0] & 2,
                t.value
            ];
            switch(op[0]){
                case 0:
                case 1:
                    t = op;
                    break;
                case 4:
                    _.label++;
                    return {
                        value: op[1],
                        done: false
                    };
                case 5:
                    _.label++;
                    y = op[1];
                    op = [
                        0
                    ];
                    continue;
                case 7:
                    op = _.ops.pop();
                    _.trys.pop();
                    continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                        _ = 0;
                        continue;
                    }
                    if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                        _.label = op[1];
                        break;
                    }
                    if (op[0] === 6 && _.label < t[1]) {
                        _.label = t[1];
                        t = op;
                        break;
                    }
                    if (t && _.label < t[2]) {
                        _.label = t[2];
                        _.ops.push(op);
                        break;
                    }
                    if (t[2]) _.ops.pop();
                    _.trys.pop();
                    continue;
            }
            op = body.call(thisArg, _);
        } catch (e) {
            op = [
                6,
                e
            ];
            y = 0;
        } finally{
            f = t = 0;
        }
        if (op[0] & 5) throw op[1];
        return {
            value: op[0] ? op[1] : void 0,
            done: true
        };
    }
}
function runtime_unsupported_iterable_to_array(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return runtime_array_like_to_array(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return runtime_array_like_to_array(o, minLen);
}







var // @ts-expect-error - Set synchronously in constructor.
_widgetResult = /*#__PURE__*/ new WeakMap(), _signal = /*#__PURE__*/ new WeakMap();
var runtime_Runtime = /*#__PURE__*/ function() {
    "use strict";
    function Runtime(model, options) {
        var _this = this;
        runtime_class_call_check(this, Runtime);
        runtime_class_private_field_init(this, _widgetResult, {
            writable: true,
            value: void 0
        });
        runtime_class_private_field_init(this, _signal, {
            writable: true,
            value: void 0
        });
        runtime_class_private_field_set(this, _signal, options.signal);
        runtime_class_private_field_get(this, _signal).throwIfAborted();
        runtime_class_private_field_get(this, _signal).addEventListener("abort", function() {
            return dispose();
        });
        var binding = BINDINGS.getOrCreate(model);
        var experimental = {
            // @ts-expect-error - invoke.bind loses generic type parameter
            invoke: invoke.bind(null, model)
        };
        var dispose = createRoot(function(dispose) {
            // DOMWidgetModel is untyped by trait shape; we know the anywidget traits, so narrow to AnyModel<State> for type-safe `.get()` access
            // oxlint-disable-next-line typescript-eslint/no-unsafe-type-assertion -- see above
            var typedModel = model;
            var id = typedModel.get("_anywidget_id");
            var css = observe(typedModel, "_css", {
                signal: runtime_class_private_field_get(_this, _signal)
            });
            var esm = observe(typedModel, "_esm", {
                signal: runtime_class_private_field_get(_this, _signal)
            });
            var _solid_createSignal = runtime_sliced_to_array(createSignal({
                status: "pending"
            }), 2), widgetResult = _solid_createSignal[0], setWidgetResult = _solid_createSignal[1];
            runtime_class_private_field_set(_this, _widgetResult, widgetResult);
            createEffect(solid_on(css, function() {
                return console.debug("[anywidget] css hot updated: ".concat(id));
            }, {
                defer: true
            }));
            createEffect(solid_on(esm, function() {
                return console.debug("[anywidget] esm hot updated: ".concat(id));
            }, {
                defer: true
            }));
            createEffect(function() {
                return loadCss(css(), id);
            });
            createEffect(function() {
                // Per-effect controller so a stale loadWidget resolution from a
                // previous _esm value cannot overwrite a newer one. Solid fires
                // onCleanup before re-running the effect, aborting the prior load.
                var controller = new AbortController();
                onCleanup(function() {
                    return controller.abort();
                });
                loadWidget(esm(), id).then(function(widget) {
                    return runtime_async_to_generator(function() {
                        return runtime_ts_generator(this, function(_state) {
                            switch(_state.label){
                                case 0:
                                    if (controller.signal.aborted) return [
                                        2
                                    ];
                                    return [
                                        4,
                                        binding.bind(widget, {
                                            experimental: experimental
                                        })
                                    ];
                                case 1:
                                    _state.sent();
                                    if (controller.signal.aborted) return [
                                        2
                                    ];
                                    setWidgetResult({
                                        status: "ready",
                                        data: widget
                                    });
                                    return [
                                        2
                                    ];
                            }
                        });
                    })();
                }).catch(function(error) {
                    if (controller.signal.aborted) return;
                    setWidgetResult({
                        status: "error",
                        error: error
                    });
                });
            });
            return dispose;
        });
    }
    runtime_create_class(Runtime, [
        {
            key: "createView",
            value: function createView(view, options) {
                return runtime_async_to_generator(function() {
                    var _this, model, signal, binding, experimental, host, dispose;
                    return runtime_ts_generator(this, function(_state) {
                        _this = this;
                        model = view.model;
                        signal = AbortSignal.any([
                            runtime_class_private_field_get(this, _signal),
                            options.signal
                        ]); // either model or view destroyed
                        signal.throwIfAborted();
                        signal.addEventListener("abort", function() {
                            return dispose();
                        });
                        binding = BINDINGS.get(model);
                        assert(binding, "[anywidget] WidgetBinding not found.");
                        experimental = {
                            // @ts-expect-error - invoke.bind loses generic type parameter
                            invoke: invoke.bind(null, model)
                        };
                        host = createHost(model, {
                            signal: signal
                        });
                        dispose = createRoot(function(dispose) {
                            createEffect(function() {
                                // Clear all previous event listeners from this hook.
                                model.off(null, null, view);
                                view.$el.empty();
                                var result = runtime_class_private_field_get(_this, _widgetResult).call(_this);
                                if (result.status === "pending") {
                                    return;
                                }
                                if (result.status === "error") {
                                    throwAnywidgetError(result.error);
                                    return;
                                }
                                var controller = new AbortController();
                                onCleanup(function() {
                                    return controller.abort();
                                });
                                Promise.resolve().then(function() {
                                    return binding.createView(view, {
                                        signal: AbortSignal.any([
                                            signal,
                                            controller.signal
                                        ]),
                                        experimental: experimental,
                                        host: host
                                    });
                                }).catch(function(error) {
                                    return throwAnywidgetError(error);
                                });
                            });
                            return function() {
                                return dispose();
                            };
                        });
                        return [
                            2
                        ];
                    });
                }).call(this);
            }
        }
    ]);
    return Runtime;
}();

;// CONCATENATED MODULE: ./packages/anywidget/src/widget.ts
function widget_array_like_to_array(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_without_holes(arr) {
    if (Array.isArray(arr)) return widget_array_like_to_array(arr);
}
function _assert_this_initialized(self) {
    if (self === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return self;
}
function widget_asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) resolve(value);
    else Promise.resolve(value).then(_next, _throw);
}
function widget_async_to_generator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                widget_asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                widget_asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}
function _call_super(_this, derived, args) {
    derived = _get_prototype_of(derived);
    return _possible_constructor_return(_this, _is_native_reflect_construct() ? Reflect.construct(derived, args || [], _get_prototype_of(_this).constructor) : derived.apply(_this, args));
}
function widget_check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function widget_class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) return descriptor.get.call(receiver);
    return descriptor.value;
}
function widget_class_call_check(instance, Constructor) {
    if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
}
function widget_class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) throw new TypeError("attempted to " + action + " private field on non-instance");
    return privateMap.get(receiver);
}
function widget_class_private_field_get(receiver, privateMap) {
    var descriptor = widget_class_extract_field_descriptor(receiver, privateMap, "get");
    return widget_class_apply_descriptor_get(receiver, descriptor);
}
function widget_class_private_field_init(obj, privateMap, value) {
    widget_check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function widget_defineProperties(target, props) {
    for(var i = 0; i < props.length; i++){
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}
function widget_create_class(Constructor, protoProps, staticProps) {
    if (protoProps) widget_defineProperties(Constructor.prototype, protoProps);
    if (staticProps) widget_defineProperties(Constructor, staticProps);
    return Constructor;
}
function widget_define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else obj[key] = value;
    return obj;
}
function _get(target, property, receiver) {
    if (typeof Reflect !== "undefined" && Reflect.get) _get = Reflect.get;
    else {
        _get = function get(target, property, receiver) {
            var base = _super_prop_base(target, property);
            if (!base) return;
            var desc = Object.getOwnPropertyDescriptor(base, property);
            if (desc.get) return desc.get.call(receiver || target);
            return desc.value;
        };
    }
    return _get(target, property, receiver || target);
}
function _get_prototype_of(o) {
    _get_prototype_of = Object.setPrototypeOf ? Object.getPrototypeOf : function getPrototypeOf(o) {
        return o.__proto__ || Object.getPrototypeOf(o);
    };
    return _get_prototype_of(o);
}
function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
        throw new TypeError("Super expression must either be null or a function");
    }
    subClass.prototype = Object.create(superClass && superClass.prototype, {
        constructor: {
            value: subClass,
            writable: true,
            configurable: true
        }
    });
    if (superClass) _set_prototype_of(subClass, superClass);
}
function _is_native_reflect_construct() {
    try {
        var result = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
    } catch (_) {}
    return (_is_native_reflect_construct = function() {
        return !!result;
    })();
}
function _iterable_to_array(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) {
        return Array.from(iter);
    }
}
function _non_iterable_spread() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _possible_constructor_return(self, call) {
    if (call && (widget_type_of(call) === "object" || typeof call === "function")) return call;
    return _assert_this_initialized(self);
}
function _set_prototype_of(o, p) {
    _set_prototype_of = Object.setPrototypeOf || function setPrototypeOf(o, p) {
        o.__proto__ = p;
        return o;
    };
    return _set_prototype_of(o, p);
}
function _super_prop_base(object, property) {
    while(!Object.prototype.hasOwnProperty.call(object, property)){
        object = _get_prototype_of(object);
        if (object === null) break;
    }
    return object;
}
function _to_consumable_array(arr) {
    return _array_without_holes(arr) || _iterable_to_array(arr) || widget_unsupported_iterable_to_array(arr) || _non_iterable_spread();
}
function widget_ts_generator(thisArg, body) {
    var f, y, t, _ = {
        label: 0,
        sent: function() {
            if (t[0] & 1) throw t[1];
            return t[1];
        },
        trys: [],
        ops: []
    }, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype), d = Object.defineProperty;
    return d(g, "next", {
        value: verb(0)
    }), d(g, "throw", {
        value: verb(1)
    }), d(g, "return", {
        value: verb(2)
    }), typeof Symbol === "function" && d(g, Symbol.iterator, {
        value: function() {
            return this;
        }
    }), g;
    function verb(n) {
        return function(v) {
            return step([
                n,
                v
            ]);
        };
    }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while(g && (g = 0, op[0] && (_ = 0)), _)try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [
                op[0] & 2,
                t.value
            ];
            switch(op[0]){
                case 0:
                case 1:
                    t = op;
                    break;
                case 4:
                    _.label++;
                    return {
                        value: op[1],
                        done: false
                    };
                case 5:
                    _.label++;
                    y = op[1];
                    op = [
                        0
                    ];
                    continue;
                case 7:
                    op = _.ops.pop();
                    _.trys.pop();
                    continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                        _ = 0;
                        continue;
                    }
                    if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                        _.label = op[1];
                        break;
                    }
                    if (op[0] === 6 && _.label < t[1]) {
                        _.label = t[1];
                        t = op;
                        break;
                    }
                    if (t && _.label < t[2]) {
                        _.label = t[2];
                        _.ops.push(op);
                        break;
                    }
                    if (t[2]) _.ops.pop();
                    _.trys.pop();
                    continue;
            }
            op = body.call(thisArg, _);
        } catch (e) {
            op = [
                6,
                e
            ];
            y = 0;
        } finally{
            f = t = 0;
        }
        if (op[0] & 5) throw op[1];
        return {
            value: op[0] ? op[1] : void 0,
            done: true
        };
    }
}
function widget_type_of(obj) {
    "@swc/helpers - typeof";
    return obj && typeof Symbol !== "undefined" && obj.constructor === Symbol ? "symbol" : typeof obj;
}
function widget_unsupported_iterable_to_array(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return widget_array_like_to_array(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return widget_array_like_to_array(o, minLen);
}



// @ts-expect-error - injected by bundler
var version = "0.11.0";
/* export default */ function src_widget(param) {
    var DOMWidgetModel = param.DOMWidgetModel, DOMWidgetView = param.DOMWidgetView;
    var RUNTIMES = new WeakMap();
    var AnyModel = /*#__PURE__*/ function(DOMWidgetModel) {
        "use strict";
        _inherits(AnyModel, DOMWidgetModel);
        function AnyModel() {
            widget_class_call_check(this, AnyModel);
            return _call_super(this, AnyModel, arguments);
        }
        widget_create_class(AnyModel, [
            {
                key: "initialize",
                value: function initialize() {
                    var _this = this;
                    for(var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++){
                        args[_key] = arguments[_key];
                    }
                    var _$_get;
                    (_$_get = _get(_get_prototype_of(AnyModel.prototype), "initialize", this)).call.apply(_$_get, [
                        this
                    ].concat(_to_consumable_array(args)));
                    var controller = new AbortController();
                    this.once("destroy", function() {
                        controller.abort("[anywidget] Runtime destroyed.");
                        BINDINGS.destroy(_this);
                        RUNTIMES.delete(_this);
                    });
                    RUNTIMES.set(this, new runtime_Runtime(this, {
                        signal: controller.signal
                    }));
                }
            },
            {
                /**
     * We override to support binary trailets because JSON.parse(JSON.stringify())
     * does not properly clone binary data (it just returns an empty object).
     *
     * https://github.com/jupyter-widgets/ipywidgets/blob/47058a373d2c2b3acf101677b2745e14b76dd74b/packages/base/src/widget.ts#L562-L583
     */ key: "serialize",
                value: function serialize(state) {
                    // oxlint-disable-next-line typescript-eslint/no-unsafe-type-assertion -- accessing static `.serializers` on `this.constructor`
                    var serializers = this.constructor.serializers || {};
                    var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
                    try {
                        for(var _iterator = Object.keys(state)[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
                            var k = _step.value;
                            try {
                                var _serializers_k, _state_k;
                                var serialize = (_serializers_k = serializers[k]) === null || _serializers_k === void 0 ? void 0 : _serializers_k.serialize;
                                if (serialize) {
                                    state[k] = serialize(state[k], this);
                                } else if (k === "layout" || k === "style") {
                                    // These keys come from ipywidgets, rely on JSON.stringify trick.
                                    state[k] = JSON.parse(JSON.stringify(state[k]));
                                } else {
                                    state[k] = structuredClone(state[k]);
                                }
                                if (typeof ((_state_k = state[k]) === null || _state_k === void 0 ? void 0 : _state_k.toJSON) === "function") {
                                    state[k] = state[k].toJSON();
                                }
                            } catch (e) {
                                console.error("Error serializing widget state attribute: ", k);
                                throw e;
                            }
                        }
                    } catch (err) {
                        _didIteratorError = true;
                        _iteratorError = err;
                    } finally{
                        try {
                            if (!_iteratorNormalCompletion && _iterator.return != null) {
                                _iterator.return();
                            }
                        } finally{
                            if (_didIteratorError) {
                                throw _iteratorError;
                            }
                        }
                    }
                    return state;
                }
            }
        ]);
        return AnyModel;
    }(DOMWidgetModel);
    widget_define_property(AnyModel, "model_name", "AnyModel");
    widget_define_property(AnyModel, "model_module", "anywidget");
    widget_define_property(AnyModel, "model_module_version", version);
    widget_define_property(AnyModel, "view_name", "AnyView");
    widget_define_property(AnyModel, "view_module", "anywidget");
    widget_define_property(AnyModel, "view_module_version", version);
    var _controller = /*#__PURE__*/ new WeakMap();
    var AnyView = /*#__PURE__*/ function(DOMWidgetView) {
        "use strict";
        _inherits(AnyView, DOMWidgetView);
        function AnyView() {
            widget_class_call_check(this, AnyView);
            var _this;
            _this = _call_super(this, AnyView, arguments), widget_class_private_field_init(_this, _controller, {
                writable: true,
                value: new AbortController()
            });
            return _this;
        }
        widget_create_class(AnyView, [
            {
                key: "render",
                value: function render() {
                    return widget_async_to_generator(function() {
                        var runtime;
                        return widget_ts_generator(this, function(_state) {
                            switch(_state.label){
                                case 0:
                                    runtime = RUNTIMES.get(this.model);
                                    assert(runtime, "[anywidget] Runtime not found.");
                                    return [
                                        4,
                                        runtime.createView(this, {
                                            signal: widget_class_private_field_get(this, _controller).signal
                                        })
                                    ];
                                case 1:
                                    _state.sent();
                                    return [
                                        2
                                    ];
                            }
                        });
                    }).call(this);
                }
            },
            {
                key: "remove",
                value: function remove() {
                    widget_class_private_field_get(this, _controller).abort("[anywidget] View destroyed.");
                    _get(_get_prototype_of(AnyView.prototype), "remove", this).call(this);
                }
            }
        ]);
        return AnyView;
    }(DOMWidgetView);
    return {
        AnyModel: AnyModel,
        AnyView: AnyView
    };
}

;// CONCATENATED MODULE: ./packages/anywidget/src/index.js


// @ts-expect-error -- define is a global provided by the notebook runtime.
define(["@jupyter-widgets/base"], src_widget);


},

});
// The module cache
var __webpack_module_cache__ = {};

// The require function
function __webpack_require__(moduleId) {

// Check if module is in cache
var cachedModule = __webpack_module_cache__[moduleId];
if (cachedModule !== undefined) {
return cachedModule.exports;
}
// Create a new module (and put it into the cache)
var module = (__webpack_module_cache__[moduleId] = {
exports: {}
});
// Execute the module function
__webpack_modules__[moduleId](module, module.exports, __webpack_require__);

// Return the exports of the module
return module.exports;

}

// expose the modules object (__webpack_modules__)
__webpack_require__.m = __webpack_modules__;

// expose the module cache
__webpack_require__.c = __webpack_module_cache__;

// webpack/runtime/has_own_property
(() => {
__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
})();
// webpack/runtime/sharing
(() => {

__webpack_require__.S = {};
__webpack_require__.initializeSharingData = { scopeToSharingDataMapping: {  }, uniqueName: "@anywidget/monorepo" };
var initPromises = {};
var initTokens = {};
__webpack_require__.I = function(name, initScope) {
	if (!initScope) initScope = [];
	// handling circular init calls
	var initToken = initTokens[name];
	if (!initToken) initToken = initTokens[name] = {};
	if (initScope.indexOf(initToken) >= 0) return;
	initScope.push(initToken);
	// only runs once
	if (initPromises[name]) return initPromises[name];
	// creates a new share scope if needed
	if (!__webpack_require__.o(__webpack_require__.S, name))
		__webpack_require__.S[name] = {};
	// runs all init snippets from all modules reachable
	var scope = __webpack_require__.S[name];
	var warn = function (msg) {
		if (typeof console !== "undefined" && console.warn) console.warn(msg);
	};
	var uniqueName = __webpack_require__.initializeSharingData.uniqueName;
	var register = function (name, version, factory, eager) {
		var versions = (scope[name] = scope[name] || {});
		var activeVersion = versions[version];
		if (
			!activeVersion ||
			(!activeVersion.loaded &&
				(!eager != !activeVersion.eager
					? eager
					: uniqueName > activeVersion.from))
		)
			versions[version] = { get: factory, from: uniqueName, eager: !!eager };
	};
	var initExternal = function (id) {
		var handleError = function (err) {
			warn("Initialization of sharing external failed: " + err);
		};
		try {
			var module = __webpack_require__(id);
			if (!module) return;
			var initFn = function (module) {
				return (
					module &&
					module.init &&
					module.init(__webpack_require__.S[name], initScope)
				);
			};
			if (module.then) return promises.push(module.then(initFn, handleError));
			var initResult = initFn(module);
			if (initResult && initResult.then)
				return promises.push(initResult["catch"](handleError));
		} catch (err) {
			handleError(err);
		}
	};
	var promises = [];
	var scopeToSharingDataMapping = __webpack_require__.initializeSharingData.scopeToSharingDataMapping;
	if (scopeToSharingDataMapping[name]) {
		scopeToSharingDataMapping[name].forEach(function (stage) {
			if (typeof stage === "object") register(stage.name, stage.version, stage.factory, stage.eager);
			else initExternal(stage)
		});
	}
	if (!promises.length) return (initPromises[name] = 1);
	return (initPromises[name] = Promise.all(promises).then(function () {
		return (initPromises[name] = 1);
	}));
};


})();
// webpack/runtime/consumes_loading
(() => {

__webpack_require__.consumesLoadingData = { chunkMapping: {}, moduleIdToConsumeDataMapping: {}, initialConsumes: [] };
var splitAndConvert = function(str) {
  return str.split(".").map(function(item) {
    return +item == item ? +item : item;
  });
};
var parseRange = function(str) {
  // see https://docs.npmjs.com/misc/semver#range-grammar for grammar
  var parsePartial = function(str) {
    var match = /^([^-+]+)?(?:-([^+]+))?(?:\+(.+))?$/.exec(str);
    var ver = match[1] ? [0].concat(splitAndConvert(match[1])) : [0];
    if (match[2]) {
      ver.length++;
      ver.push.apply(ver, splitAndConvert(match[2]));
    }

    // remove trailing any matchers
    let last = ver[ver.length - 1];
    while (
      ver.length &&
      (last === undefined || /^[*xX]$/.test(/** @type {string} */ (last)))
    ) {
      ver.pop();
      last = ver[ver.length - 1];
    }

    return ver;
  };
  var toFixed = function(range) {
    if (range.length === 1) {
      // Special case for "*" is "x.x.x" instead of "="
      return [0];
    } else if (range.length === 2) {
      // Special case for "1" is "1.x.x" instead of "=1"
      return [1].concat(range.slice(1));
    } else if (range.length === 3) {
      // Special case for "1.2" is "1.2.x" instead of "=1.2"
      return [2].concat(range.slice(1));
    } else {
      return [range.length].concat(range.slice(1));
    }
  };
  var negate = function(range) {
    return [-range[0] - 1].concat(range.slice(1));
  };
  var parseSimple = function(str) {
    // simple       ::= primitive | partial | tilde | caret
    // primitive    ::= ( '<' | '>' | '>=' | '<=' | '=' | '!' ) ( ' ' ) * partial
    // tilde        ::= '~' ( ' ' ) * partial
    // caret        ::= '^' ( ' ' ) * partial
    const match = /^(\^|~|<=|<|>=|>|=|v|!)/.exec(str);
    const start = match ? match[0] : "";
    const remainder = parsePartial(
      start.length ? str.slice(start.length).trim() : str.trim()
    );
    switch (start) {
      case "^":
        if (remainder.length > 1 && remainder[1] === 0) {
          if (remainder.length > 2 && remainder[2] === 0) {
            return [3].concat(remainder.slice(1));
          }
          return [2].concat(remainder.slice(1));
        }
        return [1].concat(remainder.slice(1));
      case "~":
        return [2].concat(remainder.slice(1));
      case ">=":
        return remainder;
      case "=":
      case "v":
      case "":
        return toFixed(remainder);
      case "<":
        return negate(remainder);
      case ">": {
        // and( >=, not( = ) ) => >=, =, not, and
        const fixed = toFixed(remainder);
        return [, fixed, 0, remainder, 2];
      }
      case "<=":
        // or( <, = ) => <, =, or
        return [, toFixed(remainder), negate(remainder), 1];
      case "!": {
        // not =
        const fixed = toFixed(remainder);
        return [, fixed, 0];
      }
      default:
        throw new Error("Unexpected start value");
    }
  };
  var combine = function(items, fn) {
    if (items.length === 1) return items[0];
    const arr = [];
    for (const item of items.slice().reverse()) {
      if (0 in item) {
        arr.push(item);
      } else {
        arr.push.apply(arr, item.slice(1));
      }
    }
    return [,].concat(arr, items.slice(1).map(() => fn));
  };
  var parseRange = function(str) {
    // range      ::= hyphen | simple ( ' ' ( ' ' ) * simple ) * | ''
    // hyphen     ::= partial ( ' ' ) * ' - ' ( ' ' ) * partial
    const items = str.split(/\s+-\s+/);
    if (items.length === 1) {
			str = str.trim();
			const items = [];
			const r = /[-0-9A-Za-z]\s+/g;
			var start = 0;
			var match;
			while ((match = r.exec(str))) {
				const end = match.index + 1;
				items.push(parseSimple(str.slice(start, end).trim()));
				start = end;
			}
			items.push(parseSimple(str.slice(start).trim()));
      return combine(items, 2);
    }
    const a = parsePartial(items[0]);
    const b = parsePartial(items[1]);
    // >=a <=b => and( >=a, or( <b, =b ) ) => >=a, <b, =b, or, and
    return [, toFixed(b), negate(b), 1, a, 2];
  };
  var parseLogicalOr = function(str) {
    // range-set  ::= range ( logical-or range ) *
    // logical-or ::= ( ' ' ) * '||' ( ' ' ) *
    const items = str.split(/\s*\|\|\s*/).map(parseRange);
    return combine(items, 1);
  };
  return parseLogicalOr(str);
};
var parseVersion = function(str) {
	var match = /^([^-+]+)?(?:-([^+]+))?(?:\+(.+))?$/.exec(str);
	/** @type {(string|number|undefined|[])[]} */
	var ver = match[1] ? splitAndConvert(match[1]) : [];
	if (match[2]) {
		ver.length++;
		ver.push.apply(ver, splitAndConvert(match[2]));
	}
	if (match[3]) {
		ver.push([]);
		ver.push.apply(ver, splitAndConvert(match[3]));
	}
	return ver;
}
var versionLt = function(a, b) {
	a = parseVersion(a);
	b = parseVersion(b);
	var i = 0;
	for (;;) {
		// a       b  EOA     object  undefined  number  string
		// EOA        a == b  a < b   b < a      a < b   a < b
		// object     b < a   (0)     b < a      a < b   a < b
		// undefined  a < b   a < b   (0)        a < b   a < b
		// number     b < a   b < a   b < a      (1)     a < b
		// string     b < a   b < a   b < a      b < a   (1)
		// EOA end of array
		// (0) continue on
		// (1) compare them via "<"

		// Handles first row in table
		if (i >= a.length) return i < b.length && (typeof b[i])[0] != "u";

		var aValue = a[i];
		var aType = (typeof aValue)[0];

		// Handles first column in table
		if (i >= b.length) return aType == "u";

		var bValue = b[i];
		var bType = (typeof bValue)[0];

		if (aType == bType) {
			if (aType != "o" && aType != "u" && aValue != bValue) {
				return aValue < bValue;
			}
			i++;
		} else {
			// Handles remaining cases
			if (aType == "o" && bType == "n") return true;
			return bType == "s" || aType == "u";
		}
	}
}
var rangeToString = function(range) {
	var fixCount = range[0];
	var str = "";
	if (range.length === 1) {
		return "*";
	} else if (fixCount + 0.5) {
		str +=
			fixCount == 0
				? ">="
				: fixCount == -1
				? "<"
				: fixCount == 1
				? "^"
				: fixCount == 2
				? "~"
				: fixCount > 0
				? "="
				: "!=";
		var needDot = 1;
		for (var i = 1; i < range.length; i++) {
			var item = range[i];
			var t = (typeof item)[0];
			needDot--;
			str +=
				t == "u"
					? // undefined: prerelease marker, add an "-"
					  "-"
					: // number or string: add the item, set flag to add an "." between two of them
					  (needDot > 0 ? "." : "") + ((needDot = 2), item);
		}
		return str;
	} else {
		var stack = [];
		for (var i = 1; i < range.length; i++) {
			var item = range[i];
			stack.push(
				item === 0
					? "not(" + pop() + ")"
					: item === 1
					? "(" + pop() + " || " + pop() + ")"
					: item === 2
					? stack.pop() + " " + stack.pop()
					: rangeToString(item)
			);
		}
		return pop();
	}
	function pop() {
		return stack.pop().replace(/^\((.+)\)$/, "$1");
	}
}
var satisfy = function(range, version) {
	if (0 in range) {
		version = parseVersion(version);
		var fixCount = /** @type {number} */ (range[0]);
		// when negated is set it swill set for < instead of >=
		var negated = fixCount < 0;
		if (negated) fixCount = -fixCount - 1;
		for (var i = 0, j = 1, isEqual = true; ; j++, i++) {
			// cspell:word nequal nequ

			// when isEqual = true:
			// range         version: EOA/object  undefined  number    string
			// EOA                    equal       block      big-ver   big-ver
			// undefined              bigger      next       big-ver   big-ver
			// number                 smaller     block      cmp       big-cmp
			// fixed number           smaller     block      cmp-fix   differ
			// string                 smaller     block      differ    cmp
			// fixed string           smaller     block      small-cmp cmp-fix

			// when isEqual = false:
			// range         version: EOA/object  undefined  number    string
			// EOA                    nequal      block      next-ver  next-ver
			// undefined              nequal      block      next-ver  next-ver
			// number                 nequal      block      next      next
			// fixed number           nequal      block      next      next   (this never happens)
			// string                 nequal      block      next      next
			// fixed string           nequal      block      next      next   (this never happens)

			// EOA end of array
			// equal (version is equal range):
			//   when !negated: return true,
			//   when negated: return false
			// bigger (version is bigger as range):
			//   when fixed: return false,
			//   when !negated: return true,
			//   when negated: return false,
			// smaller (version is smaller as range):
			//   when !negated: return false,
			//   when negated: return true
			// nequal (version is not equal range (> resp <)): return true
			// block (version is in different prerelease area): return false
			// differ (version is different from fixed range (string vs. number)): return false
			// next: continues to the next items
			// next-ver: when fixed: return false, continues to the next item only for the version, sets isEqual=false
			// big-ver: when fixed || negated: return false, continues to the next item only for the version, sets isEqual=false
			// next-nequ: continues to the next items, sets isEqual=false
			// cmp (negated === false): version < range => return false, version > range => next-nequ, else => next
			// cmp (negated === true): version > range => return false, version < range => next-nequ, else => next
			// cmp-fix: version == range => next, else => return false
			// big-cmp: when negated => return false, else => next-nequ
			// small-cmp: when negated => next-nequ, else => return false

			var rangeType = j < range.length ? (typeof range[j])[0] : "";

			var versionValue;
			var versionType;

			// Handles first column in both tables (end of version or object)
			if (
				i >= version.length ||
				((versionValue = version[i]),
				(versionType = (typeof versionValue)[0]) == "o")
			) {
				// Handles nequal
				if (!isEqual) return true;
				// Handles bigger
				if (rangeType == "u") return j > fixCount && !negated;
				// Handles equal and smaller: (range === EOA) XOR negated
				return (rangeType == "") != negated; // equal + smaller
			}

			// Handles second column in both tables (version = undefined)
			if (versionType == "u") {
				if (!isEqual || rangeType != "u") {
					return false;
				}
			}

			// switch between first and second table
			else if (isEqual) {
				// Handle diagonal
				if (rangeType == versionType) {
					if (j <= fixCount) {
						// Handles "cmp-fix" cases
						if (versionValue != range[j]) {
							return false;
						}
					} else {
						// Handles "cmp" cases
						if (negated ? versionValue > range[j] : versionValue < range[j]) {
							return false;
						}
						if (versionValue != range[j]) isEqual = false;
					}
				}

				// Handle big-ver
				else if (rangeType != "s" && rangeType != "n") {
					if (negated || j <= fixCount) return false;
					isEqual = false;
					j--;
				}

				// Handle differ, big-cmp and small-cmp
				else if (j <= fixCount || versionType < rangeType != negated) {
					return false;
				} else {
					isEqual = false;
				}
			} else {
				// Handles all "next-ver" cases in the second table
				if (rangeType != "s" && rangeType != "n") {
					isEqual = false;
					j--;
				}

				// next is applied by default
			}
		}
	}
	/** @type {(boolean | number)[]} */
	var stack = [];
	var p = stack.pop.bind(stack);
	for (var i = 1; i < range.length; i++) {
		var item = /** @type {SemVerRange | 0 | 1 | 2} */ (range[i]);
		stack.push(
			item == 1
				? p() | p()
				: item == 2
				? p() & p()
				: item
				? satisfy(item, version)
				: !p()
		);
	}
	return !!p();
}
var ensureExistence = function(scopeName, key) {
	var scope = __webpack_require__.S[scopeName];
	if(!scope || !__webpack_require__.o(scope, key)) throw new Error("Shared module " + key + " doesn't exist in shared scope " + scopeName);
	return scope;
};
var findVersion = function(scope, key) {
	var versions = scope[key];
	var key = Object.keys(versions).reduce(function(a, b) {
		return !a || versionLt(a, b) ? b : a;
	}, 0);
	return key && versions[key]
};
var findSingletonVersionKey = function(scope, key) {
	var versions = scope[key];
	return Object.keys(versions).reduce(function(a, b) {
		return !a || (!versions[a].loaded && versionLt(a, b)) ? b : a;
	}, 0);
};
var getInvalidSingletonVersionMessage = function(scope, key, version, requiredVersion) {
	return "Unsatisfied version " + version + " from " + (version && scope[key][version].from) + " of shared singleton module " + key + " (required " + rangeToString(requiredVersion) + ")"
};
var getSingleton = function(scope, scopeName, key, requiredVersion) {
	var version = findSingletonVersionKey(scope, key);
	return get(scope[key][version]);
};
var getSingletonVersion = function(scope, scopeName, key, requiredVersion) {
	var version = findSingletonVersionKey(scope, key);
	if (!satisfy(requiredVersion, version)) warn(getInvalidSingletonVersionMessage(scope, key, version, requiredVersion));
	return get(scope[key][version]);
};
var getStrictSingletonVersion = function(scope, scopeName, key, requiredVersion) {
	var version = findSingletonVersionKey(scope, key);
	if (!satisfy(requiredVersion, version)) throw new Error(getInvalidSingletonVersionMessage(scope, key, version, requiredVersion));
	return get(scope[key][version]);
};
var findValidVersion = function(scope, key, requiredVersion) {
	var versions = scope[key];
	var key = Object.keys(versions).reduce(function(a, b) {
		if (!satisfy(requiredVersion, b)) return a;
		return !a || versionLt(a, b) ? b : a;
	}, 0);
	return key && versions[key]
};
var getInvalidVersionMessage = function(scope, scopeName, key, requiredVersion) {
	var versions = scope[key];
	return "No satisfying version (" + rangeToString(requiredVersion) + ") of shared module " + key + " found in shared scope " + scopeName + ".\n" +
		"Available versions: " + Object.keys(versions).map(function(key) {
		return key + " from " + versions[key].from;
	}).join(", ");
};
var getValidVersion = function(scope, scopeName, key, requiredVersion) {
	var entry = findValidVersion(scope, key, requiredVersion);
	if(entry) return get(entry);
	throw new Error(getInvalidVersionMessage(scope, scopeName, key, requiredVersion));
};
var warn = function(msg) {
	if (typeof console !== "undefined" && console.warn) console.warn(msg);
};
var warnInvalidVersion = function(scope, scopeName, key, requiredVersion) {
	warn(getInvalidVersionMessage(scope, scopeName, key, requiredVersion));
};
var get = function(entry) {
	entry.loaded = 1;
	return entry.get()
};
var init = function(fn) { return function(scopeName, a, b, c) {
	var promise = __webpack_require__.I(scopeName);
	if (promise && promise.then) return promise.then(fn.bind(fn, scopeName, __webpack_require__.S[scopeName], a, b, c));
	return fn(scopeName, __webpack_require__.S[scopeName], a, b, c);
}; };

var load = /*#__PURE__*/ init(function(scopeName, scope, key) {
	ensureExistence(scopeName, key);
	return get(findVersion(scope, key));
});
var loadFallback = /*#__PURE__*/ init(function(scopeName, scope, key, fallback) {
	return scope && __webpack_require__.o(scope, key) ? get(findVersion(scope, key)) : fallback();
});
var loadVersionCheck = /*#__PURE__*/ init(function(scopeName, scope, key, version) {
	ensureExistence(scopeName, key);
	return get(findValidVersion(scope, key, version) || warnInvalidVersion(scope, scopeName, key, version) || findVersion(scope, key));
});
var loadSingleton = /*#__PURE__*/ init(function(scopeName, scope, key) {
	ensureExistence(scopeName, key);
	return getSingleton(scope, scopeName, key);
});
var loadSingletonVersionCheck = /*#__PURE__*/ init(function(scopeName, scope, key, version) {
	ensureExistence(scopeName, key);
	return getSingletonVersion(scope, scopeName, key, version);
});
var loadStrictVersionCheck = /*#__PURE__*/ init(function(scopeName, scope, key, version) {
	ensureExistence(scopeName, key);
	return getValidVersion(scope, scopeName, key, version);
});
var loadStrictSingletonVersionCheck = /*#__PURE__*/ init(function(scopeName, scope, key, version) {
	ensureExistence(scopeName, key);
	return getStrictSingletonVersion(scope, scopeName, key, version);
});
var loadVersionCheckFallback = /*#__PURE__*/ init(function(scopeName, scope, key, version, fallback) {
	if(!scope || !__webpack_require__.o(scope, key)) return fallback();
	return get(findValidVersion(scope, key, version) || warnInvalidVersion(scope, scopeName, key, version) || findVersion(scope, key));
});
var loadSingletonFallback = /*#__PURE__*/ init(function(scopeName, scope, key, fallback) {
	if(!scope || !__webpack_require__.o(scope, key)) return fallback();
	return getSingleton(scope, scopeName, key);
});
var loadSingletonVersionCheckFallback = /*#__PURE__*/ init(function(scopeName, scope, key, version, fallback) {
	if(!scope || !__webpack_require__.o(scope, key)) return fallback();
	return getSingletonVersion(scope, scopeName, key, version);
});
var loadStrictVersionCheckFallback = /*#__PURE__*/ init(function(scopeName, scope, key, version, fallback) {
	var entry = scope && __webpack_require__.o(scope, key) && findValidVersion(scope, key, version);
	return entry ? get(entry) : fallback();
});
var loadStrictSingletonVersionCheckFallback = /*#__PURE__*/ init(function(scopeName, scope, key, version, fallback) {
	if(!scope || !__webpack_require__.o(scope, key)) return fallback();
	return getStrictSingletonVersion(scope, scopeName, key, version);
});
var resolveHandler = function(data) {
	var strict = false
	var singleton = false
	var versionCheck = false
	var fallback = false
	var args = [data.shareScope, data.shareKey];
	if (data.requiredVersion) {
		if (data.strictVersion) strict = true;
		if (data.singleton) singleton = true;
		args.push(parseRange(data.requiredVersion));
		versionCheck = true
	} else if (data.singleton) singleton = true;
	if (data.fallback) {
		fallback = true;
		args.push(data.fallback);
	}
	if (strict && singleton && versionCheck && fallback) return function() { return loadStrictSingletonVersionCheckFallback.apply(null, args); }
	if (strict && versionCheck && fallback) return function() { return loadStrictVersionCheckFallback.apply(null, args); }
	if (singleton && versionCheck && fallback) return function() { return loadSingletonVersionCheckFallback.apply(null, args); }
	if (strict && singleton && versionCheck) return function() { return loadStrictSingletonVersionCheck.apply(null, args); }
	if (singleton && fallback) return function() { return loadSingletonFallback.apply(null, args); }
	if (versionCheck && fallback) return function() { return loadVersionCheckFallback.apply(null, args); }
	if (strict && versionCheck) return function() { return loadStrictVersionCheck.apply(null, args); }
	if (singleton && versionCheck) return function() { return loadSingletonVersionCheck.apply(null, args); }
	if (singleton) return function() { return loadSingleton.apply(null, args); }
	if (versionCheck) return function() { return loadVersionCheck.apply(null, args); }
	if (fallback) return function() { return loadFallback.apply(null, args); }
	return function() { return load.apply(null, args); }
};
var consumeSharedInstalledModules = {};

})();
// module factories are used so entry inlining is disabled
// startup
// Load entry module and return exports
var __webpack_exports__ = __webpack_require__(592);
})()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWFpbi5iYjM1NDZiNy5qcyIsInNvdXJjZXMiOlsid2VicGFjazovL0Bhbnl3aWRnZXQvbW9ub3JlcG8vLi9wYWNrYWdlcy9hbnl3aWRnZXQvc3JjL21vZGVsLXByb3h5LnRzIiwid2VicGFjazovL0Bhbnl3aWRnZXQvbW9ub3JlcG8vLi9wYWNrYWdlcy9hbnl3aWRnZXQvc3JjL3V0aWwudHMiLCJ3ZWJwYWNrOi8vQGFueXdpZGdldC9tb25vcmVwby8uL3BhY2thZ2VzL2FueXdpZGdldC9zcmMvYmluZGluZy50cyIsIndlYnBhY2s6Ly9AYW55d2lkZ2V0L21vbm9yZXBvLy4vbm9kZV9tb2R1bGVzLy5wbnBtL3NvbGlkLWpzQDEuOS4xOC9ub2RlX21vZHVsZXMvc29saWQtanMvZGlzdC9zb2xpZC5qcyIsIndlYnBhY2s6Ly9AYW55d2lkZ2V0L21vbm9yZXBvLy4vbm9kZV9tb2R1bGVzLy5wbnBtL0BsdWtlZWQrdXVpZEAyLjAuMS9ub2RlX21vZHVsZXMvQGx1a2VlZC91dWlkL2Rpc3QvaW5kZXgubWpzIiwid2VicGFjazovL0Bhbnl3aWRnZXQvbW9ub3JlcG8vLi9wYWNrYWdlcy9hbnl3aWRnZXQvc3JjL2ludm9rZS50cyIsIndlYnBhY2s6Ly9AYW55d2lkZ2V0L21vbm9yZXBvLy4vcGFja2FnZXMvYW55d2lkZ2V0L3NyYy93aWRnZXQtcmVmLnRzIiwid2VicGFjazovL0Bhbnl3aWRnZXQvbW9ub3JlcG8vLi9wYWNrYWdlcy9hbnl3aWRnZXQvc3JjL2hvc3QudHMiLCJ3ZWJwYWNrOi8vQGFueXdpZGdldC9tb25vcmVwby8uL3BhY2thZ2VzL2FueXdpZGdldC9zcmMvbG9hZC50cyIsIndlYnBhY2s6Ly9AYW55d2lkZ2V0L21vbm9yZXBvLy4vcGFja2FnZXMvYW55d2lkZ2V0L3NyYy9vYnNlcnZlLnRzIiwid2VicGFjazovL0Bhbnl3aWRnZXQvbW9ub3JlcG8vLi9wYWNrYWdlcy9hbnl3aWRnZXQvc3JjL3J1bnRpbWUudHMiLCJ3ZWJwYWNrOi8vQGFueXdpZGdldC9tb25vcmVwby8uL3BhY2thZ2VzL2FueXdpZGdldC9zcmMvd2lkZ2V0LnRzIiwid2VicGFjazovL0Bhbnl3aWRnZXQvbW9ub3JlcG8vLi9wYWNrYWdlcy9hbnl3aWRnZXQvc3JjL2luZGV4LmpzIiwid2VicGFjazovL0Bhbnl3aWRnZXQvbW9ub3JlcG8vd2VicGFjay9ydW50aW1lL2hhc19vd25fcHJvcGVydHkiLCJ3ZWJwYWNrOi8vQGFueXdpZGdldC9tb25vcmVwby93ZWJwYWNrL3J1bnRpbWUvc2hhcmluZyIsIndlYnBhY2s6Ly9AYW55d2lkZ2V0L21vbm9yZXBvL3dlYnBhY2svcnVudGltZS9jb25zdW1lc19sb2FkaW5nIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgQW55TW9kZWwgfSBmcm9tIFwiQGFueXdpZGdldC90eXBlc1wiO1xuaW1wb3J0IHR5cGUgeyBET01XaWRnZXRNb2RlbCB9IGZyb20gXCJAanVweXRlci13aWRnZXRzL2Jhc2VcIjtcblxuLyoqXG4gKiBUaGlzIGlzIGEgdHJpY2sgc28gdGhhdCB3ZSBjYW4gY2xlYW51cCBldmVudCBsaXN0ZW5lcnMgYWRkZWRcbiAqIGJ5IHRoZSB1c2VyLWRlZmluZWQgZnVuY3Rpb24uXG4gKi9cbmV4cG9ydCBsZXQgSU5JVElBTElaRV9NQVJLRVIgPSBTeW1ib2woXCJhbnl3aWRnZXQuaW5pdGlhbGl6ZVwiKTtcblxuLyoqXG4gKiBQcnVuZXMgdGhlIHZpZXcgZG93biB0byB0aGUgbWluaW11bSBjb250ZXh0IG5lY2Vzc2FyeS5cbiAqXG4gKiBDYWxscyB0byBgbW9kZWwuZ2V0YCBhbmQgYG1vZGVsLnNldGAgYXV0b21hdGljYWxseSBhZGQgdGhlXG4gKiBgY29udGV4dGAsIHNvIHdlIGNhbiBncmFjZWZ1bGx5IHVuc3Vic2NyaWJlIGZyb20gZXZlbnRzXG4gKiBhZGRlZCBieSB1c2VyLWRlZmluZWQgaG9va3MuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBtb2RlbFByb3h5KG1vZGVsOiBET01XaWRnZXRNb2RlbCwgY29udGV4dDogdW5rbm93bik6IEFueU1vZGVsIHtcbiAgLy8gb3hsaW50LWRpc2FibGUtbmV4dC1saW5lIHR5cGVzY3JpcHQtZXNsaW50L25vLXVuc2FmZS10eXBlLWFzc2VydGlvbiAtLSBET01XaWRnZXRNb2RlbC5nZXQvc2V0L29uL29mZiBoYXZlIHdpZGVyIHNpZ25hdHVyZXMgdGhhbiBBbnlNb2RlbCwgc28gYm91bmQgdmVyc2lvbnMgZG9uJ3QgbmFycm93IGNsZWFubHk7IHRoZSBzaGFwZSBpcyBzdHJ1Y3R1cmFsbHkgY29tcGF0aWJsZVxuICByZXR1cm4ge1xuICAgIGdldDogbW9kZWwuZ2V0LmJpbmQobW9kZWwpLFxuICAgIHNldDogbW9kZWwuc2V0LmJpbmQobW9kZWwpLFxuICAgIHNhdmVfY2hhbmdlczogbW9kZWwuc2F2ZV9jaGFuZ2VzLmJpbmQobW9kZWwpLFxuICAgIHNlbmQ6IG1vZGVsLnNlbmQuYmluZChtb2RlbCksXG4gICAgb24obmFtZSwgY2FsbGJhY2spIHtcbiAgICAgIG1vZGVsLm9uKG5hbWUsIGNhbGxiYWNrLCBjb250ZXh0KTtcbiAgICB9LFxuICAgIG9mZihuYW1lLCBjYWxsYmFjaykge1xuICAgICAgbW9kZWwub2ZmKG5hbWUsIGNhbGxiYWNrLCBjb250ZXh0KTtcbiAgICB9LFxuICAgIC8vIFRoZSB3aWRnZXRfbWFuYWdlciB0eXBlIGlzIHdpZGVyIHRoYW4gd2hhdCB3ZSB3YW50IHRvIGV4cG9zZSB0b1xuICAgIC8vIGRldmVsb3BlcnMuIEluIGEgZnV0dXJlIHZlcnNpb24sIHdlIHdpbGwgZXhwb3NlIGEgbW9yZSBsaW1pdGVkIEFQSSBidXRcbiAgICAvLyB0aGF0IGNhbiB3YWl0IGZvciBhIG1pbm9yIHZlcnNpb24gYnVtcC5cbiAgICB3aWRnZXRfbWFuYWdlcjogbW9kZWwud2lkZ2V0X21hbmFnZXIsXG4gIH0gYXMgQW55TW9kZWw7XG59XG4iLCJleHBvcnQgdHlwZSBBd2FpdGFibGU8VD4gPSBUIHwgUHJvbWlzZUxpa2U8VD47XG5cbmV4cG9ydCBpbnRlcmZhY2UgUmVhZHk8VD4ge1xuICBzdGF0dXM6IFwicmVhZHlcIjtcbiAgZGF0YTogVDtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBQZW5kaW5nIHtcbiAgc3RhdHVzOiBcInBlbmRpbmdcIjtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBFcnJvcmVkIHtcbiAgc3RhdHVzOiBcImVycm9yXCI7XG4gIGVycm9yOiB1bmtub3duO1xufVxuXG5leHBvcnQgdHlwZSBSZXN1bHQ8VD4gPSBQZW5kaW5nIHwgUmVhZHk8VD4gfCBFcnJvcmVkO1xuXG5leHBvcnQgZnVuY3Rpb24gYXNzZXJ0KGNvbmRpdGlvbjogdW5rbm93biwgbWVzc2FnZTogc3RyaW5nKTogYXNzZXJ0cyBjb25kaXRpb24ge1xuICBpZiAoIWNvbmRpdGlvbikgdGhyb3cgbmV3IEVycm9yKG1lc3NhZ2UpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2FmZUNsZWFudXAoXG4gIGZuOiB2b2lkIHwgKCgpID0+IEF3YWl0YWJsZTx2b2lkPikgfCB1bmRlZmluZWQsXG4gIGtpbmQ6IHN0cmluZyxcbik6IFByb21pc2U8dm9pZD4ge1xuICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKClcbiAgICAudGhlbigoKSA9PiBmbj8uKCkpXG4gICAgLmNhdGNoKChlKSA9PiBjb25zb2xlLndhcm4oYFthbnl3aWRnZXRdIGVycm9yIGNsZWFuaW5nIHVwICR7a2luZH0uYCwgZSkpO1xufVxuXG4vKipcbiAqIENsZWFucyB1cCB0aGUgc3RhY2sgdHJhY2UgYXQgYW55d2lkZ2V0IGJvdW5kYXJ5LlxuICogWW91IGNhbiBmdWxseSBpbnNwZWN0IHRoZSBlbnRpcmUgc3RhY2sgdHJhY2UgaW4gdGhlIGNvbnNvbGUgaW50ZXJhY3RpdmVseSxcbiAqIGJ1dCB0aGUgaW5pdGlhbCBlcnJvciBtZXNzYWdlIGlzIGNsZWFuZWQgdXAgdG8gYmUgbW9yZSB1c2VyLWZyaWVuZGx5LlxuICovXG5leHBvcnQgZnVuY3Rpb24gdGhyb3dBbnl3aWRnZXRFcnJvcihzb3VyY2U6IHVua25vd24pOiBuZXZlciB7XG4gIGlmICghKHNvdXJjZSBpbnN0YW5jZW9mIEVycm9yKSkge1xuICAgIC8vIERvbid0IGtub3cgd2hhdCB0byBkbyB3aXRoIHRoaXMuXG4gICAgdGhyb3cgc291cmNlO1xuICB9XG4gIGxldCBsaW5lcyA9IHNvdXJjZS5zdGFjaz8uc3BsaXQoXCJcXG5cIikgPz8gW107XG4gIGxldCBhbnl3aWRnZXRJbmRleCA9IGxpbmVzLmZpbmRJbmRleCgobGluZSkgPT4gbGluZS5pbmNsdWRlcyhcImFueXdpZGdldFwiKSk7XG4gIGxldCBjbGVhblN0YWNrID0gYW55d2lkZ2V0SW5kZXggPT09IC0xID8gbGluZXMgOiBsaW5lcy5zbGljZSgwLCBhbnl3aWRnZXRJbmRleCArIDEpO1xuICBzb3VyY2Uuc3RhY2sgPSBjbGVhblN0YWNrLmpvaW4oXCJcXG5cIik7XG4gIGNvbnNvbGUuZXJyb3Ioc291cmNlKTtcbiAgdGhyb3cgc291cmNlO1xufVxuXG4vKipcbiAqIFBvbHlmaWxsIGZvciB7QGxpbmsgaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvSmF2YVNjcmlwdC9SZWZlcmVuY2UvR2xvYmFsX09iamVjdHMvUHJvbWlzZS93aXRoUmVzb2x2ZXJzIFByb21pc2Uud2l0aFJlc29sdmVyc31cbiAqXG4gKiBUcmV2b3IoMjAyNS0wMy0xNCk6IFNob3VsZCBiZSBhYmxlIHRvIHJlbW92ZSBvbmNlIG1vcmUgc3RhYmxlIGFjcm9zcyBicm93c2Vycy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHByb21pc2VXaXRoUmVzb2x2ZXJzPFQ+KCk6IFByb21pc2VXaXRoUmVzb2x2ZXJzPFQ+IHtcbiAgbGV0IHJlc29sdmUhOiAodmFsdWU6IFQgfCBQcm9taXNlTGlrZTxUPikgPT4gdm9pZDtcbiAgbGV0IHJlamVjdCE6IChyZWFzb24/OiB1bmtub3duKSA9PiB2b2lkO1xuICBsZXQgcHJvbWlzZSA9IG5ldyBQcm9taXNlPFQ+KChyZXMsIHJlaikgPT4ge1xuICAgIHJlc29sdmUgPSByZXM7XG4gICAgcmVqZWN0ID0gcmVqO1xuICB9KTtcbiAgcmV0dXJuIHsgcHJvbWlzZSwgcmVzb2x2ZSwgcmVqZWN0IH07XG59XG4iLCJpbXBvcnQgdHlwZSB7IEV4cGVyaW1lbnRhbCwgSG9zdCB9IGZyb20gXCJAYW55d2lkZ2V0L3R5cGVzXCI7XG5pbXBvcnQgdHlwZSB7IERPTVdpZGdldE1vZGVsIH0gZnJvbSBcIkBqdXB5dGVyLXdpZGdldHMvYmFzZVwiO1xuXG5pbXBvcnQgdHlwZSB7IEFueVdpZGdldCB9IGZyb20gXCIuL2xvYWQudHNcIjtcbmltcG9ydCB7IElOSVRJQUxJWkVfTUFSS0VSLCBtb2RlbFByb3h5IH0gZnJvbSBcIi4vbW9kZWwtcHJveHkudHNcIjtcbmltcG9ydCB7IHR5cGUgQXdhaXRhYmxlLCBwcm9taXNlV2l0aFJlc29sdmVycywgc2FmZUNsZWFudXAgfSBmcm9tIFwiLi91dGlsLnRzXCI7XG5cbi8qKlxuICogVGhlIG1pbmltYWwgc3VyZmFjZSBgY3JlYXRlVmlld2AgbmVlZHMgZnJvbSBhIHZpZXctbGlrZSBvYmplY3QuIFRoZSBvYmplY3RcbiAqIGlkZW50aXR5IGlzIHVzZWQgYXMgdGhlIGxpc3RlbmVyIGNvbnRleHQgZm9yIGBtb2RlbFByb3h5YCwgYW5kIGBlbGAgaXMgdGhlXG4gKiByZW5kZXIgdGFyZ2V0LlxuICovXG5leHBvcnQgaW50ZXJmYWNlIFZpZXdUYXJnZXQge1xuICBlbDogSFRNTEVsZW1lbnQ7XG59XG5cbmZ1bmN0aW9uIGlzU2FmZUNsZWFudXBGdW5jdGlvbih4OiB1bmtub3duKTogeCBpcyAoKSA9PiBBd2FpdGFibGU8dm9pZD4ge1xuICByZXR1cm4gdHlwZW9mIHggPT09IFwiZnVuY3Rpb25cIjtcbn1cblxuZXhwb3J0IGNsYXNzIFdpZGdldEJpbmRpbmcge1xuICAjY29udHJvbGxlcjogQWJvcnRDb250cm9sbGVyIHwgdW5kZWZpbmVkO1xuICAjd2lkZ2V0RGVmOiBBbnlXaWRnZXQgfCB1bmRlZmluZWQ7XG4gICNleHBvcnRzOiB1bmtub3duO1xuICAjbW9kZWw6IERPTVdpZGdldE1vZGVsO1xuICByZWFkeTogUHJvbWlzZTx1bmtub3duPjtcbiAgI3Jlc29sdmVyczogUHJvbWlzZVdpdGhSZXNvbHZlcnM8dW5rbm93bj47XG5cbiAgY29uc3RydWN0b3IobW9kZWw6IERPTVdpZGdldE1vZGVsKSB7XG4gICAgdGhpcy4jbW9kZWwgPSBtb2RlbDtcbiAgICB0aGlzLiNyZXNvbHZlcnMgPSBwcm9taXNlV2l0aFJlc29sdmVycygpO1xuICAgIHRoaXMucmVhZHkgPSB0aGlzLiNyZXNvbHZlcnMucHJvbWlzZTtcbiAgfVxuXG4gIGFzeW5jIGJpbmQoXG4gICAgd2lkZ2V0RGVmOiBBbnlXaWRnZXQsXG4gICAgeyBleHBlcmltZW50YWwgfTogeyBleHBlcmltZW50YWw6IEV4cGVyaW1lbnRhbCB9LFxuICApOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBpZiAodGhpcy4jd2lkZ2V0RGVmID09PSB3aWRnZXREZWYpIHJldHVybjtcblxuICAgIGlmICh0aGlzLiN3aWRnZXREZWYgJiYgdGhpcy4jd2lkZ2V0RGVmICE9PSB3aWRnZXREZWYpIHtcbiAgICAgIHRoaXMuI2NvbnRyb2xsZXI/LmFib3J0KCk7XG4gICAgICAvLyBTZXR0bGUgdGhlIG9sZCBwcm9taXNlIHNvIGFueSBhd2FpdGVyIHRoYXQgY2FwdHVyZWQgYHRoaXMucmVhZHlgXG4gICAgICAvLyAoZS5nLiBhIHBhcmVudCdzIGBob3N0LmdldFdpZGdldGAgc25hcHNob3QpIHVuYmxvY2tzIGluc3RlYWQgb2ZcbiAgICAgIC8vIGhhbmdpbmcgdW50aWwgdGhlIGhvc3QncyAxMHMgdGltZW91dC4gTm8tb3AgaWYgYWxyZWFkeSByZXNvbHZlZC5cbiAgICAgIGxldCBwcmV2UmVzb2x2ZXJzID0gdGhpcy4jcmVzb2x2ZXJzO1xuICAgICAgdGhpcy4jcmVzb2x2ZXJzID0gcHJvbWlzZVdpdGhSZXNvbHZlcnMoKTtcbiAgICAgIHRoaXMucmVhZHkgPSB0aGlzLiNyZXNvbHZlcnMucHJvbWlzZTtcbiAgICAgIHByZXZSZXNvbHZlcnMucHJvbWlzZS5jYXRjaCgoKSA9PiB7fSk7XG4gICAgICBwcmV2UmVzb2x2ZXJzLnJlamVjdChuZXcgRXJyb3IoXCJbYW55d2lkZ2V0XSB3aWRnZXQgYmluZCBhYm9ydGVkIGJ5IHJlLWJpbmRcIikpO1xuICAgIH1cblxuICAgIHRoaXMuI3dpZGdldERlZiA9IHdpZGdldERlZjtcbiAgICB0aGlzLiNjb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xuICAgIGxldCBzaWduYWwgPSB0aGlzLiNjb250cm9sbGVyLnNpZ25hbDtcbiAgICBsZXQgbW9kZWwgPSB0aGlzLiNtb2RlbDtcblxuICAgIG1vZGVsLm9mZihudWxsLCBudWxsLCBJTklUSUFMSVpFX01BUktFUik7XG5cbiAgICBsZXQgcmVzdWx0ID0gYXdhaXQgd2lkZ2V0RGVmLmluaXRpYWxpemU/Lih7XG4gICAgICBtb2RlbDogbW9kZWxQcm94eShtb2RlbCwgSU5JVElBTElaRV9NQVJLRVIpLFxuICAgICAgc2lnbmFsLFxuICAgICAgZXhwZXJpbWVudGFsLFxuICAgIH0pO1xuXG4gICAgaWYgKHNpZ25hbC5hYm9ydGVkKSB7XG4gICAgICBhd2FpdCBzYWZlQ2xlYW51cChpc1NhZmVDbGVhbnVwRnVuY3Rpb24ocmVzdWx0KSA/IHJlc3VsdCA6IHVuZGVmaW5lZCwgXCJlc20gdXBkYXRlXCIpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGlmIChpc1NhZmVDbGVhbnVwRnVuY3Rpb24ocmVzdWx0KSkge1xuICAgICAgc2lnbmFsLmFkZEV2ZW50TGlzdGVuZXIoXCJhYm9ydFwiLCAoKSA9PiBzYWZlQ2xlYW51cChyZXN1bHQsIFwiZXNtIHVwZGF0ZVwiKSk7XG4gICAgICB0aGlzLiNleHBvcnRzID0gdW5kZWZpbmVkO1xuICAgIH0gZWxzZSBpZiAodHlwZW9mIHJlc3VsdCA9PT0gXCJvYmplY3RcIiAmJiByZXN1bHQgIT09IG51bGwpIHtcbiAgICAgIHRoaXMuI2V4cG9ydHMgPSByZXN1bHQ7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuI2V4cG9ydHMgPSB1bmRlZmluZWQ7XG4gICAgfVxuXG4gICAgdGhpcy4jcmVzb2x2ZXJzLnJlc29sdmUodGhpcy4jZXhwb3J0cyk7XG4gIH1cblxuICBhc3luYyBjcmVhdGVWaWV3KFxuICAgIHRhcmdldDogVmlld1RhcmdldCxcbiAgICB7IHNpZ25hbCwgZXhwZXJpbWVudGFsLCBob3N0IH06IHsgc2lnbmFsOiBBYm9ydFNpZ25hbDsgZXhwZXJpbWVudGFsOiBFeHBlcmltZW50YWw7IGhvc3Q6IEhvc3QgfSxcbiAgKTogUHJvbWlzZTx1bmRlZmluZWQ+IHtcbiAgICBhd2FpdCB0aGlzLnJlYWR5O1xuICAgIGlmICghdGhpcy4jd2lkZ2V0RGVmPy5yZW5kZXIpIHJldHVybjtcbiAgICBsZXQgY29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcbiAgICBsZXQgY29tYmluZWQgPSBBYm9ydFNpZ25hbC5hbnkoW3NpZ25hbCwgY29udHJvbGxlci5zaWduYWxdKTtcbiAgICBsZXQgbW9kZWwgPSB0aGlzLiNtb2RlbDtcbiAgICBsZXQgY2xlYW51cCA9IGF3YWl0IHRoaXMuI3dpZGdldERlZi5yZW5kZXIoe1xuICAgICAgbW9kZWw6IG1vZGVsUHJveHkobW9kZWwsIHRhcmdldCksXG4gICAgICBlbDogdGFyZ2V0LmVsLFxuICAgICAgc2lnbmFsOiBjb21iaW5lZCxcbiAgICAgIGhvc3QsXG4gICAgICBleHBlcmltZW50YWwsXG4gICAgfSk7XG4gICAgbGV0IGRpc3Bvc2VWaWV3ID0gKHJlYXNvbjogc3RyaW5nKTogdm9pZCA9PiB7XG4gICAgICAvLyBDbGVhciBsaXN0ZW5lcnMga2V5ZWQgdG8gdGhpcyB0YXJnZXQuIEZvciBlcGhlbWVyYWwgYHtlbH1gIHRhcmdldHNcbiAgICAgIC8vIChob3N0LmdldFdpZGdldCgpLnJlbmRlciksIHRoaXMgcHJldmVudHMgbGVha3MgYWNyb3NzIHJlLXJlbmRlcnMuXG4gICAgICBtb2RlbC5vZmYobnVsbCwgbnVsbCwgdGFyZ2V0KTtcbiAgICAgIHZvaWQgc2FmZUNsZWFudXAoY2xlYW51cCwgcmVhc29uKTtcbiAgICB9O1xuICAgIGlmIChjb21iaW5lZC5hYm9ydGVkKSB7XG4gICAgICBkaXNwb3NlVmlldyhcImRpc3Bvc2UgdmlldyAtIGFscmVhZHkgYWJvcnRlZFwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29tYmluZWQuYWRkRXZlbnRMaXN0ZW5lcihcImFib3J0XCIsICgpID0+IGRpc3Bvc2VWaWV3KFwiZGlzcG9zZSB2aWV3IC0gYWJvcnRlZFwiKSk7XG4gIH1cblxuICBnZXQgZXhwb3J0cygpOiB1bmtub3duIHtcbiAgICByZXR1cm4gdGhpcy4jZXhwb3J0cztcbiAgfVxuXG4gIGRlc3Ryb3koKTogdm9pZCB7XG4gICAgdGhpcy4jY29udHJvbGxlcj8uYWJvcnQoKTtcbiAgICB0aGlzLiNjb250cm9sbGVyID0gdW5kZWZpbmVkO1xuICAgIHRoaXMuI3dpZGdldERlZiA9IHVuZGVmaW5lZDtcbiAgfVxufVxuXG5jbGFzcyBCaW5kaW5nTWFuYWdlciB7XG4gICNiaW5kaW5ncyA9IG5ldyBNYXA8RE9NV2lkZ2V0TW9kZWwsIFdpZGdldEJpbmRpbmc+KCk7XG5cbiAgZ2V0T3JDcmVhdGUobW9kZWw6IERPTVdpZGdldE1vZGVsKTogV2lkZ2V0QmluZGluZyB7XG4gICAgbGV0IGJpbmRpbmcgPSB0aGlzLiNiaW5kaW5ncy5nZXQobW9kZWwpO1xuICAgIGlmICghYmluZGluZykge1xuICAgICAgYmluZGluZyA9IG5ldyBXaWRnZXRCaW5kaW5nKG1vZGVsKTtcbiAgICAgIHRoaXMuI2JpbmRpbmdzLnNldChtb2RlbCwgYmluZGluZyk7XG4gICAgfVxuICAgIHJldHVybiBiaW5kaW5nO1xuICB9XG5cbiAgZ2V0KG1vZGVsOiBET01XaWRnZXRNb2RlbCk6IFdpZGdldEJpbmRpbmcgfCB1bmRlZmluZWQge1xuICAgIHJldHVybiB0aGlzLiNiaW5kaW5ncy5nZXQobW9kZWwpO1xuICB9XG5cbiAgZGVzdHJveShtb2RlbDogRE9NV2lkZ2V0TW9kZWwpOiB2b2lkIHtcbiAgICBsZXQgYmluZGluZyA9IHRoaXMuI2JpbmRpbmdzLmdldChtb2RlbCk7XG4gICAgaWYgKGJpbmRpbmcpIHtcbiAgICAgIGJpbmRpbmcuZGVzdHJveSgpO1xuICAgICAgdGhpcy4jYmluZGluZ3MuZGVsZXRlKG1vZGVsKTtcbiAgICB9XG4gIH1cbn1cblxuZXhwb3J0IGxldCBCSU5ESU5HUyA9IG5ldyBCaW5kaW5nTWFuYWdlcigpO1xuIiwibGV0IHRhc2tJZENvdW50ZXIgPSAxLFxuICBpc0NhbGxiYWNrU2NoZWR1bGVkID0gZmFsc2UsXG4gIGlzUGVyZm9ybWluZ1dvcmsgPSBmYWxzZSxcbiAgdGFza1F1ZXVlID0gW10sXG4gIGN1cnJlbnRUYXNrID0gbnVsbCxcbiAgc2hvdWxkWWllbGRUb0hvc3QgPSBudWxsLFxuICB5aWVsZEludGVydmFsID0gNSxcbiAgZGVhZGxpbmUgPSAwLFxuICBtYXhZaWVsZEludGVydmFsID0gMzAwLFxuICBtYXhEZWFkbGluZSA9IDAsXG4gIHNjaGVkdWxlQ2FsbGJhY2sgPSBudWxsLFxuICBzY2hlZHVsZWRDYWxsYmFjayA9IG51bGw7XG5jb25zdCBtYXhTaWduZWQzMUJpdEludCA9IDEwNzM3NDE4MjM7XG5mdW5jdGlvbiBzZXR1cFNjaGVkdWxlcigpIHtcbiAgY29uc3QgY2hhbm5lbCA9IG5ldyBNZXNzYWdlQ2hhbm5lbCgpLFxuICAgIHBvcnQxID0gY2hhbm5lbC5wb3J0MSxcbiAgICBwb3J0ID0gY2hhbm5lbC5wb3J0MjtcbiAgaWYgKHR5cGVvZiBwb3J0MS51bnJlZiA9PT0gXCJmdW5jdGlvblwiKSBwb3J0MS51bnJlZigpO1xuICBpZiAodHlwZW9mIHBvcnQudW5yZWYgPT09IFwiZnVuY3Rpb25cIikgcG9ydC51bnJlZigpO1xuICBzY2hlZHVsZUNhbGxiYWNrID0gKCkgPT4gcG9ydC5wb3N0TWVzc2FnZShudWxsKTtcbiAgcG9ydDEub25tZXNzYWdlID0gKCkgPT4ge1xuICAgIGlmIChzY2hlZHVsZWRDYWxsYmFjayAhPT0gbnVsbCkge1xuICAgICAgY29uc3QgY3VycmVudFRpbWUgPSBwZXJmb3JtYW5jZS5ub3coKTtcbiAgICAgIGRlYWRsaW5lID0gY3VycmVudFRpbWUgKyB5aWVsZEludGVydmFsO1xuICAgICAgbWF4RGVhZGxpbmUgPSBjdXJyZW50VGltZSArIG1heFlpZWxkSW50ZXJ2YWw7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBoYXNNb3JlV29yayA9IHNjaGVkdWxlZENhbGxiYWNrKGN1cnJlbnRUaW1lKTtcbiAgICAgICAgaWYgKCFoYXNNb3JlV29yaykge1xuICAgICAgICAgIHNjaGVkdWxlZENhbGxiYWNrID0gbnVsbDtcbiAgICAgICAgfSBlbHNlIHBvcnQucG9zdE1lc3NhZ2UobnVsbCk7XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBwb3J0LnBvc3RNZXNzYWdlKG51bGwpO1xuICAgICAgICB0aHJvdyBlcnJvcjtcbiAgICAgIH1cbiAgICB9XG4gIH07XG4gIGlmIChuYXZpZ2F0b3IgJiYgbmF2aWdhdG9yLnNjaGVkdWxpbmcgJiYgbmF2aWdhdG9yLnNjaGVkdWxpbmcuaXNJbnB1dFBlbmRpbmcpIHtcbiAgICBjb25zdCBzY2hlZHVsaW5nID0gbmF2aWdhdG9yLnNjaGVkdWxpbmc7XG4gICAgc2hvdWxkWWllbGRUb0hvc3QgPSAoKSA9PiB7XG4gICAgICBjb25zdCBjdXJyZW50VGltZSA9IHBlcmZvcm1hbmNlLm5vdygpO1xuICAgICAgaWYgKGN1cnJlbnRUaW1lID49IGRlYWRsaW5lKSB7XG4gICAgICAgIGlmIChzY2hlZHVsaW5nLmlzSW5wdXRQZW5kaW5nKCkpIHtcbiAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gY3VycmVudFRpbWUgPj0gbWF4RGVhZGxpbmU7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgfTtcbiAgfSBlbHNlIHtcbiAgICBzaG91bGRZaWVsZFRvSG9zdCA9ICgpID0+IHBlcmZvcm1hbmNlLm5vdygpID49IGRlYWRsaW5lO1xuICB9XG59XG5mdW5jdGlvbiBlbnF1ZXVlKHRhc2tRdWV1ZSwgdGFzaykge1xuICBmdW5jdGlvbiBmaW5kSW5kZXgoKSB7XG4gICAgbGV0IG0gPSAwO1xuICAgIGxldCBuID0gdGFza1F1ZXVlLmxlbmd0aCAtIDE7XG4gICAgd2hpbGUgKG0gPD0gbikge1xuICAgICAgY29uc3QgayA9IG4gKyBtID4+IDE7XG4gICAgICBjb25zdCBjbXAgPSB0YXNrLmV4cGlyYXRpb25UaW1lIC0gdGFza1F1ZXVlW2tdLmV4cGlyYXRpb25UaW1lO1xuICAgICAgaWYgKGNtcCA+IDApIG0gPSBrICsgMTtlbHNlIGlmIChjbXAgPCAwKSBuID0gayAtIDE7ZWxzZSByZXR1cm4gaztcbiAgICB9XG4gICAgcmV0dXJuIG07XG4gIH1cbiAgdGFza1F1ZXVlLnNwbGljZShmaW5kSW5kZXgoKSwgMCwgdGFzayk7XG59XG5mdW5jdGlvbiByZXF1ZXN0Q2FsbGJhY2soZm4sIG9wdGlvbnMpIHtcbiAgaWYgKCFzY2hlZHVsZUNhbGxiYWNrKSBzZXR1cFNjaGVkdWxlcigpO1xuICBsZXQgc3RhcnRUaW1lID0gcGVyZm9ybWFuY2Uubm93KCksXG4gICAgdGltZW91dCA9IG1heFNpZ25lZDMxQml0SW50O1xuICBpZiAob3B0aW9ucyAmJiBvcHRpb25zLnRpbWVvdXQpIHRpbWVvdXQgPSBvcHRpb25zLnRpbWVvdXQ7XG4gIGNvbnN0IG5ld1Rhc2sgPSB7XG4gICAgaWQ6IHRhc2tJZENvdW50ZXIrKyxcbiAgICBmbixcbiAgICBzdGFydFRpbWUsXG4gICAgZXhwaXJhdGlvblRpbWU6IHN0YXJ0VGltZSArIHRpbWVvdXRcbiAgfTtcbiAgZW5xdWV1ZSh0YXNrUXVldWUsIG5ld1Rhc2spO1xuICBpZiAoIWlzQ2FsbGJhY2tTY2hlZHVsZWQgJiYgIWlzUGVyZm9ybWluZ1dvcmspIHtcbiAgICBpc0NhbGxiYWNrU2NoZWR1bGVkID0gdHJ1ZTtcbiAgICBzY2hlZHVsZWRDYWxsYmFjayA9IGZsdXNoV29yaztcbiAgICBzY2hlZHVsZUNhbGxiYWNrKCk7XG4gIH1cbiAgcmV0dXJuIG5ld1Rhc2s7XG59XG5mdW5jdGlvbiBjYW5jZWxDYWxsYmFjayh0YXNrKSB7XG4gIHRhc2suZm4gPSBudWxsO1xufVxuZnVuY3Rpb24gZmx1c2hXb3JrKGluaXRpYWxUaW1lKSB7XG4gIGlzQ2FsbGJhY2tTY2hlZHVsZWQgPSBmYWxzZTtcbiAgaXNQZXJmb3JtaW5nV29yayA9IHRydWU7XG4gIHRyeSB7XG4gICAgcmV0dXJuIHdvcmtMb29wKGluaXRpYWxUaW1lKTtcbiAgfSBmaW5hbGx5IHtcbiAgICBjdXJyZW50VGFzayA9IG51bGw7XG4gICAgaXNQZXJmb3JtaW5nV29yayA9IGZhbHNlO1xuICB9XG59XG5mdW5jdGlvbiB3b3JrTG9vcChpbml0aWFsVGltZSkge1xuICBsZXQgY3VycmVudFRpbWUgPSBpbml0aWFsVGltZTtcbiAgY3VycmVudFRhc2sgPSB0YXNrUXVldWVbMF0gfHwgbnVsbDtcbiAgd2hpbGUgKGN1cnJlbnRUYXNrICE9PSBudWxsKSB7XG4gICAgaWYgKGN1cnJlbnRUYXNrLmV4cGlyYXRpb25UaW1lID4gY3VycmVudFRpbWUgJiYgc2hvdWxkWWllbGRUb0hvc3QoKSkge1xuICAgICAgYnJlYWs7XG4gICAgfVxuICAgIGNvbnN0IGNhbGxiYWNrID0gY3VycmVudFRhc2suZm47XG4gICAgaWYgKGNhbGxiYWNrICE9PSBudWxsKSB7XG4gICAgICBjdXJyZW50VGFzay5mbiA9IG51bGw7XG4gICAgICBjb25zdCBkaWRVc2VyQ2FsbGJhY2tUaW1lb3V0ID0gY3VycmVudFRhc2suZXhwaXJhdGlvblRpbWUgPD0gY3VycmVudFRpbWU7XG4gICAgICBjYWxsYmFjayhkaWRVc2VyQ2FsbGJhY2tUaW1lb3V0KTtcbiAgICAgIGN1cnJlbnRUaW1lID0gcGVyZm9ybWFuY2Uubm93KCk7XG4gICAgICBpZiAoY3VycmVudFRhc2sgPT09IHRhc2tRdWV1ZVswXSkge1xuICAgICAgICB0YXNrUXVldWUuc2hpZnQoKTtcbiAgICAgIH1cbiAgICB9IGVsc2UgdGFza1F1ZXVlLnNoaWZ0KCk7XG4gICAgY3VycmVudFRhc2sgPSB0YXNrUXVldWVbMF0gfHwgbnVsbDtcbiAgfVxuICByZXR1cm4gY3VycmVudFRhc2sgIT09IG51bGw7XG59XG5cbmNvbnN0IHNoYXJlZENvbmZpZyA9IHtcbiAgY29udGV4dDogdW5kZWZpbmVkLFxuICByZWdpc3RyeTogdW5kZWZpbmVkLFxuICBlZmZlY3RzOiB1bmRlZmluZWQsXG4gIGRvbmU6IGZhbHNlLFxuICBnZXRDb250ZXh0SWQoKSB7XG4gICAgcmV0dXJuIGdldENvbnRleHRJZCh0aGlzLmNvbnRleHQuY291bnQpO1xuICB9LFxuICBnZXROZXh0Q29udGV4dElkKCkge1xuICAgIHJldHVybiBnZXRDb250ZXh0SWQodGhpcy5jb250ZXh0LmNvdW50KyspO1xuICB9XG59O1xuZnVuY3Rpb24gZ2V0Q29udGV4dElkKGNvdW50KSB7XG4gIGNvbnN0IG51bSA9IFN0cmluZyhjb3VudCksXG4gICAgbGVuID0gbnVtLmxlbmd0aCAtIDE7XG4gIHJldHVybiBzaGFyZWRDb25maWcuY29udGV4dC5pZCArIChsZW4gPyBTdHJpbmcuZnJvbUNoYXJDb2RlKDk2ICsgbGVuKSA6IFwiXCIpICsgbnVtO1xufVxuZnVuY3Rpb24gc2V0SHlkcmF0ZUNvbnRleHQoY29udGV4dCkge1xuICBzaGFyZWRDb25maWcuY29udGV4dCA9IGNvbnRleHQ7XG59XG5mdW5jdGlvbiBuZXh0SHlkcmF0ZUNvbnRleHQoKSB7XG4gIHJldHVybiB7XG4gICAgLi4uc2hhcmVkQ29uZmlnLmNvbnRleHQsXG4gICAgaWQ6IHNoYXJlZENvbmZpZy5nZXROZXh0Q29udGV4dElkKCksXG4gICAgY291bnQ6IDBcbiAgfTtcbn1cblxuY29uc3QgSVNfREVWID0gZmFsc2U7XG5jb25zdCBlcXVhbEZuID0gKGEsIGIpID0+IGEgPT09IGI7XG5jb25zdCAkUFJPWFkgPSBTeW1ib2woXCJzb2xpZC1wcm94eVwiKTtcbmNvbnN0IFNVUFBPUlRTX1BST1hZID0gdHlwZW9mIFByb3h5ID09PSBcImZ1bmN0aW9uXCI7XG5jb25zdCAkVFJBQ0sgPSBTeW1ib2woXCJzb2xpZC10cmFja1wiKTtcbmNvbnN0ICRERVZDT01QID0gU3ltYm9sKFwic29saWQtZGV2LWNvbXBvbmVudFwiKTtcbmNvbnN0IHNpZ25hbE9wdGlvbnMgPSB7XG4gIGVxdWFsczogZXF1YWxGblxufTtcbmxldCBFUlJPUiA9IG51bGw7XG5sZXQgcnVuRWZmZWN0cyA9IHJ1blF1ZXVlO1xuY29uc3QgU1RBTEUgPSAxO1xuY29uc3QgUEVORElORyA9IDI7XG5jb25zdCBVTk9XTkVEID0ge1xuICBvd25lZDogbnVsbCxcbiAgY2xlYW51cHM6IG51bGwsXG4gIGNvbnRleHQ6IG51bGwsXG4gIG93bmVyOiBudWxsXG59O1xuY29uc3QgTk9fSU5JVCA9IHt9O1xudmFyIE93bmVyID0gbnVsbDtcbmxldCBUcmFuc2l0aW9uID0gbnVsbDtcbmxldCBTY2hlZHVsZXIgPSBudWxsO1xubGV0IEV4dGVybmFsU291cmNlQ29uZmlnID0gbnVsbDtcbmxldCBMaXN0ZW5lciA9IG51bGw7XG5sZXQgVXBkYXRlcyA9IG51bGw7XG5sZXQgRWZmZWN0cyA9IG51bGw7XG5sZXQgRXhlY0NvdW50ID0gMDtcbmZ1bmN0aW9uIGNyZWF0ZVJvb3QoZm4sIGRldGFjaGVkT3duZXIpIHtcbiAgY29uc3QgbGlzdGVuZXIgPSBMaXN0ZW5lcixcbiAgICBvd25lciA9IE93bmVyLFxuICAgIHVub3duZWQgPSBmbi5sZW5ndGggPT09IDAsXG4gICAgY3VycmVudCA9IGRldGFjaGVkT3duZXIgPT09IHVuZGVmaW5lZCA/IG93bmVyIDogZGV0YWNoZWRPd25lcixcbiAgICByb290ID0gdW5vd25lZCA/IFVOT1dORUQgOiB7XG4gICAgICBvd25lZDogbnVsbCxcbiAgICAgIGNsZWFudXBzOiBudWxsLFxuICAgICAgY29udGV4dDogY3VycmVudCA/IGN1cnJlbnQuY29udGV4dCA6IG51bGwsXG4gICAgICBvd25lcjogY3VycmVudFxuICAgIH0sXG4gICAgdXBkYXRlRm4gPSB1bm93bmVkID8gZm4gOiAoKSA9PiBmbihjcmVhdGVEaXNwb3Nlcihyb290KSk7XG4gIE93bmVyID0gcm9vdDtcbiAgTGlzdGVuZXIgPSBudWxsO1xuICB0cnkge1xuICAgIHJldHVybiBydW5VcGRhdGVzKHVwZGF0ZUZuLCB0cnVlKTtcbiAgfSBmaW5hbGx5IHtcbiAgICBMaXN0ZW5lciA9IGxpc3RlbmVyO1xuICAgIE93bmVyID0gb3duZXI7XG4gIH1cbn1cbmZ1bmN0aW9uIGNyZWF0ZURpc3Bvc2VyKHJvb3QpIHtcbiAgcmV0dXJuICgpID0+IHVudHJhY2soKCkgPT4gY2xlYW5Ob2RlKHJvb3QpKTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZVNpZ25hbCh2YWx1ZSwgb3B0aW9ucykge1xuICBvcHRpb25zID0gb3B0aW9ucyA/IE9iamVjdC5hc3NpZ24oe30sIHNpZ25hbE9wdGlvbnMsIG9wdGlvbnMpIDogc2lnbmFsT3B0aW9ucztcbiAgY29uc3QgcyA9IHtcbiAgICB2YWx1ZSxcbiAgICBvYnNlcnZlcnM6IG51bGwsXG4gICAgb2JzZXJ2ZXJTbG90czogbnVsbCxcbiAgICBjb21wYXJhdG9yOiBvcHRpb25zLmVxdWFscyB8fCB1bmRlZmluZWRcbiAgfTtcbiAgY29uc3Qgc2V0dGVyID0gdmFsdWUgPT4ge1xuICAgIGlmICh0eXBlb2YgdmFsdWUgPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgaWYgKFRyYW5zaXRpb24gJiYgVHJhbnNpdGlvbi5ydW5uaW5nICYmIFRyYW5zaXRpb24uc291cmNlcy5oYXMocykpIHZhbHVlID0gdmFsdWUocy50VmFsdWUpO2Vsc2UgdmFsdWUgPSB2YWx1ZShzLnZhbHVlKTtcbiAgICB9XG4gICAgcmV0dXJuIHdyaXRlU2lnbmFsKHMsIHZhbHVlKTtcbiAgfTtcbiAgcmV0dXJuIFtyZWFkU2lnbmFsLmJpbmQocyksIHNldHRlcl07XG59XG5mdW5jdGlvbiBjcmVhdGVDb21wdXRlZChmbiwgdmFsdWUsIG9wdGlvbnMpIHtcbiAgY29uc3QgYyA9IGNyZWF0ZUNvbXB1dGF0aW9uKGZuLCB2YWx1ZSwgdHJ1ZSwgU1RBTEUpO1xuICBpZiAoU2NoZWR1bGVyICYmIFRyYW5zaXRpb24gJiYgVHJhbnNpdGlvbi5ydW5uaW5nKSBVcGRhdGVzLnB1c2goYyk7ZWxzZSB1cGRhdGVDb21wdXRhdGlvbihjKTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZVJlbmRlckVmZmVjdChmbiwgdmFsdWUsIG9wdGlvbnMpIHtcbiAgY29uc3QgYyA9IGNyZWF0ZUNvbXB1dGF0aW9uKGZuLCB2YWx1ZSwgZmFsc2UsIFNUQUxFKTtcbiAgaWYgKFNjaGVkdWxlciAmJiBUcmFuc2l0aW9uICYmIFRyYW5zaXRpb24ucnVubmluZykgVXBkYXRlcy5wdXNoKGMpO2Vsc2UgdXBkYXRlQ29tcHV0YXRpb24oYyk7XG59XG5mdW5jdGlvbiBjcmVhdGVFZmZlY3QoZm4sIHZhbHVlLCBvcHRpb25zKSB7XG4gIHJ1bkVmZmVjdHMgPSBydW5Vc2VyRWZmZWN0cztcbiAgY29uc3QgYyA9IGNyZWF0ZUNvbXB1dGF0aW9uKGZuLCB2YWx1ZSwgZmFsc2UsIFNUQUxFKSxcbiAgICBzID0gU3VzcGVuc2VDb250ZXh0ICYmIHVzZUNvbnRleHQoU3VzcGVuc2VDb250ZXh0KTtcbiAgaWYgKHMpIGMuc3VzcGVuc2UgPSBzO1xuICBpZiAoIW9wdGlvbnMgfHwgIW9wdGlvbnMucmVuZGVyKSBjLnVzZXIgPSB0cnVlO1xuICBFZmZlY3RzID8gRWZmZWN0cy5wdXNoKGMpIDogdXBkYXRlQ29tcHV0YXRpb24oYyk7XG59XG5mdW5jdGlvbiBjcmVhdGVSZWFjdGlvbihvbkludmFsaWRhdGUsIG9wdGlvbnMpIHtcbiAgbGV0IGZuO1xuICBjb25zdCBjID0gY3JlYXRlQ29tcHV0YXRpb24oKCkgPT4ge1xuICAgICAgZm4gPyBmbigpIDogdW50cmFjayhvbkludmFsaWRhdGUpO1xuICAgICAgZm4gPSB1bmRlZmluZWQ7XG4gICAgfSwgdW5kZWZpbmVkLCBmYWxzZSwgMCksXG4gICAgcyA9IFN1c3BlbnNlQ29udGV4dCAmJiB1c2VDb250ZXh0KFN1c3BlbnNlQ29udGV4dCk7XG4gIGlmIChzKSBjLnN1c3BlbnNlID0gcztcbiAgYy51c2VyID0gdHJ1ZTtcbiAgcmV0dXJuIHRyYWNraW5nID0+IHtcbiAgICBmbiA9IHRyYWNraW5nO1xuICAgIHVwZGF0ZUNvbXB1dGF0aW9uKGMpO1xuICB9O1xufVxuZnVuY3Rpb24gY3JlYXRlTWVtbyhmbiwgdmFsdWUsIG9wdGlvbnMpIHtcbiAgb3B0aW9ucyA9IG9wdGlvbnMgPyBPYmplY3QuYXNzaWduKHt9LCBzaWduYWxPcHRpb25zLCBvcHRpb25zKSA6IHNpZ25hbE9wdGlvbnM7XG4gIGNvbnN0IGMgPSBjcmVhdGVDb21wdXRhdGlvbihmbiwgdmFsdWUsIHRydWUsIDApO1xuICBjLm9ic2VydmVycyA9IG51bGw7XG4gIGMub2JzZXJ2ZXJTbG90cyA9IG51bGw7XG4gIGMuY29tcGFyYXRvciA9IG9wdGlvbnMuZXF1YWxzIHx8IHVuZGVmaW5lZDtcbiAgaWYgKFNjaGVkdWxlciAmJiBUcmFuc2l0aW9uICYmIFRyYW5zaXRpb24ucnVubmluZykge1xuICAgIGMudFN0YXRlID0gU1RBTEU7XG4gICAgVXBkYXRlcy5wdXNoKGMpO1xuICB9IGVsc2UgdXBkYXRlQ29tcHV0YXRpb24oYyk7XG4gIHJldHVybiByZWFkU2lnbmFsLmJpbmQoYyk7XG59XG5mdW5jdGlvbiBpc1Byb21pc2Uodikge1xuICByZXR1cm4gdiAmJiB0eXBlb2YgdiA9PT0gXCJvYmplY3RcIiAmJiBcInRoZW5cIiBpbiB2O1xufVxuZnVuY3Rpb24gY3JlYXRlUmVzb3VyY2UocFNvdXJjZSwgcEZldGNoZXIsIHBPcHRpb25zKSB7XG4gIGxldCBzb3VyY2U7XG4gIGxldCBmZXRjaGVyO1xuICBsZXQgb3B0aW9ucztcbiAgaWYgKHR5cGVvZiBwRmV0Y2hlciA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgc291cmNlID0gcFNvdXJjZTtcbiAgICBmZXRjaGVyID0gcEZldGNoZXI7XG4gICAgb3B0aW9ucyA9IHBPcHRpb25zIHx8IHt9O1xuICB9IGVsc2Uge1xuICAgIHNvdXJjZSA9IHRydWU7XG4gICAgZmV0Y2hlciA9IHBTb3VyY2U7XG4gICAgb3B0aW9ucyA9IHBGZXRjaGVyIHx8IHt9O1xuICB9XG4gIGxldCBwciA9IG51bGwsXG4gICAgaW5pdFAgPSBOT19JTklULFxuICAgIGlkID0gbnVsbCxcbiAgICBsb2FkZWRVbmRlclRyYW5zaXRpb24gPSBmYWxzZSxcbiAgICBzY2hlZHVsZWQgPSBmYWxzZSxcbiAgICByZXNvbHZlZCA9IFwiaW5pdGlhbFZhbHVlXCIgaW4gb3B0aW9ucyxcbiAgICBkeW5hbWljID0gdHlwZW9mIHNvdXJjZSA9PT0gXCJmdW5jdGlvblwiICYmIGNyZWF0ZU1lbW8oc291cmNlKTtcbiAgY29uc3QgY29udGV4dHMgPSBuZXcgU2V0KCksXG4gICAgW3ZhbHVlLCBzZXRWYWx1ZV0gPSAob3B0aW9ucy5zdG9yYWdlIHx8IGNyZWF0ZVNpZ25hbCkob3B0aW9ucy5pbml0aWFsVmFsdWUpLFxuICAgIFtlcnJvciwgc2V0RXJyb3JdID0gY3JlYXRlU2lnbmFsKHVuZGVmaW5lZCksXG4gICAgW3RyYWNrLCB0cmlnZ2VyXSA9IGNyZWF0ZVNpZ25hbCh1bmRlZmluZWQsIHtcbiAgICAgIGVxdWFsczogZmFsc2VcbiAgICB9KSxcbiAgICBbc3RhdGUsIHNldFN0YXRlXSA9IGNyZWF0ZVNpZ25hbChyZXNvbHZlZCA/IFwicmVhZHlcIiA6IFwidW5yZXNvbHZlZFwiKTtcbiAgaWYgKE93bmVyKSBvbkNsZWFudXAoKCkgPT4ge1xuICAgIGZvciAoY29uc3QgYyBvZiBjb250ZXh0cy5rZXlzKCkpIGMuZGVjcmVtZW50KCk7XG4gICAgY29udGV4dHMuY2xlYXIoKTtcbiAgICBpZiAoVHJhbnNpdGlvbiAmJiBwcikgVHJhbnNpdGlvbi5wcm9taXNlcy5kZWxldGUocHIpO1xuICAgIHByID0gbnVsbDtcbiAgfSk7XG4gIGlmIChzaGFyZWRDb25maWcuY29udGV4dCkge1xuICAgIGlkID0gc2hhcmVkQ29uZmlnLmdldE5leHRDb250ZXh0SWQoKTtcbiAgICBpZiAob3B0aW9ucy5zc3JMb2FkRnJvbSA9PT0gXCJpbml0aWFsXCIpIGluaXRQID0gb3B0aW9ucy5pbml0aWFsVmFsdWU7ZWxzZSBpZiAoc2hhcmVkQ29uZmlnLmxvYWQgJiYgc2hhcmVkQ29uZmlnLmhhcyhpZCkpIGluaXRQID0gc2hhcmVkQ29uZmlnLmxvYWQoaWQpO1xuICB9XG4gIGZ1bmN0aW9uIGxvYWRFbmQocCwgdiwgZXJyb3IsIGtleSkge1xuICAgIGlmIChwciA9PT0gcCkge1xuICAgICAgcHIgPSBudWxsO1xuICAgICAga2V5ICE9PSB1bmRlZmluZWQgJiYgKHJlc29sdmVkID0gdHJ1ZSk7XG4gICAgICBpZiAoKHAgPT09IGluaXRQIHx8IHYgPT09IGluaXRQKSAmJiBvcHRpb25zLm9uSHlkcmF0ZWQpIHF1ZXVlTWljcm90YXNrKCgpID0+IG9wdGlvbnMub25IeWRyYXRlZChrZXksIHtcbiAgICAgICAgdmFsdWU6IHZcbiAgICAgIH0pKTtcbiAgICAgIGluaXRQID0gTk9fSU5JVDtcbiAgICAgIGlmIChUcmFuc2l0aW9uICYmIHAgJiYgbG9hZGVkVW5kZXJUcmFuc2l0aW9uKSB7XG4gICAgICAgIFRyYW5zaXRpb24ucHJvbWlzZXMuZGVsZXRlKHApO1xuICAgICAgICBsb2FkZWRVbmRlclRyYW5zaXRpb24gPSBmYWxzZTtcbiAgICAgICAgcnVuVXBkYXRlcygoKSA9PiB7XG4gICAgICAgICAgVHJhbnNpdGlvbi5ydW5uaW5nID0gdHJ1ZTtcbiAgICAgICAgICBjb21wbGV0ZUxvYWQodiwgZXJyb3IpO1xuICAgICAgICB9LCBmYWxzZSk7XG4gICAgICB9IGVsc2UgY29tcGxldGVMb2FkKHYsIGVycm9yKTtcbiAgICB9XG4gICAgcmV0dXJuIHY7XG4gIH1cbiAgZnVuY3Rpb24gY29tcGxldGVMb2FkKHYsIGVycikge1xuICAgIHJ1blVwZGF0ZXMoKCkgPT4ge1xuICAgICAgaWYgKGVyciA9PT0gdW5kZWZpbmVkKSBzZXRWYWx1ZSgoKSA9PiB2KTtcbiAgICAgIHNldFN0YXRlKGVyciAhPT0gdW5kZWZpbmVkID8gXCJlcnJvcmVkXCIgOiByZXNvbHZlZCA/IFwicmVhZHlcIiA6IFwidW5yZXNvbHZlZFwiKTtcbiAgICAgIHNldEVycm9yKGVycik7XG4gICAgICBmb3IgKGNvbnN0IGMgb2YgY29udGV4dHMua2V5cygpKSBjLmRlY3JlbWVudCgpO1xuICAgICAgY29udGV4dHMuY2xlYXIoKTtcbiAgICB9LCBmYWxzZSk7XG4gIH1cbiAgZnVuY3Rpb24gcmVhZCgpIHtcbiAgICBjb25zdCBjID0gU3VzcGVuc2VDb250ZXh0ICYmIHVzZUNvbnRleHQoU3VzcGVuc2VDb250ZXh0KSxcbiAgICAgIHYgPSB2YWx1ZSgpLFxuICAgICAgZXJyID0gZXJyb3IoKTtcbiAgICBpZiAoZXJyICE9PSB1bmRlZmluZWQgJiYgIXByKSB0aHJvdyBlcnI7XG4gICAgaWYgKExpc3RlbmVyICYmICFMaXN0ZW5lci51c2VyICYmIGMpIHtcbiAgICAgIGNyZWF0ZUNvbXB1dGVkKCgpID0+IHtcbiAgICAgICAgdHJhY2soKTtcbiAgICAgICAgaWYgKHByKSB7XG4gICAgICAgICAgaWYgKGMucmVzb2x2ZWQgJiYgVHJhbnNpdGlvbiAmJiBsb2FkZWRVbmRlclRyYW5zaXRpb24pIFRyYW5zaXRpb24ucHJvbWlzZXMuYWRkKHByKTtlbHNlIGlmICghY29udGV4dHMuaGFzKGMpKSB7XG4gICAgICAgICAgICBjLmluY3JlbWVudCgpO1xuICAgICAgICAgICAgY29udGV4dHMuYWRkKGMpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICAgIHJldHVybiB2O1xuICB9XG4gIGZ1bmN0aW9uIGxvYWQocmVmZXRjaGluZyA9IHRydWUpIHtcbiAgICBpZiAocmVmZXRjaGluZyAhPT0gZmFsc2UgJiYgc2NoZWR1bGVkKSByZXR1cm47XG4gICAgc2NoZWR1bGVkID0gZmFsc2U7XG4gICAgY29uc3QgbG9va3VwID0gZHluYW1pYyA/IGR5bmFtaWMoKSA6IHNvdXJjZTtcbiAgICBsb2FkZWRVbmRlclRyYW5zaXRpb24gPSBUcmFuc2l0aW9uICYmIFRyYW5zaXRpb24ucnVubmluZztcbiAgICBpZiAobG9va3VwID09IG51bGwgfHwgbG9va3VwID09PSBmYWxzZSkge1xuICAgICAgbG9hZEVuZChwciwgdW50cmFjayh2YWx1ZSkpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoVHJhbnNpdGlvbiAmJiBwcikgVHJhbnNpdGlvbi5wcm9taXNlcy5kZWxldGUocHIpO1xuICAgIGxldCBlcnJvcjtcbiAgICBjb25zdCBwID0gaW5pdFAgIT09IE5PX0lOSVQgPyBpbml0UCA6IHVudHJhY2soKCkgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgcmV0dXJuIGZldGNoZXIobG9va3VwLCB7XG4gICAgICAgICAgdmFsdWU6IHZhbHVlKCksXG4gICAgICAgICAgcmVmZXRjaGluZ1xuICAgICAgICB9KTtcbiAgICAgIH0gY2F0Y2ggKGZldGNoZXJFcnJvcikge1xuICAgICAgICBlcnJvciA9IGZldGNoZXJFcnJvcjtcbiAgICAgIH1cbiAgICB9KTtcbiAgICBpZiAoZXJyb3IgIT09IHVuZGVmaW5lZCkge1xuICAgICAgbG9hZEVuZChwciwgdW5kZWZpbmVkLCBjYXN0RXJyb3IoZXJyb3IpLCBsb29rdXApO1xuICAgICAgcmV0dXJuO1xuICAgIH0gZWxzZSBpZiAoIWlzUHJvbWlzZShwKSkge1xuICAgICAgbG9hZEVuZChwciwgcCwgdW5kZWZpbmVkLCBsb29rdXApO1xuICAgICAgcmV0dXJuIHA7XG4gICAgfVxuICAgIHByID0gcDtcbiAgICBpZiAoXCJ2XCIgaW4gcCkge1xuICAgICAgaWYgKHAucyA9PT0gMSkgbG9hZEVuZChwciwgcC52LCB1bmRlZmluZWQsIGxvb2t1cCk7ZWxzZSBsb2FkRW5kKHByLCB1bmRlZmluZWQsIGNhc3RFcnJvcihwLnYpLCBsb29rdXApO1xuICAgICAgcmV0dXJuIHA7XG4gICAgfVxuICAgIHNjaGVkdWxlZCA9IHRydWU7XG4gICAgcXVldWVNaWNyb3Rhc2soKCkgPT4gc2NoZWR1bGVkID0gZmFsc2UpO1xuICAgIHJ1blVwZGF0ZXMoKCkgPT4ge1xuICAgICAgc2V0U3RhdGUocmVzb2x2ZWQgPyBcInJlZnJlc2hpbmdcIiA6IFwicGVuZGluZ1wiKTtcbiAgICAgIHRyaWdnZXIoKTtcbiAgICB9LCBmYWxzZSk7XG4gICAgcmV0dXJuIHAudGhlbih2ID0+IGxvYWRFbmQocCwgdiwgdW5kZWZpbmVkLCBsb29rdXApLCBlID0+IGxvYWRFbmQocCwgdW5kZWZpbmVkLCBjYXN0RXJyb3IoZSksIGxvb2t1cCkpO1xuICB9XG4gIE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKHJlYWQsIHtcbiAgICBzdGF0ZToge1xuICAgICAgZ2V0OiAoKSA9PiBzdGF0ZSgpXG4gICAgfSxcbiAgICBlcnJvcjoge1xuICAgICAgZ2V0OiAoKSA9PiBlcnJvcigpXG4gICAgfSxcbiAgICBsb2FkaW5nOiB7XG4gICAgICBnZXQoKSB7XG4gICAgICAgIGNvbnN0IHMgPSBzdGF0ZSgpO1xuICAgICAgICByZXR1cm4gcyA9PT0gXCJwZW5kaW5nXCIgfHwgcyA9PT0gXCJyZWZyZXNoaW5nXCI7XG4gICAgICB9XG4gICAgfSxcbiAgICBsYXRlc3Q6IHtcbiAgICAgIGdldCgpIHtcbiAgICAgICAgaWYgKCFyZXNvbHZlZCkgcmV0dXJuIHJlYWQoKTtcbiAgICAgICAgY29uc3QgZXJyID0gZXJyb3IoKTtcbiAgICAgICAgaWYgKGVyciAmJiAhcHIpIHRocm93IGVycjtcbiAgICAgICAgcmV0dXJuIHZhbHVlKCk7XG4gICAgICB9XG4gICAgfVxuICB9KTtcbiAgbGV0IG93bmVyID0gT3duZXI7XG4gIGlmIChkeW5hbWljKSBjcmVhdGVDb21wdXRlZCgoKSA9PiAob3duZXIgPSBPd25lciwgbG9hZChmYWxzZSkpKTtlbHNlIGxvYWQoZmFsc2UpO1xuICByZXR1cm4gW3JlYWQsIHtcbiAgICByZWZldGNoOiBpbmZvID0+IHJ1bldpdGhPd25lcihvd25lciwgKCkgPT4gbG9hZChpbmZvKSksXG4gICAgbXV0YXRlOiBzZXRWYWx1ZVxuICB9XTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZURlZmVycmVkKHNvdXJjZSwgb3B0aW9ucykge1xuICBsZXQgdCxcbiAgICB0aW1lb3V0ID0gb3B0aW9ucyA/IG9wdGlvbnMudGltZW91dE1zIDogdW5kZWZpbmVkO1xuICBjb25zdCBub2RlID0gY3JlYXRlQ29tcHV0YXRpb24oKCkgPT4ge1xuICAgIGlmICghdCB8fCAhdC5mbikgdCA9IHJlcXVlc3RDYWxsYmFjaygoKSA9PiBzZXREZWZlcnJlZCgoKSA9PiBub2RlLnZhbHVlKSwgdGltZW91dCAhPT0gdW5kZWZpbmVkID8ge1xuICAgICAgdGltZW91dFxuICAgIH0gOiB1bmRlZmluZWQpO1xuICAgIHJldHVybiBzb3VyY2UoKTtcbiAgfSwgdW5kZWZpbmVkLCB0cnVlKTtcbiAgY29uc3QgW2RlZmVycmVkLCBzZXREZWZlcnJlZF0gPSBjcmVhdGVTaWduYWwoVHJhbnNpdGlvbiAmJiBUcmFuc2l0aW9uLnJ1bm5pbmcgJiYgVHJhbnNpdGlvbi5zb3VyY2VzLmhhcyhub2RlKSA/IG5vZGUudFZhbHVlIDogbm9kZS52YWx1ZSwgb3B0aW9ucyk7XG4gIHVwZGF0ZUNvbXB1dGF0aW9uKG5vZGUpO1xuICBzZXREZWZlcnJlZCgoKSA9PiBUcmFuc2l0aW9uICYmIFRyYW5zaXRpb24ucnVubmluZyAmJiBUcmFuc2l0aW9uLnNvdXJjZXMuaGFzKG5vZGUpID8gbm9kZS50VmFsdWUgOiBub2RlLnZhbHVlKTtcbiAgcmV0dXJuIGRlZmVycmVkO1xufVxuZnVuY3Rpb24gY3JlYXRlU2VsZWN0b3Ioc291cmNlLCBmbiA9IGVxdWFsRm4sIG9wdGlvbnMpIHtcbiAgY29uc3Qgc3VicyA9IG5ldyBNYXAoKTtcbiAgY29uc3Qgbm9kZSA9IGNyZWF0ZUNvbXB1dGF0aW9uKHAgPT4ge1xuICAgIGNvbnN0IHYgPSBzb3VyY2UoKTtcbiAgICBmb3IgKGNvbnN0IFtrZXksIHZhbF0gb2Ygc3Vicy5lbnRyaWVzKCkpIGlmIChmbihrZXksIHYpICE9PSBmbihrZXksIHApKSB7XG4gICAgICBmb3IgKGNvbnN0IGMgb2YgdmFsLnZhbHVlcygpKSB7XG4gICAgICAgIGlmIChUcmFuc2l0aW9uICYmIFRyYW5zaXRpb24ucnVubmluZykgYy50U3RhdGUgPSBTVEFMRTtlbHNlIGMuc3RhdGUgPSBTVEFMRTtcbiAgICAgICAgaWYgKGMucHVyZSkgVXBkYXRlcy5wdXNoKGMpO2Vsc2UgRWZmZWN0cy5wdXNoKGMpO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gdjtcbiAgfSwgdW5kZWZpbmVkLCB0cnVlLCBTVEFMRSk7XG4gIHVwZGF0ZUNvbXB1dGF0aW9uKG5vZGUpO1xuICByZXR1cm4ga2V5ID0+IHtcbiAgICBjb25zdCBsaXN0ZW5lciA9IExpc3RlbmVyO1xuICAgIGlmIChsaXN0ZW5lcikge1xuICAgICAgbGV0IGw7XG4gICAgICBpZiAobCA9IHN1YnMuZ2V0KGtleSkpIGwuYWRkKGxpc3RlbmVyKTtlbHNlIHN1YnMuc2V0KGtleSwgbCA9IG5ldyBTZXQoW2xpc3RlbmVyXSkpO1xuICAgICAgb25DbGVhbnVwKCgpID0+IHtcbiAgICAgICAgbC5kZWxldGUobGlzdGVuZXIpO1xuICAgICAgICAhbC5zaXplICYmIHN1YnMuZGVsZXRlKGtleSk7XG4gICAgICB9KTtcbiAgICB9XG4gICAgcmV0dXJuIGZuKGtleSwgVHJhbnNpdGlvbiAmJiBUcmFuc2l0aW9uLnJ1bm5pbmcgJiYgVHJhbnNpdGlvbi5zb3VyY2VzLmhhcyhub2RlKSA/IG5vZGUudFZhbHVlIDogbm9kZS52YWx1ZSk7XG4gIH07XG59XG5mdW5jdGlvbiBiYXRjaChmbikge1xuICByZXR1cm4gcnVuVXBkYXRlcyhmbiwgZmFsc2UpO1xufVxuZnVuY3Rpb24gdW50cmFjayhmbikge1xuICBpZiAoIUV4dGVybmFsU291cmNlQ29uZmlnICYmIExpc3RlbmVyID09PSBudWxsKSByZXR1cm4gZm4oKTtcbiAgY29uc3QgbGlzdGVuZXIgPSBMaXN0ZW5lcjtcbiAgTGlzdGVuZXIgPSBudWxsO1xuICB0cnkge1xuICAgIGlmIChFeHRlcm5hbFNvdXJjZUNvbmZpZykgcmV0dXJuIEV4dGVybmFsU291cmNlQ29uZmlnLnVudHJhY2soZm4pO1xuICAgIHJldHVybiBmbigpO1xuICB9IGZpbmFsbHkge1xuICAgIExpc3RlbmVyID0gbGlzdGVuZXI7XG4gIH1cbn1cbmZ1bmN0aW9uIG9uKGRlcHMsIGZuLCBvcHRpb25zKSB7XG4gIGNvbnN0IGlzQXJyYXkgPSBBcnJheS5pc0FycmF5KGRlcHMpO1xuICBsZXQgcHJldklucHV0O1xuICBsZXQgZGVmZXIgPSBvcHRpb25zICYmIG9wdGlvbnMuZGVmZXI7XG4gIHJldHVybiBwcmV2VmFsdWUgPT4ge1xuICAgIGxldCBpbnB1dDtcbiAgICBpZiAoaXNBcnJheSkge1xuICAgICAgaW5wdXQgPSBBcnJheShkZXBzLmxlbmd0aCk7XG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGRlcHMubGVuZ3RoOyBpKyspIGlucHV0W2ldID0gZGVwc1tpXSgpO1xuICAgIH0gZWxzZSBpbnB1dCA9IGRlcHMoKTtcbiAgICBpZiAoZGVmZXIpIHtcbiAgICAgIGRlZmVyID0gZmFsc2U7XG4gICAgICByZXR1cm4gcHJldlZhbHVlO1xuICAgIH1cbiAgICBjb25zdCByZXN1bHQgPSB1bnRyYWNrKCgpID0+IGZuKGlucHV0LCBwcmV2SW5wdXQsIHByZXZWYWx1ZSkpO1xuICAgIHByZXZJbnB1dCA9IGlucHV0O1xuICAgIHJldHVybiByZXN1bHQ7XG4gIH07XG59XG5mdW5jdGlvbiBvbk1vdW50KGZuKSB7XG4gIGNyZWF0ZUVmZmVjdCgoKSA9PiB1bnRyYWNrKGZuKSk7XG59XG5mdW5jdGlvbiBvbkNsZWFudXAoZm4pIHtcbiAgaWYgKE93bmVyID09PSBudWxsKSA7ZWxzZSBpZiAoT3duZXIuY2xlYW51cHMgPT09IG51bGwpIE93bmVyLmNsZWFudXBzID0gW2ZuXTtlbHNlIE93bmVyLmNsZWFudXBzLnB1c2goZm4pO1xuICByZXR1cm4gZm47XG59XG5mdW5jdGlvbiBjYXRjaEVycm9yKGZuLCBoYW5kbGVyKSB7XG4gIEVSUk9SIHx8IChFUlJPUiA9IFN5bWJvbChcImVycm9yXCIpKTtcbiAgT3duZXIgPSBjcmVhdGVDb21wdXRhdGlvbih1bmRlZmluZWQsIHVuZGVmaW5lZCwgdHJ1ZSk7XG4gIE93bmVyLmNvbnRleHQgPSB7XG4gICAgLi4uT3duZXIuY29udGV4dCxcbiAgICBbRVJST1JdOiBbaGFuZGxlcl1cbiAgfTtcbiAgaWYgKFRyYW5zaXRpb24gJiYgVHJhbnNpdGlvbi5ydW5uaW5nKSBUcmFuc2l0aW9uLnNvdXJjZXMuYWRkKE93bmVyKTtcbiAgdHJ5IHtcbiAgICByZXR1cm4gZm4oKTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgaGFuZGxlRXJyb3IoZXJyKTtcbiAgfSBmaW5hbGx5IHtcbiAgICBPd25lciA9IE93bmVyLm93bmVyO1xuICB9XG59XG5mdW5jdGlvbiBnZXRMaXN0ZW5lcigpIHtcbiAgcmV0dXJuIExpc3RlbmVyO1xufVxuZnVuY3Rpb24gZ2V0T3duZXIoKSB7XG4gIHJldHVybiBPd25lcjtcbn1cbmZ1bmN0aW9uIHJ1bldpdGhPd25lcihvLCBmbikge1xuICBjb25zdCBwcmV2ID0gT3duZXI7XG4gIGNvbnN0IHByZXZMaXN0ZW5lciA9IExpc3RlbmVyO1xuICBPd25lciA9IG87XG4gIExpc3RlbmVyID0gbnVsbDtcbiAgdHJ5IHtcbiAgICByZXR1cm4gcnVuVXBkYXRlcyhmbiwgdHJ1ZSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGhhbmRsZUVycm9yKGVycik7XG4gIH0gZmluYWxseSB7XG4gICAgT3duZXIgPSBwcmV2O1xuICAgIExpc3RlbmVyID0gcHJldkxpc3RlbmVyO1xuICB9XG59XG5mdW5jdGlvbiBlbmFibGVTY2hlZHVsaW5nKHNjaGVkdWxlciA9IHJlcXVlc3RDYWxsYmFjaykge1xuICBTY2hlZHVsZXIgPSBzY2hlZHVsZXI7XG59XG5mdW5jdGlvbiBzdGFydFRyYW5zaXRpb24oZm4pIHtcbiAgaWYgKFRyYW5zaXRpb24gJiYgVHJhbnNpdGlvbi5ydW5uaW5nKSB7XG4gICAgZm4oKTtcbiAgICByZXR1cm4gVHJhbnNpdGlvbi5kb25lO1xuICB9XG4gIGNvbnN0IGwgPSBMaXN0ZW5lcjtcbiAgY29uc3QgbyA9IE93bmVyO1xuICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCkudGhlbigoKSA9PiB7XG4gICAgTGlzdGVuZXIgPSBsO1xuICAgIE93bmVyID0gbztcbiAgICBsZXQgdDtcbiAgICBpZiAoU2NoZWR1bGVyIHx8IFN1c3BlbnNlQ29udGV4dCkge1xuICAgICAgdCA9IFRyYW5zaXRpb24gfHwgKFRyYW5zaXRpb24gPSB7XG4gICAgICAgIHNvdXJjZXM6IG5ldyBTZXQoKSxcbiAgICAgICAgZWZmZWN0czogW10sXG4gICAgICAgIHByb21pc2VzOiBuZXcgU2V0KCksXG4gICAgICAgIGRpc3Bvc2VkOiBuZXcgU2V0KCksXG4gICAgICAgIHF1ZXVlOiBuZXcgU2V0KCksXG4gICAgICAgIHJ1bm5pbmc6IHRydWVcbiAgICAgIH0pO1xuICAgICAgdC5kb25lIHx8ICh0LmRvbmUgPSBuZXcgUHJvbWlzZShyZXMgPT4gdC5yZXNvbHZlID0gcmVzKSk7XG4gICAgICB0LnJ1bm5pbmcgPSB0cnVlO1xuICAgIH1cbiAgICBydW5VcGRhdGVzKGZuLCBmYWxzZSk7XG4gICAgTGlzdGVuZXIgPSBPd25lciA9IG51bGw7XG4gICAgcmV0dXJuIHQgPyB0LmRvbmUgOiB1bmRlZmluZWQ7XG4gIH0pO1xufVxuY29uc3QgW3RyYW5zUGVuZGluZywgc2V0VHJhbnNQZW5kaW5nXSA9IC8qQF9fUFVSRV9fKi9jcmVhdGVTaWduYWwoZmFsc2UpO1xuZnVuY3Rpb24gdXNlVHJhbnNpdGlvbigpIHtcbiAgcmV0dXJuIFt0cmFuc1BlbmRpbmcsIHN0YXJ0VHJhbnNpdGlvbl07XG59XG5mdW5jdGlvbiByZXN1bWVFZmZlY3RzKGUpIHtcbiAgRWZmZWN0cy5wdXNoLmFwcGx5KEVmZmVjdHMsIGUpO1xuICBlLmxlbmd0aCA9IDA7XG59XG5mdW5jdGlvbiBjcmVhdGVDb250ZXh0KGRlZmF1bHRWYWx1ZSwgb3B0aW9ucykge1xuICBjb25zdCBpZCA9IFN5bWJvbChcImNvbnRleHRcIik7XG4gIHJldHVybiB7XG4gICAgaWQsXG4gICAgUHJvdmlkZXI6IGNyZWF0ZVByb3ZpZGVyKGlkKSxcbiAgICBkZWZhdWx0VmFsdWVcbiAgfTtcbn1cbmZ1bmN0aW9uIHVzZUNvbnRleHQoY29udGV4dCkge1xuICBsZXQgdmFsdWU7XG4gIHJldHVybiBPd25lciAmJiBPd25lci5jb250ZXh0ICYmICh2YWx1ZSA9IE93bmVyLmNvbnRleHRbY29udGV4dC5pZF0pICE9PSB1bmRlZmluZWQgPyB2YWx1ZSA6IGNvbnRleHQuZGVmYXVsdFZhbHVlO1xufVxuZnVuY3Rpb24gY2hpbGRyZW4oZm4pIHtcbiAgY29uc3QgY2hpbGRyZW4gPSBjcmVhdGVNZW1vKGZuKTtcbiAgY29uc3QgbWVtbyA9IGNyZWF0ZU1lbW8oKCkgPT4gcmVzb2x2ZUNoaWxkcmVuKGNoaWxkcmVuKCkpKTtcbiAgbWVtby50b0FycmF5ID0gKCkgPT4ge1xuICAgIGNvbnN0IGMgPSBtZW1vKCk7XG4gICAgcmV0dXJuIEFycmF5LmlzQXJyYXkoYykgPyBjIDogYyAhPSBudWxsID8gW2NdIDogW107XG4gIH07XG4gIHJldHVybiBtZW1vO1xufVxubGV0IFN1c3BlbnNlQ29udGV4dDtcbmZ1bmN0aW9uIGdldFN1c3BlbnNlQ29udGV4dCgpIHtcbiAgcmV0dXJuIFN1c3BlbnNlQ29udGV4dCB8fCAoU3VzcGVuc2VDb250ZXh0ID0gY3JlYXRlQ29udGV4dCgpKTtcbn1cbmZ1bmN0aW9uIGVuYWJsZUV4dGVybmFsU291cmNlKGZhY3RvcnksIHVudHJhY2sgPSBmbiA9PiBmbigpKSB7XG4gIGlmIChFeHRlcm5hbFNvdXJjZUNvbmZpZykge1xuICAgIGNvbnN0IHtcbiAgICAgIGZhY3Rvcnk6IG9sZEZhY3RvcnksXG4gICAgICB1bnRyYWNrOiBvbGRVbnRyYWNrXG4gICAgfSA9IEV4dGVybmFsU291cmNlQ29uZmlnO1xuICAgIEV4dGVybmFsU291cmNlQ29uZmlnID0ge1xuICAgICAgZmFjdG9yeTogKGZuLCB0cmlnZ2VyKSA9PiB7XG4gICAgICAgIGNvbnN0IG9sZFNvdXJjZSA9IG9sZEZhY3RvcnkoZm4sIHRyaWdnZXIpO1xuICAgICAgICBjb25zdCBzb3VyY2UgPSBmYWN0b3J5KHggPT4gb2xkU291cmNlLnRyYWNrKHgpLCB0cmlnZ2VyKTtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICB0cmFjazogeCA9PiBzb3VyY2UudHJhY2soeCksXG4gICAgICAgICAgZGlzcG9zZSgpIHtcbiAgICAgICAgICAgIHNvdXJjZS5kaXNwb3NlKCk7XG4gICAgICAgICAgICBvbGRTb3VyY2UuZGlzcG9zZSgpO1xuICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICAgIH0sXG4gICAgICB1bnRyYWNrOiBmbiA9PiBvbGRVbnRyYWNrKCgpID0+IHVudHJhY2soZm4pKVxuICAgIH07XG4gIH0gZWxzZSB7XG4gICAgRXh0ZXJuYWxTb3VyY2VDb25maWcgPSB7XG4gICAgICBmYWN0b3J5LFxuICAgICAgdW50cmFja1xuICAgIH07XG4gIH1cbn1cbmZ1bmN0aW9uIHJlYWRTaWduYWwoKSB7XG4gIGNvbnN0IHJ1bm5pbmdUcmFuc2l0aW9uID0gVHJhbnNpdGlvbiAmJiBUcmFuc2l0aW9uLnJ1bm5pbmc7XG4gIGlmICh0aGlzLnNvdXJjZXMgJiYgKHJ1bm5pbmdUcmFuc2l0aW9uID8gdGhpcy50U3RhdGUgOiB0aGlzLnN0YXRlKSkge1xuICAgIGlmICgocnVubmluZ1RyYW5zaXRpb24gPyB0aGlzLnRTdGF0ZSA6IHRoaXMuc3RhdGUpID09PSBTVEFMRSkgdXBkYXRlQ29tcHV0YXRpb24odGhpcyk7ZWxzZSB7XG4gICAgICBjb25zdCB1cGRhdGVzID0gVXBkYXRlcztcbiAgICAgIFVwZGF0ZXMgPSBudWxsO1xuICAgICAgcnVuVXBkYXRlcygoKSA9PiBsb29rVXBzdHJlYW0odGhpcyksIGZhbHNlKTtcbiAgICAgIFVwZGF0ZXMgPSB1cGRhdGVzO1xuICAgIH1cbiAgfVxuICBpZiAoTGlzdGVuZXIpIHtcbiAgICBjb25zdCBvYnNlcnZlcnMgPSB0aGlzLm9ic2VydmVycztcbiAgICBpZiAoIW9ic2VydmVycyB8fCBvYnNlcnZlcnNbb2JzZXJ2ZXJzLmxlbmd0aCAtIDFdICE9PSBMaXN0ZW5lcikge1xuICAgICAgY29uc3Qgc1Nsb3QgPSBvYnNlcnZlcnMgPyBvYnNlcnZlcnMubGVuZ3RoIDogMDtcbiAgICAgIGlmICghTGlzdGVuZXIuc291cmNlcykge1xuICAgICAgICBMaXN0ZW5lci5zb3VyY2VzID0gW3RoaXNdO1xuICAgICAgICBMaXN0ZW5lci5zb3VyY2VTbG90cyA9IFtzU2xvdF07XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBMaXN0ZW5lci5zb3VyY2VzLnB1c2godGhpcyk7XG4gICAgICAgIExpc3RlbmVyLnNvdXJjZVNsb3RzLnB1c2goc1Nsb3QpO1xuICAgICAgfVxuICAgICAgaWYgKCFvYnNlcnZlcnMpIHtcbiAgICAgICAgdGhpcy5vYnNlcnZlcnMgPSBbTGlzdGVuZXJdO1xuICAgICAgICB0aGlzLm9ic2VydmVyU2xvdHMgPSBbTGlzdGVuZXIuc291cmNlcy5sZW5ndGggLSAxXTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIG9ic2VydmVycy5wdXNoKExpc3RlbmVyKTtcbiAgICAgICAgdGhpcy5vYnNlcnZlclNsb3RzLnB1c2goTGlzdGVuZXIuc291cmNlcy5sZW5ndGggLSAxKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgaWYgKHJ1bm5pbmdUcmFuc2l0aW9uICYmIFRyYW5zaXRpb24uc291cmNlcy5oYXModGhpcykpIHJldHVybiB0aGlzLnRWYWx1ZTtcbiAgcmV0dXJuIHRoaXMudmFsdWU7XG59XG5mdW5jdGlvbiB3cml0ZVNpZ25hbChub2RlLCB2YWx1ZSwgaXNDb21wKSB7XG4gIGxldCBjdXJyZW50ID0gVHJhbnNpdGlvbiAmJiBUcmFuc2l0aW9uLnJ1bm5pbmcgJiYgVHJhbnNpdGlvbi5zb3VyY2VzLmhhcyhub2RlKSA/IG5vZGUudFZhbHVlIDogbm9kZS52YWx1ZTtcbiAgaWYgKCFub2RlLmNvbXBhcmF0b3IgfHwgIW5vZGUuY29tcGFyYXRvcihjdXJyZW50LCB2YWx1ZSkpIHtcbiAgICBpZiAoVHJhbnNpdGlvbikge1xuICAgICAgY29uc3QgVHJhbnNpdGlvblJ1bm5pbmcgPSBUcmFuc2l0aW9uLnJ1bm5pbmc7XG4gICAgICBpZiAoVHJhbnNpdGlvblJ1bm5pbmcgfHwgIWlzQ29tcCAmJiBUcmFuc2l0aW9uLnNvdXJjZXMuaGFzKG5vZGUpKSB7XG4gICAgICAgIFRyYW5zaXRpb24uc291cmNlcy5hZGQobm9kZSk7XG4gICAgICAgIG5vZGUudFZhbHVlID0gdmFsdWU7XG4gICAgICB9XG4gICAgICBpZiAoIVRyYW5zaXRpb25SdW5uaW5nKSBub2RlLnZhbHVlID0gdmFsdWU7XG4gICAgfSBlbHNlIG5vZGUudmFsdWUgPSB2YWx1ZTtcbiAgICBpZiAobm9kZS5vYnNlcnZlcnMgJiYgbm9kZS5vYnNlcnZlcnMubGVuZ3RoKSB7XG4gICAgICBydW5VcGRhdGVzKCgpID0+IHtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBub2RlLm9ic2VydmVycy5sZW5ndGg7IGkgKz0gMSkge1xuICAgICAgICAgIGNvbnN0IG8gPSBub2RlLm9ic2VydmVyc1tpXTtcbiAgICAgICAgICBjb25zdCBUcmFuc2l0aW9uUnVubmluZyA9IFRyYW5zaXRpb24gJiYgVHJhbnNpdGlvbi5ydW5uaW5nO1xuICAgICAgICAgIGlmIChUcmFuc2l0aW9uUnVubmluZyAmJiBUcmFuc2l0aW9uLmRpc3Bvc2VkLmhhcyhvKSkgY29udGludWU7XG4gICAgICAgICAgaWYgKFRyYW5zaXRpb25SdW5uaW5nID8gIW8udFN0YXRlIDogIW8uc3RhdGUpIHtcbiAgICAgICAgICAgIGlmIChvLnB1cmUpIFVwZGF0ZXMucHVzaChvKTtlbHNlIEVmZmVjdHMucHVzaChvKTtcbiAgICAgICAgICAgIGlmIChvLm9ic2VydmVycykgbWFya0Rvd25zdHJlYW0obyk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmICghVHJhbnNpdGlvblJ1bm5pbmcpIG8uc3RhdGUgPSBTVEFMRTtlbHNlIG8udFN0YXRlID0gU1RBTEU7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKFVwZGF0ZXMubGVuZ3RoID4gMTBlNSkge1xuICAgICAgICAgIFVwZGF0ZXMgPSBbXTtcbiAgICAgICAgICBpZiAoSVNfREVWKSA7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCk7XG4gICAgICAgIH1cbiAgICAgIH0sIGZhbHNlKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHZhbHVlO1xufVxuZnVuY3Rpb24gdXBkYXRlQ29tcHV0YXRpb24obm9kZSkge1xuICBpZiAoIW5vZGUuZm4pIHJldHVybjtcbiAgY2xlYW5Ob2RlKG5vZGUpO1xuICBjb25zdCB0aW1lID0gRXhlY0NvdW50O1xuICBydW5Db21wdXRhdGlvbihub2RlLCBUcmFuc2l0aW9uICYmIFRyYW5zaXRpb24ucnVubmluZyAmJiBUcmFuc2l0aW9uLnNvdXJjZXMuaGFzKG5vZGUpID8gbm9kZS50VmFsdWUgOiBub2RlLnZhbHVlLCB0aW1lKTtcbiAgaWYgKFRyYW5zaXRpb24gJiYgIVRyYW5zaXRpb24ucnVubmluZyAmJiBUcmFuc2l0aW9uLnNvdXJjZXMuaGFzKG5vZGUpKSB7XG4gICAgcXVldWVNaWNyb3Rhc2soKCkgPT4ge1xuICAgICAgcnVuVXBkYXRlcygoKSA9PiB7XG4gICAgICAgIFRyYW5zaXRpb24gJiYgKFRyYW5zaXRpb24ucnVubmluZyA9IHRydWUpO1xuICAgICAgICBMaXN0ZW5lciA9IE93bmVyID0gbm9kZTtcbiAgICAgICAgcnVuQ29tcHV0YXRpb24obm9kZSwgbm9kZS50VmFsdWUsIHRpbWUpO1xuICAgICAgICBMaXN0ZW5lciA9IE93bmVyID0gbnVsbDtcbiAgICAgIH0sIGZhbHNlKTtcbiAgICB9KTtcbiAgfVxufVxuZnVuY3Rpb24gcnVuQ29tcHV0YXRpb24obm9kZSwgdmFsdWUsIHRpbWUpIHtcbiAgbGV0IG5leHRWYWx1ZTtcbiAgY29uc3Qgb3duZXIgPSBPd25lcixcbiAgICBsaXN0ZW5lciA9IExpc3RlbmVyO1xuICBMaXN0ZW5lciA9IE93bmVyID0gbm9kZTtcbiAgdHJ5IHtcbiAgICBuZXh0VmFsdWUgPSBub2RlLmZuKHZhbHVlKTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgaWYgKG5vZGUucHVyZSkge1xuICAgICAgaWYgKFRyYW5zaXRpb24gJiYgVHJhbnNpdGlvbi5ydW5uaW5nKSB7XG4gICAgICAgIG5vZGUudFN0YXRlID0gU1RBTEU7XG4gICAgICAgIG5vZGUudE93bmVkICYmIG5vZGUudE93bmVkLmZvckVhY2goY2xlYW5Ob2RlKTtcbiAgICAgICAgbm9kZS50T3duZWQgPSB1bmRlZmluZWQ7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBub2RlLnN0YXRlID0gU1RBTEU7XG4gICAgICAgIG5vZGUub3duZWQgJiYgbm9kZS5vd25lZC5mb3JFYWNoKGNsZWFuTm9kZSk7XG4gICAgICAgIG5vZGUub3duZWQgPSBudWxsO1xuICAgICAgfVxuICAgIH1cbiAgICBub2RlLnVwZGF0ZWRBdCA9IHRpbWUgKyAxO1xuICAgIHJldHVybiBoYW5kbGVFcnJvcihlcnIpO1xuICB9IGZpbmFsbHkge1xuICAgIExpc3RlbmVyID0gbGlzdGVuZXI7XG4gICAgT3duZXIgPSBvd25lcjtcbiAgfVxuICBpZiAoIW5vZGUudXBkYXRlZEF0IHx8IG5vZGUudXBkYXRlZEF0IDw9IHRpbWUpIHtcbiAgICBpZiAobm9kZS51cGRhdGVkQXQgIT0gbnVsbCAmJiBcIm9ic2VydmVyc1wiIGluIG5vZGUpIHtcbiAgICAgIHdyaXRlU2lnbmFsKG5vZGUsIG5leHRWYWx1ZSwgdHJ1ZSk7XG4gICAgfSBlbHNlIGlmIChUcmFuc2l0aW9uICYmIFRyYW5zaXRpb24ucnVubmluZyAmJiBub2RlLnB1cmUpIHtcbiAgICAgIGlmICghVHJhbnNpdGlvbi5zb3VyY2VzLmhhcyhub2RlKSkgbm9kZS52YWx1ZSA9IG5leHRWYWx1ZTtcbiAgICAgIFRyYW5zaXRpb24uc291cmNlcy5hZGQobm9kZSk7XG4gICAgICBub2RlLnRWYWx1ZSA9IG5leHRWYWx1ZTtcbiAgICB9IGVsc2Ugbm9kZS52YWx1ZSA9IG5leHRWYWx1ZTtcbiAgICBub2RlLnVwZGF0ZWRBdCA9IHRpbWU7XG4gIH1cbn1cbmZ1bmN0aW9uIGNyZWF0ZUNvbXB1dGF0aW9uKGZuLCBpbml0LCBwdXJlLCBzdGF0ZSA9IFNUQUxFLCBvcHRpb25zKSB7XG4gIGNvbnN0IGMgPSB7XG4gICAgZm4sXG4gICAgc3RhdGU6IHN0YXRlLFxuICAgIHVwZGF0ZWRBdDogbnVsbCxcbiAgICBvd25lZDogbnVsbCxcbiAgICBzb3VyY2VzOiBudWxsLFxuICAgIHNvdXJjZVNsb3RzOiBudWxsLFxuICAgIGNsZWFudXBzOiBudWxsLFxuICAgIHZhbHVlOiBpbml0LFxuICAgIG93bmVyOiBPd25lcixcbiAgICBjb250ZXh0OiBPd25lciA/IE93bmVyLmNvbnRleHQgOiBudWxsLFxuICAgIHB1cmVcbiAgfTtcbiAgaWYgKFRyYW5zaXRpb24gJiYgVHJhbnNpdGlvbi5ydW5uaW5nKSB7XG4gICAgYy5zdGF0ZSA9IDA7XG4gICAgYy50U3RhdGUgPSBzdGF0ZTtcbiAgfVxuICBpZiAoT3duZXIgPT09IG51bGwpIDtlbHNlIGlmIChPd25lciAhPT0gVU5PV05FRCkge1xuICAgIGlmIChUcmFuc2l0aW9uICYmIFRyYW5zaXRpb24ucnVubmluZyAmJiBPd25lci5wdXJlKSB7XG4gICAgICBpZiAoIU93bmVyLnRPd25lZCkgT3duZXIudE93bmVkID0gW2NdO2Vsc2UgT3duZXIudE93bmVkLnB1c2goYyk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGlmICghT3duZXIub3duZWQpIE93bmVyLm93bmVkID0gW2NdO2Vsc2UgT3duZXIub3duZWQucHVzaChjKTtcbiAgICB9XG4gIH1cbiAgaWYgKEV4dGVybmFsU291cmNlQ29uZmlnICYmIGMuZm4pIHtcbiAgICBjb25zdCBzb3VyY2VGbiA9IGMuZm47XG4gICAgY29uc3QgW3RyYWNrLCB0cmlnZ2VyXSA9IGNyZWF0ZVNpZ25hbCh1bmRlZmluZWQsIHtcbiAgICAgIGVxdWFsczogZmFsc2VcbiAgICB9KTtcbiAgICBjb25zdCBvcmRpbmFyeSA9IEV4dGVybmFsU291cmNlQ29uZmlnLmZhY3Rvcnkoc291cmNlRm4sIHRyaWdnZXIpO1xuICAgIG9uQ2xlYW51cCgoKSA9PiBvcmRpbmFyeS5kaXNwb3NlKCkpO1xuICAgIGxldCBpblRyYW5zaXRpb247XG4gICAgbGV0IHRyYWNrZWRPcmRpbmFyeSA9IGZhbHNlO1xuICAgIGNvbnN0IHRyaWdnZXJJblRyYW5zaXRpb24gPSAoKSA9PiBzdGFydFRyYW5zaXRpb24odHJpZ2dlcikudGhlbigoKSA9PiB7XG4gICAgICBpZiAoaW5UcmFuc2l0aW9uKSB7XG4gICAgICAgIGluVHJhbnNpdGlvbi5kaXNwb3NlKCk7XG4gICAgICAgIGluVHJhbnNpdGlvbiA9IHVuZGVmaW5lZDtcbiAgICAgICAgaWYgKCF0cmFja2VkT3JkaW5hcnkpIHRyaWdnZXIoKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgICBjLmZuID0geCA9PiB7XG4gICAgICB0cmFjaygpO1xuICAgICAgaWYgKFRyYW5zaXRpb24gJiYgVHJhbnNpdGlvbi5ydW5uaW5nKSB7XG4gICAgICAgIGlmICghaW5UcmFuc2l0aW9uKSBpblRyYW5zaXRpb24gPSBFeHRlcm5hbFNvdXJjZUNvbmZpZy5mYWN0b3J5KHNvdXJjZUZuLCB0cmlnZ2VySW5UcmFuc2l0aW9uKTtcbiAgICAgICAgcmV0dXJuIGluVHJhbnNpdGlvbi50cmFjayh4KTtcbiAgICAgIH1cbiAgICAgIHRyYWNrZWRPcmRpbmFyeSA9IHRydWU7XG4gICAgICByZXR1cm4gb3JkaW5hcnkudHJhY2soeCk7XG4gICAgfTtcbiAgfVxuICByZXR1cm4gYztcbn1cbmZ1bmN0aW9uIHJ1blRvcChub2RlKSB7XG4gIGNvbnN0IHJ1bm5pbmdUcmFuc2l0aW9uID0gVHJhbnNpdGlvbiAmJiBUcmFuc2l0aW9uLnJ1bm5pbmc7XG4gIGlmICgocnVubmluZ1RyYW5zaXRpb24gPyBub2RlLnRTdGF0ZSA6IG5vZGUuc3RhdGUpID09PSAwKSByZXR1cm47XG4gIGlmICgocnVubmluZ1RyYW5zaXRpb24gPyBub2RlLnRTdGF0ZSA6IG5vZGUuc3RhdGUpID09PSBQRU5ESU5HKSByZXR1cm4gbG9va1Vwc3RyZWFtKG5vZGUpO1xuICBpZiAobm9kZS5zdXNwZW5zZSAmJiB1bnRyYWNrKG5vZGUuc3VzcGVuc2UuaW5GYWxsYmFjaykpIHJldHVybiBub2RlLnN1c3BlbnNlLmVmZmVjdHMucHVzaChub2RlKTtcbiAgY29uc3QgYW5jZXN0b3JzID0gW25vZGVdO1xuICB3aGlsZSAoKG5vZGUgPSBub2RlLm93bmVyKSAmJiAoIW5vZGUudXBkYXRlZEF0IHx8IG5vZGUudXBkYXRlZEF0IDwgRXhlY0NvdW50KSkge1xuICAgIGlmIChydW5uaW5nVHJhbnNpdGlvbiAmJiBUcmFuc2l0aW9uLmRpc3Bvc2VkLmhhcyhub2RlKSkgcmV0dXJuO1xuICAgIGlmIChydW5uaW5nVHJhbnNpdGlvbiA/IG5vZGUudFN0YXRlIDogbm9kZS5zdGF0ZSkgYW5jZXN0b3JzLnB1c2gobm9kZSk7XG4gIH1cbiAgZm9yIChsZXQgaSA9IGFuY2VzdG9ycy5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuICAgIG5vZGUgPSBhbmNlc3RvcnNbaV07XG4gICAgaWYgKHJ1bm5pbmdUcmFuc2l0aW9uKSB7XG4gICAgICBsZXQgdG9wID0gbm9kZSxcbiAgICAgICAgcHJldiA9IGFuY2VzdG9yc1tpICsgMV07XG4gICAgICB3aGlsZSAoKHRvcCA9IHRvcC5vd25lcikgJiYgdG9wICE9PSBwcmV2KSB7XG4gICAgICAgIGlmIChUcmFuc2l0aW9uLmRpc3Bvc2VkLmhhcyh0b3ApKSByZXR1cm47XG4gICAgICB9XG4gICAgfVxuICAgIGlmICgocnVubmluZ1RyYW5zaXRpb24gPyBub2RlLnRTdGF0ZSA6IG5vZGUuc3RhdGUpID09PSBTVEFMRSkge1xuICAgICAgdXBkYXRlQ29tcHV0YXRpb24obm9kZSk7XG4gICAgfSBlbHNlIGlmICgocnVubmluZ1RyYW5zaXRpb24gPyBub2RlLnRTdGF0ZSA6IG5vZGUuc3RhdGUpID09PSBQRU5ESU5HKSB7XG4gICAgICBjb25zdCB1cGRhdGVzID0gVXBkYXRlcztcbiAgICAgIFVwZGF0ZXMgPSBudWxsO1xuICAgICAgcnVuVXBkYXRlcygoKSA9PiBsb29rVXBzdHJlYW0obm9kZSwgYW5jZXN0b3JzWzBdKSwgZmFsc2UpO1xuICAgICAgVXBkYXRlcyA9IHVwZGF0ZXM7XG4gICAgfVxuICB9XG59XG5mdW5jdGlvbiBydW5VcGRhdGVzKGZuLCBpbml0KSB7XG4gIGlmIChVcGRhdGVzKSByZXR1cm4gZm4oKTtcbiAgbGV0IHdhaXQgPSBmYWxzZTtcbiAgaWYgKCFpbml0KSBVcGRhdGVzID0gW107XG4gIGlmIChFZmZlY3RzKSB3YWl0ID0gdHJ1ZTtlbHNlIEVmZmVjdHMgPSBbXTtcbiAgRXhlY0NvdW50Kys7XG4gIHRyeSB7XG4gICAgY29uc3QgcmVzID0gZm4oKTtcbiAgICBjb21wbGV0ZVVwZGF0ZXMod2FpdCk7XG4gICAgcmV0dXJuIHJlcztcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgaWYgKCF3YWl0KSBFZmZlY3RzID0gbnVsbDtcbiAgICBVcGRhdGVzID0gbnVsbDtcbiAgICBoYW5kbGVFcnJvcihlcnIpO1xuICB9XG59XG5mdW5jdGlvbiBjb21wbGV0ZVVwZGF0ZXMod2FpdCkge1xuICBpZiAoVXBkYXRlcykge1xuICAgIGlmIChTY2hlZHVsZXIgJiYgVHJhbnNpdGlvbiAmJiBUcmFuc2l0aW9uLnJ1bm5pbmcpIHNjaGVkdWxlUXVldWUoVXBkYXRlcyk7ZWxzZSBydW5RdWV1ZShVcGRhdGVzKTtcbiAgICBVcGRhdGVzID0gbnVsbDtcbiAgfVxuICBpZiAod2FpdCkgcmV0dXJuO1xuICBsZXQgcmVzO1xuICBpZiAoVHJhbnNpdGlvbikge1xuICAgIGlmICghVHJhbnNpdGlvbi5wcm9taXNlcy5zaXplICYmICFUcmFuc2l0aW9uLnF1ZXVlLnNpemUpIHtcbiAgICAgIGNvbnN0IHNvdXJjZXMgPSBUcmFuc2l0aW9uLnNvdXJjZXM7XG4gICAgICBjb25zdCBkaXNwb3NlZCA9IFRyYW5zaXRpb24uZGlzcG9zZWQ7XG4gICAgICBFZmZlY3RzLnB1c2guYXBwbHkoRWZmZWN0cywgVHJhbnNpdGlvbi5lZmZlY3RzKTtcbiAgICAgIHJlcyA9IFRyYW5zaXRpb24ucmVzb2x2ZTtcbiAgICAgIGZvciAoY29uc3QgZSBvZiBFZmZlY3RzKSB7XG4gICAgICAgIFwidFN0YXRlXCIgaW4gZSAmJiAoZS5zdGF0ZSA9IGUudFN0YXRlKTtcbiAgICAgICAgZGVsZXRlIGUudFN0YXRlO1xuICAgICAgfVxuICAgICAgVHJhbnNpdGlvbiA9IG51bGw7XG4gICAgICBydW5VcGRhdGVzKCgpID0+IHtcbiAgICAgICAgZm9yIChjb25zdCBkIG9mIGRpc3Bvc2VkKSBjbGVhbk5vZGUoZCk7XG4gICAgICAgIGZvciAoY29uc3QgdiBvZiBzb3VyY2VzKSB7XG4gICAgICAgICAgdi52YWx1ZSA9IHYudFZhbHVlO1xuICAgICAgICAgIGlmICh2Lm93bmVkKSB7XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMCwgbGVuID0gdi5vd25lZC5sZW5ndGg7IGkgPCBsZW47IGkrKykgY2xlYW5Ob2RlKHYub3duZWRbaV0pO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAodi50T3duZWQpIHYub3duZWQgPSB2LnRPd25lZDtcbiAgICAgICAgICBkZWxldGUgdi50VmFsdWU7XG4gICAgICAgICAgZGVsZXRlIHYudE93bmVkO1xuICAgICAgICAgIHYudFN0YXRlID0gMDtcbiAgICAgICAgfVxuICAgICAgICBzZXRUcmFuc1BlbmRpbmcoZmFsc2UpO1xuICAgICAgfSwgZmFsc2UpO1xuICAgIH0gZWxzZSBpZiAoVHJhbnNpdGlvbi5ydW5uaW5nKSB7XG4gICAgICBUcmFuc2l0aW9uLnJ1bm5pbmcgPSBmYWxzZTtcbiAgICAgIFRyYW5zaXRpb24uZWZmZWN0cy5wdXNoLmFwcGx5KFRyYW5zaXRpb24uZWZmZWN0cywgRWZmZWN0cyk7XG4gICAgICBFZmZlY3RzID0gbnVsbDtcbiAgICAgIHNldFRyYW5zUGVuZGluZyh0cnVlKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gIH1cbiAgY29uc3QgZSA9IEVmZmVjdHM7XG4gIEVmZmVjdHMgPSBudWxsO1xuICBpZiAoZS5sZW5ndGgpIHJ1blVwZGF0ZXMoKCkgPT4gcnVuRWZmZWN0cyhlKSwgZmFsc2UpO1xuICBpZiAocmVzKSByZXMoKTtcbn1cbmZ1bmN0aW9uIHJ1blF1ZXVlKHF1ZXVlKSB7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgcXVldWUubGVuZ3RoOyBpKyspIHJ1blRvcChxdWV1ZVtpXSk7XG59XG5mdW5jdGlvbiBzY2hlZHVsZVF1ZXVlKHF1ZXVlKSB7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgcXVldWUubGVuZ3RoOyBpKyspIHtcbiAgICBjb25zdCBpdGVtID0gcXVldWVbaV07XG4gICAgY29uc3QgdGFza3MgPSBUcmFuc2l0aW9uLnF1ZXVlO1xuICAgIGlmICghdGFza3MuaGFzKGl0ZW0pKSB7XG4gICAgICB0YXNrcy5hZGQoaXRlbSk7XG4gICAgICBTY2hlZHVsZXIoKCkgPT4ge1xuICAgICAgICB0YXNrcy5kZWxldGUoaXRlbSk7XG4gICAgICAgIHJ1blVwZGF0ZXMoKCkgPT4ge1xuICAgICAgICAgIFRyYW5zaXRpb24ucnVubmluZyA9IHRydWU7XG4gICAgICAgICAgcnVuVG9wKGl0ZW0pO1xuICAgICAgICB9LCBmYWxzZSk7XG4gICAgICAgIFRyYW5zaXRpb24gJiYgKFRyYW5zaXRpb24ucnVubmluZyA9IGZhbHNlKTtcbiAgICAgIH0pO1xuICAgIH1cbiAgfVxufVxuZnVuY3Rpb24gcnVuVXNlckVmZmVjdHMocXVldWUpIHtcbiAgbGV0IGksXG4gICAgdXNlckxlbmd0aCA9IDA7XG4gIGZvciAoaSA9IDA7IGkgPCBxdWV1ZS5sZW5ndGg7IGkrKykge1xuICAgIGNvbnN0IGUgPSBxdWV1ZVtpXTtcbiAgICBpZiAoIWUudXNlcikgcnVuVG9wKGUpO2Vsc2UgcXVldWVbdXNlckxlbmd0aCsrXSA9IGU7XG4gIH1cbiAgaWYgKHNoYXJlZENvbmZpZy5jb250ZXh0KSB7XG4gICAgaWYgKHNoYXJlZENvbmZpZy5jb3VudCkge1xuICAgICAgc2hhcmVkQ29uZmlnLmVmZmVjdHMgfHwgKHNoYXJlZENvbmZpZy5lZmZlY3RzID0gW10pO1xuICAgICAgc2hhcmVkQ29uZmlnLmVmZmVjdHMucHVzaCguLi5xdWV1ZS5zbGljZSgwLCB1c2VyTGVuZ3RoKSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHNldEh5ZHJhdGVDb250ZXh0KCk7XG4gIH1cbiAgaWYgKHNoYXJlZENvbmZpZy5lZmZlY3RzICYmIChzaGFyZWRDb25maWcuZG9uZSB8fCAhc2hhcmVkQ29uZmlnLmNvdW50KSkge1xuICAgIHF1ZXVlID0gWy4uLnNoYXJlZENvbmZpZy5lZmZlY3RzLCAuLi5xdWV1ZV07XG4gICAgdXNlckxlbmd0aCArPSBzaGFyZWRDb25maWcuZWZmZWN0cy5sZW5ndGg7XG4gICAgZGVsZXRlIHNoYXJlZENvbmZpZy5lZmZlY3RzO1xuICB9XG4gIGZvciAoaSA9IDA7IGkgPCB1c2VyTGVuZ3RoOyBpKyspIHJ1blRvcChxdWV1ZVtpXSk7XG59XG5mdW5jdGlvbiBsb29rVXBzdHJlYW0obm9kZSwgaWdub3JlKSB7XG4gIGNvbnN0IHJ1bm5pbmdUcmFuc2l0aW9uID0gVHJhbnNpdGlvbiAmJiBUcmFuc2l0aW9uLnJ1bm5pbmc7XG4gIGlmIChydW5uaW5nVHJhbnNpdGlvbikgbm9kZS50U3RhdGUgPSAwO2Vsc2Ugbm9kZS5zdGF0ZSA9IDA7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgbm9kZS5zb3VyY2VzLmxlbmd0aDsgaSArPSAxKSB7XG4gICAgY29uc3Qgc291cmNlID0gbm9kZS5zb3VyY2VzW2ldO1xuICAgIGlmIChzb3VyY2Uuc291cmNlcykge1xuICAgICAgY29uc3Qgc3RhdGUgPSBydW5uaW5nVHJhbnNpdGlvbiA/IHNvdXJjZS50U3RhdGUgOiBzb3VyY2Uuc3RhdGU7XG4gICAgICBpZiAoc3RhdGUgPT09IFNUQUxFKSB7XG4gICAgICAgIGlmIChzb3VyY2UgIT09IGlnbm9yZSAmJiAoIXNvdXJjZS51cGRhdGVkQXQgfHwgc291cmNlLnVwZGF0ZWRBdCA8IEV4ZWNDb3VudCkpIHJ1blRvcChzb3VyY2UpO1xuICAgICAgfSBlbHNlIGlmIChzdGF0ZSA9PT0gUEVORElORykgbG9va1Vwc3RyZWFtKHNvdXJjZSwgaWdub3JlKTtcbiAgICB9XG4gIH1cbn1cbmZ1bmN0aW9uIG1hcmtEb3duc3RyZWFtKG5vZGUpIHtcbiAgY29uc3QgcnVubmluZ1RyYW5zaXRpb24gPSBUcmFuc2l0aW9uICYmIFRyYW5zaXRpb24ucnVubmluZztcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBub2RlLm9ic2VydmVycy5sZW5ndGg7IGkgKz0gMSkge1xuICAgIGNvbnN0IG8gPSBub2RlLm9ic2VydmVyc1tpXTtcbiAgICBpZiAocnVubmluZ1RyYW5zaXRpb24gPyAhby50U3RhdGUgOiAhby5zdGF0ZSkge1xuICAgICAgaWYgKHJ1bm5pbmdUcmFuc2l0aW9uKSBvLnRTdGF0ZSA9IFBFTkRJTkc7ZWxzZSBvLnN0YXRlID0gUEVORElORztcbiAgICAgIGlmIChvLnB1cmUpIFVwZGF0ZXMucHVzaChvKTtlbHNlIEVmZmVjdHMucHVzaChvKTtcbiAgICAgIG8ub2JzZXJ2ZXJzICYmIG1hcmtEb3duc3RyZWFtKG8pO1xuICAgIH1cbiAgfVxufVxuZnVuY3Rpb24gY2xlYW5Ob2RlKG5vZGUpIHtcbiAgbGV0IGk7XG4gIGlmIChub2RlLnNvdXJjZXMpIHtcbiAgICB3aGlsZSAobm9kZS5zb3VyY2VzLmxlbmd0aCkge1xuICAgICAgY29uc3Qgc291cmNlID0gbm9kZS5zb3VyY2VzLnBvcCgpLFxuICAgICAgICBpbmRleCA9IG5vZGUuc291cmNlU2xvdHMucG9wKCksXG4gICAgICAgIG9icyA9IHNvdXJjZS5vYnNlcnZlcnM7XG4gICAgICBpZiAob2JzICYmIG9icy5sZW5ndGgpIHtcbiAgICAgICAgY29uc3QgbiA9IG9icy5wb3AoKSxcbiAgICAgICAgICBzID0gc291cmNlLm9ic2VydmVyU2xvdHMucG9wKCk7XG4gICAgICAgIGlmIChpbmRleCA8IG9icy5sZW5ndGgpIHtcbiAgICAgICAgICBuLnNvdXJjZVNsb3RzW3NdID0gaW5kZXg7XG4gICAgICAgICAgb2JzW2luZGV4XSA9IG47XG4gICAgICAgICAgc291cmNlLm9ic2VydmVyU2xvdHNbaW5kZXhdID0gcztcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfVxuICBpZiAobm9kZS50T3duZWQpIHtcbiAgICBmb3IgKGkgPSBub2RlLnRPd25lZC5sZW5ndGggLSAxOyBpID49IDA7IGktLSkgY2xlYW5Ob2RlKG5vZGUudE93bmVkW2ldKTtcbiAgICBkZWxldGUgbm9kZS50T3duZWQ7XG4gIH1cbiAgaWYgKFRyYW5zaXRpb24gJiYgVHJhbnNpdGlvbi5ydW5uaW5nICYmIG5vZGUucHVyZSkge1xuICAgIHJlc2V0KG5vZGUsIHRydWUpO1xuICB9IGVsc2UgaWYgKG5vZGUub3duZWQpIHtcbiAgICBmb3IgKGkgPSBub2RlLm93bmVkLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSBjbGVhbk5vZGUobm9kZS5vd25lZFtpXSk7XG4gICAgbm9kZS5vd25lZCA9IG51bGw7XG4gIH1cbiAgaWYgKG5vZGUuY2xlYW51cHMpIHtcbiAgICBmb3IgKGkgPSBub2RlLmNsZWFudXBzLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSBub2RlLmNsZWFudXBzW2ldKCk7XG4gICAgbm9kZS5jbGVhbnVwcyA9IG51bGw7XG4gIH1cbiAgaWYgKFRyYW5zaXRpb24gJiYgVHJhbnNpdGlvbi5ydW5uaW5nKSBub2RlLnRTdGF0ZSA9IDA7ZWxzZSBub2RlLnN0YXRlID0gMDtcbn1cbmZ1bmN0aW9uIHJlc2V0KG5vZGUsIHRvcCkge1xuICBpZiAoIXRvcCkge1xuICAgIG5vZGUudFN0YXRlID0gMDtcbiAgICBUcmFuc2l0aW9uLmRpc3Bvc2VkLmFkZChub2RlKTtcbiAgfVxuICBpZiAobm9kZS5vd25lZCkge1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbm9kZS5vd25lZC5sZW5ndGg7IGkrKykgcmVzZXQobm9kZS5vd25lZFtpXSk7XG4gIH1cbn1cbmZ1bmN0aW9uIGNhc3RFcnJvcihlcnIpIHtcbiAgaWYgKGVyciBpbnN0YW5jZW9mIEVycm9yKSByZXR1cm4gZXJyO1xuICByZXR1cm4gbmV3IEVycm9yKHR5cGVvZiBlcnIgPT09IFwic3RyaW5nXCIgPyBlcnIgOiBcIlVua25vd24gZXJyb3JcIiwge1xuICAgIGNhdXNlOiBlcnJcbiAgfSk7XG59XG5mdW5jdGlvbiBydW5FcnJvcnMoZXJyLCBmbnMsIG93bmVyKSB7XG4gIHRyeSB7XG4gICAgZm9yIChjb25zdCBmIG9mIGZucykgZihlcnIpO1xuICB9IGNhdGNoIChlKSB7XG4gICAgaGFuZGxlRXJyb3IoZSwgb3duZXIgJiYgb3duZXIub3duZXIgfHwgbnVsbCk7XG4gIH1cbn1cbmZ1bmN0aW9uIGhhbmRsZUVycm9yKGVyciwgb3duZXIgPSBPd25lcikge1xuICBjb25zdCBmbnMgPSBFUlJPUiAmJiBvd25lciAmJiBvd25lci5jb250ZXh0ICYmIG93bmVyLmNvbnRleHRbRVJST1JdO1xuICBjb25zdCBlcnJvciA9IGNhc3RFcnJvcihlcnIpO1xuICBpZiAoIWZucykgdGhyb3cgZXJyb3I7XG4gIGlmIChFZmZlY3RzKSBFZmZlY3RzLnB1c2goe1xuICAgIGZuKCkge1xuICAgICAgcnVuRXJyb3JzKGVycm9yLCBmbnMsIG93bmVyKTtcbiAgICB9LFxuICAgIHN0YXRlOiBTVEFMRVxuICB9KTtlbHNlIHJ1bkVycm9ycyhlcnJvciwgZm5zLCBvd25lcik7XG59XG5mdW5jdGlvbiByZXNvbHZlQ2hpbGRyZW4oY2hpbGRyZW4pIHtcbiAgaWYgKHR5cGVvZiBjaGlsZHJlbiA9PT0gXCJmdW5jdGlvblwiICYmICFjaGlsZHJlbi5sZW5ndGgpIHJldHVybiByZXNvbHZlQ2hpbGRyZW4oY2hpbGRyZW4oKSk7XG4gIGlmIChBcnJheS5pc0FycmF5KGNoaWxkcmVuKSkge1xuICAgIGNvbnN0IHJlc3VsdHMgPSBbXTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGNoaWxkcmVuLmxlbmd0aDsgaSsrKSB7XG4gICAgICBjb25zdCByZXN1bHQgPSByZXNvbHZlQ2hpbGRyZW4oY2hpbGRyZW5baV0pO1xuICAgICAgaWYgKEFycmF5LmlzQXJyYXkocmVzdWx0KSkge1xuICAgICAgICBpZiAocmVzdWx0Lmxlbmd0aCA8IDMyNzY4KSByZXN1bHRzLnB1c2guYXBwbHkocmVzdWx0cywgcmVzdWx0KTtlbHNlIGZvciAobGV0IGogPSAwOyBqIDwgcmVzdWx0Lmxlbmd0aDsgaisrKSByZXN1bHRzLnB1c2gocmVzdWx0W2pdKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJlc3VsdHMucHVzaChyZXN1bHQpO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0cztcbiAgfVxuICByZXR1cm4gY2hpbGRyZW47XG59XG5mdW5jdGlvbiBjcmVhdGVQcm92aWRlcihpZCwgb3B0aW9ucykge1xuICByZXR1cm4gZnVuY3Rpb24gcHJvdmlkZXIocHJvcHMpIHtcbiAgICBsZXQgcmVzO1xuICAgIGNyZWF0ZVJlbmRlckVmZmVjdCgoKSA9PiByZXMgPSB1bnRyYWNrKCgpID0+IHtcbiAgICAgIE93bmVyLmNvbnRleHQgPSB7XG4gICAgICAgIC4uLk93bmVyLmNvbnRleHQsXG4gICAgICAgIFtpZF06IHByb3BzLnZhbHVlXG4gICAgICB9O1xuICAgICAgcmV0dXJuIGNoaWxkcmVuKCgpID0+IHByb3BzLmNoaWxkcmVuKTtcbiAgICB9KSwgdW5kZWZpbmVkKTtcbiAgICByZXR1cm4gcmVzO1xuICB9O1xufVxuZnVuY3Rpb24gb25FcnJvcihmbikge1xuICBFUlJPUiB8fCAoRVJST1IgPSBTeW1ib2woXCJlcnJvclwiKSk7XG4gIGlmIChPd25lciA9PT0gbnVsbCkgO2Vsc2UgaWYgKE93bmVyLmNvbnRleHQgPT09IG51bGwgfHwgIU93bmVyLmNvbnRleHRbRVJST1JdKSB7XG4gICAgT3duZXIuY29udGV4dCA9IHtcbiAgICAgIC4uLk93bmVyLmNvbnRleHQsXG4gICAgICBbRVJST1JdOiBbZm5dXG4gICAgfTtcbiAgICBtdXRhdGVDb250ZXh0KE93bmVyLCBFUlJPUiwgW2ZuXSk7XG4gIH0gZWxzZSBPd25lci5jb250ZXh0W0VSUk9SXS5wdXNoKGZuKTtcbn1cbmZ1bmN0aW9uIG11dGF0ZUNvbnRleHQobywga2V5LCB2YWx1ZSkge1xuICBpZiAoby5vd25lZCkge1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgby5vd25lZC5sZW5ndGg7IGkrKykge1xuICAgICAgaWYgKG8ub3duZWRbaV0uY29udGV4dCA9PT0gby5jb250ZXh0KSBtdXRhdGVDb250ZXh0KG8ub3duZWRbaV0sIGtleSwgdmFsdWUpO1xuICAgICAgaWYgKCFvLm93bmVkW2ldLmNvbnRleHQpIHtcbiAgICAgICAgby5vd25lZFtpXS5jb250ZXh0ID0gby5jb250ZXh0O1xuICAgICAgICBtdXRhdGVDb250ZXh0KG8ub3duZWRbaV0sIGtleSwgdmFsdWUpO1xuICAgICAgfSBlbHNlIGlmICghby5vd25lZFtpXS5jb250ZXh0W2tleV0pIHtcbiAgICAgICAgby5vd25lZFtpXS5jb250ZXh0W2tleV0gPSB2YWx1ZTtcbiAgICAgICAgbXV0YXRlQ29udGV4dChvLm93bmVkW2ldLCBrZXksIHZhbHVlKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cblxuZnVuY3Rpb24gb2JzZXJ2YWJsZShpbnB1dCkge1xuICByZXR1cm4ge1xuICAgIHN1YnNjcmliZShvYnNlcnZlcikge1xuICAgICAgaWYgKCEob2JzZXJ2ZXIgaW5zdGFuY2VvZiBPYmplY3QpIHx8IG9ic2VydmVyID09IG51bGwpIHtcbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkV4cGVjdGVkIHRoZSBvYnNlcnZlciB0byBiZSBhbiBvYmplY3QuXCIpO1xuICAgICAgfVxuICAgICAgY29uc3QgaGFuZGxlciA9IHR5cGVvZiBvYnNlcnZlciA9PT0gXCJmdW5jdGlvblwiID8gb2JzZXJ2ZXIgOiBvYnNlcnZlci5uZXh0ICYmIG9ic2VydmVyLm5leHQuYmluZChvYnNlcnZlcik7XG4gICAgICBpZiAoIWhhbmRsZXIpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICB1bnN1YnNjcmliZSgpIHt9XG4gICAgICAgIH07XG4gICAgICB9XG4gICAgICBjb25zdCBkaXNwb3NlID0gY3JlYXRlUm9vdChkaXNwb3NlciA9PiB7XG4gICAgICAgIGNyZWF0ZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgICAgY29uc3QgdiA9IGlucHV0KCk7XG4gICAgICAgICAgdW50cmFjaygoKSA9PiBoYW5kbGVyKHYpKTtcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiBkaXNwb3NlcjtcbiAgICAgIH0pO1xuICAgICAgaWYgKGdldE93bmVyKCkpIG9uQ2xlYW51cChkaXNwb3NlKTtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHVuc3Vic2NyaWJlKCkge1xuICAgICAgICAgIGRpc3Bvc2UoKTtcbiAgICAgICAgfVxuICAgICAgfTtcbiAgICB9LFxuICAgIFtTeW1ib2wub2JzZXJ2YWJsZSB8fCBcIkBAb2JzZXJ2YWJsZVwiXSgpIHtcbiAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgfTtcbn1cbmZ1bmN0aW9uIGZyb20ocHJvZHVjZXIsIGluaXRhbFZhbHVlID0gdW5kZWZpbmVkKSB7XG4gIGNvbnN0IFtzLCBzZXRdID0gY3JlYXRlU2lnbmFsKGluaXRhbFZhbHVlLCB7XG4gICAgZXF1YWxzOiBmYWxzZVxuICB9KTtcbiAgaWYgKFwic3Vic2NyaWJlXCIgaW4gcHJvZHVjZXIpIHtcbiAgICBjb25zdCB1bnN1YiA9IHByb2R1Y2VyLnN1YnNjcmliZSh2ID0+IHNldCgoKSA9PiB2KSk7XG4gICAgb25DbGVhbnVwKCgpID0+IFwidW5zdWJzY3JpYmVcIiBpbiB1bnN1YiA/IHVuc3ViLnVuc3Vic2NyaWJlKCkgOiB1bnN1YigpKTtcbiAgfSBlbHNlIHtcbiAgICBjb25zdCBjbGVhbiA9IHByb2R1Y2VyKHNldCk7XG4gICAgb25DbGVhbnVwKGNsZWFuKTtcbiAgfVxuICByZXR1cm4gcztcbn1cblxuY29uc3QgRkFMTEJBQ0sgPSBTeW1ib2woXCJmYWxsYmFja1wiKTtcbmZ1bmN0aW9uIGRpc3Bvc2UoZCkge1xuICBmb3IgKGxldCBpID0gMDsgaSA8IGQubGVuZ3RoOyBpKyspIGRbaV0oKTtcbn1cbmZ1bmN0aW9uIG1hcEFycmF5KGxpc3QsIG1hcEZuLCBvcHRpb25zID0ge30pIHtcbiAgbGV0IGl0ZW1zID0gW10sXG4gICAgbWFwcGVkID0gW10sXG4gICAgZGlzcG9zZXJzID0gW10sXG4gICAgbGVuID0gMCxcbiAgICBpbmRleGVzID0gbWFwRm4ubGVuZ3RoID4gMSA/IFtdIDogbnVsbDtcbiAgb25DbGVhbnVwKCgpID0+IGRpc3Bvc2UoZGlzcG9zZXJzKSk7XG4gIHJldHVybiAoKSA9PiB7XG4gICAgbGV0IG5ld0l0ZW1zID0gbGlzdCgpIHx8IFtdLFxuICAgICAgbmV3TGVuID0gbmV3SXRlbXMubGVuZ3RoLFxuICAgICAgaSxcbiAgICAgIGo7XG4gICAgbmV3SXRlbXNbJFRSQUNLXTtcbiAgICByZXR1cm4gdW50cmFjaygoKSA9PiB7XG4gICAgICBsZXQgbmV3SW5kaWNlcywgbmV3SW5kaWNlc05leHQsIHRlbXAsIHRlbXBkaXNwb3NlcnMsIHRlbXBJbmRleGVzLCBzdGFydCwgZW5kLCBuZXdFbmQsIGl0ZW07XG4gICAgICBpZiAobmV3TGVuID09PSAwKSB7XG4gICAgICAgIGlmIChsZW4gIT09IDApIHtcbiAgICAgICAgICBkaXNwb3NlKGRpc3Bvc2Vycyk7XG4gICAgICAgICAgZGlzcG9zZXJzID0gW107XG4gICAgICAgICAgaXRlbXMgPSBbXTtcbiAgICAgICAgICBtYXBwZWQgPSBbXTtcbiAgICAgICAgICBsZW4gPSAwO1xuICAgICAgICAgIGluZGV4ZXMgJiYgKGluZGV4ZXMgPSBbXSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKG9wdGlvbnMuZmFsbGJhY2spIHtcbiAgICAgICAgICBpdGVtcyA9IFtGQUxMQkFDS107XG4gICAgICAgICAgbWFwcGVkWzBdID0gY3JlYXRlUm9vdChkaXNwb3NlciA9PiB7XG4gICAgICAgICAgICBkaXNwb3NlcnNbMF0gPSBkaXNwb3NlcjtcbiAgICAgICAgICAgIHJldHVybiBvcHRpb25zLmZhbGxiYWNrKCk7XG4gICAgICAgICAgfSk7XG4gICAgICAgICAgbGVuID0gMTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgZWxzZSBpZiAobGVuID09PSAwKSB7XG4gICAgICAgIG1hcHBlZCA9IG5ldyBBcnJheShuZXdMZW4pO1xuICAgICAgICBmb3IgKGogPSAwOyBqIDwgbmV3TGVuOyBqKyspIHtcbiAgICAgICAgICBpdGVtc1tqXSA9IG5ld0l0ZW1zW2pdO1xuICAgICAgICAgIG1hcHBlZFtqXSA9IGNyZWF0ZVJvb3QobWFwcGVyKTtcbiAgICAgICAgfVxuICAgICAgICBsZW4gPSBuZXdMZW47XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0ZW1wID0gbmV3IEFycmF5KG5ld0xlbik7XG4gICAgICAgIHRlbXBkaXNwb3NlcnMgPSBuZXcgQXJyYXkobmV3TGVuKTtcbiAgICAgICAgaW5kZXhlcyAmJiAodGVtcEluZGV4ZXMgPSBuZXcgQXJyYXkobmV3TGVuKSk7XG4gICAgICAgIGZvciAoc3RhcnQgPSAwLCBlbmQgPSBNYXRoLm1pbihsZW4sIG5ld0xlbik7IHN0YXJ0IDwgZW5kICYmIGl0ZW1zW3N0YXJ0XSA9PT0gbmV3SXRlbXNbc3RhcnRdOyBzdGFydCsrKTtcbiAgICAgICAgZm9yIChlbmQgPSBsZW4gLSAxLCBuZXdFbmQgPSBuZXdMZW4gLSAxOyBlbmQgPj0gc3RhcnQgJiYgbmV3RW5kID49IHN0YXJ0ICYmIGl0ZW1zW2VuZF0gPT09IG5ld0l0ZW1zW25ld0VuZF07IGVuZC0tLCBuZXdFbmQtLSkge1xuICAgICAgICAgIHRlbXBbbmV3RW5kXSA9IG1hcHBlZFtlbmRdO1xuICAgICAgICAgIHRlbXBkaXNwb3NlcnNbbmV3RW5kXSA9IGRpc3Bvc2Vyc1tlbmRdO1xuICAgICAgICAgIGluZGV4ZXMgJiYgKHRlbXBJbmRleGVzW25ld0VuZF0gPSBpbmRleGVzW2VuZF0pO1xuICAgICAgICB9XG4gICAgICAgIG5ld0luZGljZXMgPSBuZXcgTWFwKCk7XG4gICAgICAgIG5ld0luZGljZXNOZXh0ID0gbmV3IEFycmF5KG5ld0VuZCArIDEpO1xuICAgICAgICBmb3IgKGogPSBuZXdFbmQ7IGogPj0gc3RhcnQ7IGotLSkge1xuICAgICAgICAgIGl0ZW0gPSBuZXdJdGVtc1tqXTtcbiAgICAgICAgICBpID0gbmV3SW5kaWNlcy5nZXQoaXRlbSk7XG4gICAgICAgICAgbmV3SW5kaWNlc05leHRbal0gPSBpID09PSB1bmRlZmluZWQgPyAtMSA6IGk7XG4gICAgICAgICAgbmV3SW5kaWNlcy5zZXQoaXRlbSwgaik7XG4gICAgICAgIH1cbiAgICAgICAgZm9yIChpID0gc3RhcnQ7IGkgPD0gZW5kOyBpKyspIHtcbiAgICAgICAgICBpdGVtID0gaXRlbXNbaV07XG4gICAgICAgICAgaiA9IG5ld0luZGljZXMuZ2V0KGl0ZW0pO1xuICAgICAgICAgIGlmIChqICE9PSB1bmRlZmluZWQgJiYgaiAhPT0gLTEpIHtcbiAgICAgICAgICAgIHRlbXBbal0gPSBtYXBwZWRbaV07XG4gICAgICAgICAgICB0ZW1wZGlzcG9zZXJzW2pdID0gZGlzcG9zZXJzW2ldO1xuICAgICAgICAgICAgaW5kZXhlcyAmJiAodGVtcEluZGV4ZXNbal0gPSBpbmRleGVzW2ldKTtcbiAgICAgICAgICAgIGogPSBuZXdJbmRpY2VzTmV4dFtqXTtcbiAgICAgICAgICAgIG5ld0luZGljZXMuc2V0KGl0ZW0sIGopO1xuICAgICAgICAgIH0gZWxzZSBkaXNwb3NlcnNbaV0oKTtcbiAgICAgICAgfVxuICAgICAgICBmb3IgKGogPSBzdGFydDsgaiA8IG5ld0xlbjsgaisrKSB7XG4gICAgICAgICAgaWYgKGogaW4gdGVtcCkge1xuICAgICAgICAgICAgbWFwcGVkW2pdID0gdGVtcFtqXTtcbiAgICAgICAgICAgIGRpc3Bvc2Vyc1tqXSA9IHRlbXBkaXNwb3NlcnNbal07XG4gICAgICAgICAgICBpZiAoaW5kZXhlcykge1xuICAgICAgICAgICAgICBpbmRleGVzW2pdID0gdGVtcEluZGV4ZXNbal07XG4gICAgICAgICAgICAgIGluZGV4ZXNbal0oaik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSBlbHNlIG1hcHBlZFtqXSA9IGNyZWF0ZVJvb3QobWFwcGVyKTtcbiAgICAgICAgfVxuICAgICAgICBtYXBwZWQgPSBtYXBwZWQuc2xpY2UoMCwgbGVuID0gbmV3TGVuKTtcbiAgICAgICAgaXRlbXMgPSBuZXdJdGVtcy5zbGljZSgwKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBtYXBwZWQ7XG4gICAgfSk7XG4gICAgZnVuY3Rpb24gbWFwcGVyKGRpc3Bvc2VyKSB7XG4gICAgICBkaXNwb3NlcnNbal0gPSBkaXNwb3NlcjtcbiAgICAgIGlmIChpbmRleGVzKSB7XG4gICAgICAgIGNvbnN0IFtzLCBzZXRdID0gY3JlYXRlU2lnbmFsKGopO1xuICAgICAgICBpbmRleGVzW2pdID0gc2V0O1xuICAgICAgICByZXR1cm4gbWFwRm4obmV3SXRlbXNbal0sIHMpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIG1hcEZuKG5ld0l0ZW1zW2pdKTtcbiAgICB9XG4gIH07XG59XG5mdW5jdGlvbiBpbmRleEFycmF5KGxpc3QsIG1hcEZuLCBvcHRpb25zID0ge30pIHtcbiAgbGV0IGl0ZW1zID0gW10sXG4gICAgbWFwcGVkID0gW10sXG4gICAgZGlzcG9zZXJzID0gW10sXG4gICAgc2lnbmFscyA9IFtdLFxuICAgIGxlbiA9IDAsXG4gICAgaTtcbiAgb25DbGVhbnVwKCgpID0+IGRpc3Bvc2UoZGlzcG9zZXJzKSk7XG4gIHJldHVybiAoKSA9PiB7XG4gICAgY29uc3QgbmV3SXRlbXMgPSBsaXN0KCkgfHwgW10sXG4gICAgICBuZXdMZW4gPSBuZXdJdGVtcy5sZW5ndGg7XG4gICAgbmV3SXRlbXNbJFRSQUNLXTtcbiAgICByZXR1cm4gdW50cmFjaygoKSA9PiB7XG4gICAgICBpZiAobmV3TGVuID09PSAwKSB7XG4gICAgICAgIGlmIChsZW4gIT09IDApIHtcbiAgICAgICAgICBkaXNwb3NlKGRpc3Bvc2Vycyk7XG4gICAgICAgICAgZGlzcG9zZXJzID0gW107XG4gICAgICAgICAgaXRlbXMgPSBbXTtcbiAgICAgICAgICBtYXBwZWQgPSBbXTtcbiAgICAgICAgICBsZW4gPSAwO1xuICAgICAgICAgIHNpZ25hbHMgPSBbXTtcbiAgICAgICAgfVxuICAgICAgICBpZiAob3B0aW9ucy5mYWxsYmFjaykge1xuICAgICAgICAgIGl0ZW1zID0gW0ZBTExCQUNLXTtcbiAgICAgICAgICBtYXBwZWRbMF0gPSBjcmVhdGVSb290KGRpc3Bvc2VyID0+IHtcbiAgICAgICAgICAgIGRpc3Bvc2Vyc1swXSA9IGRpc3Bvc2VyO1xuICAgICAgICAgICAgcmV0dXJuIG9wdGlvbnMuZmFsbGJhY2soKTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBsZW4gPSAxO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBtYXBwZWQ7XG4gICAgICB9XG4gICAgICBpZiAoaXRlbXNbMF0gPT09IEZBTExCQUNLKSB7XG4gICAgICAgIGRpc3Bvc2Vyc1swXSgpO1xuICAgICAgICBkaXNwb3NlcnMgPSBbXTtcbiAgICAgICAgaXRlbXMgPSBbXTtcbiAgICAgICAgbWFwcGVkID0gW107XG4gICAgICAgIGxlbiA9IDA7XG4gICAgICB9XG4gICAgICBmb3IgKGkgPSAwOyBpIDwgbmV3TGVuOyBpKyspIHtcbiAgICAgICAgaWYgKGkgPCBpdGVtcy5sZW5ndGggJiYgaXRlbXNbaV0gIT09IG5ld0l0ZW1zW2ldKSB7XG4gICAgICAgICAgc2lnbmFsc1tpXSgoKSA9PiBuZXdJdGVtc1tpXSk7XG4gICAgICAgIH0gZWxzZSBpZiAoaSA+PSBpdGVtcy5sZW5ndGgpIHtcbiAgICAgICAgICBtYXBwZWRbaV0gPSBjcmVhdGVSb290KG1hcHBlcik7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGZvciAoOyBpIDwgaXRlbXMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgZGlzcG9zZXJzW2ldKCk7XG4gICAgICB9XG4gICAgICBsZW4gPSBzaWduYWxzLmxlbmd0aCA9IGRpc3Bvc2Vycy5sZW5ndGggPSBuZXdMZW47XG4gICAgICBpdGVtcyA9IG5ld0l0ZW1zLnNsaWNlKDApO1xuICAgICAgcmV0dXJuIG1hcHBlZCA9IG1hcHBlZC5zbGljZSgwLCBsZW4pO1xuICAgIH0pO1xuICAgIGZ1bmN0aW9uIG1hcHBlcihkaXNwb3Nlcikge1xuICAgICAgZGlzcG9zZXJzW2ldID0gZGlzcG9zZXI7XG4gICAgICBjb25zdCBbcywgc2V0XSA9IGNyZWF0ZVNpZ25hbChuZXdJdGVtc1tpXSk7XG4gICAgICBzaWduYWxzW2ldID0gc2V0O1xuICAgICAgcmV0dXJuIG1hcEZuKHMsIGkpO1xuICAgIH1cbiAgfTtcbn1cblxubGV0IGh5ZHJhdGlvbkVuYWJsZWQgPSBmYWxzZTtcbmZ1bmN0aW9uIGVuYWJsZUh5ZHJhdGlvbigpIHtcbiAgaHlkcmF0aW9uRW5hYmxlZCA9IHRydWU7XG59XG5mdW5jdGlvbiBjcmVhdGVDb21wb25lbnQoQ29tcCwgcHJvcHMpIHtcbiAgaWYgKGh5ZHJhdGlvbkVuYWJsZWQpIHtcbiAgICBpZiAoc2hhcmVkQ29uZmlnLmNvbnRleHQpIHtcbiAgICAgIGNvbnN0IGMgPSBzaGFyZWRDb25maWcuY29udGV4dDtcbiAgICAgIHNldEh5ZHJhdGVDb250ZXh0KG5leHRIeWRyYXRlQ29udGV4dCgpKTtcbiAgICAgIGNvbnN0IHIgPSB1bnRyYWNrKCgpID0+IENvbXAocHJvcHMgfHwge30pKTtcbiAgICAgIHNldEh5ZHJhdGVDb250ZXh0KGMpO1xuICAgICAgcmV0dXJuIHI7XG4gICAgfVxuICB9XG4gIHJldHVybiB1bnRyYWNrKCgpID0+IENvbXAocHJvcHMgfHwge30pKTtcbn1cbmZ1bmN0aW9uIHRydWVGbigpIHtcbiAgcmV0dXJuIHRydWU7XG59XG5jb25zdCBwcm9wVHJhcHMgPSB7XG4gIGdldChfLCBwcm9wZXJ0eSwgcmVjZWl2ZXIpIHtcbiAgICBpZiAocHJvcGVydHkgPT09ICRQUk9YWSkgcmV0dXJuIHJlY2VpdmVyO1xuICAgIHJldHVybiBfLmdldChwcm9wZXJ0eSk7XG4gIH0sXG4gIGhhcyhfLCBwcm9wZXJ0eSkge1xuICAgIGlmIChwcm9wZXJ0eSA9PT0gJFBST1hZKSByZXR1cm4gdHJ1ZTtcbiAgICByZXR1cm4gXy5oYXMocHJvcGVydHkpO1xuICB9LFxuICBzZXQ6IHRydWVGbixcbiAgZGVsZXRlUHJvcGVydHk6IHRydWVGbixcbiAgZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKF8sIHByb3BlcnR5KSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBnZXQoKSB7XG4gICAgICAgIHJldHVybiBfLmdldChwcm9wZXJ0eSk7XG4gICAgICB9LFxuICAgICAgc2V0OiB0cnVlRm4sXG4gICAgICBkZWxldGVQcm9wZXJ0eTogdHJ1ZUZuXG4gICAgfTtcbiAgfSxcbiAgb3duS2V5cyhfKSB7XG4gICAgcmV0dXJuIF8ua2V5cygpO1xuICB9XG59O1xuZnVuY3Rpb24gcmVzb2x2ZVNvdXJjZShzKSB7XG4gIHJldHVybiAhKHMgPSB0eXBlb2YgcyA9PT0gXCJmdW5jdGlvblwiID8gcygpIDogcykgPyB7fSA6IHM7XG59XG5mdW5jdGlvbiByZXNvbHZlU291cmNlcygpIHtcbiAgZm9yIChsZXQgaSA9IDAsIGxlbmd0aCA9IHRoaXMubGVuZ3RoOyBpIDwgbGVuZ3RoOyArK2kpIHtcbiAgICBjb25zdCB2ID0gdGhpc1tpXSgpO1xuICAgIGlmICh2ICE9PSB1bmRlZmluZWQpIHJldHVybiB2O1xuICB9XG59XG5mdW5jdGlvbiBtZXJnZVByb3BzKC4uLnNvdXJjZXMpIHtcbiAgbGV0IHByb3h5ID0gZmFsc2U7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgc291cmNlcy5sZW5ndGg7IGkrKykge1xuICAgIGNvbnN0IHMgPSBzb3VyY2VzW2ldO1xuICAgIHByb3h5ID0gcHJveHkgfHwgISFzICYmICRQUk9YWSBpbiBzO1xuICAgIHNvdXJjZXNbaV0gPSB0eXBlb2YgcyA9PT0gXCJmdW5jdGlvblwiID8gKHByb3h5ID0gdHJ1ZSwgY3JlYXRlTWVtbyhzKSkgOiBzO1xuICB9XG4gIGlmIChTVVBQT1JUU19QUk9YWSAmJiBwcm94eSkge1xuICAgIHJldHVybiBuZXcgUHJveHkoe1xuICAgICAgZ2V0KHByb3BlcnR5KSB7XG4gICAgICAgIGZvciAobGV0IGkgPSBzb3VyY2VzLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG4gICAgICAgICAgY29uc3QgdiA9IHJlc29sdmVTb3VyY2Uoc291cmNlc1tpXSlbcHJvcGVydHldO1xuICAgICAgICAgIGlmICh2ICE9PSB1bmRlZmluZWQpIHJldHVybiB2O1xuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgaGFzKHByb3BlcnR5KSB7XG4gICAgICAgIGZvciAobGV0IGkgPSBzb3VyY2VzLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG4gICAgICAgICAgaWYgKHByb3BlcnR5IGluIHJlc29sdmVTb3VyY2Uoc291cmNlc1tpXSkpIHJldHVybiB0cnVlO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH0sXG4gICAgICBrZXlzKCkge1xuICAgICAgICBjb25zdCBrZXlzID0gW107XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgc291cmNlcy5sZW5ndGg7IGkrKykga2V5cy5wdXNoKC4uLk9iamVjdC5rZXlzKHJlc29sdmVTb3VyY2Uoc291cmNlc1tpXSkpKTtcbiAgICAgICAgcmV0dXJuIFsuLi5uZXcgU2V0KGtleXMpXTtcbiAgICAgIH1cbiAgICB9LCBwcm9wVHJhcHMpO1xuICB9XG4gIGNvbnN0IHNvdXJjZXNNYXAgPSB7fTtcbiAgY29uc3QgZGVmaW5lZCA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gIGZvciAobGV0IGkgPSBzb3VyY2VzLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG4gICAgY29uc3Qgc291cmNlID0gc291cmNlc1tpXTtcbiAgICBpZiAoIXNvdXJjZSkgY29udGludWU7XG4gICAgY29uc3Qgc291cmNlS2V5cyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzKHNvdXJjZSk7XG4gICAgZm9yIChsZXQgaSA9IHNvdXJjZUtleXMubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIHtcbiAgICAgIGNvbnN0IGtleSA9IHNvdXJjZUtleXNbaV07XG4gICAgICBpZiAoa2V5ID09PSBcIl9fcHJvdG9fX1wiIHx8IGtleSA9PT0gXCJjb25zdHJ1Y3RvclwiKSBjb250aW51ZTtcbiAgICAgIGNvbnN0IGRlc2MgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHNvdXJjZSwga2V5KTtcbiAgICAgIGlmICghZGVmaW5lZFtrZXldKSB7XG4gICAgICAgIGRlZmluZWRba2V5XSA9IGRlc2MuZ2V0ID8ge1xuICAgICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgICAgICAgIGdldDogcmVzb2x2ZVNvdXJjZXMuYmluZChzb3VyY2VzTWFwW2tleV0gPSBbZGVzYy5nZXQuYmluZChzb3VyY2UpXSlcbiAgICAgICAgfSA6IGRlc2MudmFsdWUgIT09IHVuZGVmaW5lZCA/IGRlc2MgOiB1bmRlZmluZWQ7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zdCBzb3VyY2VzID0gc291cmNlc01hcFtrZXldO1xuICAgICAgICBpZiAoc291cmNlcykge1xuICAgICAgICAgIGlmIChkZXNjLmdldCkgc291cmNlcy5wdXNoKGRlc2MuZ2V0LmJpbmQoc291cmNlKSk7ZWxzZSBpZiAoZGVzYy52YWx1ZSAhPT0gdW5kZWZpbmVkKSBzb3VyY2VzLnB1c2goKCkgPT4gZGVzYy52YWx1ZSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgY29uc3QgdGFyZ2V0ID0ge307XG4gIGNvbnN0IGRlZmluZWRLZXlzID0gT2JqZWN0LmtleXMoZGVmaW5lZCk7XG4gIGZvciAobGV0IGkgPSBkZWZpbmVkS2V5cy5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuICAgIGNvbnN0IGtleSA9IGRlZmluZWRLZXlzW2ldLFxuICAgICAgZGVzYyA9IGRlZmluZWRba2V5XTtcbiAgICBpZiAoZGVzYyAmJiBkZXNjLmdldCkgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRhcmdldCwga2V5LCBkZXNjKTtlbHNlIHRhcmdldFtrZXldID0gZGVzYyA/IGRlc2MudmFsdWUgOiB1bmRlZmluZWQ7XG4gIH1cbiAgcmV0dXJuIHRhcmdldDtcbn1cbmZ1bmN0aW9uIHNwbGl0UHJvcHMocHJvcHMsIC4uLmtleXMpIHtcbiAgY29uc3QgbGVuID0ga2V5cy5sZW5ndGg7XG4gIGlmIChTVVBQT1JUU19QUk9YWSAmJiAkUFJPWFkgaW4gcHJvcHMpIHtcbiAgICBjb25zdCBibG9ja2VkID0gbGVuID4gMSA/IGtleXMuZmxhdCgpIDoga2V5c1swXTtcbiAgICBjb25zdCBjbGFpbWVkID0gbmV3IFNldCgpO1xuICAgIGNvbnN0IHJlcyA9IGtleXMubWFwKGsgPT4ge1xuICAgICAgY29uc3Qgb3duZWQgPSBrLmZpbHRlcihwcm9wZXJ0eSA9PiAhY2xhaW1lZC5oYXMocHJvcGVydHkpICYmIChjbGFpbWVkLmFkZChwcm9wZXJ0eSksIHRydWUpKTtcbiAgICAgIHJldHVybiBuZXcgUHJveHkoe1xuICAgICAgICBnZXQocHJvcGVydHkpIHtcbiAgICAgICAgICByZXR1cm4gb3duZWQuaW5jbHVkZXMocHJvcGVydHkpID8gcHJvcHNbcHJvcGVydHldIDogdW5kZWZpbmVkO1xuICAgICAgICB9LFxuICAgICAgICBoYXMocHJvcGVydHkpIHtcbiAgICAgICAgICByZXR1cm4gb3duZWQuaW5jbHVkZXMocHJvcGVydHkpICYmIHByb3BlcnR5IGluIHByb3BzO1xuICAgICAgICB9LFxuICAgICAgICBrZXlzKCkge1xuICAgICAgICAgIHJldHVybiBvd25lZC5maWx0ZXIocHJvcGVydHkgPT4gcHJvcGVydHkgaW4gcHJvcHMpO1xuICAgICAgICB9XG4gICAgICB9LCBwcm9wVHJhcHMpO1xuICAgIH0pO1xuICAgIHJlcy5wdXNoKG5ldyBQcm94eSh7XG4gICAgICBnZXQocHJvcGVydHkpIHtcbiAgICAgICAgcmV0dXJuIGJsb2NrZWQuaW5jbHVkZXMocHJvcGVydHkpID8gdW5kZWZpbmVkIDogcHJvcHNbcHJvcGVydHldO1xuICAgICAgfSxcbiAgICAgIGhhcyhwcm9wZXJ0eSkge1xuICAgICAgICByZXR1cm4gYmxvY2tlZC5pbmNsdWRlcyhwcm9wZXJ0eSkgPyBmYWxzZSA6IHByb3BlcnR5IGluIHByb3BzO1xuICAgICAgfSxcbiAgICAgIGtleXMoKSB7XG4gICAgICAgIHJldHVybiBPYmplY3Qua2V5cyhwcm9wcykuZmlsdGVyKGsgPT4gIWJsb2NrZWQuaW5jbHVkZXMoaykpO1xuICAgICAgfVxuICAgIH0sIHByb3BUcmFwcykpO1xuICAgIHJldHVybiByZXM7XG4gIH1cbiAgY29uc3Qgb2JqZWN0cyA9IFtdO1xuICBmb3IgKGxldCBpID0gMDsgaSA8PSBsZW47IGkrKykge1xuICAgIG9iamVjdHNbaV0gPSB7fTtcbiAgfVxuICBmb3IgKGNvbnN0IHByb3BOYW1lIG9mIE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzKHByb3BzKSkge1xuICAgIGxldCBrZXlJbmRleCA9IGxlbjtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGtleXMubGVuZ3RoOyBpKyspIHtcbiAgICAgIGlmIChrZXlzW2ldLmluY2x1ZGVzKHByb3BOYW1lKSkge1xuICAgICAgICBrZXlJbmRleCA9IGk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgIH1cbiAgICBjb25zdCBkZXNjID0gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcihwcm9wcywgcHJvcE5hbWUpO1xuICAgIGNvbnN0IGlzRGVmYXVsdERlc2MgPSAhZGVzYy5nZXQgJiYgIWRlc2Muc2V0ICYmIGRlc2MuZW51bWVyYWJsZSAmJiBkZXNjLndyaXRhYmxlICYmIGRlc2MuY29uZmlndXJhYmxlO1xuICAgIGlzRGVmYXVsdERlc2MgPyBvYmplY3RzW2tleUluZGV4XVtwcm9wTmFtZV0gPSBkZXNjLnZhbHVlIDogT2JqZWN0LmRlZmluZVByb3BlcnR5KG9iamVjdHNba2V5SW5kZXhdLCBwcm9wTmFtZSwgZGVzYyk7XG4gIH1cbiAgcmV0dXJuIG9iamVjdHM7XG59XG5mdW5jdGlvbiBsYXp5KGZuKSB7XG4gIGxldCBjb21wO1xuICBsZXQgcDtcbiAgY29uc3QgbG9hZCA9ICgpID0+IHtcbiAgICBpZiAoIXApIHtcbiAgICAgIGNvbnN0IGN1ciA9IHAgPSBmbigpO1xuICAgICAgY3VyLnRoZW4obW9kID0+IHtcbiAgICAgICAgY29tcCA9ICgpID0+IG1vZC5kZWZhdWx0O1xuICAgICAgfSwgKCkgPT4ge1xuICAgICAgICBpZiAocCA9PT0gY3VyKSBwID0gdW5kZWZpbmVkO1xuICAgICAgfSk7XG4gICAgfVxuICAgIHJldHVybiBwO1xuICB9O1xuICBjb25zdCB3cmFwID0gcHJvcHMgPT4ge1xuICAgIGNvbnN0IGN0eCA9IHNoYXJlZENvbmZpZy5jb250ZXh0O1xuICAgIGlmIChjdHgpIHtcbiAgICAgIGNvbnN0IFtzLCBzZXRdID0gY3JlYXRlU2lnbmFsKCk7XG4gICAgICBzaGFyZWRDb25maWcuY291bnQgfHwgKHNoYXJlZENvbmZpZy5jb3VudCA9IDApO1xuICAgICAgc2hhcmVkQ29uZmlnLmNvdW50Kys7XG4gICAgICBsb2FkKCkudGhlbihtb2QgPT4ge1xuICAgICAgICAhc2hhcmVkQ29uZmlnLmRvbmUgJiYgc2V0SHlkcmF0ZUNvbnRleHQoY3R4KTtcbiAgICAgICAgc2hhcmVkQ29uZmlnLmNvdW50LS07XG4gICAgICAgIHNldCgoKSA9PiBtb2QuZGVmYXVsdCk7XG4gICAgICAgIHNldEh5ZHJhdGVDb250ZXh0KCk7XG4gICAgICB9LCBlcnIgPT4ge1xuICAgICAgICAhc2hhcmVkQ29uZmlnLmRvbmUgJiYgc2V0SHlkcmF0ZUNvbnRleHQoY3R4KTtcbiAgICAgICAgc2hhcmVkQ29uZmlnLmNvdW50LS07XG4gICAgICAgIHNldCgoKSA9PiAoKSA9PiB7XG4gICAgICAgICAgdGhyb3cgZXJyO1xuICAgICAgICB9KTtcbiAgICAgICAgc2V0SHlkcmF0ZUNvbnRleHQoKTtcbiAgICAgIH0pO1xuICAgICAgY29tcCA9IHM7XG4gICAgfSBlbHNlIGlmICghY29tcCkge1xuICAgICAgY29uc3QgW3NdID0gY3JlYXRlUmVzb3VyY2UoKCkgPT4gbG9hZCgpLnRoZW4obW9kID0+IG1vZC5kZWZhdWx0KSk7XG4gICAgICBjb21wID0gcztcbiAgICAgIG9uQ2xlYW51cCgoKSA9PiB7XG4gICAgICAgIGlmIChjb21wID09PSBzKSBjb21wID0gdW5kZWZpbmVkO1xuICAgICAgfSk7XG4gICAgfVxuICAgIGxldCBDb21wO1xuICAgIHJldHVybiBjcmVhdGVNZW1vKCgpID0+IChDb21wID0gY29tcD8uKCkpID8gdW50cmFjaygoKSA9PiB7XG4gICAgICBpZiAoSVNfREVWKSA7XG4gICAgICBpZiAoIWN0eCB8fCBzaGFyZWRDb25maWcuZG9uZSkgcmV0dXJuIENvbXAocHJvcHMpO1xuICAgICAgY29uc3QgYyA9IHNoYXJlZENvbmZpZy5jb250ZXh0O1xuICAgICAgc2V0SHlkcmF0ZUNvbnRleHQoY3R4KTtcbiAgICAgIGNvbnN0IHIgPSBDb21wKHByb3BzKTtcbiAgICAgIHNldEh5ZHJhdGVDb250ZXh0KGMpO1xuICAgICAgcmV0dXJuIHI7XG4gICAgfSkgOiBcIlwiKTtcbiAgfTtcbiAgd3JhcC5wcmVsb2FkID0gKCkgPT4gbG9hZCgpO1xuICByZXR1cm4gd3JhcDtcbn1cbmxldCBjb3VudGVyID0gMDtcbmZ1bmN0aW9uIGNyZWF0ZVVuaXF1ZUlkKCkge1xuICBjb25zdCBjdHggPSBzaGFyZWRDb25maWcuY29udGV4dDtcbiAgcmV0dXJuIGN0eCA/IHNoYXJlZENvbmZpZy5nZXROZXh0Q29udGV4dElkKCkgOiBgY2wtJHtjb3VudGVyKyt9YDtcbn1cblxuY29uc3QgbmFycm93ZWRFcnJvciA9IG5hbWUgPT4gYFN0YWxlIHJlYWQgZnJvbSA8JHtuYW1lfT4uYDtcbmZ1bmN0aW9uIEZvcihwcm9wcykge1xuICBjb25zdCBmYWxsYmFjayA9IFwiZmFsbGJhY2tcIiBpbiBwcm9wcyAmJiB7XG4gICAgZmFsbGJhY2s6ICgpID0+IHByb3BzLmZhbGxiYWNrXG4gIH07XG4gIHJldHVybiBjcmVhdGVNZW1vKG1hcEFycmF5KCgpID0+IHByb3BzLmVhY2gsIHByb3BzLmNoaWxkcmVuLCBmYWxsYmFjayB8fCB1bmRlZmluZWQpKTtcbn1cbmZ1bmN0aW9uIEluZGV4KHByb3BzKSB7XG4gIGNvbnN0IGZhbGxiYWNrID0gXCJmYWxsYmFja1wiIGluIHByb3BzICYmIHtcbiAgICBmYWxsYmFjazogKCkgPT4gcHJvcHMuZmFsbGJhY2tcbiAgfTtcbiAgcmV0dXJuIGNyZWF0ZU1lbW8oaW5kZXhBcnJheSgoKSA9PiBwcm9wcy5lYWNoLCBwcm9wcy5jaGlsZHJlbiwgZmFsbGJhY2sgfHwgdW5kZWZpbmVkKSk7XG59XG5mdW5jdGlvbiBTaG93KHByb3BzKSB7XG4gIGNvbnN0IGtleWVkID0gcHJvcHMua2V5ZWQ7XG4gIGNvbnN0IGNvbmRpdGlvblZhbHVlID0gY3JlYXRlTWVtbygoKSA9PiBwcm9wcy53aGVuLCB1bmRlZmluZWQsIHVuZGVmaW5lZCk7XG4gIGNvbnN0IGNvbmRpdGlvbiA9IGtleWVkID8gY29uZGl0aW9uVmFsdWUgOiBjcmVhdGVNZW1vKGNvbmRpdGlvblZhbHVlLCB1bmRlZmluZWQsIHtcbiAgICBlcXVhbHM6IChhLCBiKSA9PiAhYSA9PT0gIWJcbiAgfSk7XG4gIHJldHVybiBjcmVhdGVNZW1vKCgpID0+IHtcbiAgICBjb25zdCBjID0gY29uZGl0aW9uKCk7XG4gICAgaWYgKGMpIHtcbiAgICAgIGNvbnN0IGNoaWxkID0gcHJvcHMuY2hpbGRyZW47XG4gICAgICBjb25zdCBmbiA9IHR5cGVvZiBjaGlsZCA9PT0gXCJmdW5jdGlvblwiICYmIGNoaWxkLmxlbmd0aCA+IDA7XG4gICAgICByZXR1cm4gZm4gPyB1bnRyYWNrKCgpID0+IGNoaWxkKGtleWVkID8gYyA6ICgpID0+IHtcbiAgICAgICAgaWYgKCF1bnRyYWNrKGNvbmRpdGlvbikpIHRocm93IG5hcnJvd2VkRXJyb3IoXCJTaG93XCIpO1xuICAgICAgICByZXR1cm4gY29uZGl0aW9uVmFsdWUoKTtcbiAgICAgIH0pKSA6IGNoaWxkO1xuICAgIH1cbiAgICByZXR1cm4gcHJvcHMuZmFsbGJhY2s7XG4gIH0sIHVuZGVmaW5lZCwgdW5kZWZpbmVkKTtcbn1cbmZ1bmN0aW9uIFN3aXRjaChwcm9wcykge1xuICBjb25zdCBjaHMgPSBjaGlsZHJlbigoKSA9PiBwcm9wcy5jaGlsZHJlbik7XG4gIGNvbnN0IHN3aXRjaEZ1bmMgPSBjcmVhdGVNZW1vKCgpID0+IHtcbiAgICBjb25zdCBjaCA9IGNocygpO1xuICAgIGNvbnN0IG1wcyA9IEFycmF5LmlzQXJyYXkoY2gpID8gY2ggOiBbY2hdO1xuICAgIGxldCBmdW5jID0gKCkgPT4gdW5kZWZpbmVkO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbXBzLmxlbmd0aDsgaSsrKSB7XG4gICAgICBjb25zdCBpbmRleCA9IGk7XG4gICAgICBjb25zdCBtcCA9IG1wc1tpXTtcbiAgICAgIGNvbnN0IHByZXZGdW5jID0gZnVuYztcbiAgICAgIGNvbnN0IGNvbmRpdGlvblZhbHVlID0gY3JlYXRlTWVtbygoKSA9PiBwcmV2RnVuYygpID8gdW5kZWZpbmVkIDogbXAud2hlbiwgdW5kZWZpbmVkLCB1bmRlZmluZWQpO1xuICAgICAgY29uc3QgY29uZGl0aW9uID0gbXAua2V5ZWQgPyBjb25kaXRpb25WYWx1ZSA6IGNyZWF0ZU1lbW8oY29uZGl0aW9uVmFsdWUsIHVuZGVmaW5lZCwge1xuICAgICAgICBlcXVhbHM6IChhLCBiKSA9PiAhYSA9PT0gIWJcbiAgICAgIH0pO1xuICAgICAgZnVuYyA9ICgpID0+IHByZXZGdW5jKCkgfHwgKGNvbmRpdGlvbigpID8gW2luZGV4LCBjb25kaXRpb25WYWx1ZSwgbXBdIDogdW5kZWZpbmVkKTtcbiAgICB9XG4gICAgcmV0dXJuIGZ1bmM7XG4gIH0pO1xuICByZXR1cm4gY3JlYXRlTWVtbygoKSA9PiB7XG4gICAgY29uc3Qgc2VsID0gc3dpdGNoRnVuYygpKCk7XG4gICAgaWYgKCFzZWwpIHJldHVybiBwcm9wcy5mYWxsYmFjaztcbiAgICBjb25zdCBbaW5kZXgsIGNvbmRpdGlvblZhbHVlLCBtcF0gPSBzZWw7XG4gICAgY29uc3QgY2hpbGQgPSBtcC5jaGlsZHJlbjtcbiAgICBjb25zdCBmbiA9IHR5cGVvZiBjaGlsZCA9PT0gXCJmdW5jdGlvblwiICYmIGNoaWxkLmxlbmd0aCA+IDA7XG4gICAgcmV0dXJuIGZuID8gdW50cmFjaygoKSA9PiBjaGlsZChtcC5rZXllZCA/IGNvbmRpdGlvblZhbHVlKCkgOiAoKSA9PiB7XG4gICAgICBpZiAodW50cmFjayhzd2l0Y2hGdW5jKSgpPy5bMF0gIT09IGluZGV4KSB0aHJvdyBuYXJyb3dlZEVycm9yKFwiTWF0Y2hcIik7XG4gICAgICByZXR1cm4gY29uZGl0aW9uVmFsdWUoKTtcbiAgICB9KSkgOiBjaGlsZDtcbiAgfSwgdW5kZWZpbmVkLCB1bmRlZmluZWQpO1xufVxuZnVuY3Rpb24gTWF0Y2gocHJvcHMpIHtcbiAgcmV0dXJuIHByb3BzO1xufVxubGV0IEVycm9ycztcbmZ1bmN0aW9uIHJlc2V0RXJyb3JCb3VuZGFyaWVzKCkge1xuICBFcnJvcnMgJiYgWy4uLkVycm9yc10uZm9yRWFjaChmbiA9PiBmbigpKTtcbn1cbmZ1bmN0aW9uIEVycm9yQm91bmRhcnkocHJvcHMpIHtcbiAgbGV0IGVycjtcbiAgaWYgKHNoYXJlZENvbmZpZy5jb250ZXh0ICYmIHNoYXJlZENvbmZpZy5sb2FkKSBlcnIgPSBzaGFyZWRDb25maWcubG9hZChzaGFyZWRDb25maWcuZ2V0Q29udGV4dElkKCkpO1xuICBjb25zdCBbZXJyb3JlZCwgc2V0RXJyb3JlZF0gPSBjcmVhdGVTaWduYWwoZXJyLCB1bmRlZmluZWQpO1xuICBFcnJvcnMgfHwgKEVycm9ycyA9IG5ldyBTZXQoKSk7XG4gIEVycm9ycy5hZGQoc2V0RXJyb3JlZCk7XG4gIG9uQ2xlYW51cCgoKSA9PiBFcnJvcnMuZGVsZXRlKHNldEVycm9yZWQpKTtcbiAgcmV0dXJuIGNyZWF0ZU1lbW8oKCkgPT4ge1xuICAgIGxldCBlO1xuICAgIGlmIChlID0gZXJyb3JlZCgpKSB7XG4gICAgICBjb25zdCBmID0gcHJvcHMuZmFsbGJhY2s7XG4gICAgICByZXR1cm4gdHlwZW9mIGYgPT09IFwiZnVuY3Rpb25cIiAmJiBmLmxlbmd0aCA/IHVudHJhY2soKCkgPT4gZihlLCAoKSA9PiBzZXRFcnJvcmVkKCkpKSA6IGY7XG4gICAgfVxuICAgIHJldHVybiBjYXRjaEVycm9yKCgpID0+IHByb3BzLmNoaWxkcmVuLCBzZXRFcnJvcmVkKTtcbiAgfSwgdW5kZWZpbmVkLCB1bmRlZmluZWQpO1xufVxuXG5jb25zdCBzdXNwZW5zZUxpc3RFcXVhbHMgPSAoYSwgYikgPT4gYS5zaG93Q29udGVudCA9PT0gYi5zaG93Q29udGVudCAmJiBhLnNob3dGYWxsYmFjayA9PT0gYi5zaG93RmFsbGJhY2s7XG5jb25zdCBTdXNwZW5zZUxpc3RDb250ZXh0ID0gLyogI19fUFVSRV9fICovY3JlYXRlQ29udGV4dCgpO1xuZnVuY3Rpb24gU3VzcGVuc2VMaXN0KHByb3BzKSB7XG4gIGxldCBbd3JhcHBlciwgc2V0V3JhcHBlcl0gPSBjcmVhdGVTaWduYWwoKCkgPT4gKHtcbiAgICAgIGluRmFsbGJhY2s6IGZhbHNlXG4gICAgfSkpLFxuICAgIHNob3c7XG4gIGNvbnN0IGxpc3RDb250ZXh0ID0gdXNlQ29udGV4dChTdXNwZW5zZUxpc3RDb250ZXh0KTtcbiAgY29uc3QgW3JlZ2lzdHJ5LCBzZXRSZWdpc3RyeV0gPSBjcmVhdGVTaWduYWwoW10pO1xuICBpZiAobGlzdENvbnRleHQpIHtcbiAgICBzaG93ID0gbGlzdENvbnRleHQucmVnaXN0ZXIoY3JlYXRlTWVtbygoKSA9PiB3cmFwcGVyKCkoKS5pbkZhbGxiYWNrKSk7XG4gIH1cbiAgY29uc3QgcmVzb2x2ZWQgPSBjcmVhdGVNZW1vKHByZXYgPT4ge1xuICAgIGNvbnN0IHJldmVhbCA9IHByb3BzLnJldmVhbE9yZGVyLFxuICAgICAgdGFpbCA9IHByb3BzLnRhaWwsXG4gICAgICB7XG4gICAgICAgIHNob3dDb250ZW50ID0gdHJ1ZSxcbiAgICAgICAgc2hvd0ZhbGxiYWNrID0gdHJ1ZVxuICAgICAgfSA9IHNob3cgPyBzaG93KCkgOiB7fSxcbiAgICAgIHJlZyA9IHJlZ2lzdHJ5KCksXG4gICAgICByZXZlcnNlID0gcmV2ZWFsID09PSBcImJhY2t3YXJkc1wiO1xuICAgIGlmIChyZXZlYWwgPT09IFwidG9nZXRoZXJcIikge1xuICAgICAgY29uc3QgYWxsID0gcmVnLmV2ZXJ5KGluRmFsbGJhY2sgPT4gIWluRmFsbGJhY2soKSk7XG4gICAgICBjb25zdCByZXMgPSByZWcubWFwKCgpID0+ICh7XG4gICAgICAgIHNob3dDb250ZW50OiBhbGwgJiYgc2hvd0NvbnRlbnQsXG4gICAgICAgIHNob3dGYWxsYmFja1xuICAgICAgfSkpO1xuICAgICAgcmVzLmluRmFsbGJhY2sgPSAhYWxsO1xuICAgICAgcmV0dXJuIHJlcztcbiAgICB9XG4gICAgbGV0IHN0b3AgPSBmYWxzZTtcbiAgICBsZXQgaW5GYWxsYmFjayA9IHByZXYuaW5GYWxsYmFjaztcbiAgICBjb25zdCByZXMgPSBbXTtcbiAgICBmb3IgKGxldCBpID0gMCwgbGVuID0gcmVnLmxlbmd0aDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgICBjb25zdCBuID0gcmV2ZXJzZSA/IGxlbiAtIGkgLSAxIDogaSxcbiAgICAgICAgcyA9IHJlZ1tuXSgpO1xuICAgICAgaWYgKCFzdG9wICYmICFzKSB7XG4gICAgICAgIHJlc1tuXSA9IHtcbiAgICAgICAgICBzaG93Q29udGVudCxcbiAgICAgICAgICBzaG93RmFsbGJhY2tcbiAgICAgICAgfTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnN0IG5leHQgPSAhc3RvcDtcbiAgICAgICAgaWYgKG5leHQpIGluRmFsbGJhY2sgPSB0cnVlO1xuICAgICAgICByZXNbbl0gPSB7XG4gICAgICAgICAgc2hvd0NvbnRlbnQ6IG5leHQsXG4gICAgICAgICAgc2hvd0ZhbGxiYWNrOiAhdGFpbCB8fCBuZXh0ICYmIHRhaWwgPT09IFwiY29sbGFwc2VkXCIgPyBzaG93RmFsbGJhY2sgOiBmYWxzZVxuICAgICAgICB9O1xuICAgICAgICBzdG9wID0gdHJ1ZTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKCFzdG9wKSBpbkZhbGxiYWNrID0gZmFsc2U7XG4gICAgcmVzLmluRmFsbGJhY2sgPSBpbkZhbGxiYWNrO1xuICAgIHJldHVybiByZXM7XG4gIH0sIHtcbiAgICBpbkZhbGxiYWNrOiBmYWxzZVxuICB9KTtcbiAgc2V0V3JhcHBlcigoKSA9PiByZXNvbHZlZCk7XG4gIHJldHVybiBjcmVhdGVDb21wb25lbnQoU3VzcGVuc2VMaXN0Q29udGV4dC5Qcm92aWRlciwge1xuICAgIHZhbHVlOiB7XG4gICAgICByZWdpc3RlcjogaW5GYWxsYmFjayA9PiB7XG4gICAgICAgIGxldCBpbmRleDtcbiAgICAgICAgc2V0UmVnaXN0cnkocmVnaXN0cnkgPT4ge1xuICAgICAgICAgIGluZGV4ID0gcmVnaXN0cnkubGVuZ3RoO1xuICAgICAgICAgIHJldHVybiBbLi4ucmVnaXN0cnksIGluRmFsbGJhY2tdO1xuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIGNyZWF0ZU1lbW8oKCkgPT4gcmVzb2x2ZWQoKVtpbmRleF0sIHVuZGVmaW5lZCwge1xuICAgICAgICAgIGVxdWFsczogc3VzcGVuc2VMaXN0RXF1YWxzXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0sXG4gICAgZ2V0IGNoaWxkcmVuKCkge1xuICAgICAgcmV0dXJuIHByb3BzLmNoaWxkcmVuO1xuICAgIH1cbiAgfSk7XG59XG5mdW5jdGlvbiBTdXNwZW5zZShwcm9wcykge1xuICBsZXQgY291bnRlciA9IDAsXG4gICAgc2hvdyxcbiAgICBjdHgsXG4gICAgcCxcbiAgICBmbGlja2VyLFxuICAgIGVycm9yO1xuICBjb25zdCBbaW5GYWxsYmFjaywgc2V0RmFsbGJhY2tdID0gY3JlYXRlU2lnbmFsKGZhbHNlKSxcbiAgICBTdXNwZW5zZUNvbnRleHQgPSBnZXRTdXNwZW5zZUNvbnRleHQoKSxcbiAgICBzdG9yZSA9IHtcbiAgICAgIGluY3JlbWVudDogKCkgPT4ge1xuICAgICAgICBpZiAoKytjb3VudGVyID09PSAxKSBzZXRGYWxsYmFjayh0cnVlKTtcbiAgICAgIH0sXG4gICAgICBkZWNyZW1lbnQ6ICgpID0+IHtcbiAgICAgICAgaWYgKC0tY291bnRlciA9PT0gMCkgc2V0RmFsbGJhY2soZmFsc2UpO1xuICAgICAgfSxcbiAgICAgIGluRmFsbGJhY2ssXG4gICAgICBlZmZlY3RzOiBbXSxcbiAgICAgIHJlc29sdmVkOiBmYWxzZVxuICAgIH0sXG4gICAgb3duZXIgPSBnZXRPd25lcigpO1xuICBpZiAoc2hhcmVkQ29uZmlnLmNvbnRleHQgJiYgc2hhcmVkQ29uZmlnLmxvYWQpIHtcbiAgICBjb25zdCBrZXkgPSBzaGFyZWRDb25maWcuZ2V0Q29udGV4dElkKCk7XG4gICAgbGV0IHJlZiA9IHNoYXJlZENvbmZpZy5sb2FkKGtleSk7XG4gICAgaWYgKHJlZikge1xuICAgICAgaWYgKHR5cGVvZiByZWYgIT09IFwib2JqZWN0XCIgfHwgcmVmLnMgIT09IDEpIHAgPSByZWY7ZWxzZSBzaGFyZWRDb25maWcuZ2F0aGVyKGtleSk7XG4gICAgfVxuICAgIGlmIChwICYmIHAgIT09IFwiJCRmXCIpIHtcbiAgICAgIGNvbnN0IFtzLCBzZXRdID0gY3JlYXRlU2lnbmFsKHVuZGVmaW5lZCwge1xuICAgICAgICBlcXVhbHM6IGZhbHNlXG4gICAgICB9KTtcbiAgICAgIGZsaWNrZXIgPSBzO1xuICAgICAgcC50aGVuKCgpID0+IHtcbiAgICAgICAgaWYgKHNoYXJlZENvbmZpZy5kb25lKSByZXR1cm4gc2V0KCk7XG4gICAgICAgIHNoYXJlZENvbmZpZy5nYXRoZXIoa2V5KTtcbiAgICAgICAgc2V0SHlkcmF0ZUNvbnRleHQoY3R4KTtcbiAgICAgICAgc2V0KCk7XG4gICAgICAgIHNldEh5ZHJhdGVDb250ZXh0KCk7XG4gICAgICB9LCBlcnIgPT4ge1xuICAgICAgICBlcnJvciA9IGVycjtcbiAgICAgICAgc2V0KCk7XG4gICAgICB9KTtcbiAgICB9XG4gIH1cbiAgY29uc3QgbGlzdENvbnRleHQgPSB1c2VDb250ZXh0KFN1c3BlbnNlTGlzdENvbnRleHQpO1xuICBpZiAobGlzdENvbnRleHQpIHNob3cgPSBsaXN0Q29udGV4dC5yZWdpc3RlcihzdG9yZS5pbkZhbGxiYWNrKTtcbiAgbGV0IGRpc3Bvc2U7XG4gIG9uQ2xlYW51cCgoKSA9PiBkaXNwb3NlICYmIGRpc3Bvc2UoKSk7XG4gIHJldHVybiBjcmVhdGVDb21wb25lbnQoU3VzcGVuc2VDb250ZXh0LlByb3ZpZGVyLCB7XG4gICAgdmFsdWU6IHN0b3JlLFxuICAgIGdldCBjaGlsZHJlbigpIHtcbiAgICAgIHJldHVybiBjcmVhdGVNZW1vKCgpID0+IHtcbiAgICAgICAgaWYgKGVycm9yKSB0aHJvdyBlcnJvcjtcbiAgICAgICAgY3R4ID0gc2hhcmVkQ29uZmlnLmNvbnRleHQ7XG4gICAgICAgIGlmIChmbGlja2VyKSB7XG4gICAgICAgICAgZmxpY2tlcigpO1xuICAgICAgICAgIHJldHVybiBmbGlja2VyID0gdW5kZWZpbmVkO1xuICAgICAgICB9XG4gICAgICAgIGlmIChjdHggJiYgcCA9PT0gXCIkJGZcIikgc2V0SHlkcmF0ZUNvbnRleHQoKTtcbiAgICAgICAgY29uc3QgcmVuZGVyZWQgPSBjcmVhdGVNZW1vKCgpID0+IHByb3BzLmNoaWxkcmVuKTtcbiAgICAgICAgcmV0dXJuIGNyZWF0ZU1lbW8ocHJldiA9PiB7XG4gICAgICAgICAgY29uc3QgaW5GYWxsYmFjayA9IHN0b3JlLmluRmFsbGJhY2soKSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgc2hvd0NvbnRlbnQgPSB0cnVlLFxuICAgICAgICAgICAgICBzaG93RmFsbGJhY2sgPSB0cnVlXG4gICAgICAgICAgICB9ID0gc2hvdyA/IHNob3coKSA6IHt9O1xuICAgICAgICAgIGlmICgoIWluRmFsbGJhY2sgfHwgcCAmJiBwICE9PSBcIiQkZlwiKSAmJiBzaG93Q29udGVudCkge1xuICAgICAgICAgICAgc3RvcmUucmVzb2x2ZWQgPSB0cnVlO1xuICAgICAgICAgICAgZGlzcG9zZSAmJiBkaXNwb3NlKCk7XG4gICAgICAgICAgICBkaXNwb3NlID0gY3R4ID0gcCA9IHVuZGVmaW5lZDtcbiAgICAgICAgICAgIHJlc3VtZUVmZmVjdHMoc3RvcmUuZWZmZWN0cyk7XG4gICAgICAgICAgICByZXR1cm4gcmVuZGVyZWQoKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKCFzaG93RmFsbGJhY2spIHJldHVybjtcbiAgICAgICAgICBpZiAoZGlzcG9zZSkgcmV0dXJuIHByZXY7XG4gICAgICAgICAgcmV0dXJuIGNyZWF0ZVJvb3QoZGlzcG9zZXIgPT4ge1xuICAgICAgICAgICAgZGlzcG9zZSA9IGRpc3Bvc2VyO1xuICAgICAgICAgICAgaWYgKGN0eCkge1xuICAgICAgICAgICAgICBzZXRIeWRyYXRlQ29udGV4dCh7XG4gICAgICAgICAgICAgICAgaWQ6IGN0eC5pZCArIFwiRlwiLFxuICAgICAgICAgICAgICAgIGNvdW50OiAwXG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICBjdHggPSB1bmRlZmluZWQ7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gcHJvcHMuZmFsbGJhY2s7XG4gICAgICAgICAgfSwgb3duZXIpO1xuICAgICAgICB9KTtcbiAgICAgIH0pO1xuICAgIH1cbiAgfSk7XG59XG5cbmNvbnN0IERFViA9IHVuZGVmaW5lZDtcblxuZXhwb3J0IHsgJERFVkNPTVAsICRQUk9YWSwgJFRSQUNLLCBERVYsIEVycm9yQm91bmRhcnksIEZvciwgSW5kZXgsIE1hdGNoLCBTaG93LCBTdXNwZW5zZSwgU3VzcGVuc2VMaXN0LCBTd2l0Y2gsIGJhdGNoLCBjYW5jZWxDYWxsYmFjaywgY2F0Y2hFcnJvciwgY2hpbGRyZW4sIGNyZWF0ZUNvbXBvbmVudCwgY3JlYXRlQ29tcHV0ZWQsIGNyZWF0ZUNvbnRleHQsIGNyZWF0ZURlZmVycmVkLCBjcmVhdGVFZmZlY3QsIGNyZWF0ZU1lbW8sIGNyZWF0ZVJlYWN0aW9uLCBjcmVhdGVSZW5kZXJFZmZlY3QsIGNyZWF0ZVJlc291cmNlLCBjcmVhdGVSb290LCBjcmVhdGVTZWxlY3RvciwgY3JlYXRlU2lnbmFsLCBjcmVhdGVVbmlxdWVJZCwgZW5hYmxlRXh0ZXJuYWxTb3VyY2UsIGVuYWJsZUh5ZHJhdGlvbiwgZW5hYmxlU2NoZWR1bGluZywgZXF1YWxGbiwgZnJvbSwgZ2V0TGlzdGVuZXIsIGdldE93bmVyLCBpbmRleEFycmF5LCBsYXp5LCBtYXBBcnJheSwgbWVyZ2VQcm9wcywgb2JzZXJ2YWJsZSwgb24sIG9uQ2xlYW51cCwgb25FcnJvciwgb25Nb3VudCwgcmVxdWVzdENhbGxiYWNrLCByZXNldEVycm9yQm91bmRhcmllcywgcnVuV2l0aE93bmVyLCBzaGFyZWRDb25maWcsIHNwbGl0UHJvcHMsIHN0YXJ0VHJhbnNpdGlvbiwgdW50cmFjaywgdXNlQ29udGV4dCwgdXNlVHJhbnNpdGlvbiB9O1xuIiwidmFyIElEWD0yNTYsIEhFWD1bXSwgQlVGRkVSO1xud2hpbGUgKElEWC0tKSBIRVhbSURYXSA9IChJRFggKyAyNTYpLnRvU3RyaW5nKDE2KS5zdWJzdHJpbmcoMSk7XG5cbmV4cG9ydCBmdW5jdGlvbiB2NCgpIHtcblx0dmFyIGk9MCwgbnVtLCBvdXQ9Jyc7XG5cblx0aWYgKCFCVUZGRVIgfHwgKChJRFggKyAxNikgPiAyNTYpKSB7XG5cdFx0QlVGRkVSID0gQXJyYXkoaT0yNTYpO1xuXHRcdHdoaWxlIChpLS0pIEJVRkZFUltpXSA9IDI1NiAqIE1hdGgucmFuZG9tKCkgfCAwO1xuXHRcdGkgPSBJRFggPSAwO1xuXHR9XG5cblx0Zm9yICg7IGkgPCAxNjsgaSsrKSB7XG5cdFx0bnVtID0gQlVGRkVSW0lEWCArIGldO1xuXHRcdGlmIChpPT02KSBvdXQgKz0gSEVYW251bSAmIDE1IHwgNjRdO1xuXHRcdGVsc2UgaWYgKGk9PTgpIG91dCArPSBIRVhbbnVtICYgNjMgfCAxMjhdO1xuXHRcdGVsc2Ugb3V0ICs9IEhFWFtudW1dO1xuXG5cdFx0aWYgKGkgJiAxICYmIGkgPiAxICYmIGkgPCAxMSkgb3V0ICs9ICctJztcblx0fVxuXG5cdElEWCsrO1xuXHRyZXR1cm4gb3V0O1xufVxuIiwiaW1wb3J0IHR5cGUgeyBBbnlNb2RlbCB9IGZyb20gXCJAYW55d2lkZ2V0L3R5cGVzXCI7XG5pbXBvcnQgKiBhcyB1dWlkIGZyb20gXCJAbHVrZWVkL3V1aWRcIjtcblxuZXhwb3J0IGludGVyZmFjZSBJbnZva2VPcHRpb25zIHtcbiAgYnVmZmVycz86IERhdGFWaWV3W107XG4gIHNpZ25hbD86IEFib3J0U2lnbmFsO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gaW52b2tlPFQ+KFxuICBtb2RlbDogQW55TW9kZWwsXG4gIG5hbWU6IHN0cmluZyxcbiAgbXNnPzogdW5rbm93bixcbiAgb3B0aW9uczogSW52b2tlT3B0aW9ucyA9IHt9LFxuKTogUHJvbWlzZTxbVCwgRGF0YVZpZXdbXV0+IHtcbiAgLy8gY3J5cHRvLnJhbmRvbVVVSUQoKSBpcyBub3QgYXZhaWxhYmxlIGluIG5vbi1zZWN1cmUgY29udGV4dHMgKGkuZS4sIGh0dHA6Ly8pXG4gIC8vIHNvIHdlIHVzZSBzaW1wbGUgKG5vbi1zZWN1cmUpIHBvbHlmaWxsLlxuICBsZXQgaWQgPSB1dWlkLnY0KCk7XG4gIGxldCBzaWduYWwgPSBvcHRpb25zLnNpZ25hbCA/PyBBYm9ydFNpZ25hbC50aW1lb3V0KDMwMDApO1xuXG4gIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgaWYgKHNpZ25hbC5hYm9ydGVkKSB7XG4gICAgICByZWplY3Qoc2lnbmFsLnJlYXNvbik7XG4gICAgfVxuICAgIHNpZ25hbC5hZGRFdmVudExpc3RlbmVyKFwiYWJvcnRcIiwgKCkgPT4ge1xuICAgICAgbW9kZWwub2ZmKFwibXNnOmN1c3RvbVwiLCBoYW5kbGVyKTtcbiAgICAgIHJlamVjdChzaWduYWwucmVhc29uKTtcbiAgICB9KTtcblxuICAgIGZ1bmN0aW9uIGhhbmRsZXIoXG4gICAgICBtc2c6IHsgaWQ6IHN0cmluZzsga2luZDogXCJhbnl3aWRnZXQtY29tbWFuZC1yZXNwb25zZVwiOyByZXNwb25zZTogVCB9LFxuICAgICAgYnVmZmVyczogRGF0YVZpZXdbXSxcbiAgICApOiB2b2lkIHtcbiAgICAgIGlmICghKG1zZy5pZCA9PT0gaWQpKSByZXR1cm47XG4gICAgICByZXNvbHZlKFttc2cucmVzcG9uc2UsIGJ1ZmZlcnNdKTtcbiAgICAgIG1vZGVsLm9mZihcIm1zZzpjdXN0b21cIiwgaGFuZGxlcik7XG4gICAgfVxuICAgIG1vZGVsLm9uKFwibXNnOmN1c3RvbVwiLCBoYW5kbGVyKTtcbiAgICBtb2RlbC5zZW5kKHsgaWQsIGtpbmQ6IFwiYW55d2lkZ2V0LWNvbW1hbmRcIiwgbmFtZSwgbXNnIH0sIHVuZGVmaW5lZCwgb3B0aW9ucy5idWZmZXJzID8/IFtdKTtcbiAgfSk7XG59XG4iLCJleHBvcnQgbGV0IFdJREdFVF9SRUZfUFJFRklYID0gXCJhbnl3aWRnZXQ6XCI7XG5cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZVdpZGdldFJlZihyZWY6IHVua25vd24pOiBzdHJpbmcge1xuICBpZiAodHlwZW9mIHJlZiA9PT0gXCJzdHJpbmdcIiAmJiByZWYuc3RhcnRzV2l0aChXSURHRVRfUkVGX1BSRUZJWCkpIHtcbiAgICByZXR1cm4gcmVmLnNsaWNlKFdJREdFVF9SRUZfUFJFRklYLmxlbmd0aCk7XG4gIH1cbiAgdGhyb3cgbmV3IEVycm9yKGBbYW55d2lkZ2V0XSBJbnZhbGlkIHdpZGdldCByZWZlcmVuY2U6ICR7SlNPTi5zdHJpbmdpZnkocmVmKX1gKTtcbn1cbiIsImltcG9ydCB0eXBlIHsgSG9zdCB9IGZyb20gXCJAYW55d2lkZ2V0L3R5cGVzXCI7XG5pbXBvcnQgdHlwZSB7IERPTVdpZGdldE1vZGVsIH0gZnJvbSBcIkBqdXB5dGVyLXdpZGdldHMvYmFzZVwiO1xuXG5pbXBvcnQgeyBCSU5ESU5HUyB9IGZyb20gXCIuL2JpbmRpbmcudHNcIjtcbmltcG9ydCB7IGludm9rZSB9IGZyb20gXCIuL2ludm9rZS50c1wiO1xuaW1wb3J0IHsgbW9kZWxQcm94eSB9IGZyb20gXCIuL21vZGVsLXByb3h5LnRzXCI7XG5pbXBvcnQgeyBwYXJzZVdpZGdldFJlZiB9IGZyb20gXCIuL3dpZGdldC1yZWYudHNcIjtcblxuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZUhvc3QobW9kZWw6IERPTVdpZGdldE1vZGVsLCB7IHNpZ25hbCB9OiB7IHNpZ25hbDogQWJvcnRTaWduYWwgfSk6IEhvc3Qge1xuICBsZXQgaG9zdDogSG9zdCA9IHtcbiAgICAvLyBAdHMtZXhwZWN0LWVycm9yIC0gbW9kZWxQcm94eSByZXR1cm5zIEFueU1vZGVsOyBnZW5lcmljIFQgaXMgZXJhc2VkIGF0IHJ1bnRpbWVcbiAgICBhc3luYyBnZXRNb2RlbChyZWYpIHtcbiAgICAgIGxldCBtb2RlbElkID0gcGFyc2VXaWRnZXRSZWYocmVmKTtcbiAgICAgIGxldCBjaGlsZE1vZGVsID0gYXdhaXQgbW9kZWwud2lkZ2V0X21hbmFnZXIuZ2V0X21vZGVsKG1vZGVsSWQpO1xuICAgICAgbGV0IGNvbnRleHQgPSBTeW1ib2woXCJhbnl3aWRnZXQuaG9zdC5nZXRNb2RlbFwiKTtcbiAgICAgIHNpZ25hbC5hZGRFdmVudExpc3RlbmVyKFwiYWJvcnRcIiwgKCkgPT4gY2hpbGRNb2RlbC5vZmYobnVsbCwgbnVsbCwgY29udGV4dCkpO1xuICAgICAgcmV0dXJuIG1vZGVsUHJveHkoY2hpbGRNb2RlbCwgY29udGV4dCk7XG4gICAgfSxcbiAgICAvLyBAdHMtZXhwZWN0LWVycm9yIC0gZ2VuZXJpYyBUIGlzIGVyYXNlZCBhdCBydW50aW1lLCBleHBvcnRzIHR5cGVkIGFzIHVua25vd25cbiAgICBhc3luYyBnZXRXaWRnZXQocmVmKSB7XG4gICAgICBsZXQgbW9kZWxJZCA9IHBhcnNlV2lkZ2V0UmVmKHJlZik7XG4gICAgICBsZXQgY2hpbGRNb2RlbCA9IGF3YWl0IG1vZGVsLndpZGdldF9tYW5hZ2VyLmdldF9tb2RlbChtb2RlbElkKTtcbiAgICAgIGxldCBjaGlsZEJpbmRpbmcgPSBCSU5ESU5HUy5nZXQoY2hpbGRNb2RlbCk7XG4gICAgICBpZiAoIWNoaWxkQmluZGluZykge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYFthbnl3aWRnZXRdIE5vIGJpbmRpbmcgZm91bmQgZm9yIHdpZGdldCAke21vZGVsSWR9YCk7XG4gICAgICB9XG4gICAgICBsZXQgdGltZXI6IFJldHVyblR5cGU8dHlwZW9mIHNldFRpbWVvdXQ+IHwgdW5kZWZpbmVkO1xuICAgICAgbGV0IGV4cG9ydHMgPSBhd2FpdCBuZXcgUHJvbWlzZTx1bmtub3duPigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgIHRpbWVyID0gc2V0VGltZW91dChcbiAgICAgICAgICAoKSA9PlxuICAgICAgICAgICAgcmVqZWN0KG5ldyBFcnJvcihgW2FueXdpZGdldF0gVGltZWQgb3V0IHdhaXRpbmcgZm9yIHdpZGdldCAke21vZGVsSWR9IHRvIGluaXRpYWxpemVgKSksXG4gICAgICAgICAgMTBfMDAwLFxuICAgICAgICApO1xuICAgICAgICBjaGlsZEJpbmRpbmcucmVhZHkudGhlbihyZXNvbHZlLCByZWplY3QpO1xuICAgICAgfSkuZmluYWxseSgoKSA9PiBjbGVhclRpbWVvdXQodGltZXIpKTtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIGV4cG9ydHMsXG4gICAgICAgIGFzeW5jIHJlbmRlcih7IGVsLCBzaWduYWw6IHZpZXdTaWduYWwgfSkge1xuICAgICAgICAgIGxldCBjaGlsZFZpZXdTaWduYWwgPSB2aWV3U2lnbmFsID8/IHNpZ25hbDtcbiAgICAgICAgICBhd2FpdCBjaGlsZEJpbmRpbmcuY3JlYXRlVmlldyhcbiAgICAgICAgICAgIHsgZWwgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgc2lnbmFsOiBjaGlsZFZpZXdTaWduYWwsXG4gICAgICAgICAgICAgIGV4cGVyaW1lbnRhbDoge1xuICAgICAgICAgICAgICAgIC8vIEB0cy1leHBlY3QtZXJyb3IgLSBiaW5kIGlzbid0IHdvcmtpbmdcbiAgICAgICAgICAgICAgICBpbnZva2U6IGludm9rZS5iaW5kKG51bGwsIGNoaWxkTW9kZWwpLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICBob3N0LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICApO1xuICAgICAgICB9LFxuICAgICAgfTtcbiAgICB9LFxuICB9O1xuICByZXR1cm4gaG9zdDtcbn1cbiIsImltcG9ydCB0eXBlIHsgSW5pdGlhbGl6ZSwgUmVuZGVyIH0gZnJvbSBcIkBhbnl3aWRnZXQvdHlwZXNcIjtcblxuaW1wb3J0IHsgYXNzZXJ0IH0gZnJvbSBcIi4vdXRpbC50c1wiO1xuXG5leHBvcnQgaW50ZXJmYWNlIEFueVdpZGdldCB7XG4gIGluaXRpYWxpemU/OiBJbml0aWFsaXplO1xuICByZW5kZXI/OiBSZW5kZXI7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgQW55V2lkZ2V0TW9kdWxlIHtcbiAgcmVuZGVyPzogUmVuZGVyO1xuICBkZWZhdWx0PzogQW55V2lkZ2V0IHwgKCgpID0+IEFueVdpZGdldCB8IFByb21pc2U8QW55V2lkZ2V0Pik7XG59XG5cbmZ1bmN0aW9uIGlzSHJlZihzdHI6IHN0cmluZyk6IHN0ciBpcyBgaHR0cHM6Ly8ke3N0cmluZ31gIHwgYGh0dHA6Ly8ke3N0cmluZ31gIHtcbiAgcmV0dXJuIHN0ci5zdGFydHNXaXRoKFwiaHR0cDovL1wiKSB8fCBzdHIuc3RhcnRzV2l0aChcImh0dHBzOi8vXCIpO1xufVxuXG5hc3luYyBmdW5jdGlvbiBsb2FkQ3NzSHJlZihocmVmOiBzdHJpbmcsIGFueXdpZGdldElkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgbGV0IHByZXYgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yPEhUTUxMaW5rRWxlbWVudD4oYGxpbmtbaWQ9JyR7YW55d2lkZ2V0SWR9J11gKTtcblxuICAvLyBBZGFwdGVkIGZyb20gaHR0cHM6Ly9naXRodWIuY29tL3ZpdGVqcy92aXRlL2Jsb2IvZDU5ZTFhY2MyZWZjMDMwNzQ4ODM2NGU5ZjJmYWQ1MjhlYzU3ZjIwNC9wYWNrYWdlcy92aXRlL3NyYy9jbGllbnQvY2xpZW50LnRzI0wxODUtTDIwMVxuICAvLyBTd2FwcyBvdXQgb2xkIHN0eWxlcyB3aXRoIG5ldywgYnV0IGF2b2lkcyBmbGFzaCBvZiB1bnN0eWxlZCBjb250ZW50LlxuICAvLyBObyBuZWVkIHRvIGF3YWl0IHRoZSBsb2FkIHNpbmNlIHdlIGFscmVhZHkgaGF2ZSBzdHlsZXMgYXBwbGllZC5cbiAgaWYgKHByZXYpIHtcbiAgICAvLyBveGxpbnQtZGlzYWJsZS1uZXh0LWxpbmUgdHlwZXNjcmlwdC1lc2xpbnQvbm8tdW5zYWZlLXR5cGUtYXNzZXJ0aW9uIC0tIE5vZGUuY2xvbmVOb2RlKCkgcmV0dXJucyBOb2RlOyB3ZSBrbm93IHByZXYgaXMgSFRNTExpbmtFbGVtZW50IHNvIHRoZSBjbG9uZSBpcyB0b29cbiAgICBsZXQgbmV3TGluayA9IHByZXYuY2xvbmVOb2RlKCkgYXMgdW5rbm93biBhcyBIVE1MTGlua0VsZW1lbnQ7XG4gICAgbmV3TGluay5ocmVmID0gaHJlZjtcbiAgICBuZXdMaW5rLmFkZEV2ZW50TGlzdGVuZXIoXCJsb2FkXCIsICgpID0+IHByZXY/LnJlbW92ZSgpKTtcbiAgICBuZXdMaW5rLmFkZEV2ZW50TGlzdGVuZXIoXCJlcnJvclwiLCAoKSA9PiBwcmV2Py5yZW1vdmUoKSk7XG4gICAgcHJldi5hZnRlcihuZXdMaW5rKTtcbiAgICByZXR1cm47XG4gIH1cblxuICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcbiAgICBsZXQgbGluayA9IE9iamVjdC5hc3NpZ24oZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImxpbmtcIiksIHtcbiAgICAgIHJlbDogXCJzdHlsZXNoZWV0XCIsXG4gICAgICBocmVmLFxuICAgICAgb25sb2FkOiByZXNvbHZlLFxuICAgIH0pO1xuICAgIGRvY3VtZW50LmhlYWQuYXBwZW5kQ2hpbGQobGluayk7XG4gIH0pO1xufVxuXG5mdW5jdGlvbiBsb2FkQ3NzVGV4dChjc3NUZXh0OiBzdHJpbmcsIGFueXdpZGdldElkOiBzdHJpbmcpOiB2b2lkIHtcbiAgbGV0IHByZXYgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yPEhUTUxTdHlsZUVsZW1lbnQ+KGBzdHlsZVtpZD0nJHthbnl3aWRnZXRJZH0nXWApO1xuICBpZiAocHJldikge1xuICAgIC8vIHJlcGxhY2UgaW5zdGVhZCBvZiBjcmVhdGluZyBhIG5ldyBET00gbm9kZVxuICAgIHByZXYudGV4dENvbnRlbnQgPSBjc3NUZXh0O1xuICAgIHJldHVybjtcbiAgfVxuICBsZXQgc3R5bGUgPSBPYmplY3QuYXNzaWduKGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzdHlsZVwiKSwge1xuICAgIGlkOiBhbnl3aWRnZXRJZCxcbiAgICB0eXBlOiBcInRleHQvY3NzXCIsXG4gIH0pO1xuICBzdHlsZS5hcHBlbmRDaGlsZChkb2N1bWVudC5jcmVhdGVUZXh0Tm9kZShjc3NUZXh0KSk7XG4gIGRvY3VtZW50LmhlYWQuYXBwZW5kQ2hpbGQoc3R5bGUpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbG9hZENzcyhjc3M6IHN0cmluZyB8IHVuZGVmaW5lZCwgYW55d2lkZ2V0SWQ6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBpZiAoIWNzcyB8fCAhYW55d2lkZ2V0SWQpIHJldHVybjtcbiAgaWYgKGlzSHJlZihjc3MpKSByZXR1cm4gbG9hZENzc0hyZWYoY3NzLCBhbnl3aWRnZXRJZCk7XG4gIHJldHVybiBsb2FkQ3NzVGV4dChjc3MsIGFueXdpZGdldElkKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gbG9hZEVzbShlc206IHN0cmluZyk6IFByb21pc2U8QW55V2lkZ2V0TW9kdWxlPiB7XG4gIGlmIChpc0hyZWYoZXNtKSkge1xuICAgIHJldHVybiBhd2FpdCBpbXBvcnQoLyogd2VicGFja0lnbm9yZTogdHJ1ZSAqLyAvKiBAdml0ZS1pZ25vcmUgKi8gZXNtKTtcbiAgfVxuICBsZXQgdXJsID0gVVJMLmNyZWF0ZU9iamVjdFVSTChuZXcgQmxvYihbZXNtXSwgeyB0eXBlOiBcInRleHQvamF2YXNjcmlwdFwiIH0pKTtcbiAgbGV0IG1vZCA9IGF3YWl0IGltcG9ydCgvKiB3ZWJwYWNrSWdub3JlOiB0cnVlICovIC8qIEB2aXRlLWlnbm9yZSAqLyB1cmwpO1xuICBVUkwucmV2b2tlT2JqZWN0VVJMKHVybCk7XG4gIHJldHVybiBtb2Q7XG59XG5cbmZ1bmN0aW9uIHdhcm5SZW5kZXJEZXByZWNhdGlvbihhbnl3aWRnZXRJZDogc3RyaW5nKTogdm9pZCB7XG4gIGNvbnNvbGUud2FybihgXFxcblthbnl3aWRnZXRdIERlcHJlY2F0aW9uIFdhcm5pbmcgZm9yICR7YW55d2lkZ2V0SWR9OiBEaXJlY3QgZXhwb3J0IG9mIGEgJ3JlbmRlcicgd2lsbCBsaWtlbHkgYmUgZGVwcmVjYXRlZCBpbiB0aGUgZnV0dXJlLiBUbyBtaWdyYXRlIC4uLlxuXG5SZW1vdmUgdGhlICdleHBvcnQnIGtleXdvcmQgZnJvbSAncmVuZGVyJ1xuLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGZ1bmN0aW9uIHJlbmRlcih7IG1vZGVsLCBlbCB9KSB7IC4uLiB9XG5eXl5eXl5cblxuQ3JlYXRlIGEgZGVmYXVsdCBleHBvcnQgdGhhdCByZXR1cm5zIGFuIG9iamVjdCB3aXRoICdyZW5kZXInXG4tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZnVuY3Rpb24gcmVuZGVyKHsgbW9kZWwsIGVsIH0pIHsgLi4uIH1cbiAgICAgICAgIF5eXl5eXlxuZXhwb3J0IGRlZmF1bHQgeyByZW5kZXIgfVxuICAgICAgICAgICAgICAgICBeXl5eXl5cblxuUGluIHRvIGFueXdpZGdldD49MC45LjAgaW4geW91ciBweXByb2plY3QudG9tbFxuLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5kZXBlbmRlbmNpZXMgPSBbXCJhbnl3aWRnZXQ+PTAuOS4wXCJdXG5cblRvIGxlYXJuIG1vcmUsIHBsZWFzZSBzZWU6IGh0dHBzOi8vZ2l0aHViLmNvbS9tYW56dC9hbnl3aWRnZXQvcHVsbC8zOTUuXG5gKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGxvYWRXaWRnZXQoZXNtOiBzdHJpbmcsIGFueXdpZGdldElkOiBzdHJpbmcpOiBQcm9taXNlPEFueVdpZGdldD4ge1xuICBsZXQgbW9kID0gYXdhaXQgbG9hZEVzbShlc20pO1xuICBpZiAobW9kLnJlbmRlcikge1xuICAgIHdhcm5SZW5kZXJEZXByZWNhdGlvbihhbnl3aWRnZXRJZCk7XG4gICAgcmV0dXJuIHtcbiAgICAgIGFzeW5jIGluaXRpYWxpemUoKSB7fSxcbiAgICAgIHJlbmRlcjogbW9kLnJlbmRlcixcbiAgICB9O1xuICB9XG4gIGFzc2VydChtb2QuZGVmYXVsdCwgYFthbnl3aWRnZXRdIG1vZHVsZSBtdXN0IGV4cG9ydCBhIGRlZmF1bHQgZnVuY3Rpb24gb3Igb2JqZWN0LmApO1xuICBsZXQgd2lkZ2V0ID0gdHlwZW9mIG1vZC5kZWZhdWx0ID09PSBcImZ1bmN0aW9uXCIgPyBhd2FpdCBtb2QuZGVmYXVsdCgpIDogbW9kLmRlZmF1bHQ7XG4gIHJldHVybiB3aWRnZXQ7XG59XG4iLCJpbXBvcnQgdHlwZSB7IEFueU1vZGVsIH0gZnJvbSBcIkBhbnl3aWRnZXQvdHlwZXNcIjtcbmltcG9ydCAqIGFzIHNvbGlkIGZyb20gXCJzb2xpZC1qc1wiO1xuXG5leHBvcnQgZnVuY3Rpb24gb2JzZXJ2ZTxUIGV4dGVuZHMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4sIEsgZXh0ZW5kcyBrZXlvZiBUICYgc3RyaW5nPihcbiAgbW9kZWw6IEFueU1vZGVsPFQ+LFxuICBuYW1lOiBLLFxuICB7IHNpZ25hbCB9OiB7IHNpZ25hbD86IEFib3J0U2lnbmFsIH0sXG4pOiBzb2xpZC5BY2Nlc3NvcjxUW0tdPiB7XG4gIGxldCBbZ2V0LCBzZXRdID0gc29saWQuY3JlYXRlU2lnbmFsKG1vZGVsLmdldChuYW1lKSk7XG4gIGxldCB1cGRhdGUgPSAoKSA9PiBzZXQoKCkgPT4gbW9kZWwuZ2V0KG5hbWUpKTtcbiAgbW9kZWwub24oYGNoYW5nZToke25hbWV9YCwgdXBkYXRlKTtcbiAgc2lnbmFsPy5hZGRFdmVudExpc3RlbmVyKFwiYWJvcnRcIiwgKCkgPT4ge1xuICAgIG1vZGVsLm9mZihgY2hhbmdlOiR7bmFtZX1gLCB1cGRhdGUpO1xuICB9KTtcbiAgcmV0dXJuIGdldDtcbn1cbiIsImltcG9ydCB0eXBlIHsgQW55TW9kZWwsIEV4cGVyaW1lbnRhbCB9IGZyb20gXCJAYW55d2lkZ2V0L3R5cGVzXCI7XG5pbXBvcnQgdHlwZSB7IERPTVdpZGdldE1vZGVsLCBET01XaWRnZXRWaWV3IH0gZnJvbSBcIkBqdXB5dGVyLXdpZGdldHMvYmFzZVwiO1xuaW1wb3J0ICogYXMgc29saWQgZnJvbSBcInNvbGlkLWpzXCI7XG5cbmltcG9ydCB7IEJJTkRJTkdTIH0gZnJvbSBcIi4vYmluZGluZy50c1wiO1xuaW1wb3J0IHsgY3JlYXRlSG9zdCB9IGZyb20gXCIuL2hvc3QudHNcIjtcbmltcG9ydCB7IGludm9rZSB9IGZyb20gXCIuL2ludm9rZS50c1wiO1xuaW1wb3J0IHsgdHlwZSBBbnlXaWRnZXQsIGxvYWRDc3MsIGxvYWRXaWRnZXQgfSBmcm9tIFwiLi9sb2FkLnRzXCI7XG5pbXBvcnQgeyBvYnNlcnZlIH0gZnJvbSBcIi4vb2JzZXJ2ZS50c1wiO1xuaW1wb3J0IHsgYXNzZXJ0LCB0eXBlIFJlc3VsdCwgdGhyb3dBbnl3aWRnZXRFcnJvciB9IGZyb20gXCIuL3V0aWwudHNcIjtcblxuaW50ZXJmYWNlIFN0YXRlIHtcbiAgW2tleTogc3RyaW5nXTogdW5rbm93bjtcbiAgX2VzbTogc3RyaW5nO1xuICBfYW55d2lkZ2V0X2lkOiBzdHJpbmc7XG4gIF9jc3M6IHN0cmluZyB8IHVuZGVmaW5lZDtcbn1cblxuZXhwb3J0IGNsYXNzIFJ1bnRpbWUge1xuICAvLyBAdHMtZXhwZWN0LWVycm9yIC0gU2V0IHN5bmNocm9ub3VzbHkgaW4gY29uc3RydWN0b3IuXG4gICN3aWRnZXRSZXN1bHQ6IHNvbGlkLkFjY2Vzc29yPFJlc3VsdDxBbnlXaWRnZXQ+PjtcbiAgI3NpZ25hbDogQWJvcnRTaWduYWw7XG5cbiAgY29uc3RydWN0b3IobW9kZWw6IERPTVdpZGdldE1vZGVsLCBvcHRpb25zOiB7IHNpZ25hbDogQWJvcnRTaWduYWwgfSkge1xuICAgIHRoaXMuI3NpZ25hbCA9IG9wdGlvbnMuc2lnbmFsO1xuICAgIHRoaXMuI3NpZ25hbC50aHJvd0lmQWJvcnRlZCgpO1xuICAgIHRoaXMuI3NpZ25hbC5hZGRFdmVudExpc3RlbmVyKFwiYWJvcnRcIiwgKCkgPT4gZGlzcG9zZSgpKTtcbiAgICBsZXQgYmluZGluZyA9IEJJTkRJTkdTLmdldE9yQ3JlYXRlKG1vZGVsKTtcbiAgICBsZXQgZXhwZXJpbWVudGFsOiBFeHBlcmltZW50YWwgPSB7XG4gICAgICAvLyBAdHMtZXhwZWN0LWVycm9yIC0gaW52b2tlLmJpbmQgbG9zZXMgZ2VuZXJpYyB0eXBlIHBhcmFtZXRlclxuICAgICAgaW52b2tlOiBpbnZva2UuYmluZChudWxsLCBtb2RlbCksXG4gICAgfTtcbiAgICBsZXQgZGlzcG9zZSA9IHNvbGlkLmNyZWF0ZVJvb3QoKGRpc3Bvc2UpID0+IHtcbiAgICAgIC8vIERPTVdpZGdldE1vZGVsIGlzIHVudHlwZWQgYnkgdHJhaXQgc2hhcGU7IHdlIGtub3cgdGhlIGFueXdpZGdldCB0cmFpdHMsIHNvIG5hcnJvdyB0byBBbnlNb2RlbDxTdGF0ZT4gZm9yIHR5cGUtc2FmZSBgLmdldCgpYCBhY2Nlc3NcbiAgICAgIC8vIG94bGludC1kaXNhYmxlLW5leHQtbGluZSB0eXBlc2NyaXB0LWVzbGludC9uby11bnNhZmUtdHlwZS1hc3NlcnRpb24gLS0gc2VlIGFib3ZlXG4gICAgICBsZXQgdHlwZWRNb2RlbCA9IG1vZGVsIGFzIHVua25vd24gYXMgQW55TW9kZWw8U3RhdGU+O1xuICAgICAgbGV0IGlkID0gdHlwZWRNb2RlbC5nZXQoXCJfYW55d2lkZ2V0X2lkXCIpO1xuICAgICAgbGV0IGNzcyA9IG9ic2VydmUodHlwZWRNb2RlbCwgXCJfY3NzXCIsIHsgc2lnbmFsOiB0aGlzLiNzaWduYWwgfSk7XG4gICAgICBsZXQgZXNtID0gb2JzZXJ2ZSh0eXBlZE1vZGVsLCBcIl9lc21cIiwgeyBzaWduYWw6IHRoaXMuI3NpZ25hbCB9KTtcbiAgICAgIGxldCBbd2lkZ2V0UmVzdWx0LCBzZXRXaWRnZXRSZXN1bHRdID0gc29saWQuY3JlYXRlU2lnbmFsPFJlc3VsdDxBbnlXaWRnZXQ+Pih7XG4gICAgICAgIHN0YXR1czogXCJwZW5kaW5nXCIsXG4gICAgICB9KTtcbiAgICAgIHRoaXMuI3dpZGdldFJlc3VsdCA9IHdpZGdldFJlc3VsdDtcblxuICAgICAgc29saWQuY3JlYXRlRWZmZWN0KFxuICAgICAgICBzb2xpZC5vbihjc3MsICgpID0+IGNvbnNvbGUuZGVidWcoYFthbnl3aWRnZXRdIGNzcyBob3QgdXBkYXRlZDogJHtpZH1gKSwgeyBkZWZlcjogdHJ1ZSB9KSxcbiAgICAgICk7XG4gICAgICBzb2xpZC5jcmVhdGVFZmZlY3QoXG4gICAgICAgIHNvbGlkLm9uKGVzbSwgKCkgPT4gY29uc29sZS5kZWJ1ZyhgW2FueXdpZGdldF0gZXNtIGhvdCB1cGRhdGVkOiAke2lkfWApLCB7IGRlZmVyOiB0cnVlIH0pLFxuICAgICAgKTtcbiAgICAgIHNvbGlkLmNyZWF0ZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIHJldHVybiBsb2FkQ3NzKGNzcygpLCBpZCk7XG4gICAgICB9KTtcbiAgICAgIHNvbGlkLmNyZWF0ZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIC8vIFBlci1lZmZlY3QgY29udHJvbGxlciBzbyBhIHN0YWxlIGxvYWRXaWRnZXQgcmVzb2x1dGlvbiBmcm9tIGFcbiAgICAgICAgLy8gcHJldmlvdXMgX2VzbSB2YWx1ZSBjYW5ub3Qgb3ZlcndyaXRlIGEgbmV3ZXIgb25lLiBTb2xpZCBmaXJlc1xuICAgICAgICAvLyBvbkNsZWFudXAgYmVmb3JlIHJlLXJ1bm5pbmcgdGhlIGVmZmVjdCwgYWJvcnRpbmcgdGhlIHByaW9yIGxvYWQuXG4gICAgICAgIGxldCBjb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xuICAgICAgICBzb2xpZC5vbkNsZWFudXAoKCkgPT4gY29udHJvbGxlci5hYm9ydCgpKTtcbiAgICAgICAgbG9hZFdpZGdldChlc20oKSwgaWQpXG4gICAgICAgICAgLnRoZW4oYXN5bmMgKHdpZGdldCkgPT4ge1xuICAgICAgICAgICAgaWYgKGNvbnRyb2xsZXIuc2lnbmFsLmFib3J0ZWQpIHJldHVybjtcbiAgICAgICAgICAgIGF3YWl0IGJpbmRpbmcuYmluZCh3aWRnZXQsIHsgZXhwZXJpbWVudGFsIH0pO1xuICAgICAgICAgICAgaWYgKGNvbnRyb2xsZXIuc2lnbmFsLmFib3J0ZWQpIHJldHVybjtcbiAgICAgICAgICAgIHNldFdpZGdldFJlc3VsdCh7IHN0YXR1czogXCJyZWFkeVwiLCBkYXRhOiB3aWRnZXQgfSk7XG4gICAgICAgICAgfSlcbiAgICAgICAgICAuY2F0Y2goKGVycm9yKSA9PiB7XG4gICAgICAgICAgICBpZiAoY29udHJvbGxlci5zaWduYWwuYWJvcnRlZCkgcmV0dXJuO1xuICAgICAgICAgICAgc2V0V2lkZ2V0UmVzdWx0KHsgc3RhdHVzOiBcImVycm9yXCIsIGVycm9yIH0pO1xuICAgICAgICAgIH0pO1xuICAgICAgfSk7XG5cbiAgICAgIHJldHVybiBkaXNwb3NlO1xuICAgIH0pO1xuICB9XG5cbiAgYXN5bmMgY3JlYXRlVmlldyh2aWV3OiBET01XaWRnZXRWaWV3LCBvcHRpb25zOiB7IHNpZ25hbDogQWJvcnRTaWduYWwgfSk6IFByb21pc2U8dm9pZD4ge1xuICAgIGxldCBtb2RlbCA9IHZpZXcubW9kZWw7XG4gICAgbGV0IHNpZ25hbCA9IEFib3J0U2lnbmFsLmFueShbdGhpcy4jc2lnbmFsLCBvcHRpb25zLnNpZ25hbF0pOyAvLyBlaXRoZXIgbW9kZWwgb3IgdmlldyBkZXN0cm95ZWRcbiAgICBzaWduYWwudGhyb3dJZkFib3J0ZWQoKTtcbiAgICBzaWduYWwuYWRkRXZlbnRMaXN0ZW5lcihcImFib3J0XCIsICgpID0+IGRpc3Bvc2UoKSk7XG4gICAgbGV0IGJpbmRpbmcgPSBCSU5ESU5HUy5nZXQobW9kZWwpO1xuICAgIGFzc2VydChiaW5kaW5nLCBcIlthbnl3aWRnZXRdIFdpZGdldEJpbmRpbmcgbm90IGZvdW5kLlwiKTtcbiAgICBsZXQgZXhwZXJpbWVudGFsOiBFeHBlcmltZW50YWwgPSB7XG4gICAgICAvLyBAdHMtZXhwZWN0LWVycm9yIC0gaW52b2tlLmJpbmQgbG9zZXMgZ2VuZXJpYyB0eXBlIHBhcmFtZXRlclxuICAgICAgaW52b2tlOiBpbnZva2UuYmluZChudWxsLCBtb2RlbCksXG4gICAgfTtcbiAgICBsZXQgaG9zdCA9IGNyZWF0ZUhvc3QobW9kZWwsIHsgc2lnbmFsIH0pO1xuICAgIGxldCBkaXNwb3NlID0gc29saWQuY3JlYXRlUm9vdCgoZGlzcG9zZSkgPT4ge1xuICAgICAgc29saWQuY3JlYXRlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgLy8gQ2xlYXIgYWxsIHByZXZpb3VzIGV2ZW50IGxpc3RlbmVycyBmcm9tIHRoaXMgaG9vay5cbiAgICAgICAgbW9kZWwub2ZmKG51bGwsIG51bGwsIHZpZXcpO1xuICAgICAgICB2aWV3LiRlbC5lbXB0eSgpO1xuICAgICAgICBsZXQgcmVzdWx0ID0gdGhpcy4jd2lkZ2V0UmVzdWx0KCk7XG4gICAgICAgIGlmIChyZXN1bHQuc3RhdHVzID09PSBcInBlbmRpbmdcIikge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAocmVzdWx0LnN0YXR1cyA9PT0gXCJlcnJvclwiKSB7XG4gICAgICAgICAgdGhyb3dBbnl3aWRnZXRFcnJvcihyZXN1bHQuZXJyb3IpO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBsZXQgY29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcbiAgICAgICAgc29saWQub25DbGVhbnVwKCgpID0+IGNvbnRyb2xsZXIuYWJvcnQoKSk7XG4gICAgICAgIFByb21pc2UucmVzb2x2ZSgpXG4gICAgICAgICAgLnRoZW4oKCkgPT5cbiAgICAgICAgICAgIGJpbmRpbmcuY3JlYXRlVmlldyh2aWV3LCB7XG4gICAgICAgICAgICAgIHNpZ25hbDogQWJvcnRTaWduYWwuYW55KFtzaWduYWwsIGNvbnRyb2xsZXIuc2lnbmFsXSksXG4gICAgICAgICAgICAgIGV4cGVyaW1lbnRhbCxcbiAgICAgICAgICAgICAgaG9zdCxcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgIClcbiAgICAgICAgICAuY2F0Y2goKGVycm9yKSA9PiB0aHJvd0FueXdpZGdldEVycm9yKGVycm9yKSk7XG4gICAgICB9KTtcbiAgICAgIHJldHVybiAoKSA9PiBkaXNwb3NlKCk7XG4gICAgfSk7XG4gIH1cbn1cbiIsImltcG9ydCB7IEJJTkRJTkdTIH0gZnJvbSBcIi4vYmluZGluZy50c1wiO1xuaW1wb3J0IHsgUnVudGltZSB9IGZyb20gXCIuL3J1bnRpbWUudHNcIjtcbmltcG9ydCB7IGFzc2VydCB9IGZyb20gXCIuL3V0aWwudHNcIjtcblxuLy8gQHRzLWV4cGVjdC1lcnJvciAtIGluamVjdGVkIGJ5IGJ1bmRsZXJcbmxldCB2ZXJzaW9uOiBzdHJpbmcgPSBnbG9iYWxUaGlzLlZFUlNJT047XG5cbmludGVyZmFjZSBXaWRnZXRGYWN0b3J5T3B0aW9ucyB7XG4gIERPTVdpZGdldE1vZGVsOiB0eXBlb2YgaW1wb3J0KFwiQGp1cHl0ZXItd2lkZ2V0cy9iYXNlXCIpLkRPTVdpZGdldE1vZGVsO1xuICBET01XaWRnZXRWaWV3OiB0eXBlb2YgaW1wb3J0KFwiQGp1cHl0ZXItd2lkZ2V0cy9iYXNlXCIpLkRPTVdpZGdldFZpZXc7XG59XG5cbmludGVyZmFjZSBXaWRnZXRGYWN0b3J5UmVzdWx0IHtcbiAgQW55TW9kZWw6IHR5cGVvZiBpbXBvcnQoXCJAanVweXRlci13aWRnZXRzL2Jhc2VcIikuRE9NV2lkZ2V0TW9kZWw7XG4gIEFueVZpZXc6IHR5cGVvZiBpbXBvcnQoXCJAanVweXRlci13aWRnZXRzL2Jhc2VcIikuRE9NV2lkZ2V0Vmlldztcbn1cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gKHtcbiAgRE9NV2lkZ2V0TW9kZWwsXG4gIERPTVdpZGdldFZpZXcsXG59OiBXaWRnZXRGYWN0b3J5T3B0aW9ucyk6IFdpZGdldEZhY3RvcnlSZXN1bHQge1xuICBsZXQgUlVOVElNRVMgPSBuZXcgV2Vha01hcDxJbnN0YW5jZVR5cGU8dHlwZW9mIERPTVdpZGdldE1vZGVsPiwgUnVudGltZT4oKTtcblxuICBjbGFzcyBBbnlNb2RlbCBleHRlbmRzIERPTVdpZGdldE1vZGVsIHtcbiAgICBzdGF0aWMgbW9kZWxfbmFtZSA9IFwiQW55TW9kZWxcIjtcbiAgICBzdGF0aWMgbW9kZWxfbW9kdWxlID0gXCJhbnl3aWRnZXRcIjtcbiAgICBzdGF0aWMgbW9kZWxfbW9kdWxlX3ZlcnNpb24gPSB2ZXJzaW9uO1xuXG4gICAgc3RhdGljIHZpZXdfbmFtZSA9IFwiQW55Vmlld1wiO1xuICAgIHN0YXRpYyB2aWV3X21vZHVsZSA9IFwiYW55d2lkZ2V0XCI7XG4gICAgc3RhdGljIHZpZXdfbW9kdWxlX3ZlcnNpb24gPSB2ZXJzaW9uO1xuXG4gICAgaW5pdGlhbGl6ZSguLi5hcmdzOiBQYXJhbWV0ZXJzPEluc3RhbmNlVHlwZTx0eXBlb2YgRE9NV2lkZ2V0TW9kZWw+W1wiaW5pdGlhbGl6ZVwiXT4pOiB2b2lkIHtcbiAgICAgIHN1cGVyLmluaXRpYWxpemUoLi4uYXJncyk7XG4gICAgICBsZXQgY29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcbiAgICAgIHRoaXMub25jZShcImRlc3Ryb3lcIiwgKCkgPT4ge1xuICAgICAgICBjb250cm9sbGVyLmFib3J0KFwiW2FueXdpZGdldF0gUnVudGltZSBkZXN0cm95ZWQuXCIpO1xuICAgICAgICBCSU5ESU5HUy5kZXN0cm95KHRoaXMpO1xuICAgICAgICBSVU5USU1FUy5kZWxldGUodGhpcyk7XG4gICAgICB9KTtcbiAgICAgIFJVTlRJTUVTLnNldCh0aGlzLCBuZXcgUnVudGltZSh0aGlzLCB7IHNpZ25hbDogY29udHJvbGxlci5zaWduYWwgfSkpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFdlIG92ZXJyaWRlIHRvIHN1cHBvcnQgYmluYXJ5IHRyYWlsZXRzIGJlY2F1c2UgSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeSgpKVxuICAgICAqIGRvZXMgbm90IHByb3Blcmx5IGNsb25lIGJpbmFyeSBkYXRhIChpdCBqdXN0IHJldHVybnMgYW4gZW1wdHkgb2JqZWN0KS5cbiAgICAgKlxuICAgICAqIGh0dHBzOi8vZ2l0aHViLmNvbS9qdXB5dGVyLXdpZGdldHMvaXB5d2lkZ2V0cy9ibG9iLzQ3MDU4YTM3M2QyYzJiM2FjZjEwMTY3N2IyNzQ1ZTE0Yjc2ZGQ3NGIvcGFja2FnZXMvYmFzZS9zcmMvd2lkZ2V0LnRzI0w1NjItTDU4M1xuICAgICAqL1xuICAgIHNlcmlhbGl6ZShzdGF0ZTogUmVjb3JkPHN0cmluZywgYW55Pik6IFJlY29yZDxzdHJpbmcsIGFueT4ge1xuICAgICAgLy8gb3hsaW50LWRpc2FibGUtbmV4dC1saW5lIHR5cGVzY3JpcHQtZXNsaW50L25vLXVuc2FmZS10eXBlLWFzc2VydGlvbiAtLSBhY2Nlc3Npbmcgc3RhdGljIGAuc2VyaWFsaXplcnNgIG9uIGB0aGlzLmNvbnN0cnVjdG9yYFxuICAgICAgbGV0IHNlcmlhbGl6ZXJzID0gKHRoaXMuY29uc3RydWN0b3IgYXMgdHlwZW9mIERPTVdpZGdldE1vZGVsKS5zZXJpYWxpemVycyB8fCB7fTtcbiAgICAgIGZvciAobGV0IGsgb2YgT2JqZWN0LmtleXMoc3RhdGUpKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgbGV0IHNlcmlhbGl6ZSA9IHNlcmlhbGl6ZXJzW2tdPy5zZXJpYWxpemU7XG4gICAgICAgICAgaWYgKHNlcmlhbGl6ZSkge1xuICAgICAgICAgICAgc3RhdGVba10gPSBzZXJpYWxpemUoc3RhdGVba10sIHRoaXMpO1xuICAgICAgICAgIH0gZWxzZSBpZiAoayA9PT0gXCJsYXlvdXRcIiB8fCBrID09PSBcInN0eWxlXCIpIHtcbiAgICAgICAgICAgIC8vIFRoZXNlIGtleXMgY29tZSBmcm9tIGlweXdpZGdldHMsIHJlbHkgb24gSlNPTi5zdHJpbmdpZnkgdHJpY2suXG4gICAgICAgICAgICBzdGF0ZVtrXSA9IEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkoc3RhdGVba10pKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgc3RhdGVba10gPSBzdHJ1Y3R1cmVkQ2xvbmUoc3RhdGVba10pO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAodHlwZW9mIHN0YXRlW2tdPy50b0pTT04gPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgICAgICAgc3RhdGVba10gPSBzdGF0ZVtrXS50b0pTT04oKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3Igc2VyaWFsaXppbmcgd2lkZ2V0IHN0YXRlIGF0dHJpYnV0ZTogXCIsIGspO1xuICAgICAgICAgIHRocm93IGU7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJldHVybiBzdGF0ZTtcbiAgICB9XG4gIH1cblxuICBjbGFzcyBBbnlWaWV3IGV4dGVuZHMgRE9NV2lkZ2V0VmlldyB7XG4gICAgI2NvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG4gICAgYXN5bmMgcmVuZGVyKCk6IFByb21pc2U8dm9pZD4ge1xuICAgICAgbGV0IHJ1bnRpbWUgPSBSVU5USU1FUy5nZXQodGhpcy5tb2RlbCk7XG4gICAgICBhc3NlcnQocnVudGltZSwgXCJbYW55d2lkZ2V0XSBSdW50aW1lIG5vdCBmb3VuZC5cIik7XG4gICAgICBhd2FpdCBydW50aW1lLmNyZWF0ZVZpZXcodGhpcywgeyBzaWduYWw6IHRoaXMuI2NvbnRyb2xsZXIuc2lnbmFsIH0pO1xuICAgIH1cbiAgICByZW1vdmUoKTogdm9pZCB7XG4gICAgICB0aGlzLiNjb250cm9sbGVyLmFib3J0KFwiW2FueXdpZGdldF0gVmlldyBkZXN0cm95ZWQuXCIpO1xuICAgICAgc3VwZXIucmVtb3ZlKCk7XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIHsgQW55TW9kZWwsIEFueVZpZXcgfTtcbn1cbiIsImltcG9ydCBjcmVhdGUgZnJvbSBcIi4vd2lkZ2V0LnRzXCI7XG5cbi8vIEB0cy1leHBlY3QtZXJyb3IgLS0gZGVmaW5lIGlzIGEgZ2xvYmFsIHByb3ZpZGVkIGJ5IHRoZSBub3RlYm9vayBydW50aW1lLlxuZGVmaW5lKFtcIkBqdXB5dGVyLXdpZGdldHMvYmFzZVwiXSwgY3JlYXRlKTtcbiIsIl9fd2VicGFja19yZXF1aXJlX18ubyA9IChvYmosIHByb3ApID0+IChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqLCBwcm9wKSkiLCJcbl9fd2VicGFja19yZXF1aXJlX18uUyA9IHt9O1xuX193ZWJwYWNrX3JlcXVpcmVfXy5pbml0aWFsaXplU2hhcmluZ0RhdGEgPSB7IHNjb3BlVG9TaGFyaW5nRGF0YU1hcHBpbmc6IHsgIH0sIHVuaXF1ZU5hbWU6IFwiQGFueXdpZGdldC9tb25vcmVwb1wiIH07XG52YXIgaW5pdFByb21pc2VzID0ge307XG52YXIgaW5pdFRva2VucyA9IHt9O1xuX193ZWJwYWNrX3JlcXVpcmVfXy5JID0gZnVuY3Rpb24obmFtZSwgaW5pdFNjb3BlKSB7XG5cdGlmICghaW5pdFNjb3BlKSBpbml0U2NvcGUgPSBbXTtcblx0Ly8gaGFuZGxpbmcgY2lyY3VsYXIgaW5pdCBjYWxsc1xuXHR2YXIgaW5pdFRva2VuID0gaW5pdFRva2Vuc1tuYW1lXTtcblx0aWYgKCFpbml0VG9rZW4pIGluaXRUb2tlbiA9IGluaXRUb2tlbnNbbmFtZV0gPSB7fTtcblx0aWYgKGluaXRTY29wZS5pbmRleE9mKGluaXRUb2tlbikgPj0gMCkgcmV0dXJuO1xuXHRpbml0U2NvcGUucHVzaChpbml0VG9rZW4pO1xuXHQvLyBvbmx5IHJ1bnMgb25jZVxuXHRpZiAoaW5pdFByb21pc2VzW25hbWVdKSByZXR1cm4gaW5pdFByb21pc2VzW25hbWVdO1xuXHQvLyBjcmVhdGVzIGEgbmV3IHNoYXJlIHNjb3BlIGlmIG5lZWRlZFxuXHRpZiAoIV9fd2VicGFja19yZXF1aXJlX18ubyhfX3dlYnBhY2tfcmVxdWlyZV9fLlMsIG5hbWUpKVxuXHRcdF9fd2VicGFja19yZXF1aXJlX18uU1tuYW1lXSA9IHt9O1xuXHQvLyBydW5zIGFsbCBpbml0IHNuaXBwZXRzIGZyb20gYWxsIG1vZHVsZXMgcmVhY2hhYmxlXG5cdHZhciBzY29wZSA9IF9fd2VicGFja19yZXF1aXJlX18uU1tuYW1lXTtcblx0dmFyIHdhcm4gPSBmdW5jdGlvbiAobXNnKSB7XG5cdFx0aWYgKHR5cGVvZiBjb25zb2xlICE9PSBcInVuZGVmaW5lZFwiICYmIGNvbnNvbGUud2FybikgY29uc29sZS53YXJuKG1zZyk7XG5cdH07XG5cdHZhciB1bmlxdWVOYW1lID0gX193ZWJwYWNrX3JlcXVpcmVfXy5pbml0aWFsaXplU2hhcmluZ0RhdGEudW5pcXVlTmFtZTtcblx0dmFyIHJlZ2lzdGVyID0gZnVuY3Rpb24gKG5hbWUsIHZlcnNpb24sIGZhY3RvcnksIGVhZ2VyKSB7XG5cdFx0dmFyIHZlcnNpb25zID0gKHNjb3BlW25hbWVdID0gc2NvcGVbbmFtZV0gfHwge30pO1xuXHRcdHZhciBhY3RpdmVWZXJzaW9uID0gdmVyc2lvbnNbdmVyc2lvbl07XG5cdFx0aWYgKFxuXHRcdFx0IWFjdGl2ZVZlcnNpb24gfHxcblx0XHRcdCghYWN0aXZlVmVyc2lvbi5sb2FkZWQgJiZcblx0XHRcdFx0KCFlYWdlciAhPSAhYWN0aXZlVmVyc2lvbi5lYWdlclxuXHRcdFx0XHRcdD8gZWFnZXJcblx0XHRcdFx0XHQ6IHVuaXF1ZU5hbWUgPiBhY3RpdmVWZXJzaW9uLmZyb20pKVxuXHRcdClcblx0XHRcdHZlcnNpb25zW3ZlcnNpb25dID0geyBnZXQ6IGZhY3RvcnksIGZyb206IHVuaXF1ZU5hbWUsIGVhZ2VyOiAhIWVhZ2VyIH07XG5cdH07XG5cdHZhciBpbml0RXh0ZXJuYWwgPSBmdW5jdGlvbiAoaWQpIHtcblx0XHR2YXIgaGFuZGxlRXJyb3IgPSBmdW5jdGlvbiAoZXJyKSB7XG5cdFx0XHR3YXJuKFwiSW5pdGlhbGl6YXRpb24gb2Ygc2hhcmluZyBleHRlcm5hbCBmYWlsZWQ6IFwiICsgZXJyKTtcblx0XHR9O1xuXHRcdHRyeSB7XG5cdFx0XHR2YXIgbW9kdWxlID0gX193ZWJwYWNrX3JlcXVpcmVfXyhpZCk7XG5cdFx0XHRpZiAoIW1vZHVsZSkgcmV0dXJuO1xuXHRcdFx0dmFyIGluaXRGbiA9IGZ1bmN0aW9uIChtb2R1bGUpIHtcblx0XHRcdFx0cmV0dXJuIChcblx0XHRcdFx0XHRtb2R1bGUgJiZcblx0XHRcdFx0XHRtb2R1bGUuaW5pdCAmJlxuXHRcdFx0XHRcdG1vZHVsZS5pbml0KF9fd2VicGFja19yZXF1aXJlX18uU1tuYW1lXSwgaW5pdFNjb3BlKVxuXHRcdFx0XHQpO1xuXHRcdFx0fTtcblx0XHRcdGlmIChtb2R1bGUudGhlbikgcmV0dXJuIHByb21pc2VzLnB1c2gobW9kdWxlLnRoZW4oaW5pdEZuLCBoYW5kbGVFcnJvcikpO1xuXHRcdFx0dmFyIGluaXRSZXN1bHQgPSBpbml0Rm4obW9kdWxlKTtcblx0XHRcdGlmIChpbml0UmVzdWx0ICYmIGluaXRSZXN1bHQudGhlbilcblx0XHRcdFx0cmV0dXJuIHByb21pc2VzLnB1c2goaW5pdFJlc3VsdFtcImNhdGNoXCJdKGhhbmRsZUVycm9yKSk7XG5cdFx0fSBjYXRjaCAoZXJyKSB7XG5cdFx0XHRoYW5kbGVFcnJvcihlcnIpO1xuXHRcdH1cblx0fTtcblx0dmFyIHByb21pc2VzID0gW107XG5cdHZhciBzY29wZVRvU2hhcmluZ0RhdGFNYXBwaW5nID0gX193ZWJwYWNrX3JlcXVpcmVfXy5pbml0aWFsaXplU2hhcmluZ0RhdGEuc2NvcGVUb1NoYXJpbmdEYXRhTWFwcGluZztcblx0aWYgKHNjb3BlVG9TaGFyaW5nRGF0YU1hcHBpbmdbbmFtZV0pIHtcblx0XHRzY29wZVRvU2hhcmluZ0RhdGFNYXBwaW5nW25hbWVdLmZvckVhY2goZnVuY3Rpb24gKHN0YWdlKSB7XG5cdFx0XHRpZiAodHlwZW9mIHN0YWdlID09PSBcIm9iamVjdFwiKSByZWdpc3RlcihzdGFnZS5uYW1lLCBzdGFnZS52ZXJzaW9uLCBzdGFnZS5mYWN0b3J5LCBzdGFnZS5lYWdlcik7XG5cdFx0XHRlbHNlIGluaXRFeHRlcm5hbChzdGFnZSlcblx0XHR9KTtcblx0fVxuXHRpZiAoIXByb21pc2VzLmxlbmd0aCkgcmV0dXJuIChpbml0UHJvbWlzZXNbbmFtZV0gPSAxKTtcblx0cmV0dXJuIChpbml0UHJvbWlzZXNbbmFtZV0gPSBQcm9taXNlLmFsbChwcm9taXNlcykudGhlbihmdW5jdGlvbiAoKSB7XG5cdFx0cmV0dXJuIChpbml0UHJvbWlzZXNbbmFtZV0gPSAxKTtcblx0fSkpO1xufTtcblxuIiwiXG5fX3dlYnBhY2tfcmVxdWlyZV9fLmNvbnN1bWVzTG9hZGluZ0RhdGEgPSB7IGNodW5rTWFwcGluZzoge30sIG1vZHVsZUlkVG9Db25zdW1lRGF0YU1hcHBpbmc6IHt9LCBpbml0aWFsQ29uc3VtZXM6IFtdIH07XG52YXIgc3BsaXRBbmRDb252ZXJ0ID0gZnVuY3Rpb24oc3RyKSB7XG4gIHJldHVybiBzdHIuc3BsaXQoXCIuXCIpLm1hcChmdW5jdGlvbihpdGVtKSB7XG4gICAgcmV0dXJuICtpdGVtID09IGl0ZW0gPyAraXRlbSA6IGl0ZW07XG4gIH0pO1xufTtcbnZhciBwYXJzZVJhbmdlID0gZnVuY3Rpb24oc3RyKSB7XG4gIC8vIHNlZSBodHRwczovL2RvY3MubnBtanMuY29tL21pc2Mvc2VtdmVyI3JhbmdlLWdyYW1tYXIgZm9yIGdyYW1tYXJcbiAgdmFyIHBhcnNlUGFydGlhbCA9IGZ1bmN0aW9uKHN0cikge1xuICAgIHZhciBtYXRjaCA9IC9eKFteLStdKyk/KD86LShbXitdKykpPyg/OlxcKyguKykpPyQvLmV4ZWMoc3RyKTtcbiAgICB2YXIgdmVyID0gbWF0Y2hbMV0gPyBbMF0uY29uY2F0KHNwbGl0QW5kQ29udmVydChtYXRjaFsxXSkpIDogWzBdO1xuICAgIGlmIChtYXRjaFsyXSkge1xuICAgICAgdmVyLmxlbmd0aCsrO1xuICAgICAgdmVyLnB1c2guYXBwbHkodmVyLCBzcGxpdEFuZENvbnZlcnQobWF0Y2hbMl0pKTtcbiAgICB9XG5cbiAgICAvLyByZW1vdmUgdHJhaWxpbmcgYW55IG1hdGNoZXJzXG4gICAgbGV0IGxhc3QgPSB2ZXJbdmVyLmxlbmd0aCAtIDFdO1xuICAgIHdoaWxlIChcbiAgICAgIHZlci5sZW5ndGggJiZcbiAgICAgIChsYXN0ID09PSB1bmRlZmluZWQgfHwgL15bKnhYXSQvLnRlc3QoLyoqIEB0eXBlIHtzdHJpbmd9ICovIChsYXN0KSkpXG4gICAgKSB7XG4gICAgICB2ZXIucG9wKCk7XG4gICAgICBsYXN0ID0gdmVyW3Zlci5sZW5ndGggLSAxXTtcbiAgICB9XG5cbiAgICByZXR1cm4gdmVyO1xuICB9O1xuICB2YXIgdG9GaXhlZCA9IGZ1bmN0aW9uKHJhbmdlKSB7XG4gICAgaWYgKHJhbmdlLmxlbmd0aCA9PT0gMSkge1xuICAgICAgLy8gU3BlY2lhbCBjYXNlIGZvciBcIipcIiBpcyBcIngueC54XCIgaW5zdGVhZCBvZiBcIj1cIlxuICAgICAgcmV0dXJuIFswXTtcbiAgICB9IGVsc2UgaWYgKHJhbmdlLmxlbmd0aCA9PT0gMikge1xuICAgICAgLy8gU3BlY2lhbCBjYXNlIGZvciBcIjFcIiBpcyBcIjEueC54XCIgaW5zdGVhZCBvZiBcIj0xXCJcbiAgICAgIHJldHVybiBbMV0uY29uY2F0KHJhbmdlLnNsaWNlKDEpKTtcbiAgICB9IGVsc2UgaWYgKHJhbmdlLmxlbmd0aCA9PT0gMykge1xuICAgICAgLy8gU3BlY2lhbCBjYXNlIGZvciBcIjEuMlwiIGlzIFwiMS4yLnhcIiBpbnN0ZWFkIG9mIFwiPTEuMlwiXG4gICAgICByZXR1cm4gWzJdLmNvbmNhdChyYW5nZS5zbGljZSgxKSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiBbcmFuZ2UubGVuZ3RoXS5jb25jYXQocmFuZ2Uuc2xpY2UoMSkpO1xuICAgIH1cbiAgfTtcbiAgdmFyIG5lZ2F0ZSA9IGZ1bmN0aW9uKHJhbmdlKSB7XG4gICAgcmV0dXJuIFstcmFuZ2VbMF0gLSAxXS5jb25jYXQocmFuZ2Uuc2xpY2UoMSkpO1xuICB9O1xuICB2YXIgcGFyc2VTaW1wbGUgPSBmdW5jdGlvbihzdHIpIHtcbiAgICAvLyBzaW1wbGUgICAgICAgOjo9IHByaW1pdGl2ZSB8IHBhcnRpYWwgfCB0aWxkZSB8IGNhcmV0XG4gICAgLy8gcHJpbWl0aXZlICAgIDo6PSAoICc8JyB8ICc+JyB8ICc+PScgfCAnPD0nIHwgJz0nIHwgJyEnICkgKCAnICcgKSAqIHBhcnRpYWxcbiAgICAvLyB0aWxkZSAgICAgICAgOjo9ICd+JyAoICcgJyApICogcGFydGlhbFxuICAgIC8vIGNhcmV0ICAgICAgICA6Oj0gJ14nICggJyAnICkgKiBwYXJ0aWFsXG4gICAgY29uc3QgbWF0Y2ggPSAvXihcXF58fnw8PXw8fD49fD58PXx2fCEpLy5leGVjKHN0cik7XG4gICAgY29uc3Qgc3RhcnQgPSBtYXRjaCA/IG1hdGNoWzBdIDogXCJcIjtcbiAgICBjb25zdCByZW1haW5kZXIgPSBwYXJzZVBhcnRpYWwoXG4gICAgICBzdGFydC5sZW5ndGggPyBzdHIuc2xpY2Uoc3RhcnQubGVuZ3RoKS50cmltKCkgOiBzdHIudHJpbSgpXG4gICAgKTtcbiAgICBzd2l0Y2ggKHN0YXJ0KSB7XG4gICAgICBjYXNlIFwiXlwiOlxuICAgICAgICBpZiAocmVtYWluZGVyLmxlbmd0aCA+IDEgJiYgcmVtYWluZGVyWzFdID09PSAwKSB7XG4gICAgICAgICAgaWYgKHJlbWFpbmRlci5sZW5ndGggPiAyICYmIHJlbWFpbmRlclsyXSA9PT0gMCkge1xuICAgICAgICAgICAgcmV0dXJuIFszXS5jb25jYXQocmVtYWluZGVyLnNsaWNlKDEpKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIFsyXS5jb25jYXQocmVtYWluZGVyLnNsaWNlKDEpKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gWzFdLmNvbmNhdChyZW1haW5kZXIuc2xpY2UoMSkpO1xuICAgICAgY2FzZSBcIn5cIjpcbiAgICAgICAgcmV0dXJuIFsyXS5jb25jYXQocmVtYWluZGVyLnNsaWNlKDEpKTtcbiAgICAgIGNhc2UgXCI+PVwiOlxuICAgICAgICByZXR1cm4gcmVtYWluZGVyO1xuICAgICAgY2FzZSBcIj1cIjpcbiAgICAgIGNhc2UgXCJ2XCI6XG4gICAgICBjYXNlIFwiXCI6XG4gICAgICAgIHJldHVybiB0b0ZpeGVkKHJlbWFpbmRlcik7XG4gICAgICBjYXNlIFwiPFwiOlxuICAgICAgICByZXR1cm4gbmVnYXRlKHJlbWFpbmRlcik7XG4gICAgICBjYXNlIFwiPlwiOiB7XG4gICAgICAgIC8vIGFuZCggPj0sIG5vdCggPSApICkgPT4gPj0sID0sIG5vdCwgYW5kXG4gICAgICAgIGNvbnN0IGZpeGVkID0gdG9GaXhlZChyZW1haW5kZXIpO1xuICAgICAgICByZXR1cm4gWywgZml4ZWQsIDAsIHJlbWFpbmRlciwgMl07XG4gICAgICB9XG4gICAgICBjYXNlIFwiPD1cIjpcbiAgICAgICAgLy8gb3IoIDwsID0gKSA9PiA8LCA9LCBvclxuICAgICAgICByZXR1cm4gWywgdG9GaXhlZChyZW1haW5kZXIpLCBuZWdhdGUocmVtYWluZGVyKSwgMV07XG4gICAgICBjYXNlIFwiIVwiOiB7XG4gICAgICAgIC8vIG5vdCA9XG4gICAgICAgIGNvbnN0IGZpeGVkID0gdG9GaXhlZChyZW1haW5kZXIpO1xuICAgICAgICByZXR1cm4gWywgZml4ZWQsIDBdO1xuICAgICAgfVxuICAgICAgZGVmYXVsdDpcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiVW5leHBlY3RlZCBzdGFydCB2YWx1ZVwiKTtcbiAgICB9XG4gIH07XG4gIHZhciBjb21iaW5lID0gZnVuY3Rpb24oaXRlbXMsIGZuKSB7XG4gICAgaWYgKGl0ZW1zLmxlbmd0aCA9PT0gMSkgcmV0dXJuIGl0ZW1zWzBdO1xuICAgIGNvbnN0IGFyciA9IFtdO1xuICAgIGZvciAoY29uc3QgaXRlbSBvZiBpdGVtcy5zbGljZSgpLnJldmVyc2UoKSkge1xuICAgICAgaWYgKDAgaW4gaXRlbSkge1xuICAgICAgICBhcnIucHVzaChpdGVtKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGFyci5wdXNoLmFwcGx5KGFyciwgaXRlbS5zbGljZSgxKSk7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBbLF0uY29uY2F0KGFyciwgaXRlbXMuc2xpY2UoMSkubWFwKCgpID0+IGZuKSk7XG4gIH07XG4gIHZhciBwYXJzZVJhbmdlID0gZnVuY3Rpb24oc3RyKSB7XG4gICAgLy8gcmFuZ2UgICAgICA6Oj0gaHlwaGVuIHwgc2ltcGxlICggJyAnICggJyAnICkgKiBzaW1wbGUgKSAqIHwgJydcbiAgICAvLyBoeXBoZW4gICAgIDo6PSBwYXJ0aWFsICggJyAnICkgKiAnIC0gJyAoICcgJyApICogcGFydGlhbFxuICAgIGNvbnN0IGl0ZW1zID0gc3RyLnNwbGl0KC9cXHMrLVxccysvKTtcbiAgICBpZiAoaXRlbXMubGVuZ3RoID09PSAxKSB7XG5cdFx0XHRzdHIgPSBzdHIudHJpbSgpO1xuXHRcdFx0Y29uc3QgaXRlbXMgPSBbXTtcblx0XHRcdGNvbnN0IHIgPSAvWy0wLTlBLVphLXpdXFxzKy9nO1xuXHRcdFx0dmFyIHN0YXJ0ID0gMDtcblx0XHRcdHZhciBtYXRjaDtcblx0XHRcdHdoaWxlICgobWF0Y2ggPSByLmV4ZWMoc3RyKSkpIHtcblx0XHRcdFx0Y29uc3QgZW5kID0gbWF0Y2guaW5kZXggKyAxO1xuXHRcdFx0XHRpdGVtcy5wdXNoKHBhcnNlU2ltcGxlKHN0ci5zbGljZShzdGFydCwgZW5kKS50cmltKCkpKTtcblx0XHRcdFx0c3RhcnQgPSBlbmQ7XG5cdFx0XHR9XG5cdFx0XHRpdGVtcy5wdXNoKHBhcnNlU2ltcGxlKHN0ci5zbGljZShzdGFydCkudHJpbSgpKSk7XG4gICAgICByZXR1cm4gY29tYmluZShpdGVtcywgMik7XG4gICAgfVxuICAgIGNvbnN0IGEgPSBwYXJzZVBhcnRpYWwoaXRlbXNbMF0pO1xuICAgIGNvbnN0IGIgPSBwYXJzZVBhcnRpYWwoaXRlbXNbMV0pO1xuICAgIC8vID49YSA8PWIgPT4gYW5kKCA+PWEsIG9yKCA8YiwgPWIgKSApID0+ID49YSwgPGIsID1iLCBvciwgYW5kXG4gICAgcmV0dXJuIFssIHRvRml4ZWQoYiksIG5lZ2F0ZShiKSwgMSwgYSwgMl07XG4gIH07XG4gIHZhciBwYXJzZUxvZ2ljYWxPciA9IGZ1bmN0aW9uKHN0cikge1xuICAgIC8vIHJhbmdlLXNldCAgOjo9IHJhbmdlICggbG9naWNhbC1vciByYW5nZSApICpcbiAgICAvLyBsb2dpY2FsLW9yIDo6PSAoICcgJyApICogJ3x8JyAoICcgJyApICpcbiAgICBjb25zdCBpdGVtcyA9IHN0ci5zcGxpdCgvXFxzKlxcfFxcfFxccyovKS5tYXAocGFyc2VSYW5nZSk7XG4gICAgcmV0dXJuIGNvbWJpbmUoaXRlbXMsIDEpO1xuICB9O1xuICByZXR1cm4gcGFyc2VMb2dpY2FsT3Ioc3RyKTtcbn07XG52YXIgcGFyc2VWZXJzaW9uID0gZnVuY3Rpb24oc3RyKSB7XG5cdHZhciBtYXRjaCA9IC9eKFteLStdKyk/KD86LShbXitdKykpPyg/OlxcKyguKykpPyQvLmV4ZWMoc3RyKTtcblx0LyoqIEB0eXBlIHsoc3RyaW5nfG51bWJlcnx1bmRlZmluZWR8W10pW119ICovXG5cdHZhciB2ZXIgPSBtYXRjaFsxXSA/IHNwbGl0QW5kQ29udmVydChtYXRjaFsxXSkgOiBbXTtcblx0aWYgKG1hdGNoWzJdKSB7XG5cdFx0dmVyLmxlbmd0aCsrO1xuXHRcdHZlci5wdXNoLmFwcGx5KHZlciwgc3BsaXRBbmRDb252ZXJ0KG1hdGNoWzJdKSk7XG5cdH1cblx0aWYgKG1hdGNoWzNdKSB7XG5cdFx0dmVyLnB1c2goW10pO1xuXHRcdHZlci5wdXNoLmFwcGx5KHZlciwgc3BsaXRBbmRDb252ZXJ0KG1hdGNoWzNdKSk7XG5cdH1cblx0cmV0dXJuIHZlcjtcbn1cbnZhciB2ZXJzaW9uTHQgPSBmdW5jdGlvbihhLCBiKSB7XG5cdGEgPSBwYXJzZVZlcnNpb24oYSk7XG5cdGIgPSBwYXJzZVZlcnNpb24oYik7XG5cdHZhciBpID0gMDtcblx0Zm9yICg7Oykge1xuXHRcdC8vIGEgICAgICAgYiAgRU9BICAgICBvYmplY3QgIHVuZGVmaW5lZCAgbnVtYmVyICBzdHJpbmdcblx0XHQvLyBFT0EgICAgICAgIGEgPT0gYiAgYSA8IGIgICBiIDwgYSAgICAgIGEgPCBiICAgYSA8IGJcblx0XHQvLyBvYmplY3QgICAgIGIgPCBhICAgKDApICAgICBiIDwgYSAgICAgIGEgPCBiICAgYSA8IGJcblx0XHQvLyB1bmRlZmluZWQgIGEgPCBiICAgYSA8IGIgICAoMCkgICAgICAgIGEgPCBiICAgYSA8IGJcblx0XHQvLyBudW1iZXIgICAgIGIgPCBhICAgYiA8IGEgICBiIDwgYSAgICAgICgxKSAgICAgYSA8IGJcblx0XHQvLyBzdHJpbmcgICAgIGIgPCBhICAgYiA8IGEgICBiIDwgYSAgICAgIGIgPCBhICAgKDEpXG5cdFx0Ly8gRU9BIGVuZCBvZiBhcnJheVxuXHRcdC8vICgwKSBjb250aW51ZSBvblxuXHRcdC8vICgxKSBjb21wYXJlIHRoZW0gdmlhIFwiPFwiXG5cblx0XHQvLyBIYW5kbGVzIGZpcnN0IHJvdyBpbiB0YWJsZVxuXHRcdGlmIChpID49IGEubGVuZ3RoKSByZXR1cm4gaSA8IGIubGVuZ3RoICYmICh0eXBlb2YgYltpXSlbMF0gIT0gXCJ1XCI7XG5cblx0XHR2YXIgYVZhbHVlID0gYVtpXTtcblx0XHR2YXIgYVR5cGUgPSAodHlwZW9mIGFWYWx1ZSlbMF07XG5cblx0XHQvLyBIYW5kbGVzIGZpcnN0IGNvbHVtbiBpbiB0YWJsZVxuXHRcdGlmIChpID49IGIubGVuZ3RoKSByZXR1cm4gYVR5cGUgPT0gXCJ1XCI7XG5cblx0XHR2YXIgYlZhbHVlID0gYltpXTtcblx0XHR2YXIgYlR5cGUgPSAodHlwZW9mIGJWYWx1ZSlbMF07XG5cblx0XHRpZiAoYVR5cGUgPT0gYlR5cGUpIHtcblx0XHRcdGlmIChhVHlwZSAhPSBcIm9cIiAmJiBhVHlwZSAhPSBcInVcIiAmJiBhVmFsdWUgIT0gYlZhbHVlKSB7XG5cdFx0XHRcdHJldHVybiBhVmFsdWUgPCBiVmFsdWU7XG5cdFx0XHR9XG5cdFx0XHRpKys7XG5cdFx0fSBlbHNlIHtcblx0XHRcdC8vIEhhbmRsZXMgcmVtYWluaW5nIGNhc2VzXG5cdFx0XHRpZiAoYVR5cGUgPT0gXCJvXCIgJiYgYlR5cGUgPT0gXCJuXCIpIHJldHVybiB0cnVlO1xuXHRcdFx0cmV0dXJuIGJUeXBlID09IFwic1wiIHx8IGFUeXBlID09IFwidVwiO1xuXHRcdH1cblx0fVxufVxudmFyIHJhbmdlVG9TdHJpbmcgPSBmdW5jdGlvbihyYW5nZSkge1xuXHR2YXIgZml4Q291bnQgPSByYW5nZVswXTtcblx0dmFyIHN0ciA9IFwiXCI7XG5cdGlmIChyYW5nZS5sZW5ndGggPT09IDEpIHtcblx0XHRyZXR1cm4gXCIqXCI7XG5cdH0gZWxzZSBpZiAoZml4Q291bnQgKyAwLjUpIHtcblx0XHRzdHIgKz1cblx0XHRcdGZpeENvdW50ID09IDBcblx0XHRcdFx0PyBcIj49XCJcblx0XHRcdFx0OiBmaXhDb3VudCA9PSAtMVxuXHRcdFx0XHQ/IFwiPFwiXG5cdFx0XHRcdDogZml4Q291bnQgPT0gMVxuXHRcdFx0XHQ/IFwiXlwiXG5cdFx0XHRcdDogZml4Q291bnQgPT0gMlxuXHRcdFx0XHQ/IFwiflwiXG5cdFx0XHRcdDogZml4Q291bnQgPiAwXG5cdFx0XHRcdD8gXCI9XCJcblx0XHRcdFx0OiBcIiE9XCI7XG5cdFx0dmFyIG5lZWREb3QgPSAxO1xuXHRcdGZvciAodmFyIGkgPSAxOyBpIDwgcmFuZ2UubGVuZ3RoOyBpKyspIHtcblx0XHRcdHZhciBpdGVtID0gcmFuZ2VbaV07XG5cdFx0XHR2YXIgdCA9ICh0eXBlb2YgaXRlbSlbMF07XG5cdFx0XHRuZWVkRG90LS07XG5cdFx0XHRzdHIgKz1cblx0XHRcdFx0dCA9PSBcInVcIlxuXHRcdFx0XHRcdD8gLy8gdW5kZWZpbmVkOiBwcmVyZWxlYXNlIG1hcmtlciwgYWRkIGFuIFwiLVwiXG5cdFx0XHRcdFx0ICBcIi1cIlxuXHRcdFx0XHRcdDogLy8gbnVtYmVyIG9yIHN0cmluZzogYWRkIHRoZSBpdGVtLCBzZXQgZmxhZyB0byBhZGQgYW4gXCIuXCIgYmV0d2VlbiB0d28gb2YgdGhlbVxuXHRcdFx0XHRcdCAgKG5lZWREb3QgPiAwID8gXCIuXCIgOiBcIlwiKSArICgobmVlZERvdCA9IDIpLCBpdGVtKTtcblx0XHR9XG5cdFx0cmV0dXJuIHN0cjtcblx0fSBlbHNlIHtcblx0XHR2YXIgc3RhY2sgPSBbXTtcblx0XHRmb3IgKHZhciBpID0gMTsgaSA8IHJhbmdlLmxlbmd0aDsgaSsrKSB7XG5cdFx0XHR2YXIgaXRlbSA9IHJhbmdlW2ldO1xuXHRcdFx0c3RhY2sucHVzaChcblx0XHRcdFx0aXRlbSA9PT0gMFxuXHRcdFx0XHRcdD8gXCJub3QoXCIgKyBwb3AoKSArIFwiKVwiXG5cdFx0XHRcdFx0OiBpdGVtID09PSAxXG5cdFx0XHRcdFx0PyBcIihcIiArIHBvcCgpICsgXCIgfHwgXCIgKyBwb3AoKSArIFwiKVwiXG5cdFx0XHRcdFx0OiBpdGVtID09PSAyXG5cdFx0XHRcdFx0PyBzdGFjay5wb3AoKSArIFwiIFwiICsgc3RhY2sucG9wKClcblx0XHRcdFx0XHQ6IHJhbmdlVG9TdHJpbmcoaXRlbSlcblx0XHRcdCk7XG5cdFx0fVxuXHRcdHJldHVybiBwb3AoKTtcblx0fVxuXHRmdW5jdGlvbiBwb3AoKSB7XG5cdFx0cmV0dXJuIHN0YWNrLnBvcCgpLnJlcGxhY2UoL15cXCgoLispXFwpJC8sIFwiJDFcIik7XG5cdH1cbn1cbnZhciBzYXRpc2Z5ID0gZnVuY3Rpb24ocmFuZ2UsIHZlcnNpb24pIHtcblx0aWYgKDAgaW4gcmFuZ2UpIHtcblx0XHR2ZXJzaW9uID0gcGFyc2VWZXJzaW9uKHZlcnNpb24pO1xuXHRcdHZhciBmaXhDb3VudCA9IC8qKiBAdHlwZSB7bnVtYmVyfSAqLyAocmFuZ2VbMF0pO1xuXHRcdC8vIHdoZW4gbmVnYXRlZCBpcyBzZXQgaXQgc3dpbGwgc2V0IGZvciA8IGluc3RlYWQgb2YgPj1cblx0XHR2YXIgbmVnYXRlZCA9IGZpeENvdW50IDwgMDtcblx0XHRpZiAobmVnYXRlZCkgZml4Q291bnQgPSAtZml4Q291bnQgLSAxO1xuXHRcdGZvciAodmFyIGkgPSAwLCBqID0gMSwgaXNFcXVhbCA9IHRydWU7IDsgaisrLCBpKyspIHtcblx0XHRcdC8vIGNzcGVsbDp3b3JkIG5lcXVhbCBuZXF1XG5cblx0XHRcdC8vIHdoZW4gaXNFcXVhbCA9IHRydWU6XG5cdFx0XHQvLyByYW5nZSAgICAgICAgIHZlcnNpb246IEVPQS9vYmplY3QgIHVuZGVmaW5lZCAgbnVtYmVyICAgIHN0cmluZ1xuXHRcdFx0Ly8gRU9BICAgICAgICAgICAgICAgICAgICBlcXVhbCAgICAgICBibG9jayAgICAgIGJpZy12ZXIgICBiaWctdmVyXG5cdFx0XHQvLyB1bmRlZmluZWQgICAgICAgICAgICAgIGJpZ2dlciAgICAgIG5leHQgICAgICAgYmlnLXZlciAgIGJpZy12ZXJcblx0XHRcdC8vIG51bWJlciAgICAgICAgICAgICAgICAgc21hbGxlciAgICAgYmxvY2sgICAgICBjbXAgICAgICAgYmlnLWNtcFxuXHRcdFx0Ly8gZml4ZWQgbnVtYmVyICAgICAgICAgICBzbWFsbGVyICAgICBibG9jayAgICAgIGNtcC1maXggICBkaWZmZXJcblx0XHRcdC8vIHN0cmluZyAgICAgICAgICAgICAgICAgc21hbGxlciAgICAgYmxvY2sgICAgICBkaWZmZXIgICAgY21wXG5cdFx0XHQvLyBmaXhlZCBzdHJpbmcgICAgICAgICAgIHNtYWxsZXIgICAgIGJsb2NrICAgICAgc21hbGwtY21wIGNtcC1maXhcblxuXHRcdFx0Ly8gd2hlbiBpc0VxdWFsID0gZmFsc2U6XG5cdFx0XHQvLyByYW5nZSAgICAgICAgIHZlcnNpb246IEVPQS9vYmplY3QgIHVuZGVmaW5lZCAgbnVtYmVyICAgIHN0cmluZ1xuXHRcdFx0Ly8gRU9BICAgICAgICAgICAgICAgICAgICBuZXF1YWwgICAgICBibG9jayAgICAgIG5leHQtdmVyICBuZXh0LXZlclxuXHRcdFx0Ly8gdW5kZWZpbmVkICAgICAgICAgICAgICBuZXF1YWwgICAgICBibG9jayAgICAgIG5leHQtdmVyICBuZXh0LXZlclxuXHRcdFx0Ly8gbnVtYmVyICAgICAgICAgICAgICAgICBuZXF1YWwgICAgICBibG9jayAgICAgIG5leHQgICAgICBuZXh0XG5cdFx0XHQvLyBmaXhlZCBudW1iZXIgICAgICAgICAgIG5lcXVhbCAgICAgIGJsb2NrICAgICAgbmV4dCAgICAgIG5leHQgICAodGhpcyBuZXZlciBoYXBwZW5zKVxuXHRcdFx0Ly8gc3RyaW5nICAgICAgICAgICAgICAgICBuZXF1YWwgICAgICBibG9jayAgICAgIG5leHQgICAgICBuZXh0XG5cdFx0XHQvLyBmaXhlZCBzdHJpbmcgICAgICAgICAgIG5lcXVhbCAgICAgIGJsb2NrICAgICAgbmV4dCAgICAgIG5leHQgICAodGhpcyBuZXZlciBoYXBwZW5zKVxuXG5cdFx0XHQvLyBFT0EgZW5kIG9mIGFycmF5XG5cdFx0XHQvLyBlcXVhbCAodmVyc2lvbiBpcyBlcXVhbCByYW5nZSk6XG5cdFx0XHQvLyAgIHdoZW4gIW5lZ2F0ZWQ6IHJldHVybiB0cnVlLFxuXHRcdFx0Ly8gICB3aGVuIG5lZ2F0ZWQ6IHJldHVybiBmYWxzZVxuXHRcdFx0Ly8gYmlnZ2VyICh2ZXJzaW9uIGlzIGJpZ2dlciBhcyByYW5nZSk6XG5cdFx0XHQvLyAgIHdoZW4gZml4ZWQ6IHJldHVybiBmYWxzZSxcblx0XHRcdC8vICAgd2hlbiAhbmVnYXRlZDogcmV0dXJuIHRydWUsXG5cdFx0XHQvLyAgIHdoZW4gbmVnYXRlZDogcmV0dXJuIGZhbHNlLFxuXHRcdFx0Ly8gc21hbGxlciAodmVyc2lvbiBpcyBzbWFsbGVyIGFzIHJhbmdlKTpcblx0XHRcdC8vICAgd2hlbiAhbmVnYXRlZDogcmV0dXJuIGZhbHNlLFxuXHRcdFx0Ly8gICB3aGVuIG5lZ2F0ZWQ6IHJldHVybiB0cnVlXG5cdFx0XHQvLyBuZXF1YWwgKHZlcnNpb24gaXMgbm90IGVxdWFsIHJhbmdlICg+IHJlc3AgPCkpOiByZXR1cm4gdHJ1ZVxuXHRcdFx0Ly8gYmxvY2sgKHZlcnNpb24gaXMgaW4gZGlmZmVyZW50IHByZXJlbGVhc2UgYXJlYSk6IHJldHVybiBmYWxzZVxuXHRcdFx0Ly8gZGlmZmVyICh2ZXJzaW9uIGlzIGRpZmZlcmVudCBmcm9tIGZpeGVkIHJhbmdlIChzdHJpbmcgdnMuIG51bWJlcikpOiByZXR1cm4gZmFsc2Vcblx0XHRcdC8vIG5leHQ6IGNvbnRpbnVlcyB0byB0aGUgbmV4dCBpdGVtc1xuXHRcdFx0Ly8gbmV4dC12ZXI6IHdoZW4gZml4ZWQ6IHJldHVybiBmYWxzZSwgY29udGludWVzIHRvIHRoZSBuZXh0IGl0ZW0gb25seSBmb3IgdGhlIHZlcnNpb24sIHNldHMgaXNFcXVhbD1mYWxzZVxuXHRcdFx0Ly8gYmlnLXZlcjogd2hlbiBmaXhlZCB8fCBuZWdhdGVkOiByZXR1cm4gZmFsc2UsIGNvbnRpbnVlcyB0byB0aGUgbmV4dCBpdGVtIG9ubHkgZm9yIHRoZSB2ZXJzaW9uLCBzZXRzIGlzRXF1YWw9ZmFsc2Vcblx0XHRcdC8vIG5leHQtbmVxdTogY29udGludWVzIHRvIHRoZSBuZXh0IGl0ZW1zLCBzZXRzIGlzRXF1YWw9ZmFsc2Vcblx0XHRcdC8vIGNtcCAobmVnYXRlZCA9PT0gZmFsc2UpOiB2ZXJzaW9uIDwgcmFuZ2UgPT4gcmV0dXJuIGZhbHNlLCB2ZXJzaW9uID4gcmFuZ2UgPT4gbmV4dC1uZXF1LCBlbHNlID0+IG5leHRcblx0XHRcdC8vIGNtcCAobmVnYXRlZCA9PT0gdHJ1ZSk6IHZlcnNpb24gPiByYW5nZSA9PiByZXR1cm4gZmFsc2UsIHZlcnNpb24gPCByYW5nZSA9PiBuZXh0LW5lcXUsIGVsc2UgPT4gbmV4dFxuXHRcdFx0Ly8gY21wLWZpeDogdmVyc2lvbiA9PSByYW5nZSA9PiBuZXh0LCBlbHNlID0+IHJldHVybiBmYWxzZVxuXHRcdFx0Ly8gYmlnLWNtcDogd2hlbiBuZWdhdGVkID0+IHJldHVybiBmYWxzZSwgZWxzZSA9PiBuZXh0LW5lcXVcblx0XHRcdC8vIHNtYWxsLWNtcDogd2hlbiBuZWdhdGVkID0+IG5leHQtbmVxdSwgZWxzZSA9PiByZXR1cm4gZmFsc2VcblxuXHRcdFx0dmFyIHJhbmdlVHlwZSA9IGogPCByYW5nZS5sZW5ndGggPyAodHlwZW9mIHJhbmdlW2pdKVswXSA6IFwiXCI7XG5cblx0XHRcdHZhciB2ZXJzaW9uVmFsdWU7XG5cdFx0XHR2YXIgdmVyc2lvblR5cGU7XG5cblx0XHRcdC8vIEhhbmRsZXMgZmlyc3QgY29sdW1uIGluIGJvdGggdGFibGVzIChlbmQgb2YgdmVyc2lvbiBvciBvYmplY3QpXG5cdFx0XHRpZiAoXG5cdFx0XHRcdGkgPj0gdmVyc2lvbi5sZW5ndGggfHxcblx0XHRcdFx0KCh2ZXJzaW9uVmFsdWUgPSB2ZXJzaW9uW2ldKSxcblx0XHRcdFx0KHZlcnNpb25UeXBlID0gKHR5cGVvZiB2ZXJzaW9uVmFsdWUpWzBdKSA9PSBcIm9cIilcblx0XHRcdCkge1xuXHRcdFx0XHQvLyBIYW5kbGVzIG5lcXVhbFxuXHRcdFx0XHRpZiAoIWlzRXF1YWwpIHJldHVybiB0cnVlO1xuXHRcdFx0XHQvLyBIYW5kbGVzIGJpZ2dlclxuXHRcdFx0XHRpZiAocmFuZ2VUeXBlID09IFwidVwiKSByZXR1cm4gaiA+IGZpeENvdW50ICYmICFuZWdhdGVkO1xuXHRcdFx0XHQvLyBIYW5kbGVzIGVxdWFsIGFuZCBzbWFsbGVyOiAocmFuZ2UgPT09IEVPQSkgWE9SIG5lZ2F0ZWRcblx0XHRcdFx0cmV0dXJuIChyYW5nZVR5cGUgPT0gXCJcIikgIT0gbmVnYXRlZDsgLy8gZXF1YWwgKyBzbWFsbGVyXG5cdFx0XHR9XG5cblx0XHRcdC8vIEhhbmRsZXMgc2Vjb25kIGNvbHVtbiBpbiBib3RoIHRhYmxlcyAodmVyc2lvbiA9IHVuZGVmaW5lZClcblx0XHRcdGlmICh2ZXJzaW9uVHlwZSA9PSBcInVcIikge1xuXHRcdFx0XHRpZiAoIWlzRXF1YWwgfHwgcmFuZ2VUeXBlICE9IFwidVwiKSB7XG5cdFx0XHRcdFx0cmV0dXJuIGZhbHNlO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cblx0XHRcdC8vIHN3aXRjaCBiZXR3ZWVuIGZpcnN0IGFuZCBzZWNvbmQgdGFibGVcblx0XHRcdGVsc2UgaWYgKGlzRXF1YWwpIHtcblx0XHRcdFx0Ly8gSGFuZGxlIGRpYWdvbmFsXG5cdFx0XHRcdGlmIChyYW5nZVR5cGUgPT0gdmVyc2lvblR5cGUpIHtcblx0XHRcdFx0XHRpZiAoaiA8PSBmaXhDb3VudCkge1xuXHRcdFx0XHRcdFx0Ly8gSGFuZGxlcyBcImNtcC1maXhcIiBjYXNlc1xuXHRcdFx0XHRcdFx0aWYgKHZlcnNpb25WYWx1ZSAhPSByYW5nZVtqXSkge1xuXHRcdFx0XHRcdFx0XHRyZXR1cm4gZmFsc2U7XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRcdC8vIEhhbmRsZXMgXCJjbXBcIiBjYXNlc1xuXHRcdFx0XHRcdFx0aWYgKG5lZ2F0ZWQgPyB2ZXJzaW9uVmFsdWUgPiByYW5nZVtqXSA6IHZlcnNpb25WYWx1ZSA8IHJhbmdlW2pdKSB7XG5cdFx0XHRcdFx0XHRcdHJldHVybiBmYWxzZTtcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdGlmICh2ZXJzaW9uVmFsdWUgIT0gcmFuZ2Vbal0pIGlzRXF1YWwgPSBmYWxzZTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblxuXHRcdFx0XHQvLyBIYW5kbGUgYmlnLXZlclxuXHRcdFx0XHRlbHNlIGlmIChyYW5nZVR5cGUgIT0gXCJzXCIgJiYgcmFuZ2VUeXBlICE9IFwiblwiKSB7XG5cdFx0XHRcdFx0aWYgKG5lZ2F0ZWQgfHwgaiA8PSBmaXhDb3VudCkgcmV0dXJuIGZhbHNlO1xuXHRcdFx0XHRcdGlzRXF1YWwgPSBmYWxzZTtcblx0XHRcdFx0XHRqLS07XG5cdFx0XHRcdH1cblxuXHRcdFx0XHQvLyBIYW5kbGUgZGlmZmVyLCBiaWctY21wIGFuZCBzbWFsbC1jbXBcblx0XHRcdFx0ZWxzZSBpZiAoaiA8PSBmaXhDb3VudCB8fCB2ZXJzaW9uVHlwZSA8IHJhbmdlVHlwZSAhPSBuZWdhdGVkKSB7XG5cdFx0XHRcdFx0cmV0dXJuIGZhbHNlO1xuXHRcdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRcdGlzRXF1YWwgPSBmYWxzZTtcblx0XHRcdFx0fVxuXHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0Ly8gSGFuZGxlcyBhbGwgXCJuZXh0LXZlclwiIGNhc2VzIGluIHRoZSBzZWNvbmQgdGFibGVcblx0XHRcdFx0aWYgKHJhbmdlVHlwZSAhPSBcInNcIiAmJiByYW5nZVR5cGUgIT0gXCJuXCIpIHtcblx0XHRcdFx0XHRpc0VxdWFsID0gZmFsc2U7XG5cdFx0XHRcdFx0ai0tO1xuXHRcdFx0XHR9XG5cblx0XHRcdFx0Ly8gbmV4dCBpcyBhcHBsaWVkIGJ5IGRlZmF1bHRcblx0XHRcdH1cblx0XHR9XG5cdH1cblx0LyoqIEB0eXBlIHsoYm9vbGVhbiB8IG51bWJlcilbXX0gKi9cblx0dmFyIHN0YWNrID0gW107XG5cdHZhciBwID0gc3RhY2sucG9wLmJpbmQoc3RhY2spO1xuXHRmb3IgKHZhciBpID0gMTsgaSA8IHJhbmdlLmxlbmd0aDsgaSsrKSB7XG5cdFx0dmFyIGl0ZW0gPSAvKiogQHR5cGUge1NlbVZlclJhbmdlIHwgMCB8IDEgfCAyfSAqLyAocmFuZ2VbaV0pO1xuXHRcdHN0YWNrLnB1c2goXG5cdFx0XHRpdGVtID09IDFcblx0XHRcdFx0PyBwKCkgfCBwKClcblx0XHRcdFx0OiBpdGVtID09IDJcblx0XHRcdFx0PyBwKCkgJiBwKClcblx0XHRcdFx0OiBpdGVtXG5cdFx0XHRcdD8gc2F0aXNmeShpdGVtLCB2ZXJzaW9uKVxuXHRcdFx0XHQ6ICFwKClcblx0XHQpO1xuXHR9XG5cdHJldHVybiAhIXAoKTtcbn1cbnZhciBlbnN1cmVFeGlzdGVuY2UgPSBmdW5jdGlvbihzY29wZU5hbWUsIGtleSkge1xuXHR2YXIgc2NvcGUgPSBfX3dlYnBhY2tfcmVxdWlyZV9fLlNbc2NvcGVOYW1lXTtcblx0aWYoIXNjb3BlIHx8ICFfX3dlYnBhY2tfcmVxdWlyZV9fLm8oc2NvcGUsIGtleSkpIHRocm93IG5ldyBFcnJvcihcIlNoYXJlZCBtb2R1bGUgXCIgKyBrZXkgKyBcIiBkb2Vzbid0IGV4aXN0IGluIHNoYXJlZCBzY29wZSBcIiArIHNjb3BlTmFtZSk7XG5cdHJldHVybiBzY29wZTtcbn07XG52YXIgZmluZFZlcnNpb24gPSBmdW5jdGlvbihzY29wZSwga2V5KSB7XG5cdHZhciB2ZXJzaW9ucyA9IHNjb3BlW2tleV07XG5cdHZhciBrZXkgPSBPYmplY3Qua2V5cyh2ZXJzaW9ucykucmVkdWNlKGZ1bmN0aW9uKGEsIGIpIHtcblx0XHRyZXR1cm4gIWEgfHwgdmVyc2lvbkx0KGEsIGIpID8gYiA6IGE7XG5cdH0sIDApO1xuXHRyZXR1cm4ga2V5ICYmIHZlcnNpb25zW2tleV1cbn07XG52YXIgZmluZFNpbmdsZXRvblZlcnNpb25LZXkgPSBmdW5jdGlvbihzY29wZSwga2V5KSB7XG5cdHZhciB2ZXJzaW9ucyA9IHNjb3BlW2tleV07XG5cdHJldHVybiBPYmplY3Qua2V5cyh2ZXJzaW9ucykucmVkdWNlKGZ1bmN0aW9uKGEsIGIpIHtcblx0XHRyZXR1cm4gIWEgfHwgKCF2ZXJzaW9uc1thXS5sb2FkZWQgJiYgdmVyc2lvbkx0KGEsIGIpKSA/IGIgOiBhO1xuXHR9LCAwKTtcbn07XG52YXIgZ2V0SW52YWxpZFNpbmdsZXRvblZlcnNpb25NZXNzYWdlID0gZnVuY3Rpb24oc2NvcGUsIGtleSwgdmVyc2lvbiwgcmVxdWlyZWRWZXJzaW9uKSB7XG5cdHJldHVybiBcIlVuc2F0aXNmaWVkIHZlcnNpb24gXCIgKyB2ZXJzaW9uICsgXCIgZnJvbSBcIiArICh2ZXJzaW9uICYmIHNjb3BlW2tleV1bdmVyc2lvbl0uZnJvbSkgKyBcIiBvZiBzaGFyZWQgc2luZ2xldG9uIG1vZHVsZSBcIiArIGtleSArIFwiIChyZXF1aXJlZCBcIiArIHJhbmdlVG9TdHJpbmcocmVxdWlyZWRWZXJzaW9uKSArIFwiKVwiXG59O1xudmFyIGdldFNpbmdsZXRvbiA9IGZ1bmN0aW9uKHNjb3BlLCBzY29wZU5hbWUsIGtleSwgcmVxdWlyZWRWZXJzaW9uKSB7XG5cdHZhciB2ZXJzaW9uID0gZmluZFNpbmdsZXRvblZlcnNpb25LZXkoc2NvcGUsIGtleSk7XG5cdHJldHVybiBnZXQoc2NvcGVba2V5XVt2ZXJzaW9uXSk7XG59O1xudmFyIGdldFNpbmdsZXRvblZlcnNpb24gPSBmdW5jdGlvbihzY29wZSwgc2NvcGVOYW1lLCBrZXksIHJlcXVpcmVkVmVyc2lvbikge1xuXHR2YXIgdmVyc2lvbiA9IGZpbmRTaW5nbGV0b25WZXJzaW9uS2V5KHNjb3BlLCBrZXkpO1xuXHRpZiAoIXNhdGlzZnkocmVxdWlyZWRWZXJzaW9uLCB2ZXJzaW9uKSkgd2FybihnZXRJbnZhbGlkU2luZ2xldG9uVmVyc2lvbk1lc3NhZ2Uoc2NvcGUsIGtleSwgdmVyc2lvbiwgcmVxdWlyZWRWZXJzaW9uKSk7XG5cdHJldHVybiBnZXQoc2NvcGVba2V5XVt2ZXJzaW9uXSk7XG59O1xudmFyIGdldFN0cmljdFNpbmdsZXRvblZlcnNpb24gPSBmdW5jdGlvbihzY29wZSwgc2NvcGVOYW1lLCBrZXksIHJlcXVpcmVkVmVyc2lvbikge1xuXHR2YXIgdmVyc2lvbiA9IGZpbmRTaW5nbGV0b25WZXJzaW9uS2V5KHNjb3BlLCBrZXkpO1xuXHRpZiAoIXNhdGlzZnkocmVxdWlyZWRWZXJzaW9uLCB2ZXJzaW9uKSkgdGhyb3cgbmV3IEVycm9yKGdldEludmFsaWRTaW5nbGV0b25WZXJzaW9uTWVzc2FnZShzY29wZSwga2V5LCB2ZXJzaW9uLCByZXF1aXJlZFZlcnNpb24pKTtcblx0cmV0dXJuIGdldChzY29wZVtrZXldW3ZlcnNpb25dKTtcbn07XG52YXIgZmluZFZhbGlkVmVyc2lvbiA9IGZ1bmN0aW9uKHNjb3BlLCBrZXksIHJlcXVpcmVkVmVyc2lvbikge1xuXHR2YXIgdmVyc2lvbnMgPSBzY29wZVtrZXldO1xuXHR2YXIga2V5ID0gT2JqZWN0LmtleXModmVyc2lvbnMpLnJlZHVjZShmdW5jdGlvbihhLCBiKSB7XG5cdFx0aWYgKCFzYXRpc2Z5KHJlcXVpcmVkVmVyc2lvbiwgYikpIHJldHVybiBhO1xuXHRcdHJldHVybiAhYSB8fCB2ZXJzaW9uTHQoYSwgYikgPyBiIDogYTtcblx0fSwgMCk7XG5cdHJldHVybiBrZXkgJiYgdmVyc2lvbnNba2V5XVxufTtcbnZhciBnZXRJbnZhbGlkVmVyc2lvbk1lc3NhZ2UgPSBmdW5jdGlvbihzY29wZSwgc2NvcGVOYW1lLCBrZXksIHJlcXVpcmVkVmVyc2lvbikge1xuXHR2YXIgdmVyc2lvbnMgPSBzY29wZVtrZXldO1xuXHRyZXR1cm4gXCJObyBzYXRpc2Z5aW5nIHZlcnNpb24gKFwiICsgcmFuZ2VUb1N0cmluZyhyZXF1aXJlZFZlcnNpb24pICsgXCIpIG9mIHNoYXJlZCBtb2R1bGUgXCIgKyBrZXkgKyBcIiBmb3VuZCBpbiBzaGFyZWQgc2NvcGUgXCIgKyBzY29wZU5hbWUgKyBcIi5cXG5cIiArXG5cdFx0XCJBdmFpbGFibGUgdmVyc2lvbnM6IFwiICsgT2JqZWN0LmtleXModmVyc2lvbnMpLm1hcChmdW5jdGlvbihrZXkpIHtcblx0XHRyZXR1cm4ga2V5ICsgXCIgZnJvbSBcIiArIHZlcnNpb25zW2tleV0uZnJvbTtcblx0fSkuam9pbihcIiwgXCIpO1xufTtcbnZhciBnZXRWYWxpZFZlcnNpb24gPSBmdW5jdGlvbihzY29wZSwgc2NvcGVOYW1lLCBrZXksIHJlcXVpcmVkVmVyc2lvbikge1xuXHR2YXIgZW50cnkgPSBmaW5kVmFsaWRWZXJzaW9uKHNjb3BlLCBrZXksIHJlcXVpcmVkVmVyc2lvbik7XG5cdGlmKGVudHJ5KSByZXR1cm4gZ2V0KGVudHJ5KTtcblx0dGhyb3cgbmV3IEVycm9yKGdldEludmFsaWRWZXJzaW9uTWVzc2FnZShzY29wZSwgc2NvcGVOYW1lLCBrZXksIHJlcXVpcmVkVmVyc2lvbikpO1xufTtcbnZhciB3YXJuID0gZnVuY3Rpb24obXNnKSB7XG5cdGlmICh0eXBlb2YgY29uc29sZSAhPT0gXCJ1bmRlZmluZWRcIiAmJiBjb25zb2xlLndhcm4pIGNvbnNvbGUud2Fybihtc2cpO1xufTtcbnZhciB3YXJuSW52YWxpZFZlcnNpb24gPSBmdW5jdGlvbihzY29wZSwgc2NvcGVOYW1lLCBrZXksIHJlcXVpcmVkVmVyc2lvbikge1xuXHR3YXJuKGdldEludmFsaWRWZXJzaW9uTWVzc2FnZShzY29wZSwgc2NvcGVOYW1lLCBrZXksIHJlcXVpcmVkVmVyc2lvbikpO1xufTtcbnZhciBnZXQgPSBmdW5jdGlvbihlbnRyeSkge1xuXHRlbnRyeS5sb2FkZWQgPSAxO1xuXHRyZXR1cm4gZW50cnkuZ2V0KClcbn07XG52YXIgaW5pdCA9IGZ1bmN0aW9uKGZuKSB7IHJldHVybiBmdW5jdGlvbihzY29wZU5hbWUsIGEsIGIsIGMpIHtcblx0dmFyIHByb21pc2UgPSBfX3dlYnBhY2tfcmVxdWlyZV9fLkkoc2NvcGVOYW1lKTtcblx0aWYgKHByb21pc2UgJiYgcHJvbWlzZS50aGVuKSByZXR1cm4gcHJvbWlzZS50aGVuKGZuLmJpbmQoZm4sIHNjb3BlTmFtZSwgX193ZWJwYWNrX3JlcXVpcmVfXy5TW3Njb3BlTmFtZV0sIGEsIGIsIGMpKTtcblx0cmV0dXJuIGZuKHNjb3BlTmFtZSwgX193ZWJwYWNrX3JlcXVpcmVfXy5TW3Njb3BlTmFtZV0sIGEsIGIsIGMpO1xufTsgfTtcblxudmFyIGxvYWQgPSAvKiNfX1BVUkVfXyovIGluaXQoZnVuY3Rpb24oc2NvcGVOYW1lLCBzY29wZSwga2V5KSB7XG5cdGVuc3VyZUV4aXN0ZW5jZShzY29wZU5hbWUsIGtleSk7XG5cdHJldHVybiBnZXQoZmluZFZlcnNpb24oc2NvcGUsIGtleSkpO1xufSk7XG52YXIgbG9hZEZhbGxiYWNrID0gLyojX19QVVJFX18qLyBpbml0KGZ1bmN0aW9uKHNjb3BlTmFtZSwgc2NvcGUsIGtleSwgZmFsbGJhY2spIHtcblx0cmV0dXJuIHNjb3BlICYmIF9fd2VicGFja19yZXF1aXJlX18ubyhzY29wZSwga2V5KSA/IGdldChmaW5kVmVyc2lvbihzY29wZSwga2V5KSkgOiBmYWxsYmFjaygpO1xufSk7XG52YXIgbG9hZFZlcnNpb25DaGVjayA9IC8qI19fUFVSRV9fKi8gaW5pdChmdW5jdGlvbihzY29wZU5hbWUsIHNjb3BlLCBrZXksIHZlcnNpb24pIHtcblx0ZW5zdXJlRXhpc3RlbmNlKHNjb3BlTmFtZSwga2V5KTtcblx0cmV0dXJuIGdldChmaW5kVmFsaWRWZXJzaW9uKHNjb3BlLCBrZXksIHZlcnNpb24pIHx8IHdhcm5JbnZhbGlkVmVyc2lvbihzY29wZSwgc2NvcGVOYW1lLCBrZXksIHZlcnNpb24pIHx8IGZpbmRWZXJzaW9uKHNjb3BlLCBrZXkpKTtcbn0pO1xudmFyIGxvYWRTaW5nbGV0b24gPSAvKiNfX1BVUkVfXyovIGluaXQoZnVuY3Rpb24oc2NvcGVOYW1lLCBzY29wZSwga2V5KSB7XG5cdGVuc3VyZUV4aXN0ZW5jZShzY29wZU5hbWUsIGtleSk7XG5cdHJldHVybiBnZXRTaW5nbGV0b24oc2NvcGUsIHNjb3BlTmFtZSwga2V5KTtcbn0pO1xudmFyIGxvYWRTaW5nbGV0b25WZXJzaW9uQ2hlY2sgPSAvKiNfX1BVUkVfXyovIGluaXQoZnVuY3Rpb24oc2NvcGVOYW1lLCBzY29wZSwga2V5LCB2ZXJzaW9uKSB7XG5cdGVuc3VyZUV4aXN0ZW5jZShzY29wZU5hbWUsIGtleSk7XG5cdHJldHVybiBnZXRTaW5nbGV0b25WZXJzaW9uKHNjb3BlLCBzY29wZU5hbWUsIGtleSwgdmVyc2lvbik7XG59KTtcbnZhciBsb2FkU3RyaWN0VmVyc2lvbkNoZWNrID0gLyojX19QVVJFX18qLyBpbml0KGZ1bmN0aW9uKHNjb3BlTmFtZSwgc2NvcGUsIGtleSwgdmVyc2lvbikge1xuXHRlbnN1cmVFeGlzdGVuY2Uoc2NvcGVOYW1lLCBrZXkpO1xuXHRyZXR1cm4gZ2V0VmFsaWRWZXJzaW9uKHNjb3BlLCBzY29wZU5hbWUsIGtleSwgdmVyc2lvbik7XG59KTtcbnZhciBsb2FkU3RyaWN0U2luZ2xldG9uVmVyc2lvbkNoZWNrID0gLyojX19QVVJFX18qLyBpbml0KGZ1bmN0aW9uKHNjb3BlTmFtZSwgc2NvcGUsIGtleSwgdmVyc2lvbikge1xuXHRlbnN1cmVFeGlzdGVuY2Uoc2NvcGVOYW1lLCBrZXkpO1xuXHRyZXR1cm4gZ2V0U3RyaWN0U2luZ2xldG9uVmVyc2lvbihzY29wZSwgc2NvcGVOYW1lLCBrZXksIHZlcnNpb24pO1xufSk7XG52YXIgbG9hZFZlcnNpb25DaGVja0ZhbGxiYWNrID0gLyojX19QVVJFX18qLyBpbml0KGZ1bmN0aW9uKHNjb3BlTmFtZSwgc2NvcGUsIGtleSwgdmVyc2lvbiwgZmFsbGJhY2spIHtcblx0aWYoIXNjb3BlIHx8ICFfX3dlYnBhY2tfcmVxdWlyZV9fLm8oc2NvcGUsIGtleSkpIHJldHVybiBmYWxsYmFjaygpO1xuXHRyZXR1cm4gZ2V0KGZpbmRWYWxpZFZlcnNpb24oc2NvcGUsIGtleSwgdmVyc2lvbikgfHwgd2FybkludmFsaWRWZXJzaW9uKHNjb3BlLCBzY29wZU5hbWUsIGtleSwgdmVyc2lvbikgfHwgZmluZFZlcnNpb24oc2NvcGUsIGtleSkpO1xufSk7XG52YXIgbG9hZFNpbmdsZXRvbkZhbGxiYWNrID0gLyojX19QVVJFX18qLyBpbml0KGZ1bmN0aW9uKHNjb3BlTmFtZSwgc2NvcGUsIGtleSwgZmFsbGJhY2spIHtcblx0aWYoIXNjb3BlIHx8ICFfX3dlYnBhY2tfcmVxdWlyZV9fLm8oc2NvcGUsIGtleSkpIHJldHVybiBmYWxsYmFjaygpO1xuXHRyZXR1cm4gZ2V0U2luZ2xldG9uKHNjb3BlLCBzY29wZU5hbWUsIGtleSk7XG59KTtcbnZhciBsb2FkU2luZ2xldG9uVmVyc2lvbkNoZWNrRmFsbGJhY2sgPSAvKiNfX1BVUkVfXyovIGluaXQoZnVuY3Rpb24oc2NvcGVOYW1lLCBzY29wZSwga2V5LCB2ZXJzaW9uLCBmYWxsYmFjaykge1xuXHRpZighc2NvcGUgfHwgIV9fd2VicGFja19yZXF1aXJlX18ubyhzY29wZSwga2V5KSkgcmV0dXJuIGZhbGxiYWNrKCk7XG5cdHJldHVybiBnZXRTaW5nbGV0b25WZXJzaW9uKHNjb3BlLCBzY29wZU5hbWUsIGtleSwgdmVyc2lvbik7XG59KTtcbnZhciBsb2FkU3RyaWN0VmVyc2lvbkNoZWNrRmFsbGJhY2sgPSAvKiNfX1BVUkVfXyovIGluaXQoZnVuY3Rpb24oc2NvcGVOYW1lLCBzY29wZSwga2V5LCB2ZXJzaW9uLCBmYWxsYmFjaykge1xuXHR2YXIgZW50cnkgPSBzY29wZSAmJiBfX3dlYnBhY2tfcmVxdWlyZV9fLm8oc2NvcGUsIGtleSkgJiYgZmluZFZhbGlkVmVyc2lvbihzY29wZSwga2V5LCB2ZXJzaW9uKTtcblx0cmV0dXJuIGVudHJ5ID8gZ2V0KGVudHJ5KSA6IGZhbGxiYWNrKCk7XG59KTtcbnZhciBsb2FkU3RyaWN0U2luZ2xldG9uVmVyc2lvbkNoZWNrRmFsbGJhY2sgPSAvKiNfX1BVUkVfXyovIGluaXQoZnVuY3Rpb24oc2NvcGVOYW1lLCBzY29wZSwga2V5LCB2ZXJzaW9uLCBmYWxsYmFjaykge1xuXHRpZighc2NvcGUgfHwgIV9fd2VicGFja19yZXF1aXJlX18ubyhzY29wZSwga2V5KSkgcmV0dXJuIGZhbGxiYWNrKCk7XG5cdHJldHVybiBnZXRTdHJpY3RTaW5nbGV0b25WZXJzaW9uKHNjb3BlLCBzY29wZU5hbWUsIGtleSwgdmVyc2lvbik7XG59KTtcbnZhciByZXNvbHZlSGFuZGxlciA9IGZ1bmN0aW9uKGRhdGEpIHtcblx0dmFyIHN0cmljdCA9IGZhbHNlXG5cdHZhciBzaW5nbGV0b24gPSBmYWxzZVxuXHR2YXIgdmVyc2lvbkNoZWNrID0gZmFsc2Vcblx0dmFyIGZhbGxiYWNrID0gZmFsc2Vcblx0dmFyIGFyZ3MgPSBbZGF0YS5zaGFyZVNjb3BlLCBkYXRhLnNoYXJlS2V5XTtcblx0aWYgKGRhdGEucmVxdWlyZWRWZXJzaW9uKSB7XG5cdFx0aWYgKGRhdGEuc3RyaWN0VmVyc2lvbikgc3RyaWN0ID0gdHJ1ZTtcblx0XHRpZiAoZGF0YS5zaW5nbGV0b24pIHNpbmdsZXRvbiA9IHRydWU7XG5cdFx0YXJncy5wdXNoKHBhcnNlUmFuZ2UoZGF0YS5yZXF1aXJlZFZlcnNpb24pKTtcblx0XHR2ZXJzaW9uQ2hlY2sgPSB0cnVlXG5cdH0gZWxzZSBpZiAoZGF0YS5zaW5nbGV0b24pIHNpbmdsZXRvbiA9IHRydWU7XG5cdGlmIChkYXRhLmZhbGxiYWNrKSB7XG5cdFx0ZmFsbGJhY2sgPSB0cnVlO1xuXHRcdGFyZ3MucHVzaChkYXRhLmZhbGxiYWNrKTtcblx0fVxuXHRpZiAoc3RyaWN0ICYmIHNpbmdsZXRvbiAmJiB2ZXJzaW9uQ2hlY2sgJiYgZmFsbGJhY2spIHJldHVybiBmdW5jdGlvbigpIHsgcmV0dXJuIGxvYWRTdHJpY3RTaW5nbGV0b25WZXJzaW9uQ2hlY2tGYWxsYmFjay5hcHBseShudWxsLCBhcmdzKTsgfVxuXHRpZiAoc3RyaWN0ICYmIHZlcnNpb25DaGVjayAmJiBmYWxsYmFjaykgcmV0dXJuIGZ1bmN0aW9uKCkgeyByZXR1cm4gbG9hZFN0cmljdFZlcnNpb25DaGVja0ZhbGxiYWNrLmFwcGx5KG51bGwsIGFyZ3MpOyB9XG5cdGlmIChzaW5nbGV0b24gJiYgdmVyc2lvbkNoZWNrICYmIGZhbGxiYWNrKSByZXR1cm4gZnVuY3Rpb24oKSB7IHJldHVybiBsb2FkU2luZ2xldG9uVmVyc2lvbkNoZWNrRmFsbGJhY2suYXBwbHkobnVsbCwgYXJncyk7IH1cblx0aWYgKHN0cmljdCAmJiBzaW5nbGV0b24gJiYgdmVyc2lvbkNoZWNrKSByZXR1cm4gZnVuY3Rpb24oKSB7IHJldHVybiBsb2FkU3RyaWN0U2luZ2xldG9uVmVyc2lvbkNoZWNrLmFwcGx5KG51bGwsIGFyZ3MpOyB9XG5cdGlmIChzaW5nbGV0b24gJiYgZmFsbGJhY2spIHJldHVybiBmdW5jdGlvbigpIHsgcmV0dXJuIGxvYWRTaW5nbGV0b25GYWxsYmFjay5hcHBseShudWxsLCBhcmdzKTsgfVxuXHRpZiAodmVyc2lvbkNoZWNrICYmIGZhbGxiYWNrKSByZXR1cm4gZnVuY3Rpb24oKSB7IHJldHVybiBsb2FkVmVyc2lvbkNoZWNrRmFsbGJhY2suYXBwbHkobnVsbCwgYXJncyk7IH1cblx0aWYgKHN0cmljdCAmJiB2ZXJzaW9uQ2hlY2spIHJldHVybiBmdW5jdGlvbigpIHsgcmV0dXJuIGxvYWRTdHJpY3RWZXJzaW9uQ2hlY2suYXBwbHkobnVsbCwgYXJncyk7IH1cblx0aWYgKHNpbmdsZXRvbiAmJiB2ZXJzaW9uQ2hlY2spIHJldHVybiBmdW5jdGlvbigpIHsgcmV0dXJuIGxvYWRTaW5nbGV0b25WZXJzaW9uQ2hlY2suYXBwbHkobnVsbCwgYXJncyk7IH1cblx0aWYgKHNpbmdsZXRvbikgcmV0dXJuIGZ1bmN0aW9uKCkgeyByZXR1cm4gbG9hZFNpbmdsZXRvbi5hcHBseShudWxsLCBhcmdzKTsgfVxuXHRpZiAodmVyc2lvbkNoZWNrKSByZXR1cm4gZnVuY3Rpb24oKSB7IHJldHVybiBsb2FkVmVyc2lvbkNoZWNrLmFwcGx5KG51bGwsIGFyZ3MpOyB9XG5cdGlmIChmYWxsYmFjaykgcmV0dXJuIGZ1bmN0aW9uKCkgeyByZXR1cm4gbG9hZEZhbGxiYWNrLmFwcGx5KG51bGwsIGFyZ3MpOyB9XG5cdHJldHVybiBmdW5jdGlvbigpIHsgcmV0dXJuIGxvYWQuYXBwbHkobnVsbCwgYXJncyk7IH1cbn07XG52YXIgY29uc3VtZVNoYXJlZEluc3RhbGxlZE1vZHVsZXMgPSB7fTtcbiJdLCJuYW1lcyI6WyJJTklUSUFMSVpFX01BUktFUiIsIlN5bWJvbCIsIm1vZGVsUHJveHkiLCJtb2RlbCIsImNvbnRleHQiLCJvbiIsIm5hbWUiLCJjYWxsYmFjayIsIm9mZiIsImFzc2VydCIsImNvbmRpdGlvbiIsIm1lc3NhZ2UiLCJFcnJvciIsInNhZmVDbGVhbnVwIiwiZm4iLCJraW5kIiwiUHJvbWlzZSIsImUiLCJjb25zb2xlIiwidGhyb3dBbnl3aWRnZXRFcnJvciIsInNvdXJjZSIsIl9zb3VyY2Vfc3RhY2siLCJfaW5zdGFuY2VvZiIsImxpbmVzIiwiYW55d2lkZ2V0SW5kZXgiLCJsaW5lIiwiY2xlYW5TdGFjayIsInByb21pc2VXaXRoUmVzb2x2ZXJzIiwicmVzb2x2ZSIsInJlamVjdCIsInByb21pc2UiLCJyZXMiLCJyZWoiLCJpc1NhZmVDbGVhbnVwRnVuY3Rpb24iLCJ4IiwiX2NvbnRyb2xsZXIiLCJfd2lkZ2V0RGVmIiwiX2V4cG9ydHMiLCJfbW9kZWwiLCJfcmVzb2x2ZXJzIiwiV2lkZ2V0QmluZGluZyIsImJpbmQiLCJ3aWRnZXREZWYiLCJwYXJhbSIsImV4cGVyaW1lbnRhbCIsInByZXZSZXNvbHZlcnMiLCJzaWduYWwiLCJyZXN1bHQiLCJBYm9ydENvbnRyb2xsZXIiLCJ1bmRlZmluZWQiLCJfdHlwZV9vZiIsImNyZWF0ZVZpZXciLCJ0YXJnZXQiLCJob3N0IiwiY29udHJvbGxlciIsImNvbWJpbmVkIiwiY2xlYW51cCIsImRpc3Bvc2VWaWV3IiwiQWJvcnRTaWduYWwiLCJyZWFzb24iLCJkZXN0cm95IiwiX2JpbmRpbmdzIiwiQmluZGluZ01hbmFnZXIiLCJNYXAiLCJnZXRPckNyZWF0ZSIsImJpbmRpbmciLCJnZXQiLCJCSU5ESU5HUyIsInV1aWQiLCJpbnZva2UiLCJtc2ciLCJvcHRpb25zIiwiX29wdGlvbnNfc2lnbmFsIiwiaWQiLCJfb3B0aW9uc19idWZmZXJzIiwiaGFuZGxlciIsImJ1ZmZlcnMiLCJXSURHRVRfUkVGX1BSRUZJWCIsInBhcnNlV2lkZ2V0UmVmIiwicmVmIiwiSlNPTiIsImNyZWF0ZUhvc3QiLCJnZXRNb2RlbCIsIm1vZGVsSWQiLCJjaGlsZE1vZGVsIiwiZ2V0V2lkZ2V0IiwiY2hpbGRCaW5kaW5nIiwidGltZXIiLCJleHBvcnRzIiwic2V0VGltZW91dCIsImNsZWFyVGltZW91dCIsInJlbmRlciIsImVsIiwidmlld1NpZ25hbCIsImNoaWxkVmlld1NpZ25hbCIsImlzSHJlZiIsInN0ciIsImxvYWRDc3NIcmVmIiwiaHJlZiIsImFueXdpZGdldElkIiwicHJldiIsIm5ld0xpbmsiLCJkb2N1bWVudCIsImxpbmsiLCJPYmplY3QiLCJsb2FkQ3NzVGV4dCIsImNzc1RleHQiLCJzdHlsZSIsImxvYWRDc3MiLCJjc3MiLCJsb2FkRXNtIiwiZXNtIiwidXJsIiwibW9kIiwiVVJMIiwiQmxvYiIsIndhcm5SZW5kZXJEZXByZWNhdGlvbiIsImxvYWRXaWRnZXQiLCJ3aWRnZXQiLCJpbml0aWFsaXplIiwic29saWQiLCJvYnNlcnZlIiwiX3NvbGlkX2NyZWF0ZVNpZ25hbCIsInNldCIsInVwZGF0ZSIsIl93aWRnZXRSZXN1bHQiLCJfc2lnbmFsIiwiUnVudGltZSIsImRpc3Bvc2UiLCJ0eXBlZE1vZGVsIiwid2lkZ2V0UmVzdWx0Iiwic2V0V2lkZ2V0UmVzdWx0IiwiZXJyb3IiLCJ2aWV3IiwidmVyc2lvbiIsImdsb2JhbFRoaXMiLCJET01XaWRnZXRNb2RlbCIsIkRPTVdpZGdldFZpZXciLCJSVU5USU1FUyIsIldlYWtNYXAiLCJBbnlNb2RlbCIsIl9rZXkiLCJhcmdzIiwiXyRfZ2V0Iiwic2VyaWFsaXplIiwic3RhdGUiLCJzZXJpYWxpemVycyIsIl9pdGVyYXRvckVycm9yIiwiayIsIl9zZXJpYWxpemVyc19rIiwiX3N0YXRlX2siLCJzdHJ1Y3R1cmVkQ2xvbmUiLCJBbnlWaWV3IiwicnVudGltZSIsInJlbW92ZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBR0E7OztDQUdDLEdBQ00sSUFBSUEsb0JBQW9CQyxPQUFPLHdCQUF3QjtBQUU5RDs7Ozs7O0NBTUMsR0FDTSxTQUFTQyxXQUFXQyxLQUFxQixFQUFFQyxPQUFnQjtJQUNoRSx5TkFBeU47SUFDek4sT0FBTztRQUNMLEtBQUtELE1BQU0sR0FBRyxDQUFDLElBQUksQ0FBQ0E7UUFDcEIsS0FBS0EsTUFBTSxHQUFHLENBQUMsSUFBSSxDQUFDQTtRQUNwQixjQUFjQSxNQUFNLFlBQVksQ0FBQyxJQUFJLENBQUNBO1FBQ3RDLE1BQU1BLE1BQU0sSUFBSSxDQUFDLElBQUksQ0FBQ0E7UUFDdEJFLElBQUFBLFNBQUFBLEdBQUdDLElBQUksRUFBRUMsUUFBUTtZQUNmSixNQUFNLEVBQUUsQ0FBQ0csTUFBTUMsVUFBVUg7UUFDM0I7UUFDQUksS0FBQUEsU0FBQUEsSUFBSUYsSUFBSSxFQUFFQyxRQUFRO1lBQ2hCSixNQUFNLEdBQUcsQ0FBQ0csTUFBTUMsVUFBVUg7UUFDNUI7UUFDQSxrRUFBa0U7UUFDbEUseUVBQXlFO1FBQ3pFLDBDQUEwQztRQUMxQyxnQkFBZ0JELE1BQU0sY0FBYztJQUN0QztBQUNGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2hCTyxTQUFTTSxPQUFPQyxTQUFrQixFQUFFQyxPQUFlO0lBQ3hELElBQUksQ0FBQ0QsV0FBVyxNQUFNLElBQUlFLE1BQU1EO0FBQ2xDO0FBRU8sU0FBZUUsWUFDcEJDLEVBQThDLEVBQzlDQyxJQUFZOzs7WUFFWjs7Z0JBQU9DLFFBQVEsT0FBTyxHQUNuQixJQUFJLENBQUM7MkJBQU1GLGVBQUFBLHlCQUFBQTttQkFDWCxLQUFLLENBQUMsU0FBQ0c7MkJBQU1DLFFBQVEsSUFBSSxDQUFFLGlDQUFxQyxPQUFMSCxNQUFLLE1BQUlFOzs7O0lBQ3pFOztBQUVBOzs7O0NBSUMsR0FDTSxTQUFTRSxvQkFBb0JDLE1BQWU7O1FBS3JDQztJQUpaLElBQUksQ0FBUUMsWUFBTkYsUUFBa0JSLFFBQVE7UUFDOUIsbUNBQW1DO1FBQ25DLE1BQU1RO0lBQ1I7SUFDQSxJQUFJRyxpQkFBUUYsZ0JBQUFBLE9BQU8sS0FBSyxjQUFaQSxvQ0FBQUEsY0FBYyxLQUFLLENBQUMsNENBQVMsRUFBRTtJQUMzQyxJQUFJRyxpQkFBaUJELE1BQU0sU0FBUyxDQUFDLFNBQUNFO2VBQVNBLEtBQUssUUFBUSxDQUFDOztJQUM3RCxJQUFJQyxhQUFhRixtQkFBbUIsQ0FBQyxJQUFJRCxRQUFRQSxNQUFNLEtBQUssQ0FBQyxHQUFHQyxpQkFBaUI7SUFDakZKLE9BQU8sS0FBSyxHQUFHTSxXQUFXLElBQUksQ0FBQztJQUMvQlIsUUFBUSxLQUFLLENBQUNFO0lBQ2QsTUFBTUE7QUFDUjtBQUVBOzs7O0NBSUMsR0FDTSxTQUFTTztJQUNkLElBQUlDO0lBQ0osSUFBSUM7SUFDSixJQUFJQyxVQUFVLElBQUlkLFFBQVcsU0FBQ2UsS0FBS0M7UUFDakNKLFVBQVVHO1FBQ1ZGLFNBQVNHO0lBQ1g7SUFDQSxPQUFPO1FBQUVGLFNBQUFBO1FBQVNGLFNBQUFBO1FBQVNDLFFBQUFBO0lBQU87QUFDcEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzFEaUU7QUFDYTtBQVc5RSxTQUFTSSxzQkFBc0JDLENBQVU7SUFDdkMsT0FBTyxPQUFPQSxNQUFNO0FBQ3RCO0lBR0VDLGtCQUFBQSxnQ0FDQUMsMENBQ0FDLHdDQUNBQyxzQ0FFQUM7QUFOSyxJQUFNQyxxQkFBYUEsaUJBQW5COzthQUFNQSxjQVFDckMsS0FBcUI7Z0NBUnRCcUM7UUFDWEwsZ0NBQUFBLGtCQUFBQTs7bUJBQUFBLEtBQUFBOztRQUNBQyxnQ0FBQUE7O21CQUFBQSxLQUFBQTs7UUFDQUMsZ0NBQUFBOzttQkFBQUEsS0FBQUE7O1FBQ0FDLGdDQUFBQTs7bUJBQUFBLEtBQUFBOztRQUNBO1FBQ0FDLGdDQUFBQTs7bUJBQUFBLEtBQUFBOzt1Q0FHT0QsUUFBU25DO3VDQUNUb0MsWUFBYVosb0JBQW9CQTtRQUN0QyxJQUFJLENBQUMsS0FBSyxHQUFHLDZCQUFJLEVBQUNZLFlBQVcsT0FBTzs7a0JBWDNCQzs7WUFjTEMsS0FBQUE7bUJBQU4sU0FBTUE7MkRBQ0pDLFNBQW9CLEVBQ3BCQyxLQUFnRDt3QkFBOUNDLGNBdUJpQkYsbURBZGJHLGVBU0ZDLFFBQ0EzQyxPQUlBNEM7Ozs7Z0NBdkJGSCxlQUFGRCxNQUFFQztnQ0FFRixJQUFJLDZCQUFJLEVBQUNSLGdCQUFlTSxXQUFXOzs7Z0NBRW5DLElBQUksNkJBQUksRUFBQ04sZUFBYyw2QkFBSSxFQUFDQSxnQkFBZU0sV0FBVzs7MkZBQ3BELElBQUksRUFBQ1Asa0JBQUFBLGdFQUFMLDJCQUFrQixLQUFLO29DQUN2QixtRUFBbUU7b0NBQ25FLGtFQUFrRTtvQ0FDbEUsbUVBQW1FO29DQUMvRFUseUNBQWdCLElBQUksRUFBQ047bUVBQ3BCQSxZQUFhWixvQkFBb0JBO29DQUN0QyxJQUFJLENBQUMsS0FBSyxHQUFHLDZCQUFJLEVBQUNZLFlBQVcsT0FBTztvQ0FDcENNLGNBQWMsT0FBTyxDQUFDLEtBQUssQ0FBQyxZQUFPO29DQUNuQ0EsY0FBYyxNQUFNLENBQUMsSUFBSWpDLE1BQU07Z0NBQ2pDOytEQUVLd0IsWUFBYU07K0RBQ2JQLGtCQUFBQSxFQUFjLElBQUlhO2dDQUNuQkYsU0FBUyw2QkFBSSxFQUFDWCxrQkFBQUEsRUFBWSxNQUFNO2dDQUNoQ2hDLGlDQUFRLElBQUksRUFBQ21DO2dDQUVqQm5DLE1BQU0sR0FBRyxDQUFDLE1BQU0sTUFBTUgsaUJBQWlCQTtnQ0FFMUI7O3FDQUFNMEMsd0JBQUFBLFVBQVUsVUFBVSxjQUFwQkEsNENBQUFBLDJCQUFBQSxXQUF1Qjt3Q0FDeEMsT0FBT3hDLFVBQVVBLENBQUNDLE9BQU9ILGlCQUFpQkE7d0NBQzFDOEMsUUFBQUE7d0NBQ0FGLGNBQUFBO29DQUNGOzs7Z0NBSklHLFNBQVM7cUNBTVRELE9BQU8sT0FBTyxFQUFkQTs7OztnQ0FDRjs7b0NBQU1qQyxXQUFXQSxDQUFDb0Isc0JBQXNCYyxVQUFVQSxTQUFTRSxXQUFXOzs7Z0NBQXRFO2dDQUNBOzs7O2dDQUdGLElBQUloQixzQkFBc0JjLFNBQVM7b0NBQ2pDRCxPQUFPLGdCQUFnQixDQUFDLFNBQVM7K0NBQU1qQyxXQUFXQSxDQUFDa0MsUUFBUTs7bUVBQ3REVixVQUFXWTtnQ0FDbEIsT0FBTyxJQUFJQyxDQUFBQSxPQUFPSCx1Q0FBUEcsU0FBT0gsT0FBSyxNQUFNLFlBQVlBLFdBQVcsTUFBTTttRUFDbkRWLFVBQVdVO2dDQUNsQixPQUFPO21FQUNBVixVQUFXWTtnQ0FDbEI7Z0NBRUEsNkJBQUksRUFBQ1YsWUFBVyxPQUFPLDBCQUFDLElBQUksRUFBQ0Y7Ozs7OztnQkFDL0I7Ozs7WUFFTWMsS0FBQUE7bUJBQU4sU0FBTUE7MkRBQ0pDLE1BQWtCLEVBQ2xCVCxLQUErRjt3QkFBN0ZHLFFBQVFGLGNBQWNTLGtDQUlwQkMsWUFDQUMsVUFDQXBELE9BQ0FxRCxTQU9BQzs7OztnQ0FkRlgsU0FBRkgsTUFBRUcsUUFBUUYsZUFBVkQsTUFBVUMsY0FBY1MsT0FBeEJWLE1BQXdCVTtnQ0FFeEI7O29DQUFNLElBQUksQ0FBQyxLQUFLOzs7Z0NBQWhCO2dDQUNBLElBQUkseURBQUMsSUFBSSxFQUFDakIsMEVBQUwsMkJBQWlCLE1BQU0sR0FBRTs7O2dDQUMxQmtCLGFBQWEsSUFBSU47Z0NBQ2pCTyxXQUFXRyxZQUFZLEdBQUc7b0NBQUVaO29DQUFRUSxXQUFXLE1BQU07O2dDQUNyRG5ELGlDQUFRLElBQUksRUFBQ21DO2dDQUNIOztvQ0FBTSw2QkFBSSxFQUFDRixZQUFXLE1BQU0sQ0FBQzt3Q0FDekMsT0FBT2xDLFVBQVVBLENBQUNDLE9BQU9pRDt3Q0FDekIsSUFBSUEsT0FBTyxFQUFFO3dDQUNiLFFBQVFHO3dDQUNSRixNQUFBQTt3Q0FDQVQsY0FBQUE7b0NBQ0Y7OztnQ0FOSVksVUFBVTtnQ0FPVkMsY0FBYyxxQkFBQ0U7b0NBQ2pCLHFFQUFxRTtvQ0FDckUsb0VBQW9FO29DQUNwRXhELE1BQU0sR0FBRyxDQUFDLE1BQU0sTUFBTWlEO29DQUN0QixLQUFLdkMsV0FBV0EsQ0FBQzJDLFNBQVNHO2dDQUM1QjtnQ0FDQSxJQUFJSixTQUFTLE9BQU8sRUFBRTtvQ0FDcEJFLFlBQVk7b0NBQ1o7OztnQ0FDRjtnQ0FDQUYsU0FBUyxnQkFBZ0IsQ0FBQyxTQUFTOzJDQUFNRSxZQUFZOzs7Ozs7O2dCQUN2RDs7OztZQUVJO2lCQUFKO2dCQUNFLGdDQUFPLElBQUksRUFBQ3BCO1lBQ2Q7OztZQUVBdUIsS0FBQUE7bUJBQUFBLFNBQUFBOzt1RUFDRSxJQUFJLEVBQUN6QixrQkFBQUEsZ0VBQUwsMkJBQWtCLEtBQUs7K0NBQ2xCQSxrQkFBQUEsRUFBY2M7K0NBQ2RiLFlBQWFhO1lBQ3BCOzs7V0FuR1dUO0lBb0daO0lBR0NxQjtBQURGLElBQU1DLHNCQUFjQSxpQkFBcEI7O2FBQU1BO2dDQUFBQTtRQUNKRCxnQ0FBQUE7O21CQUFZLElBQUlFOzs7a0JBRFpEOztZQUdKRSxLQUFBQTttQkFBQUEsU0FBQUEsWUFBWTdELEtBQXFCO2dCQUMvQixJQUFJOEQsVUFBVSw2QkFBSSxFQUFDSixXQUFVLEdBQUcsQ0FBQzFEO2dCQUNqQyxJQUFJLENBQUM4RCxTQUFTO29CQUNaQSxVQUFVLElBQUl6QixxQkFBYUEsQ0FBQ3JDO29CQUM1Qiw2QkFBSSxFQUFDMEQsV0FBVSxHQUFHLENBQUMxRCxPQUFPOEQ7Z0JBQzVCO2dCQUNBLE9BQU9BO1lBQ1Q7OztZQUVBQyxLQUFBQTttQkFBQUEsU0FBQUEsSUFBSS9ELEtBQXFCO2dCQUN2QixPQUFPLDZCQUFJLEVBQUMwRCxXQUFVLEdBQUcsQ0FBQzFEO1lBQzVCOzs7WUFFQXlELEtBQUFBO21CQUFBQSxTQUFBQSxRQUFRekQsS0FBcUI7Z0JBQzNCLElBQUk4RCxVQUFVLDZCQUFJLEVBQUNKLFdBQVUsR0FBRyxDQUFDMUQ7Z0JBQ2pDLElBQUk4RCxTQUFTO29CQUNYQSxRQUFRLE9BQU87b0JBQ2YsNkJBQUksRUFBQ0osV0FBVSxNQUFNLENBQUMxRDtnQkFDeEI7WUFDRjs7O1dBdEJJMkQ7O0FBeUJDLElBQUlLLFdBQVcsSUFBSUwsc0JBQWNBLEdBQUc7OztBQ25KM0M7QUFDQTtBQUNBO0FBQ0EsRUFBRSxlQUFTLEdBQUcsa0RBQUU7QUFDaEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxVQUFVO0FBQ1YsUUFBUTtBQUNSO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkJBQTZCLDRCQUE0QjtBQUN6RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBQVUsZUFBUztBQUNuQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLGVBQVM7QUFDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwQkFBMEIsZUFBUztBQUNuQyxRQUFRLGVBQVM7QUFDakI7QUFDQSxNQUFNLEtBQUssZUFBUztBQUNwQixrQkFBa0IsZUFBUztBQUMzQjtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsdUJBQXVCLDJFQUEyQjtBQUNsRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0Isa0RBQUU7QUFDbEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGVBQWUsYUFBTztBQUN0QjtBQUNBO0FBQ0Esc0NBQXNDO0FBQ3RDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpR0FBaUc7QUFDakc7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxRUFBcUU7QUFDckU7QUFDQTtBQUNBO0FBQ0EscUVBQXFFO0FBQ3JFO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsUUFBUSxxQkFBZSxlQUFlLHFCQUFlO0FBQ3JEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0JBQWtCLGFBQU87QUFDekI7QUFDQSxLQUFLO0FBQ0wsUUFBUSxxQkFBZSxlQUFlLHFCQUFlO0FBQ3JEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzQ0FBc0M7QUFDdEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQSx3RUFBd0U7QUFDeEU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1QsUUFBUTtBQUNSO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSxjQUFjLHFCQUFlLGVBQWUscUJBQWU7QUFDM0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw2RkFBNkY7QUFDN0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0JBQWtCLGFBQU87QUFDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwQ0FBMEMsYUFBTztBQUNqRDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVCxRQUFRO0FBQ1I7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlEQUF5RDtBQUN6RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0Esa0VBQWtFO0FBQ2xFO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU07QUFDTjtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0RBQStEO0FBQy9ELG9DQUFvQztBQUNwQztBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDZDQUE2QztBQUM3QztBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTLGFBQU87QUFDaEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBLFNBQVMsUUFBRTtBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0JBQXNCLGlCQUFpQjtBQUN2QyxNQUFNO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQSxtQkFBbUIsYUFBTztBQUMxQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUJBQXFCLGFBQU87QUFDNUI7QUFDQTtBQUNBLHVCQUF1Qix3REFBd0Q7QUFDL0U7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFCQUFxQixxQkFBZTtBQUNwQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUyxjQUFRO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJLHFCQUFlO0FBQ25CO0FBQ0EsU0FBUyxxQkFBZSxLQUFLLHFCQUFlO0FBQzVDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU07QUFDTjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMEZBQTBGO0FBQzFGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsUUFBUTtBQUNSO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFFBQVE7QUFDUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBLHdCQUF3QiwyQkFBMkI7QUFDbkQ7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3Q0FBd0M7QUFDeEM7QUFDQTtBQUNBLGtEQUFrRDtBQUNsRDtBQUNBO0FBQ0E7QUFDQSxjQUFjLEtBQU0sRUFBRSxFQUFDO0FBQ3ZCO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1AsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsUUFBUTtBQUNSO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU07QUFDTjtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUJBQXVCO0FBQ3ZCO0FBQ0EsNENBQTRDO0FBQzVDLE1BQU07QUFDTiwwQ0FBMEM7QUFDMUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUJBQXVCLGFBQU87QUFDOUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFDQUFxQyxRQUFRO0FBQzdDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTTtBQUNOO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwyQkFBMkI7QUFDM0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDhFQUE4RTtBQUM5RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0RBQWtELFNBQVM7QUFDM0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1AsTUFBTTtBQUNOO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0JBQWtCLGtCQUFrQjtBQUNwQztBQUNBO0FBQ0Esa0JBQWtCLGtCQUFrQjtBQUNwQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsY0FBYyxrQkFBa0I7QUFDaEM7QUFDQSwyQkFBMkI7QUFDM0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGNBQWMsZ0JBQWdCO0FBQzlCO0FBQ0E7QUFDQTtBQUNBLHlDQUF5QztBQUN6QyxrQkFBa0IseUJBQXlCO0FBQzNDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQiwyQkFBMkI7QUFDN0M7QUFDQTtBQUNBLGdEQUFnRDtBQUNoRCxrQ0FBa0M7QUFDbEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFDQUFxQyxRQUFRO0FBQzdDO0FBQ0E7QUFDQTtBQUNBLElBQUksV0FBSztBQUNULElBQUk7QUFDSixvQ0FBb0MsUUFBUTtBQUM1QztBQUNBO0FBQ0E7QUFDQSx1Q0FBdUMsUUFBUTtBQUMvQztBQUNBO0FBQ0Esd0RBQXdEO0FBQ3hEO0FBQ0EsU0FBUyxXQUFLO0FBQ2Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQix1QkFBdUIsS0FBSyxXQUFLO0FBQ3JEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBLEdBQUcsRUFBRTtBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0IscUJBQXFCO0FBQ3pDO0FBQ0E7QUFDQSx1RUFBdUUscUJBQXFCLG1CQUFtQjtBQUMvRyxRQUFRO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtQ0FBbUMsYUFBTztBQUMxQztBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWEsY0FBUTtBQUNyQixLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVCQUF1QjtBQUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQixvQkFBb0I7QUFDeEM7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBQVUsYUFBTztBQUNqQixTQUFTO0FBQ1Q7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxTQUFTLGFBQU87QUFDaEIsa0JBQWtCLGNBQWM7QUFDaEM7QUFDQSwyQ0FBMkM7QUFDM0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQixhQUFPO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsYUFBTztBQUNsQjtBQUNBO0FBQ0E7QUFDQSxVQUFVLGFBQU87QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0JBQW9CLFlBQVk7QUFDaEM7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQTtBQUNBO0FBQ0EscURBQXFELGlEQUFpRDtBQUN0RyxpREFBaUQsb0VBQW9FO0FBQ3JIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlCQUF5QixZQUFZO0FBQ3JDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IsVUFBVTtBQUNsQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBWTtBQUNaO0FBQ0Esd0JBQXdCLFlBQVk7QUFDcEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxZQUFZO0FBQ1o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkNBQTZDO0FBQzdDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQixhQUFPO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVyxhQUFPO0FBQ2xCO0FBQ0E7QUFDQSxVQUFVLGFBQU87QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0JBQWtCLFlBQVk7QUFDOUI7QUFDQTtBQUNBLFVBQVU7QUFDVjtBQUNBO0FBQ0E7QUFDQSxhQUFhLGtCQUFrQjtBQUMvQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLGFBQU8sdUJBQXVCO0FBQzlDO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUyxhQUFPLHVCQUF1QjtBQUN2QztBQUNBO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQjtBQUNsQjtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDRDtBQUNBLHVEQUF1RDtBQUN2RDtBQUNBO0FBQ0Esd0NBQXdDLFlBQVk7QUFDcEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0JBQWtCLG9CQUFvQjtBQUN0QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlDQUF5QyxRQUFRO0FBQ2pEO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBLHlDQUF5QyxRQUFRO0FBQ2pEO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0Esd0JBQXdCLG9CQUFvQjtBQUM1QztBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBLG1DQUFtQyxRQUFRO0FBQzNDO0FBQ0E7QUFDQTtBQUNBLHdDQUF3QyxRQUFRO0FBQ2hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxVQUFVO0FBQ1YsUUFBUTtBQUNSO0FBQ0E7QUFDQSw0REFBNEQ7QUFDNUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUNBQXVDLFFBQVE7QUFDL0M7QUFDQTtBQUNBLG1FQUFtRTtBQUNuRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUCxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQixVQUFVO0FBQzVCO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0JBQW9CLGlCQUFpQjtBQUNyQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0EsT0FBTztBQUNQO0FBQ0EsTUFBTTtBQUNOO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQSxnREFBZ0QsYUFBTztBQUN2RCxVQUFVLEtBQU0sRUFBRSxFQUFDO0FBQ25CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUksYUFBTztBQUNYO0FBQ0E7QUFDQSx1REFBdUQsYUFBTyxHQUFHO0FBQ2pFOztBQUVBLGtEQUFrRCxLQUFLO0FBQ3ZEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQixhQUFPO0FBQ3pCLGFBQWEsYUFBTztBQUNwQjtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQSxjQUFjLGNBQVE7QUFDdEI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0IsZ0JBQWdCO0FBQ3BDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLGFBQU87QUFDdkIsVUFBVSxhQUFPO0FBQ2pCO0FBQ0EsS0FBSztBQUNMLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1EQUFtRCxhQUFPO0FBQzFEO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7O0FBRUE7QUFDQSwyQ0FBMkMsK0RBQWU7QUFDMUQ7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFFBQVEsb0JBQW9CO0FBQzVCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNDQUFzQyxTQUFTO0FBQy9DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsUUFBUTtBQUNSO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwREFBMEQ7QUFDMUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsY0FBYztBQUNkO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGVBQWU7QUFDZjtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1gsU0FBUztBQUNULE9BQU87QUFDUDtBQUNBLEdBQUc7QUFDSDs7QUFFQSxZQUFZLHlEQUFTOztBQUV5b0I7OztBQzd0RDlwQjtBQUNBOztBQUVPO0FBQ1A7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxRQUFRLFFBQVE7QUFDaEI7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7OztBQ3RCcUM7QUFPOUIsU0FBU08sT0FDZGxFLEtBQWUsRUFDZkcsSUFBWSxFQUNaZ0UsR0FBYTtRQUNiQyxVQUFBQSxpRUFBeUIsQ0FBQztRQUtiQztJQUhiLDhFQUE4RTtJQUM5RSwwQ0FBMEM7SUFDMUMsSUFBSUMsS0FBS0wsRUFBTztJQUNoQixJQUFJdEIsVUFBUzBCLGtCQUFBQSxRQUFRLE1BQU0sY0FBZEEsNkJBQUFBLGtCQUFrQmQsWUFBWSxPQUFPLENBQUM7SUFFbkQsT0FBTyxJQUFJMUMsUUFBUSxTQUFDWSxTQUFTQztZQWtCeUM2QztRQWpCcEUsSUFBSTVCLE9BQU8sT0FBTyxFQUFFO1lBQ2xCakIsT0FBT2lCLE9BQU8sTUFBTTtRQUN0QjtRQUNBQSxPQUFPLGdCQUFnQixDQUFDLFNBQVM7WUFDL0IzQyxNQUFNLEdBQUcsQ0FBQyxjQUFjd0U7WUFDeEI5QyxPQUFPaUIsT0FBTyxNQUFNO1FBQ3RCO1FBRUEsU0FBUzZCLFFBQ1BMLEdBQW9FLEVBQ3BFTSxPQUFtQjtZQUVuQixJQUFJLENBQUVOLENBQUFBLElBQUksRUFBRSxLQUFLRyxFQUFDLEdBQUk7WUFDdEI3QyxRQUFRO2dCQUFDMEMsSUFBSSxRQUFRO2dCQUFFTTthQUFRO1lBQy9CekUsTUFBTSxHQUFHLENBQUMsY0FBY3dFO1FBQzFCO1FBQ0F4RSxNQUFNLEVBQUUsQ0FBQyxjQUFjd0U7UUFDdkJ4RSxNQUFNLElBQUksQ0FBQztZQUFFc0UsSUFBQUE7WUFBSSxNQUFNO1lBQXFCbkUsTUFBQUE7WUFBTWdFLEtBQUFBO1FBQUksR0FBR3JCLFlBQVd5QixtQkFBQUEsUUFBUSxPQUFPLGNBQWZBLDhCQUFBQSxtQkFBbUIsRUFBRTtJQUMzRjtBQUNGOzs7QUN2Q08sSUFBSUcsb0JBQW9CLGFBQWE7QUFFckMsU0FBU0MsZUFBZUMsR0FBWTtJQUN6QyxJQUFJLE9BQU9BLFFBQVEsWUFBWUEsSUFBSSxVQUFVLENBQUNGLG9CQUFvQjtRQUNoRSxPQUFPRSxJQUFJLEtBQUssQ0FBQ0Ysa0JBQWtCLE1BQU07SUFDM0M7SUFDQSxNQUFNLElBQUlqRSxNQUFPLHlDQUE0RCxPQUFwQm9FLEtBQUssU0FBUyxDQUFDRDtBQUMxRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNKd0M7QUFDSDtBQUNTO0FBQ0c7QUFFMUMsU0FBU0UsV0FBVzlFLEtBQXFCLEVBQUV3QyxLQUFtQztRQUFqQ0csU0FBRkgsTUFBRUc7SUFDbEQsSUFBSU8sT0FBYTtRQUVUNkIsVUFETixpRkFBaUY7UUFDakYsU0FBTUEsU0FBU0gsR0FBRzs7b0JBQ1pJLFNBQ0FDLFlBQ0FoRjs7Ozs0QkFGQStFLFVBQVVMLGNBQWNBLENBQUNDOzRCQUNaOztnQ0FBTTVFLE1BQU0sY0FBYyxDQUFDLFNBQVMsQ0FBQ2dGOzs7NEJBQWxEQyxhQUFhOzRCQUNiaEYsVUFBVUgsT0FBTzs0QkFDckI2QyxPQUFPLGdCQUFnQixDQUFDLFNBQVM7dUNBQU1zQyxXQUFXLEdBQUcsQ0FBQyxNQUFNLE1BQU1oRjs7NEJBQ2xFOztnQ0FBT0YsVUFBVUEsQ0FBQ2tGLFlBQVloRjs7OztZQUNoQzs7UUFFTWlGLFdBRE4sOEVBQThFO1FBQzlFLFNBQU1BLFVBQVVOLEdBQUc7O29CQUNiSSxTQUNBQyxZQUNBRSxjQUlBQyxPQUNBQzs7Ozs0QkFQQUwsVUFBVUwsY0FBY0EsQ0FBQ0M7NEJBQ1o7O2dDQUFNNUUsTUFBTSxjQUFjLENBQUMsU0FBUyxDQUFDZ0Y7Ozs0QkFBbERDLGFBQWE7NEJBQ2JFLGVBQWVuQixZQUFZLENBQUNpQjs0QkFDaEMsSUFBSSxDQUFDRSxjQUFjO2dDQUNqQixNQUFNLElBQUkxRSxNQUFPLDJDQUFrRCxPQUFSdUU7NEJBQzdEOzRCQUVjOztnQ0FBTSxJQUFJbkUsUUFBaUIsU0FBQ1ksU0FBU0M7b0NBQ2pEMEQsUUFBUUUsV0FDTjsrQ0FDRTVELE9BQU8sSUFBSWpCLE1BQU8sNENBQW1ELE9BQVJ1RSxTQUFRO3VDQUN2RTtvQ0FFRkcsYUFBYSxLQUFLLENBQUMsSUFBSSxDQUFDMUQsU0FBU0M7Z0NBQ25DLEdBQUcsT0FBTyxDQUFDOzJDQUFNNkQsYUFBYUg7Ozs7NEJBUDFCQyxVQUFVOzRCQVFkOztnQ0FBTztvQ0FDTEEsU0FBQUE7b0NBQ01HLFFBQU4sU0FBTUE7Z0ZBQU9oRCxLQUEwQjtnREFBeEJpRCxJQUFZQyxZQUNyQkM7Ozs7d0RBRFNGLEtBQUZqRCxNQUFFaUQsSUFBWUMsYUFBZGxELE1BQU07d0RBQ2JtRCxrQkFBa0JELHVCQUFBQSx3QkFBQUEsYUFBYy9DO3dEQUNwQzs7NERBQU13QyxhQUFhLFVBQVUsQ0FDM0I7Z0VBQUVNLElBQUFBOzREQUFHLEdBQ0w7Z0VBQ0UsUUFBUUU7Z0VBQ1IsY0FBYztvRUFDWix3Q0FBd0M7b0VBQ3hDLFFBQVF6QixXQUFXLENBQUMsTUFBTWU7Z0VBQzVCO2dFQUNBL0IsTUFBQUE7NERBQ0Y7Ozt3REFURjs7Ozs7O3dDQVdGOztnQ0FDRjs7OztZQUNGOztJQUNGO0lBQ0EsT0FBT0E7QUFDVDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNyRG1DO0FBWW5DLFNBQVMwQyxPQUFPQyxHQUFXO0lBQ3pCLE9BQU9BLElBQUksVUFBVSxDQUFDLGNBQWNBLElBQUksVUFBVSxDQUFDO0FBQ3JEO0FBRUEsU0FBZUMsWUFBWUMsSUFBWSxFQUFFQyxXQUFtQjs7WUFDdERDLE1BT0VDOztZQVBGRCxPQUFPRSxTQUFTLGFBQWEsQ0FBbUIsWUFBdUIsT0FBWkgsYUFBWTtZQUUzRSx5SUFBeUk7WUFDekksdUVBQXVFO1lBQ3ZFLGtFQUFrRTtZQUNsRSxJQUFJQyxNQUFNO2dCQUNSLDRKQUE0SjtnQkFDeEpDLFVBQVVELEtBQUssU0FBUztnQkFDNUJDLFFBQVEsSUFBSSxHQUFHSDtnQkFDZkcsUUFBUSxnQkFBZ0IsQ0FBQyxRQUFROzJCQUFNRCxpQkFBQUEsMkJBQUFBLEtBQU0sTUFBTTs7Z0JBQ25EQyxRQUFRLGdCQUFnQixDQUFDLFNBQVM7MkJBQU1ELGlCQUFBQSwyQkFBQUEsS0FBTSxNQUFNOztnQkFDcERBLEtBQUssS0FBSyxDQUFDQztnQkFDWDs7O1lBQ0Y7WUFFQTs7Z0JBQU8sSUFBSXJGLFFBQVEsU0FBQ1k7b0JBQ2xCLElBQUkyRSxPQUFPQyxPQUFPLE1BQU0sQ0FBQ0YsU0FBUyxhQUFhLENBQUMsU0FBUzt3QkFDdkQsS0FBSzt3QkFDTEosTUFBQUE7d0JBQ0EsUUFBUXRFO29CQUNWO29CQUNBMEUsU0FBUyxJQUFJLENBQUMsV0FBVyxDQUFDQztnQkFDNUI7OztJQUNGOztBQUVBLFNBQVNFLFlBQVlDLE9BQWUsRUFBRVAsV0FBbUI7SUFDdkQsSUFBSUMsT0FBT0UsU0FBUyxhQUFhLENBQW9CLGFBQXdCLE9BQVpILGFBQVk7SUFDN0UsSUFBSUMsTUFBTTtRQUNSLDZDQUE2QztRQUM3Q0EsS0FBSyxXQUFXLEdBQUdNO1FBQ25CO0lBQ0Y7SUFDQSxJQUFJQyxRQUFRSCxPQUFPLE1BQU0sQ0FBQ0YsU0FBUyxhQUFhLENBQUMsVUFBVTtRQUN6RCxJQUFJSDtRQUNKLE1BQU07SUFDUjtJQUNBUSxNQUFNLFdBQVcsQ0FBQ0wsU0FBUyxjQUFjLENBQUNJO0lBQzFDSixTQUFTLElBQUksQ0FBQyxXQUFXLENBQUNLO0FBQzVCO0FBRU8sU0FBZUMsUUFBUUMsR0FBdUIsRUFBRVYsV0FBbUI7OztZQUN4RSxJQUFJLENBQUNVLE9BQU8sQ0FBQ1YsYUFBYTs7O1lBQzFCLElBQUlKLE9BQU9jLE1BQU07O2dCQUFPWixZQUFZWSxLQUFLVjs7WUFDekM7O2dCQUFPTSxZQUFZSSxLQUFLVjs7O0lBQzFCOztBQUVBLFNBQWVXLFFBQVFDLEdBQVc7O1lBSTVCQyxLQUNBQzs7Ozt5QkFKQWxCLE9BQU9nQixNQUFQaEI7Ozs7b0JBQ0s7O3dCQUFNLE1BQU0sQ0FBQyx1QkFBdUIsR0FBRyxnQkFBZ0IsR0FBR2dCOzs7b0JBQWpFOzt3QkFBTzs7O29CQUVMQyxNQUFNRSxJQUFJLGVBQWUsQ0FBQyxJQUFJQzt3QkFBTUo7dUJBQU07d0JBQUUsTUFBTTtvQkFBa0I7b0JBQzlEOzt3QkFBTSxNQUFNLENBQUMsdUJBQXVCLEdBQUcsZ0JBQWdCLEdBQUdDOzs7b0JBQWhFQyxNQUFNO29CQUNWQyxJQUFJLGVBQWUsQ0FBQ0Y7b0JBQ3BCOzt3QkFBT0M7Ozs7SUFDVDs7QUFFQSxTQUFTRyxzQkFBc0JqQixXQUFtQjtJQUNoRGpGLFFBQVEsSUFBSSxDQUFFLHVDQUNrQyxPQUFaaUYsYUFBWTtBQXVCbEQ7QUFFTyxTQUFla0IsV0FBV04sR0FBVyxFQUFFWixXQUFtQjs7WUFDM0RjLEtBU0FLOzs7O29CQVRNOzt3QkFBTVIsUUFBUUM7OztvQkFBcEJFLE1BQU07b0JBQ1YsSUFBSUEsSUFBSSxNQUFNLEVBQUU7d0JBQ2RHLHNCQUFzQmpCO3dCQUN0Qjs7NEJBQU87Z0NBQ0NvQixZQUFOLFNBQU1BOzs7Ozs7O29DQUFjOztnQ0FDcEIsUUFBUU4sSUFBSSxNQUFNOzRCQUNwQjs7b0JBQ0Y7b0JBQ0F4RyxNQUFNQSxDQUFDd0csSUFBSSxPQUFPLEVBQUU7eUJBQ1AsUUFBT0EsSUFBSSxPQUFPLEtBQUssVUFBUyxHQUFoQzs7OztvQkFBb0M7O3dCQUFNQSxJQUFJLE9BQU87OzsyQkFBakI7Ozs7OzsyQkFBc0JBLElBQUksT0FBTzs7O29CQUE5RUs7b0JBQ0o7O3dCQUFPQTs7OztJQUNUOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2pIa0M7QUFFM0IsU0FBU0csUUFDZHRILEtBQWtCLEVBQ2xCRyxJQUFPLEVBQ1BxQyxLQUFvQztRQUFsQ0csU0FBRkgsTUFBRUc7SUFFRixJQUFpQjRFLHVDQUFBQSxZQUFrQixDQUFDdkgsTUFBTSxHQUFHLENBQUNHLFlBQXpDNEQsTUFBWXdELHdCQUFQQyxNQUFPRDtJQUNqQixJQUFJRSxTQUFTO2VBQU1ELElBQUk7bUJBQU14SCxNQUFNLEdBQUcsQ0FBQ0c7OztJQUN2Q0gsTUFBTSxFQUFFLENBQUUsVUFBYyxPQUFMRyxPQUFRc0g7SUFDM0I5RSxtQkFBQUEsNkJBQUFBLE9BQVEsZ0JBQWdCLENBQUMsU0FBUztRQUNoQzNDLE1BQU0sR0FBRyxDQUFFLFVBQWMsT0FBTEcsT0FBUXNIO0lBQzlCO0lBQ0EsT0FBTzFEO0FBQ1Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNia0M7QUFFTTtBQUNEO0FBQ0Y7QUFDMkI7QUFDekI7QUFDOEI7SUFVbkUsdURBQXVEO0FBQ3ZEMkQsNkNBQ0FDO0FBSEssSUFBTUMsZUFBT0EsaUJBQWI7O2FBQU1BLFFBS0M1SCxLQUFxQixFQUFFb0UsT0FBZ0M7O3VDQUx4RHdEO1FBRVhGLGdDQUFBQSxPQUFBQTs7bUJBQUFBLEtBQUFBOztRQUNBQyxnQ0FBQUEsT0FBQUE7O21CQUFBQSxLQUFBQTs7OENBR09BLFNBQVV2RCxRQUFRLE1BQU07UUFDN0Isb0NBQUksRUFBQ3VELFNBQVEsY0FBYztRQUMzQixvQ0FBSSxFQUFDQSxTQUFRLGdCQUFnQixDQUFDLFNBQVM7bUJBQU1FOztRQUM3QyxJQUFJL0QsVUFBVUUsb0JBQW9CLENBQUNoRTtRQUNuQyxJQUFJeUMsZUFBNkI7WUFDL0IsOERBQThEO1lBQzlELFFBQVF5QixXQUFXLENBQUMsTUFBTWxFO1FBQzVCO1FBQ0EsSUFBSTZILFVBQVVSLFVBQWdCLENBQUMsU0FBQ1E7WUFDOUIscUlBQXFJO1lBQ3JJLG1GQUFtRjtZQUNuRixJQUFJQyxhQUFhOUg7WUFDakIsSUFBSXNFLEtBQUt3RCxXQUFXLEdBQUcsQ0FBQztZQUN4QixJQUFJcEIsTUFBTVksT0FBT0EsQ0FBQ1EsWUFBWSxRQUFRO2dCQUFFLE1BQU0sRUFBRSx1Q0FBS0g7WUFBUTtZQUM3RCxJQUFJZixNQUFNVSxPQUFPQSxDQUFDUSxZQUFZLFFBQVE7Z0JBQUUsTUFBTSxFQUFFLHVDQUFLSDtZQUFRO1lBQzdELElBQXNDSixzQkFBQUEsdUJBQUFBLENBQUFBLFlBQWtCLENBQW9CO2dCQUMxRSxRQUFRO1lBQ1YsUUFGS1EsZUFBaUNSLHdCQUFuQlMsa0JBQW1CVDttREFHakNHLGVBQWdCSztZQUVyQlYsWUFBa0IsQ0FDaEJBLFFBQVEsQ0FBQ1gsS0FBSzt1QkFBTTNGLFFBQVEsS0FBSyxDQUFFLGdDQUFrQyxPQUFIdUQ7ZUFBTztnQkFBRSxPQUFPO1lBQUs7WUFFekYrQyxZQUFrQixDQUNoQkEsUUFBUSxDQUFDVCxLQUFLO3VCQUFNN0YsUUFBUSxLQUFLLENBQUUsZ0NBQWtDLE9BQUh1RDtlQUFPO2dCQUFFLE9BQU87WUFBSztZQUV6RitDLFlBQWtCLENBQUM7Z0JBQ2pCLE9BQU9aLE9BQU9BLENBQUNDLE9BQU9wQztZQUN4QjtZQUNBK0MsWUFBa0IsQ0FBQztnQkFDakIsZ0VBQWdFO2dCQUNoRSxnRUFBZ0U7Z0JBQ2hFLG1FQUFtRTtnQkFDbkUsSUFBSWxFLGFBQWEsSUFBSU47Z0JBQ3JCd0UsU0FBZSxDQUFDOzJCQUFNbEUsV0FBVyxLQUFLOztnQkFDdEMrRCxVQUFVQSxDQUFDTixPQUFPdEMsSUFDZixJQUFJLENBQUMsU0FBTzZDOzs7OztvQ0FDWCxJQUFJaEUsV0FBVyxNQUFNLENBQUMsT0FBTyxFQUFFOzs7b0NBQy9COzt3Q0FBTVcsUUFBUSxJQUFJLENBQUNxRCxRQUFROzRDQUFFMUUsY0FBQUE7d0NBQWE7OztvQ0FBMUM7b0NBQ0EsSUFBSVUsV0FBVyxNQUFNLENBQUMsT0FBTyxFQUFFOzs7b0NBQy9CNkUsZ0JBQWdCO3dDQUFFLFFBQVE7d0NBQVMsTUFBTWI7b0NBQU87Ozs7OztvQkFDbEQ7bUJBQ0MsS0FBSyxDQUFDLFNBQUNjO29CQUNOLElBQUk5RSxXQUFXLE1BQU0sQ0FBQyxPQUFPLEVBQUU7b0JBQy9CNkUsZ0JBQWdCO3dCQUFFLFFBQVE7d0JBQVNDLE9BQUFBO29CQUFNO2dCQUMzQztZQUNKO1lBRUEsT0FBT0o7UUFDVDs7eUJBdkRTRDs7WUEwREw1RSxLQUFBQTttQkFBTixTQUFNQSxXQUFXa0YsSUFBbUIsRUFBRTlELE9BQWdDOzsrQkFDaEVwRSxPQUNBMkMsUUFHQW1CLFNBRUFyQixjQUlBUyxNQUNBMkU7Ozt3QkFYQTdILFFBQVFrSSxLQUFLLEtBQUs7d0JBQ2xCdkYsU0FBU1ksWUFBWSxHQUFHOzREQUFFLElBQUksRUFBQ29FOzRCQUFTdkQsUUFBUSxNQUFNOzRCQUFJLGlDQUFpQzt3QkFDL0Z6QixPQUFPLGNBQWM7d0JBQ3JCQSxPQUFPLGdCQUFnQixDQUFDLFNBQVM7bUNBQU1rRjs7d0JBQ25DL0QsVUFBVUUsWUFBWSxDQUFDaEU7d0JBQzNCTSxNQUFNQSxDQUFDd0QsU0FBUzt3QkFDWnJCLGVBQTZCOzRCQUMvQiw4REFBOEQ7NEJBQzlELFFBQVF5QixXQUFXLENBQUMsTUFBTWxFO3dCQUM1Qjt3QkFDSWtELE9BQU80QixVQUFVQSxDQUFDOUUsT0FBTzs0QkFBRTJDLFFBQUFBO3dCQUFPO3dCQUNsQ2tGLFVBQVVSLFVBQWdCLENBQUMsU0FBQ1E7NEJBQzlCUixZQUFrQixDQUFDO2dDQUNqQixxREFBcUQ7Z0NBQ3JEckgsTUFBTSxHQUFHLENBQUMsTUFBTSxNQUFNa0k7Z0NBQ3RCQSxLQUFLLEdBQUcsQ0FBQyxLQUFLO2dDQUNkLElBQUl0RixTQUFTLHVDQUFLOEU7Z0NBQ2xCLElBQUk5RSxPQUFPLE1BQU0sS0FBSyxXQUFXO29DQUMvQjtnQ0FDRjtnQ0FDQSxJQUFJQSxPQUFPLE1BQU0sS0FBSyxTQUFTO29DQUM3QjVCLG1CQUFtQkEsQ0FBQzRCLE9BQU8sS0FBSztvQ0FDaEM7Z0NBQ0Y7Z0NBQ0EsSUFBSU8sYUFBYSxJQUFJTjtnQ0FDckJ3RSxTQUFlLENBQUM7MkNBQU1sRSxXQUFXLEtBQUs7O2dDQUN0Q3RDLFFBQVEsT0FBTyxHQUNaLElBQUksQ0FBQzsyQ0FDSmlELFFBQVEsVUFBVSxDQUFDb0UsTUFBTTt3Q0FDdkIsUUFBUTNFLFlBQVksR0FBRyxDQUFDOzRDQUFDWjs0Q0FBUVEsV0FBVyxNQUFNO3lDQUFDO3dDQUNuRFYsY0FBQUE7d0NBQ0FTLE1BQUFBO29DQUNGO21DQUVELEtBQUssQ0FBQyxTQUFDK0U7MkNBQVVqSCxtQkFBbUJBLENBQUNpSDs7NEJBQzFDOzRCQUNBLE9BQU87dUNBQU1KOzt3QkFDZjs7Ozs7Z0JBQ0Y7Ozs7V0FqR1dEO0lBa0daOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDcEh1QztBQUNEO0FBQ0o7QUFFbkMseUNBQXlDO0FBQ3pDLElBQUlPLFVBQWtCQyxRQUFrQjtBQVl4QyxxQkFBZSxTQUFTLFdBQUM1RixLQUdGO1FBRnJCNkYsaUJBRHVCN0YsTUFDdkI2RixnQkFDQUMsZ0JBRnVCOUYsTUFFdkI4RjtJQUVBLElBQUlDLFdBQVcsSUFBSUM7SUFFbkIsSUFBTUMseUJBQU47O2tCQUFNQTtpQkFBQUE7MENBQUFBO1lBQU4seUJBQU1BOzs0QkFBQUE7O2dCQVNKckIsS0FBQUE7dUJBQUFBLFNBQUFBOztvQkFBV3NCLElBQUFBLElBQUFBLE9BQUFBLFVBQUFBLFFBQUdDLE9BQUhELFVBQUFBLE9BQUFBLE9BQUFBLEdBQUFBLE9BQUFBLE1BQUFBO3dCQUFHQyxLQUFIRCxRQUFBQSxTQUFBQSxDQUFBQSxLQUFzRTs7d0JBQy9FRTtxQkFBQUEsU0FBQUEsdUJBVkVILHFCQVVJLGNBQU5HLElBQUssY0FBTEE7OzZCQUFpQixxQkFBR0Q7b0JBQ3BCLElBQUl4RixhQUFhLElBQUlOO29CQUNyQixJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVc7d0JBQ25CTSxXQUFXLEtBQUssQ0FBQzt3QkFDakJhLGdCQUFnQjt3QkFDaEJ1RSxTQUFTLE1BQU07b0JBQ2pCO29CQUNBQSxTQUFTLEdBQUcsQ0FBQyxJQUFJLEVBQUUsSUFBSVgsZUFBT0EsQ0FBQyxJQUFJLEVBQUU7d0JBQUUsUUFBUXpFLFdBQVcsTUFBTTtvQkFBQztnQkFDbkU7OztnQkFFQTs7Ozs7S0FLQyxHQUNEMEYsS0FBQUE7dUJBQUFBLFNBQUFBLFVBQVVDLEtBQTBCO29CQUNsQywrSEFBK0g7b0JBQy9ILElBQUlDLGNBQWUsSUFBSSxDQUFDLFdBQVcsQ0FBMkIsV0FBVyxJQUFJLENBQUM7d0JBQ3pFQyxrQ0FBQUEsMkJBQUFBOzt3QkFBTCxRQUFLQSxZQUFTM0MsT0FBTyxJQUFJLENBQUN5QywyQkFBckJFLFNBQUFBLDZCQUFBQSxRQUFBQSx5QkFBQUEsaUNBQTZCOzRCQUE3QkEsSUFBSUMsSUFBSkQ7NEJBQ0gsSUFBSTtvQ0FDY0UsZ0JBU0xDO2dDQVRYLElBQUlOLGFBQVlLLGlCQUFBQSxXQUFXLENBQUNELEVBQUUsY0FBZEMscUNBQUFBLGVBQWdCLFNBQVM7Z0NBQ3pDLElBQUlMLFdBQVc7b0NBQ2JDLEtBQUssQ0FBQ0csRUFBRSxHQUFHSixVQUFVQyxLQUFLLENBQUNHLEVBQUUsRUFBRSxJQUFJO2dDQUNyQyxPQUFPLElBQUlBLE1BQU0sWUFBWUEsTUFBTSxTQUFTO29DQUMxQyxpRUFBaUU7b0NBQ2pFSCxLQUFLLENBQUNHLEVBQUUsR0FBR3BFLEtBQUssS0FBSyxDQUFDQSxLQUFLLFNBQVMsQ0FBQ2lFLEtBQUssQ0FBQ0csRUFBRTtnQ0FDL0MsT0FBTztvQ0FDTEgsS0FBSyxDQUFDRyxFQUFFLEdBQUdHLGdCQUFnQk4sS0FBSyxDQUFDRyxFQUFFO2dDQUNyQztnQ0FDQSxJQUFJLFNBQU9FLFdBQUFBLEtBQUssQ0FBQ0YsRUFBRSxjQUFSRSwrQkFBQUEsU0FBVSxNQUFNLE1BQUssWUFBWTtvQ0FDMUNMLEtBQUssQ0FBQ0csRUFBRSxHQUFHSCxLQUFLLENBQUNHLEVBQUUsQ0FBQyxNQUFNO2dDQUM1Qjs0QkFDRixFQUFFLE9BQU9uSSxHQUFHO2dDQUNWQyxRQUFRLEtBQUssQ0FBQyw4Q0FBOENrSTtnQ0FDNUQsTUFBTW5JOzRCQUNSO3dCQUNGOzt3QkFsQktrSTt3QkFBQUE7OztpQ0FBQUEsNkJBQUFBO2dDQUFBQTs7O2dDQUFBQTtzQ0FBQUE7Ozs7b0JBbUJMLE9BQU9GO2dCQUNUOzs7ZUFqRElMO01BQWlCSjtJQUNyQix1QkFESUksVUFDRyxjQUFhO0lBQ3BCLHVCQUZJQSxVQUVHLGdCQUFlO0lBQ3RCLHVCQUhJQSxVQUdHLHdCQUF1Qk47SUFFOUIsdUJBTElNLFVBS0csYUFBWTtJQUNuQix1QkFOSUEsVUFNRyxlQUFjO0lBQ3JCLHVCQVBJQSxVQU9HLHVCQUFzQk47UUE4QzdCbkc7SUFERixJQUFNcUgsd0JBQU47O2tCQUFNQTtpQkFBQUE7MENBQUFBOztvQkFBTixrQkFBTUEscUJBQ0pySCwrQkFBQUEsUUFBQUE7O3VCQUFjLElBQUlhOzs7OzRCQURkd0c7O2dCQUVFN0QsS0FBQUE7dUJBQU4sU0FBTUE7OzRCQUNBOEQ7Ozs7b0NBQUFBLFVBQVVmLFNBQVMsR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLO29DQUNyQ2pJLE1BQU1BLENBQUNnSixTQUFTO29DQUNoQjs7d0NBQU1BLFFBQVEsVUFBVSxDQUFDLElBQUksRUFBRTs0Q0FBRSxRQUFRLG1DQUFJLEVBQUN0SCxhQUFZLE1BQU07d0NBQUM7OztvQ0FBakU7Ozs7OztvQkFDRjs7OztnQkFDQXVILEtBQUFBO3VCQUFBQSxTQUFBQTtvQkFDRSxtQ0FBSSxFQUFDdkgsYUFBWSxLQUFLLENBQUM7b0JBQ3ZCLHVCQVRFcUgsb0JBU0ksVUFBTixJQUFLO2dCQUNQOzs7ZUFWSUE7TUFBZ0JmO0lBYXRCLE9BQU87UUFBRUcsVUFBQUE7UUFBVVksU0FBQUE7SUFBUTtBQUM3Qjs7O0FDekZpQzs7QUFFakM7QUFDQSxrQ0FBa0MsVUFBTTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0h4Qyx3Rjs7Ozs7QUNDQTtBQUNBLDhDQUE4QywrQkFBK0I7QUFDN0U7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaURBQWlEO0FBQ2pEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5QkFBeUI7QUFDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsRUFBRTtBQUNGOzs7Ozs7O0FDcEVBLDRDQUE0QyxnQkFBZ0Isa0NBQWtDO0FBQzlGO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVEQUF1RCxRQUFRO0FBQy9EO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU07QUFDTjtBQUNBO0FBQ0EsTUFBTTtBQUNOO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFlBQVksZ0NBQWdDO0FBQzVDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFFBQVE7QUFDUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrQkFBa0Isa0JBQWtCO0FBQ3BDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQSxrQkFBa0Isa0JBQWtCO0FBQ3BDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0QkFBNEIsUUFBUTtBQUNwQztBQUNBO0FBQ0E7QUFDQSwyQ0FBMkM7QUFDM0M7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUNBQXlDO0FBQ3pDOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLE1BQU07QUFDTjtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxZQUFZLHNCQUFzQjtBQUNsQztBQUNBO0FBQ0EsaUJBQWlCLGtCQUFrQjtBQUNuQyx3QkFBd0IseUJBQXlCO0FBQ2pEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEVBQUU7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxFQUFFO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEVBQUU7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEVBQUU7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDBCQUEwQjtBQUMxQjtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7QUFDQTtBQUNBLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBLDBFQUEwRTtBQUMxRSw2REFBNkQ7QUFDN0QsZ0VBQWdFO0FBQ2hFLDhEQUE4RDtBQUM5RCxnREFBZ0Q7QUFDaEQsbURBQW1EO0FBQ25ELGlEQUFpRDtBQUNqRCxvREFBb0Q7QUFDcEQsb0NBQW9DO0FBQ3BDLHVDQUF1QztBQUN2QyxtQ0FBbUM7QUFDbkMscUJBQXFCO0FBQ3JCO0FBQ0EifQ==