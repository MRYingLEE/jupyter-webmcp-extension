"use strict";
(() => {
  // <define:__CATALOG_BUILDS__>
  var define_CATALOG_BUILDS_default = { "widget-manager": { load: "static/remoteEntry.c8c9eed2cdefdeac.js", extension: "./extension" }, "anywidget-0.11": { load: "./static/remoteEntry.6af7c578.js", extension: "./extension" }, "anywidget-0.10": { load: "./static/remoteEntry.2b990487.js", extension: "./extension" } };

  // runtime/src/channel.ts
  var RUNTIME_CONFIG_KEY = "jupyterWebmcpRuntime";
  var RUNTIME_BASE_ATTRIBUTE = "data-jwe-runtime-base";
  var STATUS_EVENT = "jupyter-webmcp-extension:status";

  // src/shared/config.ts
  var CONFIG_ELEMENT_ID = "jupyter-config-data";
  var RUNTIME_PACKAGE = "@jupyter-webmcp-extension/runtime";
  var RUNTIME_EXTENSION = "./extension";
  var AI_COMMANDS_PACKAGE = "jupyterlab-ai-commands";
  var WEBMCP_PACKAGE = "jupyter-webmcp";
  function parsePageConfig(text) {
    let data;
    try {
      data = JSON.parse(text);
    } catch {
      return null;
    }
    if (!isRecord(data)) {
      return null;
    }
    const { federated_extensions, fullLabextensionsUrl, appName, appVersion } = data;
    if (!Array.isArray(federated_extensions)) {
      return null;
    }
    if (typeof fullLabextensionsUrl !== "string" || !fullLabextensionsUrl) {
      return null;
    }
    if (typeof appName !== "string" && typeof appVersion !== "string") {
      return null;
    }
    return data;
  }
  function federatedEntryUrl(config, name, load) {
    const base = config.fullLabextensionsUrl.replace(/\/+$/, "");
    return `${base}/${name}/${load}`;
  }
  function isExtensionDisabled(config, id) {
    let disabled = config.disabledExtensions;
    if (typeof disabled === "string") {
      try {
        disabled = JSON.parse(disabled);
      } catch {
        return false;
      }
    }
    const name = id.split(":", 1)[0];
    if (Array.isArray(disabled)) {
      return disabled.includes(id) || disabled.includes(name);
    }
    if (isRecord(disabled)) {
      return disabled[id] === true || disabled[name] === true;
    }
    return false;
  }
  function nativeExtensionNames(config) {
    return new Set(
      config.federated_extensions.map((entry) => entry?.name).filter((name) => typeof name === "string")
    );
  }
  function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }

  // scripts/catalog-pins.json
  var catalog_pins_default = {
    entries: [
      {
        id: "widget-manager",
        label: "ipywidgets widget manager",
        role: "dependency",
        federation: "@jupyter-widgets/jupyterlab-manager",
        plugin: "@jupyter-widgets/jupyterlab-manager:plugin",
        provides: "IJupyterWidgetRegistry",
        requires: [],
        source: {
          kind: "pypi",
          package: "jupyterlab_widgets",
          version: "3.0.17",
          sha256: "40ac1e9955acf116c4d995d9bfa082d86ad9ec6d91c4f134827cf5e0a5eb75e0"
        }
      },
      {
        id: "anywidget-0.11",
        label: "anywidget 0.11",
        role: "extension",
        federation: "anywidget_0_11",
        plugin: "anywidget_0_11:plugin",
        line: "0.11",
        selectedByDefault: true,
        kernelRequirement: "anywidget==0.11.*",
        conflicts: ["anywidget"],
        requires: ["widget-manager"],
        source: {
          kind: "git",
          repository: "https://github.com/manzt/anywidget",
          commit: "35160ac08e75918faee008a3b8996ab2a0a16a46"
        }
      },
      {
        id: "anywidget-0.10",
        label: "anywidget 0.10",
        role: "extension",
        federation: "anywidget_0_10",
        plugin: "anywidget_0_10:plugin",
        line: "0.10",
        kernelRequirement: "anywidget==0.10.*",
        conflicts: ["anywidget"],
        requires: ["widget-manager"],
        source: {
          kind: "git",
          repository: "https://github.com/manzt/anywidget",
          commit: "5428c60730f79e52d8ae2f235942b023c0cbc665"
        }
      }
    ]
  };

  // src/shared/catalog.ts
  var CATALOG = catalog_pins_default.entries;
  var CATALOG_EXTENSIONS = CATALOG.filter(
    (entry) => entry.role === "extension"
  );
  var DEFAULT_SELECTION = CATALOG_EXTENSIONS.filter(
    (entry) => entry.selectedByDefault
  ).map((entry) => entry.id);
  var CATALOG_IDS = new Set(
    CATALOG.map((entry) => entry.id)
  );
  function catalogEntry(id) {
    return CATALOG.find((entry) => entry.id === id);
  }

  // src/shared/decision.ts
  function decideInjection(config, selected = /* @__PURE__ */ new Set()) {
    const native = nativeExtensionNames(config);
    return {
      ai: componentState(config, native, AI_COMMANDS_PACKAGE),
      webmcp: componentState(config, native, WEBMCP_PACKAGE),
      catalog: decideCatalog(config, selected)
    };
  }
  function decideCatalog(config, selected) {
    const native = nativeExtensionNames(config);
    const states = {};
    const candidates = [];
    for (const entry of CATALOG) {
      if (entry.role !== "extension") {
        continue;
      }
      if (!selected.has(entry.id)) {
        states[entry.id] = "unselected";
      } else if (isExtensionDisabled(config, entry.plugin)) {
        states[entry.id] = "disabled";
      } else if (native.has(entry.federation)) {
        states[entry.id] = "native";
      } else if (entry.conflicts?.some((name) => native.has(name))) {
        states[entry.id] = "conflict";
      } else {
        candidates.push(entry);
        states[entry.id] = "injected";
      }
    }
    const needed = new Set(candidates.flatMap((entry) => entry.requires));
    for (const entry of CATALOG) {
      if (entry.role !== "dependency") {
        continue;
      }
      if (isExtensionDisabled(config, entry.plugin)) {
        states[entry.id] = "disabled";
      } else if (native.has(entry.federation)) {
        states[entry.id] = "native";
      } else {
        states[entry.id] = needed.has(entry.id) ? "injected" : "unselected";
      }
    }
    for (const entry of candidates) {
      const blocked = entry.requires.some((id) => states[id] === "disabled");
      if (blocked) {
        states[entry.id] = "unsupported";
      }
    }
    return states;
  }
  function needsRuntime(decision) {
    return decision.ai === "injected" || decision.webmcp === "injected" || Object.values(decision.catalog).includes("injected");
  }
  function injectedEntries(decision, runtimeLoad, builds) {
    if (!needsRuntime(decision)) {
      return [];
    }
    const runtime = {
      component: "runtime",
      name: RUNTIME_PACKAGE,
      load: runtimeLoad,
      extension: RUNTIME_EXTENSION,
      path: runtimeLoad
    };
    const catalog = [];
    for (const entry of CATALOG) {
      const build = builds[entry.id];
      if (decision.catalog[entry.id] !== "injected" || !build) {
        continue;
      }
      catalog.push({
        component: entry.id,
        name: entry.federation,
        load: build.load,
        extension: build.extension,
        path: `catalog/${entry.id}/${build.load}`
      });
    }
    return [runtime, ...catalog];
  }
  function injectRuntime(config, decision, runtimeLoad, builds) {
    const entries = injectedEntries(decision, runtimeLoad, builds);
    if (entries.length === 0) {
      return config;
    }
    const listed = config.federated_extensions.some(
      (entry) => entry?.name === RUNTIME_PACKAGE
    );
    if (listed) {
      return config;
    }
    const catalog = entries.filter((entry) => entry.component !== "runtime").map((entry) => ({
      id: entry.component,
      plugin: catalogEntry(entry.component)?.plugin ?? ""
    })).filter((flag) => flag.plugin !== "");
    return {
      ...config,
      federated_extensions: [
        ...config.federated_extensions,
        ...entries.map(({ name, load, extension }) => ({
          name,
          load,
          extension
        }))
      ],
      [RUNTIME_CONFIG_KEY]: {
        ai: decision.ai === "injected",
        webmcp: decision.webmcp === "injected",
        catalog
      }
    };
  }
  function componentState(config, native, name) {
    if (isExtensionDisabled(config, `${name}:plugin`)) {
      return "disabled";
    }
    return native.has(name) ? "native" : "injected";
  }

  // src/shared/frame-policy.ts
  function allowsTools(doc) {
    try {
      return doc.featurePolicy.allowsFeature("tools");
    } catch {
      return false;
    }
  }
  function mayInjectRuntime(input) {
    return input.isTop || input.allowsTools;
  }

  // src/shared/selection.ts
  var SELECTION_KEY = "jupyter-webmcp-extension:catalog-selection";
  function selectionFor(raw, baseUrl) {
    const fallback = new Set(DEFAULT_SELECTION);
    if (raw === null || baseUrl === void 0) {
      return fallback;
    }
    let data;
    try {
      data = JSON.parse(raw);
    } catch {
      return fallback;
    }
    if (!isRecord(data) || data.baseUrl !== baseUrl || !Array.isArray(data.ids)) {
      return fallback;
    }
    return new Set(
      data.ids.filter((id) => typeof id === "string")
    );
  }

  // src/content/bootstrap-main.ts
  function installPageHook(target, load, builds) {
    const state = { entries: [] };
    const doc = target.document;
    const views = target;
    const env = {
      target,
      load,
      builds,
      toolsAllowed: mayInjectRuntime({
        isTop: target.top === target,
        allowsTools: allowsTools(doc)
      }),
      report: (component, detail) => reportFailure(doc, component, detail)
    };
    target.addEventListener(
      "error",
      (event) => {
        const element = event.target;
        if (!(element instanceof views.HTMLScriptElement)) {
          return;
        }
        const entry = state.entries.find(
          (candidate) => candidate.requested === element.src
        );
        if (!entry) {
          return;
        }
        env.report(
          entry.component,
          entry.granted ? "Script failed to load." : "Not enabled for this frame."
        );
      },
      true
    );
    const scriptProto = views.HTMLScriptElement.prototype;
    const textDesc = Object.getOwnPropertyDescriptor(scriptProto, "textContent") ?? Object.getOwnPropertyDescriptor(views.Node.prototype, "textContent");
    if (!textDesc?.get) {
      return;
    }
    const originalGet = textDesc.get;
    Object.defineProperty(scriptProto, "textContent", {
      ...textDesc,
      get() {
        const text = originalGet.call(this);
        if (text === null || !(this instanceof views.HTMLScriptElement) || this.id !== CONFIG_ELEMENT_ID) {
          return text;
        }
        return rewriteConfigText(text, env, state);
      }
    });
    const srcDesc = Object.getOwnPropertyDescriptor(views.HTMLScriptElement.prototype, "src");
    if (srcDesc?.set) {
      const originalSet = srcDesc.set;
      Object.defineProperty(views.HTMLScriptElement.prototype, "src", {
        ...srcDesc,
        set(value) {
          originalSet.call(this, mapScriptUrl(String(value), doc, state));
        }
      });
    }
    const originalSetAttribute = views.Element.prototype.setAttribute;
    views.Element.prototype.setAttribute = function(name, value) {
      if (this instanceof views.HTMLScriptElement && name.toLowerCase() === "src") {
        value = mapScriptUrl(String(value), doc, state);
      }
      originalSetAttribute.call(this, name, value);
    };
  }
  function rewriteConfigText(text, env, state) {
    const raw = readSelection(env.target);
    if (state.lastText === text && state.lastSelection === raw && state.lastResult !== void 0) {
      return state.lastResult;
    }
    let result = text;
    state.entries = [];
    const config = parsePageConfig(text);
    if (config) {
      const selected = selectionFor(raw, config.baseUrl);
      const decision = decideInjection(config, selected);
      if (needsRuntime(decision)) {
        if (env.toolsAllowed) {
          const injected = injectRuntime(config, decision, env.load, env.builds);
          result = JSON.stringify(injected);
          state.entries = injectedEntries(decision, env.load, env.builds).map(
            (entry) => ({
              component: entry.component,
              url: federatedEntryUrl(config, entry.name, entry.load),
              path: entry.path
            })
          );
        } else {
          env.report("runtime", "The embedding frame does not allow the tools permission.");
        }
      }
    }
    state.lastText = text;
    state.lastSelection = raw;
    state.lastResult = result;
    return result;
  }
  function readSelection(target) {
    try {
      return target.sessionStorage.getItem(SELECTION_KEY);
    } catch {
      return null;
    }
  }
  function mapScriptUrl(value, doc, state) {
    const resolved = new URL(value, doc.baseURI).href;
    const entry = state.entries.find(
      (candidate) => new URL(candidate.url, doc.baseURI).href === resolved
    );
    if (!entry) {
      return value;
    }
    const base = doc.documentElement?.getAttribute(RUNTIME_BASE_ATTRIBUTE);
    entry.granted = Boolean(base);
    const mapped = base ? `${base}${entry.path}` : value;
    entry.requested = new URL(mapped, doc.baseURI).href;
    return mapped;
  }
  function reportFailure(doc, component, detail) {
    doc.dispatchEvent(
      new CustomEvent(STATUS_EVENT, {
        detail: JSON.stringify({ component, state: "failed", detail })
      })
    );
  }

  // src/content/main.ts
  installPageHook(window, "static/remoteEntry.7de493cb56aa3d0e.js", define_CATALOG_BUILDS_default);
})();
//# sourceMappingURL=content-main.js.map
