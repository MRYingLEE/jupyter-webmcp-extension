"use strict";
(() => {
  // runtime/src/channel.ts
  var RUNTIME_CONFIG_KEY = "jupyterWebmcpRuntime";
  var RUNTIME_BASE_ATTRIBUTE = "data-jwe-runtime-base";
  var STATUS_EVENT = "jupyter-webmcp-extension:status";

  // src/shared/config.ts
  var CONFIG_ELEMENT_ID = "jupyter-config-data";
  var RUNTIME_PACKAGE = "@jupyter-webmcp-extension/runtime";
  var RUNTIME_EXTENSION = "./extension";
  var AI_COMMANDS_PACKAGE = "jupyterlab-ai-commands";
  var WEBMCP_PACKAGE = "jupyter-webmcp";
  function parsePageConfig(text) {
    let data;
    try {
      data = JSON.parse(text);
    } catch {
      return null;
    }
    if (!isRecord(data)) {
      return null;
    }
    const { federated_extensions, fullLabextensionsUrl, appName, appVersion } = data;
    if (!Array.isArray(federated_extensions)) {
      return null;
    }
    if (typeof fullLabextensionsUrl !== "string" || !fullLabextensionsUrl) {
      return null;
    }
    if (typeof appName !== "string" && typeof appVersion !== "string") {
      return null;
    }
    return data;
  }
  function federatedEntryUrl(config, name, load) {
    const base = config.fullLabextensionsUrl.replace(/\/+$/, "");
    return `${base}/${name}/${load}`;
  }
  function isExtensionDisabled(config, id) {
    let disabled = config.disabledExtensions;
    if (typeof disabled === "string") {
      try {
        disabled = JSON.parse(disabled);
      } catch {
        return false;
      }
    }
    const name = id.split(":", 1)[0];
    if (Array.isArray(disabled)) {
      return disabled.includes(id) || disabled.includes(name);
    }
    if (isRecord(disabled)) {
      return disabled[id] === true || disabled[name] === true;
    }
    return false;
  }
  function nativeExtensionNames(config) {
    return new Set(
      config.federated_extensions.map((entry) => entry?.name).filter((name) => typeof name === "string")
    );
  }
  function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }

  // src/shared/decision.ts
  function decideInjection(config) {
    const native = nativeExtensionNames(config);
    return {
      ai: componentState(config, native, AI_COMMANDS_PACKAGE),
      webmcp: componentState(config, native, WEBMCP_PACKAGE)
    };
  }
  function needsRuntime(decision) {
    return decision.ai === "injected" || decision.webmcp === "injected";
  }
  function injectRuntime(config, decision, load) {
    if (!needsRuntime(decision)) {
      return config;
    }
    const listed = config.federated_extensions.some(
      (entry) => entry?.name === RUNTIME_PACKAGE
    );
    if (listed) {
      return config;
    }
    return {
      ...config,
      federated_extensions: [
        ...config.federated_extensions,
        { name: RUNTIME_PACKAGE, load, extension: RUNTIME_EXTENSION }
      ],
      [RUNTIME_CONFIG_KEY]: {
        ai: decision.ai === "injected",
        webmcp: decision.webmcp === "injected"
      }
    };
  }
  function componentState(config, native, name) {
    if (isExtensionDisabled(config, `${name}:plugin`)) {
      return "disabled";
    }
    return native.has(name) ? "native" : "injected";
  }

  // src/shared/frame-policy.ts
  function allowsTools(doc) {
    try {
      return doc.featurePolicy.allowsFeature("tools");
    } catch {
      return false;
    }
  }
  function mayInjectRuntime(input) {
    return input.isTop || input.allowsTools;
  }

  // src/content/bootstrap-main.ts
  function installPageHook(target, load) {
    const state = {};
    const doc = target.document;
    const views = target;
    const env = {
      load,
      toolsAllowed: mayInjectRuntime({
        isTop: target.top === target,
        allowsTools: allowsTools(doc)
      }),
      report: (detail) => reportRuntimeFailure(doc, detail)
    };
    target.addEventListener(
      "error",
      (event) => {
        const element = event.target;
        if (!(element instanceof views.HTMLScriptElement) || state.requestedSrc === void 0 || element.src !== state.requestedSrc) {
          return;
        }
        env.report(
          state.granted ? "Runtime script failed to load." : "Runtime is not enabled for this frame."
        );
      },
      true
    );
    const scriptProto = views.HTMLScriptElement.prototype;
    const textDesc = Object.getOwnPropertyDescriptor(scriptProto, "textContent") ?? Object.getOwnPropertyDescriptor(views.Node.prototype, "textContent");
    if (!textDesc?.get) {
      return;
    }
    const originalGet = textDesc.get;
    Object.defineProperty(scriptProto, "textContent", {
      ...textDesc,
      get() {
        const text = originalGet.call(this);
        if (text === null || !(this instanceof views.HTMLScriptElement) || this.id !== CONFIG_ELEMENT_ID) {
          return text;
        }
        return rewriteConfigText(text, env, state);
      }
    });
    const srcDesc = Object.getOwnPropertyDescriptor(views.HTMLScriptElement.prototype, "src");
    if (srcDesc?.set) {
      const originalSet = srcDesc.set;
      Object.defineProperty(views.HTMLScriptElement.prototype, "src", {
        ...srcDesc,
        set(value) {
          originalSet.call(this, mapScriptUrl(String(value), doc, state));
        }
      });
    }
    const originalSetAttribute = views.Element.prototype.setAttribute;
    views.Element.prototype.setAttribute = function(name, value) {
      if (this instanceof views.HTMLScriptElement && name.toLowerCase() === "src") {
        value = mapScriptUrl(String(value), doc, state);
      }
      originalSetAttribute.call(this, name, value);
    };
  }
  function rewriteConfigText(text, env, state) {
    if (state.lastText === text && state.lastResult !== void 0) {
      return state.lastResult;
    }
    let result = text;
    const config = parsePageConfig(text);
    if (config) {
      const decision = decideInjection(config);
      if (needsRuntime(decision)) {
        if (env.toolsAllowed) {
          const injected = injectRuntime(config, decision, env.load);
          result = JSON.stringify(injected);
          state.entryUrl = federatedEntryUrl(config, RUNTIME_PACKAGE, env.load);
          state.entryLoad = env.load;
        } else {
          env.report("The embedding frame does not allow the tools permission.");
        }
      }
    }
    state.lastText = text;
    state.lastResult = result;
    return result;
  }
  function mapScriptUrl(value, doc, state) {
    if (!state.entryUrl) {
      return value;
    }
    const resolved = new URL(value, doc.baseURI).href;
    const entry = new URL(state.entryUrl, doc.baseURI).href;
    if (resolved !== entry) {
      return value;
    }
    const base = doc.documentElement?.getAttribute(RUNTIME_BASE_ATTRIBUTE);
    state.granted = Boolean(base);
    const mapped = base ? `${base}${state.entryLoad}` : value;
    state.requestedSrc = new URL(mapped, doc.baseURI).href;
    return mapped;
  }
  function reportRuntimeFailure(doc, detail) {
    doc.dispatchEvent(
      new CustomEvent(STATUS_EVENT, {
        detail: JSON.stringify({ component: "runtime", state: "failed", detail })
      })
    );
  }

  // src/content/main.ts
  installPageHook(window, "static/remoteEntry.01bc4ee6f511ba46.js");
})();
//# sourceMappingURL=content-main.js.map
